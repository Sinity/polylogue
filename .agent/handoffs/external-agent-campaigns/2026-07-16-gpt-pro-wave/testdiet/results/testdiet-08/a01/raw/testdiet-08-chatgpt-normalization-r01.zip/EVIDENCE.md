# Evidence and design record

## Snapshot authority

The supplied project-state archive contains a Git bundle, a current-working-tree export, manifest/audit material, Beads export, history, source, and tests. The authoritative identity is:

```text
master
b9052e09103502017c0f510ecc699aac395de23c
2026-07-17T08:28:35+02:00
fix(daemon): bound raw maintenance admission (#2975)
```

`origin/master`, local `master`, and the checked-out commit all resolve to that object. The archive manifest reports `dirty=true`, but its branch delta uses the same commit as merge base and its patch, changed-file list, and branch-only log are zero bytes. This is an internal snapshot-metadata contradiction, not evidence of a branch patch. `PATCH.diff` therefore targets the named commit directly.

## Repository constraints found

`CLAUDE.md`, `.agent/CONVENTIONS.md`, and `TESTING.md` require current source and typed substrate contracts to win over stale plans, favor production routes over invented seams, preserve existing tests, and report verification honestly. The implementation follows those constraints: one parser route, existing typed models, no storage schema migration, no test deletion, and no browser campaign protocol.

The supplied Testsuite Diet adds three relevant proof obligations:

- Source normalization should prove that the tightest detector wins ambiguous shapes and that wire artifacts become independently asserted normalized facts.
- Bead-derived law L21 calls for real-wire witnesses, detector-order ambiguity, structural/asset-only survival, and representative mutations.
- Law L22 calls for authoredness, commands/outcomes, attachments, origin, event order, and temporal preservation; a role-only classifier is a named mutation.
- The proof-form audit says not to infer isolation from a `tests/unit` path, not to judge strength by mock counts, and not to delete explicit compatibility witnesses without coverage-context and mutation dominance.

Those findings drove the use of real dispatch and real SQLite archive routes despite the test file living under `tests/unit/sources`.

## Production-route findings

### Detector and lowering order

`polylogue/sources/dispatch.py` checks `browser_capture.looks_like(record)` before `chatgpt.looks_like(record)` in `_detect_provider_from_record`. `_lower_payload_specs` also gives browser-capture envelopes their own lowering mode, and `_parse_lowered_spec` sends that mode to `browser_capture.parse`. ChatGPT mapping detection is intentionally weak: `chatgpt.looks_like` accepts a mapping object. Therefore an envelope that also contains a top-level mapping is a meaningful detector-order ambiguity witness.

### ChatGPT parser

The current parser already contained substantial lifecycle support from PR #2944:

- generation grouping by the first assistant-side branch below the nearest user ancestor;
- native `reasoning_start_time`, `reasoning_end_time`, and `finished_duration_sec` parsing;
- exact finished-duration precedence over a derived start/end delta;
- one `generation_lifecycle` event per selected branch;
- explicit `provider_reported_elapsed` semantics.

The remaining production gaps were visible in composition:

- `extract_messages_from_mapping` read `model_slug` and legacy duration spellings but did not project the current `thinking_effort` field into the existing `model_effort` contract.
- Repeated native metadata could coexist with equal `durationMs` / `duration_ms` values on several emitted messages. Selecting one native owner did not clear the legacy projections on other rows, so the session sum could double count one provider-reported duration.
- `_extract_generation_timings` can observe metadata rows that `extract_messages_from_mapping` omits for lacking material content. If such a row won timing selection, the event pointed at a non-emitted message and no normalized message received the duration.
- Treating mere native-key presence as evidence would allow malformed values such as `"pending"` to promote a legacy message duration into a lifecycle event.

The patch addresses those gaps without changing the public models or event semantics.

### Browser capture

`polylogue/sources/parsers/browser_capture.py` already treats a native provider payload as authoritative. For ChatGPT it delegates to `chatgpt.parse`, attaches native-capture flags, merges envelope/acquired attachments, and separately retains lower-fidelity DOM lifecycle observations. This supports the mission's requirement not to make browser capture a separate campaign protocol.

### Storage authority and replacement

`ArchiveStore.write_raw_and_parsed_result` records raw material and parsed sessions, while `browser_capture_precedence` uses native and DOM-fallback ingest flags to decide replacement. The messages table already stores `model_effort`, `duration_ms`, active-path/variant state, status, and end-turn. The sessions table stores `reported_duration_ms` and the retained `raw_id`. No schema change was required.

The archive session envelope intentionally exposes a compact subset of message columns. The new storage survivor therefore combines `ArchiveStore.read_session` for transcript identity with a direct read-only query against the production `index.db` messages/sessions tables for model effort and nullable duration, plus `raw_revision_material` for source-tier raw fidelity.

## Provider wire evidence

Aggregate key counts from five supplied `.agent/handoffs/**/*.messages.json` snapshots were inspected without copying private values or conversation text:

| Key | Occurrences | Files |
| --- | ---: | ---: |
| `reasoning_start_time` | 1,620 | 5 |
| `reasoning_end_time` | 16 | 5 |
| `finished_duration_sec` | 32 | 5 |
| `thinking_effort` | 1,037 | 5 |
| `durationMs` | 0 | 0 |
| `duration_ms` | 0 | 0 |

The observed path is message metadata, for example `messages.<n>.metadata.thinking_effort`. This directly supports adding `thinking_effort` projection. The absence of legacy keys in the current snapshots means the legacy duplicate cases are compatibility/adversarial witnesses, not distribution claims.

The privacy-safe fixture uses `reasoning_start_time=1784164541.690012`, `reasoning_end_time=1784169732.588194`, and `finished_duration_sec=5190`. The start/end delta is approximately 5,190.898 seconds, while the provider's finished duration is 5,190 seconds. The existing Bead and parser contract designate the finished field as authoritative. The patch therefore normalizes exactly 5,190,000 ms while preserving all raw fields and the start/end event bounds. It does not relabel either value as model compute time.

## Bead evidence

Closed Bead `polylogue-3v1.2`, “Capture and normalize ChatGPT generation lifecycle timing,” states the intended contract:

- native ChatGPT metadata is authoritative;
- duplicated tree-node metadata becomes one logical duration;
- finished duration precedes valid start/end fallback;
- malformed/negative values do not create a lifecycle duration;
- browser observations remain lower-fidelity and semantically distinct;
- real parser/extension routes must be exercised;
- capture remains automatic and provider-specific campaign state is forbidden.

Its completion note points to master commit `b054f2ba95725c0b1e57b7c13b5898a5b359d049` and broad verification at merge time. That history explains why the supplied current parser already recognizes the native lifecycle keys even though the older problem statement embedded in the Bead says it only recognized legacy duration fields. Current source supersedes that stale clause. This package does not reimplement the closed feature; it adds survivors and repairs the uncovered effort/dedup/owner-composition behavior.

## Relevant history

- `b054f2ba95725c0b1e57b7c13b5898a5b359d049` — `feat(browser): preserve ChatGPT generation lifecycle evidence (#2944)`
- `8db8d60b34565f23ced411b786b252b6a4473b00` — `feat(capture): acquire assistant-produced file bytes at capture time (#2669)`
- `eeb05beff81a55f5698e1cce5f03bc0771e3c0a4` — `feat(chatgpt): record assistant sandbox file links as unfetchable attachments (#2666)`
- `607d79bddcff4f95eb046f0f80857d2ca656a515` — `fix(parsers): keep asset-only chat turns`
- `7688d103d5393e9bc3d6b249bcd6daa656eee58a` — `fix: parse ChatGPT recipient-addressed tool calls as TOOL_USE, not raw text (#2629)`
- `9f54f7faf6e06d4da95e387f69588629fbb90056` — `fix(chatgpt): strip inline citation markers; keep injected context messages (#2668)`
- `2d63feacb02dd098e738b8594b650681c9ef3f03` — `fix(parser): traverse ChatGPT message graph and extract non-parts content (#1744)`

These commits establish that graph identity, structural blocks, context, sandbox links, acquired assets, and lifecycle evidence are one composed production route. The new fixture deliberately exercises them together rather than adding disconnected unit scaffolding.

## Fixture provenance and privacy

Both fixture files are newly authored, privacy-safe wire witnesses. Their structure is based on field names and relationships observed in supplied snapshots and current source/history, but their identifiers, timestamps, text, URLs, attachment names, bytes, and graph are synthetic. They contain no email address, secret, private conversation prose, operator home path, or copied project-state archive.

The browser fixture embeds the native fixture shape and adds synthetic DOM fallback turns plus base64 for `b"PK\\x03\\x04privacy-safe-fixture"`. The raw payload is intentionally richer than the DOM representation so fidelity precedence has an observable semantic consequence.

## Contradictions and resolutions

1. **Manifest dirty flag versus empty branch delta.** Resolution: name the contradiction, use the exact commit/merge base as authority, and generate a clean patch against it.
2. **Older Bead problem text versus current parser.** Resolution: current source and completion history win; implement remaining defects and survivor coverage rather than duplicating already-landed native mapping.
3. **Current sample has no legacy duration keys.** Resolution: identify legacy fields as explicit historical/compatibility adversarial witnesses, not current prevalence.
4. **Finished duration differs from start/end delta.** Resolution: honor the provider-finished field as exact authority, retain raw/bounds, and label semantics as provider reported.
5. **Parsed raw fidelity versus typed projection.** Resolution: normalized facts live in typed message/event columns; untouched provider fields remain in source-tier raw material. No new generic metadata bag is invented.
6. **Unit-path test versus production proof.** Resolution: execute dispatch and real archive write/read paths; use shims only for unavailable optional dependencies and disclose them.

## Evidence that would falsify the design

The design should be revisited if a current native ChatGPT wire sample shows that `durationMs` / `duration_ms` represents a distinct per-node phase even when equal to `finished_duration_sec`, rather than a duplicate projection; if `thinking_effort` is not message metadata; if timing copies cross the branch key used by the parser; or if native browser captures are no longer authoritative over DOM fallback in the product contract. No such evidence was found in the supplied snapshot.

## Deletions

None. The package does not remove existing examples, helpers, schemas, or generated surfaces. Any later consolidation must demonstrate overlap and mutation dominance independently.
