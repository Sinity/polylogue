# ChatGPT capture and export normalization survivors — handoff

Revision: `testdiet-08-chatgpt-normalization-r01`

## Mission and delivered outcome

This package hardens the existing ChatGPT normalization route rather than adding a second protocol. It adds privacy-safe native-export and native-browser-capture wire fixtures, exercises the actual detector/lowering/parser dispatch, and closes two production gaps found in the supplied snapshot:

1. ChatGPT's current `thinking_effort` metadata was retained only in raw material and was not projected into `ParsedMessage.model_effort`.
2. Provider-reported lifecycle duration could be repeated as legacy `durationMs` / `duration_ms` values on related tree nodes. The lifecycle selector projected one native duration, but the legacy message projections remained and could inflate `reported_duration_ms`. A selected lifecycle owner could also be a provider metadata-only node that the message extractor intentionally omits, causing the normalized duration to disappear from emitted messages.

The implementation now selects one lifecycle duration per assistant generation branch, gives `finished_duration_sec` precedence over a valid start/end delta and then a legacy duration paired with valid native evidence, clears only equal duplicate legacy projections, preserves distinct message-local durations, and rehomes an unmaterialized timing owner to the last emitted related branch message. It projects current model-effort metadata and retains the provider-reported timing semantics without labeling the value as model-compute time.

The browser-capture path remains a transport envelope. Native ChatGPT payloads delegate to the same ChatGPT parser, acquired assistant asset bytes merge into the normalized attachment, and archive replacement uses the existing native-versus-DOM fidelity flags and precedence mechanism.

## Snapshot identity

The code authority is the supplied Polylogue project-state snapshot:

- branch: `master`
- commit: `b9052e09103502017c0f510ecc699aac395de23c`
- commit date: `2026-07-17T08:28:35+02:00`
- subject: `fix(daemon): bound raw maintenance admission (#2975)`
- remote default: `origin/master` at the same commit
- patch base: exactly the commit above

The snapshot manifest generated at `2026-07-17T105328Z` labels the source tree `dirty=true`. Its own branch-delta summary names the same commit as the merge base, while `polylogue-branch-delta.patch`, `polylogue-branch-delta-files.txt`, and `polylogue-branch-delta-log.txt` are all zero bytes. The supplied bundle checkout and tracked working-tree export therefore provide no branch patch to preserve. I treated the named commit as the authoritative base and generated `PATCH.diff` against it.

## Evidence inspected

Repository operating instructions and test guidance:

- `CLAUDE.md`
- `.agent/CONVENTIONS.md`
- `TESTING.md`
- the supplied Testsuite Diet source-normalization packet, Bead-derived laws L21/L22, and proof-form audit

Production route and dependencies:

- `polylogue/sources/dispatch.py`: `_detect_provider_from_record`, `detect_provider`, `_lower_payload_specs`, `_parse_lowered_spec`, and `parse_payload`
- `polylogue/sources/parsers/chatgpt.py`: detector, graph traversal, message/block/attachment normalization, lifecycle timing selection, and session construction
- `polylogue/sources/parsers/browser_capture.py`: envelope detection, native provider delegation, DOM fallback, lifecycle observations, and acquired-attachment merge
- `polylogue/sources/parsers/base_models.py`: typed message/session/event contracts, including `model_effort`
- `polylogue/archive/ingest_flags.py`: native-browser and DOM-fallback fidelity flags
- `polylogue/storage/sqlite/archive_tiers/ingest_precedence.py`: native/fallback replacement decision
- `polylogue/storage/sqlite/archive_tiers/archive.py`: raw-plus-parsed write route and retained raw link
- `polylogue/storage/sqlite/archive_tiers/write.py` and `index.py`: persistence of model effort, duration, messages, events, attachments, and session totals

Existing tests inspected for compatibility and current behavior:

- `tests/unit/sources/test_parsers_chatgpt.py`
- `tests/unit/sources/test_browser_capture.py`
- `tests/unit/storage/test_archive_tiers_archive.py`
- adjacent dispatch, parser-contract, and source-law tests

Beads and history:

- closed issue `polylogue-3v1.2`, “Capture and normalize ChatGPT generation lifecycle timing”
- `b054f2ba95725c0b1e57b7c13b5898a5b359d049` — native and live lifecycle evidence
- `8db8d60b34565f23ced411b786b252b6a4473b00` — acquired assistant-produced file bytes
- `eeb05beff81a55f5698e1cce5f03bc0771e3c0a4` — sandbox file links
- `607d79bddcff4f95eb046f0f80857d2ca656a515` — asset-only turns
- `7688d103d5393e9bc3d6b249bcd6daa656eee58a` — ChatGPT tool-use blocks
- `9f54f7faf6e06d4da95e387f69588629fbb90056` — citations and injected context
- `2d63feacb02dd098e738b8594b650681c9ef3f03` — graph traversal and non-parts content

Aggregate inspection of five supplied privacy-sensitive handoff message snapshots found the current native spellings without copying their content into this package: 1,620 `reasoning_start_time` occurrences, 16 `reasoning_end_time`, 32 `finished_duration_sec`, and 1,037 `thinking_effort`. Those snapshots contained no `durationMs` or `duration_ms`; the legacy spellings in the new fixture are explicit compatibility witnesses rather than claims about the current sample distribution.

## Mechanism

### Lifecycle duration authority and deduplication

`_extract_generation_timings` now limits lifecycle candidates to assistant/tool rows. Human and system duration metadata remains message-local evidence. Candidate rows are grouped by the existing generation-branch key so repeated metadata on thought, tool, recap, and final-answer nodes describes one logical generation.

Within a branch, source authority is:

1. valid non-negative finite `finished_duration_sec` (`exact`);
2. valid non-negative `reasoning_start_time` / `reasoning_end_time` delta (`derived`);
3. valid legacy `durationMs` / `duration_ms` only when the row also carries at least one valid native lifecycle value (`exact`).

Within the same source rank, the existing semantic preferences remain: reasoning recap, complete bounds, end-turn, then provider order. The selected timing records all related provider message IDs and only the legacy duration IDs whose value exactly equals the selected lifecycle duration. During parse, the selected owner receives the lifecycle duration, equal legacy duplicates are cleared, and distinct message-local durations remain untouched.

If the selected provider timing row has no emitted normalized message—such as a metadata-only assistant node with empty content—`parse` rehomes the timing and event source to the last emitted message from the same branch. This prevents duration loss without fabricating an extra message.

A malformed native key does not confer lifecycle meaning on an otherwise legacy-only duration. A bare legacy field retains the previous message-duration contract and does not synthesize a generation event.

### Model effort

ChatGPT message metadata now projects `thinking_effort`, followed by the narrow compatibility aliases `reasoning_effort`, `model_effort`, and `modelEffort`, into `ParsedMessage.model_effort`. The fixture and survivor assert the actual current `thinking_effort` spelling and prove that standard/extended values survive parsing and SQLite persistence.

### Browser capture and assets

The browser fixture contains deliberately poorer and longer DOM turns plus an embedded native ChatGPT payload. Dispatch must select the browser-capture envelope before the weak ChatGPT mapping shape. `browser_capture.parse` delegates the native payload to `chatgpt.parse`, adds the existing native fidelity flag, and merges acquired bytes into the assistant sandbox attachment without producing a duplicate attachment.

The storage survivor writes native and DOM variants in both arrival orders through `ArchiveStore.write_raw_and_parsed_result`. It then submits a still-newer and longer DOM fallback. The retained session remains the native eight-message version, the fallback write reports a skipped session, the session raw link remains attached to the native raw revision, normalized effort/duration rows remain in SQLite, and all provider timing/effort spellings remain in retained raw bytes.

## Decisions

- No new API, schema, campaign state, browser-specific ChatGPT protocol, or parallel parser framework was added.
- Structured provider fields are authoritative; no timing, role, active-branch, effort, or asset facts are inferred from prose or UI labels.
- `finished_duration_sec` remains authoritative even when its integer provider report differs slightly from the start/end wall delta. Both raw values remain durable; the semantic event explicitly says `provider_reported_elapsed`.
- Raw provider fields stay in the source-tier raw revision. They were not copied into a new parsed metadata bag because the current typed contracts and archive architecture already preserve raw authority separately.
- Existing tests and helpers were retained. No dominated deletion is proposed in this revision; deletion would require independent local certification under the Testsuite Diet rules.
- The native fixture is privacy-safe and hand-authored from observed wire shape. It contains no copied private conversation content, user identifiers, home paths, secrets, or external assets.

## Changed files

`polylogue/sources/parsers/chatgpt.py`

- projects current ChatGPT model effort;
- selects timing by source authority;
- tracks branch-related rows and equal legacy duplicates;
- prevents lifecycle creation from malformed native key presence alone;
- rehomes timing owners that are not emitted;
- removes only duplicate duration projections.

`tests/fixtures/chatgpt/native-conversation-v1.json`

- native graph fixture with active/inactive variants, runtime context, user and assistant material, reasoning/tool blocks, user upload, assistant sandbox asset, timestamps, current and legacy timing fields, effort, status, and end-turn.

`tests/fixtures/chatgpt/native-browser-capture-v1.json`

- native browser-capture envelope with deliberately inferior DOM fallback, embedded native payload, lifecycle fidelity metadata, and acquired assistant asset bytes.

`tests/unit/sources/test_chatgpt_normalization_survivors.py`

- eight test functions / nine pytest cases covering the actual dispatch/parser route and actual archive write/read route, with explicit anti-vacuity mutations in names or docstrings.

## Acceptance matrix

| Requirement | Delivered proof |
| --- | --- |
| Tight detector selection | Ambiguous envelope contains a decoy ChatGPT mapping; monkeypatch fails if the weaker detector runs before browser capture. |
| Actual detect/lower/parse route | Native and browser fixtures use `detect_provider` and `parse_payload`; no direct private-parser oracle derives expected facts. |
| Active path and variant identity | Both regenerated branches survive; inactive/active flags, variant indexes, active leaf, and parent identity are asserted. |
| Role and material origin | Runtime context, human-authored, assistant-authored, and tool-result origins are asserted independently of role-only classification. |
| Content blocks including reasoning | Text, image, thinking, tool-use, and tool-result blocks and their structured fields are asserted. |
| Attachments and assistant assets | OAuth user upload, sandbox attachment, acquired ZIP bytes, MIME, size, origin, source URL, and no duplicate are asserted. |
| Timestamps and durations | Session/message timestamps, exact provider duration, lifecycle bounds, one-duration total, distinct legacy preservation, malformed handling, and owner rehoming are asserted. |
| Model effort | Actual `thinking_effort` standard/extended values survive parse and SQLite persistence. |
| Status and end-turn | `finished_successfully` and true/false end-turn values are asserted on representative messages. |
| Native/full-fidelity versus fallback | Both arrival orders plus a newer/longer fallback exercise the real archive precedence path and retained raw link. |
| Raw-field fidelity | Retained source raw bytes contain current timing spellings, both legacy spellings, and `thinking_effort`. |
| No double counting | One 5,190,000 ms lifecycle duration is projected; equal legacy copies are cleared while an unequal 250 ms message-local duration remains. |

## Apply order

From a clean checkout of the named base commit:

```bash
git checkout --detach b9052e09103502017c0f510ecc699aac395de23c
git apply --check PATCH.diff
git apply PATCH.diff
```

Then run the focused checks listed in `TESTS.md`. `FILES/` is intentionally omitted because the unified diff contains complete new fixtures/tests and the production edit is unambiguous.

## Risks, limitations, and remaining verification

The implementation and targeted production routes were executed locally, but the supplied container did not contain the full project development dependency set. Direct pytest collection failed first on missing `hypothesis`; a frozen `uv sync --extra dev` could not reach the package index because DNS/network access was unavailable. A broader shimmed pytest collection did not complete before the local timeout. Consequently, full pytest, Ruff, mypy, generated-surface gates, and `devtools verify` remain unverified in this environment.

The archive survivor did execute the real source/index/archive writer and reader. To import that route without unavailable optional packages, the temporary harness supplied import-only stubs for `ijson`, `aiosqlite`, and `dateparser`, replaced the unused embeddings-tier DDL, and reported sqlite-vector loading as available. These shims were outside the patch and were not used to replace ChatGPT dispatch, browser parsing, source/index writes, replacement decisions, raw retention, or SQLite reads. A normal project environment must rerun the committed test file without those shims.

No operator live daemon, browser extension, authenticated ChatGPT tab, private archive, secrets, NixOS deployment, or current operator worktree was accessed. Installed-browser acquisition and live provider drift are therefore unverified. The fixtures cover the observed wire spellings and meaningful variants, but future upstream key or graph-shape changes remain a normal provider-integration risk.

The existing archive envelope reader does not expose every message column, so the storage survivor verifies `model_effort` and nullable duration directly from the real `index.db` messages table while using `ArchiveStore.read_session` for retained transcript identity. This is persistence proof, not a claim that every public presentation already renders model effort.

## Value of another iteration

A small repair pass would be valuable after applying this patch in a fully provisioned checkout: run focused/full pytest, Ruff, mypy, and project verification; fix any environment-specific typing, lint, or composition issue; and regenerate the same package structure. That is expected to be certification work rather than a redesign.

A substantial second pass would add materially different coverage: schema-generated ChatGPT family variants with an independent fact blueprint, mutation-run receipts for the named detector/authoredness/duration/asset mutations, and a public query/projection round trip for effort and lifecycle events. That could add moderate value, especially against future provider drift, but it is not required to make the implemented production behavior coherent.
