# Test design and execution record

## Test portfolio

The new suite is `tests/unit/sources/test_chatgpt_normalization_survivors.py`. It contains eight test functions and nine pytest cases because the archive-fidelity survivor is parameterized over both arrival orders. The expected normalized facts are hardcoded from the privacy-safe wire fixtures; no ChatGPT parser helper is used to manufacture the oracle.

### Native wire fixture through dispatch

`test_chatgpt_native_wire_fixture_survives_dispatch_and_semantic_normalization`

Production dependencies exercised:

- `dispatch.detect_provider`
- `dispatch._lower_payload_specs`
- `dispatch._parse_lowered_spec`
- `dispatch.parse_payload`
- `chatgpt.extract_messages_from_mapping`
- `chatgpt._extract_generation_timings`
- `chatgpt.parse`

Facts checked: provider/session identity, timestamps, eight emitted messages, active and inactive variants, active leaf and parent identity, context/user/assistant/tool authoredness, text/image/thinking/tool-use/tool-result blocks, upload and sandbox attachments, model name, current `thinking_effort`, delivery status, end-turn, one exact lifecycle duration, lifecycle bounds/source/fidelity/semantics, and no duplicate duration contribution.

Representative mutations that kill it: classify material origin by role only; filter inactive branches; drop empty-prose structural blocks; ignore `thinking_effort`; prefer duplicated legacy message durations; remove attachment extraction; remove status/end-turn projection; or bypass dispatch and parse the outer browser envelope as ChatGPT mapping data.

### Timing owner survives omitted provider node

`test_timing_only_provider_node_rehomes_duration_to_the_last_emitted_branch_message`

Production dependency exercised: post-extraction timing-owner resolution in `chatgpt.parse`.

The fixture mutation adds a metadata-only assistant node that wins timing authority but is intentionally omitted by message extraction. The asserted result keeps eight messages, places the duration and event source on the emitted final answer, and retains the single session total.

Representative mutation: remove owner rehoming or attach lifecycle events to an unmaterialized provider message ID.

### Deduplication does not erase a distinct duration

`test_generation_dedup_preserves_a_distinct_message_local_legacy_duration`

Production dependency exercised: equal-value duplicate selection and message normalization in `chatgpt._extract_generation_timings` / `chatgpt.parse`.

A related tool-result legacy duration is changed from the duplicated 5,190,000 ms value to 250 ms. The lifecycle owner retains 5,190,000 ms, the tool result retains 250 ms, and the session total is 5,190,250 ms.

Representative mutation: clear every legacy duration on a branch rather than only values equal to the selected lifecycle duration.

### Legacy-only compatibility remains message-local

`test_bare_legacy_duration_remains_message_local_without_a_synthetic_lifecycle_event`

Production dependency exercised: legacy duration extraction and lifecycle candidate gating.

A bare `duration_ms=750` remains a message duration and contributes to the session total without generating a provider-native lifecycle event.

Representative mutation: promote every legacy duration field into lifecycle evidence.

### Malformed native presence is not evidence

`test_malformed_native_timing_does_not_promote_a_legacy_duration_to_lifecycle`

Production dependency exercised: validation before legacy lifecycle fallback.

`finished_duration_sec="pending"` paired with `durationMs=750` keeps the legacy message duration but creates no lifecycle event.

Representative mutation: gate legacy promotion on native key presence instead of at least one valid native value.

### Detector-order ambiguity witness

`test_browser_capture_detector_short_circuits_the_weaker_chatgpt_mapping_shape`

Production dependency exercised: detector order in `dispatch._detect_provider_from_record` / `detect_provider`.

The browser envelope is given a top-level decoy `mapping`, so both structural detectors could claim it. The ChatGPT detector is replaced with a fail-fast spy after confirming both shapes. Detection must return ChatGPT through the browser envelope without invoking the weaker mapping detector.

Representative mutation: move ChatGPT mapping detection before browser-capture detection or loosen an earlier detector.

### Native browser delegation and acquired assets

`test_native_browser_capture_delegates_to_chatgpt_and_merges_acquired_assets`

Production dependencies exercised:

- `dispatch.parse_payload`
- `browser_capture.parse`
- ChatGPT native payload delegation
- browser envelope attachment merge

The native direct import and native browser capture must produce equal messages, events, title, and duration. DOM-only IDs must not appear. The sandbox attachment receives exact acquired bytes, byte count, MIME type, upload origin, kind, and source URL without duplication.

Representative mutations: introduce a browser-only ChatGPT parser, fall back to DOM turns despite a native payload, omit acquired-byte merge, or append a second sandbox attachment.

### Full-fidelity replacement and raw authority

`test_native_full_fidelity_replaces_or_resists_longer_dom_fallback_and_keeps_raw_fields`

Cases:

- DOM fallback arrives, then native capture.
- Native capture arrives, then DOM fallback.

Production dependencies exercised:

- fidelity flags emitted by `browser_capture.parse`
- `ArchiveStore.write_raw_and_parsed_result`
- `browser_capture_precedence`
- real source/index SQLite tiers
- `ArchiveStore.read_session`
- `ArchiveStore.raw_revision_material`

A still-newer and longer DOM fallback is submitted after both initial writes. The retained session must remain native, have eight native message IDs, retain one 5,190,000 ms duration, retain standard/extended effort in SQLite, skip the fallback replacement, preserve the native raw link, and preserve all timing/effort spellings in raw bytes.

Representative mutations: remove the native fidelity flag, allow newer/longer DOM replacement, make precedence arrival-order dependent, relink the retained session to the skipped fallback raw, omit model-effort persistence, or drop native/acquired raw fields.

## Commands executed and results

All commands below were run against the modified supplied snapshot unless otherwise stated.

### Syntax, JSON, and whitespace

```bash
python -m json.tool tests/fixtures/chatgpt/native-conversation-v1.json >/dev/null
python -m json.tool tests/fixtures/chatgpt/native-browser-capture-v1.json >/dev/null
python -m compileall -q \
  polylogue/sources/parsers/chatgpt.py \
  tests/unit/sources/test_chatgpt_normalization_survivors.py
git diff --check HEAD
```

Result: PASS.

### Actual dispatch/parser harness

A temporary dependency-isolation harness loaded the real `dispatch.py`, `chatgpt.py`, and `browser_capture.py`, then called `detect_provider` and `parse_payload` for both fixture files. It replaced only eager optional-source imports and the unused streaming `ijson` path.

Result: PASS for both fixtures.

Observed assertions included:

- provider `chatgpt`;
- one session per fixture;
- eight normalized messages;
- direct and browser-capture semantic equality;
- correct active/inactive branch data;
- all intended block types;
- two attachment identities, with acquired bytes on the browser route;
- standard/extended effort;
- one 5,190,000 ms duration;
- one provider-native lifecycle event.

### Exact non-storage survivor functions

A temporary import harness executed the seven non-storage test functions exactly, including the detector monkeypatch. Storage imports were replaced only because the module imports `ArchiveStore` for the separate storage case.

Result: `7 exact survivor functions passed`.

### Real archive survivor

A temporary harness invoked the parameterized storage test body against real temporary SQLite source/index archives in both arrival orders.

Result:

```text
passed ('dom', 'native')
passed ('native', 'dom')
```

The harness used real `ArchiveStore`, browser/native parser flags, raw writes, replacement decisions, session reads, index queries, and raw revision reads. To make the archive module importable without optional packages, it supplied import-only stubs for `ijson`, `aiosqlite`, and `dateparser`, substituted a minimal unused embeddings-tier DDL, and made the bootstrap vector-extension probe return available. No ChatGPT, browser-capture, source-tier, index-tier, precedence, or raw-retention function was replaced.

### Existing ChatGPT regression subset

A temporary harness executed six existing ChatGPT timing/archive-contract tests from `tests/unit/sources/test_parsers_chatgpt.py`, covering the pre-existing legacy archive contract, authoritative lifecycle timing, valid start/end fallback, reversed bounds, negative finished duration, and pending finished duration.

Result: `6 existing ChatGPT timing/archive-contract cases passed`.

### Patch application check

`PATCH.diff` was generated against `b9052e09103502017c0f510ecc699aac395de23c`, checked and applied to a clean shared clone at that exact commit, then both JSON fixtures, Python compilation, and `git diff --check` were rerun in the applied tree.

Result: PASS.

## Checks attempted but not completed

Direct focused pytest invocation did not collect because the container lacks project development dependencies, initially reporting missing `hypothesis`. The attempted frozen dev synchronization could not download packages because DNS/network access was unavailable. A broader shimmed pytest collector did not complete within local timeouts during import/collection. Ruff and mypy executables were not available.

These are unverified, not claimed as passing:

```bash
uv sync --frozen --extra dev
uv run pytest -q \
  tests/unit/sources/test_chatgpt_normalization_survivors.py \
  tests/unit/sources/test_parsers_chatgpt.py \
  tests/unit/sources/test_browser_capture.py \
  tests/unit/storage/test_archive_tiers_archive.py
uv run ruff check \
  polylogue/sources/parsers/chatgpt.py \
  tests/unit/sources/test_chatgpt_normalization_survivors.py
uv run mypy \
  polylogue/sources/parsers/chatgpt.py \
  tests/unit/sources/test_chatgpt_normalization_survivors.py
uv run python -m devtools verify --quick
```

The operator should run these in the normal repository environment. Any failure should be treated as certification or composition work and folded into a complete next package revision rather than emitted as a loose supplemental patch.

## Deletion certification

No existing test/helper deletion is proposed. The new fixture-driven survivor overlaps some field-level examples, but no coverage-context plus mutation evidence was available to prove dominance. Existing historical and compatibility witnesses remain intact.
