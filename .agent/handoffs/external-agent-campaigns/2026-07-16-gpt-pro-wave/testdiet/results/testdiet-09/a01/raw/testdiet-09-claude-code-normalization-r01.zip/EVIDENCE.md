# EVIDENCE — testdiet-09 Claude Code normalization laws

## Authority ordering used

1. Mission prompt and exact result-package contract.
2. Supplied snapshot's current tracked source at `b9052e09103502017c0f510ecc699aac395de23c`.
3. Repository instructions and current typed/storage architecture.
4. Complete relevant Beads records, including later notes and closure information.
5. Test-diet source-normalization laws.
6. Git history explaining why current mechanisms exist.

Where a closed Bead or historical description conflicts with the supplied source, the supplied source is treated as runtime authority and the contradiction is recorded rather than silently resolved in favor of prose.

## Snapshot evidence

`polylogue-manifest.json` and `polylogue-overview.json` both report:

```text
generated_at: 2026-07-17T105328Z
source: /realm/project/polylogue
branch: master
commit: b9052e09103502017c0f510ecc699aac395de23c
dirty: true
```

`polylogue-branch-delta.md` reports base `origin/master`, merge base equal to the same commit, an empty diff stat, and no commits. `polylogue-branch-delta.patch`, `polylogue-branch-delta-files.txt`, and `polylogue-branch-delta-log.txt` are empty. The source bundle resolves `master` and `origin/master` to that commit.

The dirty flag is therefore not representable as a supplied tracked patch. The snapshot audit also reports substantial ignored/local-state bytes, which are not code authority and were not copied. The deliverable targets the named committed tree and states this limitation explicitly.

## Repository architecture findings

`CLAUDE.md` defines a substrate-first system: sources detect and normalize provider artifacts, storage owns durable meaning, and surfaces are leaf adapters. The current Claude route follows that architecture:

```text
filesystem/emitter
  -> source_parsing / streaming JSONL iterator
  -> dispatch.detect_provider / parse_stream_payload
  -> claude.code_parser ParsedSession/Message/Block/Event
  -> ArchiveStore.write_parsed
  -> sessions/messages/blocks/session_events/session_links
  -> archive envelope and action read models
```

Important contracts found:

- `MaterialOrigin` is independent from provider role. Generic classification intentionally has no `Role.USER -> HUMAN_AUTHORED` fallback.
- Claude Code parser supplies provider-specific positive evidence after excluding protocol/context/tool-result shapes.
- Session IDs are generated as `origin:native_id`; message IDs append native message ID; block IDs append block position.
- Tool actions pair tool-use and tool-result blocks by session and tool ID, while unmatched uses remain visible.
- `agent-*` and `agent-acompact-*` fallback identities already determine parent link and branch semantics.
- Prefix-sharing is stored as a session link plus a physical divergent tail, then composed on read. Late parent arrival is explicitly repaired.
- Raw JSONL source ingest uses a blob reference and streaming parse path rather than requiring `raw_bytes` in memory.

These contracts made small production seams sufficient; no new event/storage model was needed.

## Test-diet findings

`areas/source-normalization.md` requires provider normalization to be organized by public laws rather than parser classes. The relevant laws are:

- detector tightness and ambiguous-shape precedence;
- wire artifact to normalized session/message/block facts;
- streaming/non-streaming equivalence;
- bundle/split/order equivalence;
- acquire → parse → store → read survival;
- independent planted oracle that does not call parser helpers;
- retention of compact provider-specific witnesses for unique wire quirks.

The new family test follows that form. The fixture carries exact provider wire evidence; the test plants provider-neutral expected facts and compares eager/stream output plus downstream stored/read identities.

## Bead findings

### `polylogue-z9gh.5`

Title: “Stop classifying generated subagent instructions as human-authored.” Status: closed on `2026-07-14T23:07:10Z`.

Its description says Claude's parser upgrades a plain user record with absent or human origin to `human_authored`, while generated worker instructions can have exactly that shape. It records a live coordinator tree where all 128 child sessions acquired one fabricated human-authored turn. Its design requires positive human evidence; generated/orchestration origin when known; otherwise unknown. Acceptance also names direct prompts, Agent/Workflow prompts, resumes, injected context, tool results, ambiguous legacy records, title/search/count/cost effects, and reparse impact.

Contradiction: at the supplied snapshot, `_is_claude_code_human_turn` still returned true when `origin_kind in (None, "human")` without considering `agent-*` artifact identity. The Bead is closed, but its central parser rule is not present in the supplied code. This patch repairs the concrete Agent artifact case and proves title/authored-count consequences. Workflow provenance and live reparse quantification remain outside this container.

### `polylogue-t0p.1`

Title: “Parse Claude background completion outcomes.” Status: closed; close reason names merged PR #2722 / commit `b8a1acba7`.

The record requires exact task/tool linkage, output file, status, success/failure exit codes, foreground unknown exit, fail-closed malformed templates, and idempotent duplicate/update reconciliation. Current source contains that structured parser and eager projection.

Streaming contradiction: a completion in a later non-contiguous chunk was projected only within that chunk, which did not contain the earlier start block. Generic chunk merge concatenated already-projected messages/events but did not rerun correlation. Thus the eager behavior established by the Bead did not survive the streaming route. This patch reuses the existing structured event facts and performs one final provider-specific reconciliation after merge.

## History findings

### `7120bde619a1ffaaef6a82afcba13de904adf80f` — 2026-07-02

`git blame` attributes `_record_origin_kind` and the former `_is_claude_code_human_turn` to this commit. The historical implementation deliberately classified absent origin as human after shape exclusions. That is valid for ordinary top-level interactive transcript artifacts but overgeneralizes to worker artifacts.

### `a651bb95f1fc3595cff8f545ec3768831b858daf` — 2026-07-02

Commit subject: `fix(sources): merge Claude Code stream sessions (#2520)`.

It added repeated-session chunk merging and empty human-turn preservation. Current merge behavior renumbered normalized message positions but did not preserve raw record-index continuation, a cross-chunk UUID seen set, late topology, or a final provider completion projection. Concatenation therefore preserved content in simple cases but not exact identity/correlation semantics.

### `b8a1acba732fb8c2f4f89ea96cfeae65cd2a9e13` — 2026-07-12

Commit subject: `fix(claude): project background command outcomes (#2722)`.

It introduced the correct structured notification parser, exact correlation, durable event, and fail-closed outcome behavior. The patch preserves that mechanism and only adds finalization across split chunks.

## Current-source defects reproduced by the fixtures

### Authoredness defect

Wire witness:

```json
{"type":"user","uuid":"agent-task","sessionId":"claude-lineage-parent","message":{"role":"user","content":"Inspect the normalization shard and report only evidence."}}
```

With fallback artifact ID `agent-normalization-proof`, snapshot source classified the row as a plain human turn because origin was absent. The same fallback already proved this was a subagent and supplied its parent topology. The patch makes artifact identity available during material-origin classification and yields `generated_context_pack`.

### Streaming identity defect

The family fixture uses one main session, an interleaved other session, a repeated `main-u1` UUID after the interleaving, and two rows with no UUID. Eager grouping counts only the main session's raw records and assigns `msg-7` and `msg-11`. Snapshot streaming restarted indexes and UUID sets for each contiguous group, so it could retain the repeated UUID and assign different fallback IDs. The patch carries per-session record count and exact UUID state.

### Streaming completion defect

The background start block occurs before interleaving; the terminal queue-operation event occurs in a later main-session chunk. Snapshot chunk-local parsing could not project the late terminal outcome onto the earlier block. The patch reconstructs the typed notification from the durable session event and reruns existing exact correlation after merge.

### Streaming topology defect

`isSidechain=true` appears only on the final no-UUID assistant row. Eager parsing sets `SIDECHAIN`. Snapshot chunk merge retained the first chunk's `branch_type=None`. The patch merges late branch and parent topology.

## Fixture coverage

`normalization-family.jsonl` proves:

- Claude detector claim plus negative/precedence witnesses in the test;
- explicit human turn;
- thinking, text, Bash and Read tool uses;
- background acknowledgement with task ID;
- operator `/status` command;
- interleaved second session;
- repeated UUID conflict;
- runtime environment context;
- no-UUID interruption protocol;
- foreground Bash failure with no numeric exit evidence;
- late structured background failure with exact exit `7` and output path;
- no-UUID final assistant output;
- late sidechain flag;
- token/cache usage, model identities, timestamps, cost, duration, and cwd.

`normalization-agent.jsonl` proves generated worker authoredness and subagent topology.

`normalization-lineage-parent.jsonl` and `normalization-lineage-acompact.jsonl` prove replayed-prefix removal and logical composition under both arrival orders.

## Constraints retained

- Ordinary top-level absent-origin Claude user rows remain human under the current Claude artifact contract; changing that broad compatibility rule would require a separate legacy ambiguity campaign.
- Explicit `origin.kind=human` remains human even in an agent artifact.
- Unknown/malformed background completion events are not reconstructed or guessed.
- Foreground Bash prose is not parsed for an exit code.
- Duplicate UUID handling remains exact first-record-wins.
- No existing tests/helpers were deleted.
- No live archive, daemon, browser, secret, deployment, or operator worktree was accessed.
