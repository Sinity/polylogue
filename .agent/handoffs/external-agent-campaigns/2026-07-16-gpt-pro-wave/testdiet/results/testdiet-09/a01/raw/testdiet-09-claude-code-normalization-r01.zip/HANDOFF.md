# HANDOFF — testdiet-09 Claude Code normalization laws

## Mission and delivered slice

This package implements a coherent Claude Code provider-family normalization slice against snapshot commit `b9052e09103502017c0f510ecc699aac395de23c`. It fixes two production defects and proves them through the real detector, streaming dispatcher, Claude parser, filesystem acquisition, archive writer/read model, action relation, and lineage composition routes:

1. An origin-less `type=user` instruction in an `agent-*` Claude Code artifact is generated orchestration material, not human-authored input. Explicit human provenance remains authoritative, and ordinary top-level interactive rows retain the existing positive artifact evidence.
2. A Claude session split into non-contiguous streaming chunks now preserves eager-path record identity, duplicate-UUID first-wins behavior, late topology, and late background-task completion projection. The stream still consumes iterators and does not retain raw JSONL bytes.

The implementation deliberately reuses `ParsedSession`, `ParsedMessage`, `ParsedContentBlock`, `ParsedSessionEvent`, `ArchiveStore`, session links, and the existing action projection. It does not introduce a second Claude event model or a parallel storage/read path.

## Snapshot identity

The supplied snapshot manifest reports:

- source: `/realm/project/polylogue`
- generated: `2026-07-17T105328Z`
- branch: `master`
- commit: `b9052e09103502017c0f510ecc699aac395de23c`
- dirty: `true`

The supplied branch-delta artifacts name `origin/master` as the base, the same commit as merge base, and contain no commits, changed-file list, or patch. The supplied working-tree archive reconstructed to the committed tracked contents for the files used here. Consequently `PATCH.diff` is based on the named commit. The manifest's dirty bit is preserved as an unresolved snapshot limitation: no tracked dirty patch was recoverable from the supplied authority, and ignored/local state was intentionally not imported.

## Evidence inspected

Repository guidance inspected:

- `AGENTS.md` / `CLAUDE.md`
- `.agent/CONVENTIONS.md`
- `TESTING.md`

Production routes inspected beyond the immediate parser:

- `polylogue/sources/parsers/claude/code_detection.py`
- `polylogue/sources/parsers/claude/code_parser.py`
- `polylogue/sources/parsers/claude/common.py`
- `polylogue/sources/dispatch.py`
- `polylogue/sources/source_parsing.py`
- `polylogue/sources/emitter.py`
- `polylogue/storage/blob_store.py`
- `polylogue/storage/sqlite/archive_tiers/archive.py`
- `polylogue/storage/sqlite/archive_tiers/write.py`
- `polylogue/storage/sqlite/archive_tiers/index.py`
- `polylogue/storage/sqlite/action_relation.py`
- session-link/prefix-sharing composition and late-parent repair code reached by `ArchiveStore.write_parsed`

Existing tests inspected or executed include Claude parser artifacts, parser base contracts, dispatch payloads, compaction, source streaming laws, archive revision replay, action queries, and lineage composition.

Authority records and history inspected:

- test-diet `areas/source-normalization.md`
- Bead `polylogue-z9gh.5`, “Stop classifying generated subagent instructions as human-authored”
- Bead `polylogue-t0p.1`, “Parse Claude background completion outcomes”
- commit `7120bde619a1ffaaef6a82afcba13de904adf80f`, which introduced the absent-origin human-turn rule
- commit `a651bb95f1fc3595cff8f545ec3768831b858daf`, which merged repeated Claude stream sessions by concatenation
- commit `b8a1acba732fb8c2f4f89ea96cfeae65cd2a9e13`, which added structured background completion outcomes

`EVIDENCE.md` records the resulting findings and contradictions in detail.

## Mechanism

### Authoredness at the provider boundary

`_claude_code_user_turn_origin` replaces the boolean “human turn” helper with a typed origin decision. It first excludes meta/context/tool-result/protocol shapes. For a plain user message:

- `origin.kind == "human"` yields `HUMAN_AUTHORED` in any Claude artifact;
- absent origin in an `agent-*` artifact yields `GENERATED_CONTEXT_PACK`;
- absent origin in an ordinary top-level Claude Code transcript retains `HUMAN_AUTHORED` under the existing artifact-level interactive provenance;
- any other origin kind remains governed by message-type/protocol classification rather than being promoted to human.

Artifact identity is computed before parsing records so it is available when origin is classified, title selection occurs, and archive authored-user aggregates are later computed.

### Streaming identity and topology

`parse_code_stream` now accepts compact continuation state: a per-provider-session raw record index and a set of previously observed record UUIDs. `_claude_code_stream_sessions` keeps that state across non-contiguous chunks. This preserves:

- no-UUID fallback IDs such as `msg-7` and `msg-11` exactly as eager grouping assigns them;
- first-record-wins duplicate UUID semantics even when the duplicate appears after another session's chunk;
- message/block identity derived from those native IDs;
- iterator-based lowering without retaining raw JSONL records.

The state is not constant-space: UUID memory is proportional to unique record identifiers seen per session. It is nevertheless independent of raw payload byte size and avoids whole-file materialization. A spill-backed or probabilistic dedup strategy would be a separate design decision because exact first-wins compatibility is required here.

`merge_parsed_session_chunks` now carries forward late `parent_session_provider_id` and `branch_type` values. The fixture places `isSidechain=true` only in a late main-session chunk, so deleting this merge makes streaming differ from eager parsing.

### Late background outcome reconciliation

Each Claude chunk continues to use the existing structured notification parser and exact `(task_id, tool_use_id)` correlation. After chunk merge, `reconcile_code_session_chunks`:

- collapses duplicate/update completion events by the same provider join key, retaining the latest value with eager-compatible ordering;
- reapplies terminal completion facts to background-start tool-result blocks that may have occurred in an earlier chunk;
- keeps ordinary session events before final completion events, matching eager parsing.

This preserves exit code `7` for the known background failure while an ordinary foreground failed Bash result remains `exit_code=NULL` when the provider supplied no numeric outcome.

## Decisions

- Fix authoredness in the Claude provider parser, not in generic `Role.USER` logic. Generic role is not authorship evidence.
- Use the `agent-*` artifact fallback identity already consumed for parent/subagent/compaction topology instead of adding a new provenance model.
- Preserve exact UUID and fallback-index identity rather than inventing chunk-local IDs or hashing normalized content.
- Reconcile late completion facts after the existing generic chunk merge rather than duplicating the background protocol parser in dispatch.
- Assert archive IDs literally from the storage contract, not by calling parser or identity helpers to construct the oracle.
- Exercise child-first and parent-first storage orders through the existing late-link repair and prefix-sharing mechanisms.
- Keep all existing tests and helpers. No dominated deletions are proposed in this package.

## Changed files

- `polylogue/sources/parsers/claude/code_parser.py` — typed authoredness decision, stream continuation parameters, and final background completion reconciliation.
- `polylogue/sources/parsers/claude/__init__.py` — exports the reconciliation seam used by dispatch.
- `polylogue/sources/dispatch.py` — carries per-session stream continuation state, preserves late topology, and reconciles Claude chunks.
- `tests/unit/sources/test_source_laws.py` — updates two parser doubles to accept the real stream continuation keyword arguments.
- `tests/unit/sources/test_claude_code_normalization_laws.py` — six real-route laws with independent literal oracles and named anti-vacuity mutations.
- `tests/fixtures/claude-code/normalization-family.jsonl` — interleaved family fixture with duplicate UUID, no-UUID rows, protocol/context/operator rows, token/cache/model/timestamp data, missing/late tool results, background terminal outcome, foreground unknown exit, and late sidechain topology.
- `tests/fixtures/claude-code/normalization-agent.jsonl` — origin-less generated worker task plus assistant output.
- `tests/fixtures/claude-code/normalization-lineage-parent.jsonl` — parent prefix witness.
- `tests/fixtures/claude-code/normalization-lineage-acompact.jsonl` — replayed prefix plus compaction summary.

`FILES/` is omitted because `PATCH.diff` contains complete new files and unambiguous edits.

## Acceptance matrix

| Mission fact | Production route and proof |
| --- | --- |
| Detector tightness / precedence | Generic transcript is rejected, a Codex event remains Codex, and the family fixture detects as Claude Code through `detect_provider`. |
| Message identity | Literal UUID IDs and eager-style `msg-7`/`msg-11` fallback IDs are asserted; conflicting repeated UUID is absent. |
| Block identity | Literal deterministic archive message and block IDs are asserted after write/read. |
| Streaming equivalence | Full `model_dump(mode="json")` equality between eager and streaming sessions under non-contiguous interleaving. |
| Multi-GiB lowering seam | Existing iterator/non-list source law remains green; continuation state retains no raw bytes. |
| Parent/subagent topology | `agent-*` child composes parent and fallback IDs, links to the parent, and stores as `SUBAGENT`. |
| Resume/compaction topology | `agent-acompact-*` stores only the divergent summary tail and composes the parent prefix for both arrival orders. |
| Replayed-prefix lineage | Physical child positions are `[2]`, link inheritance is `prefix-sharing`, and logical read returns the prefix once. |
| Child-before-parent repair | Subagent child remains `spawned-fresh`; late parent resolution does not steal a prefix. |
| Human vs generated material | Explicit main prompt is human; origin-less worker instruction is generated context; archive authored counts remain one human message / three words. |
| Operator/runtime distinctions | `/status` is operator command, environment injection is runtime context, interruption row is runtime protocol. |
| Thinking/output/tool use | Assistant block order is thinking, text, Bash use, Read use. |
| Tool pairing and missing result | Background and foreground Bash actions pair by tool ID; unmatched Read remains visible with no result. |
| Structured error / exit | Background completion projects `is_error=true`, `exit_code=7`, status, task ID, and output path; foreground failure has unknown exit. |
| Token/cache/model/cost/duration | Per-message input/output/cache fields, two model identities, session model set, cost, duration, and cwd are asserted in parser and SQL rows. |
| Timestamps | Exact normalized message/session timestamps and created/updated bounds are asserted. |
| Acquire → parse → store → read | Filesystem source acquisition, blob hash/size/content, stream parsing, archive write, SQL rows, envelope read, and action query are all exercised. |

## Apply order

1. Check out exactly `b9052e09103502017c0f510ecc699aac395de23c` or a descendant where the touched code has not diverged.
2. Run `git apply --check PATCH.diff`.
3. Run `git apply PATCH.diff`.
4. Run the focused commands in `TESTS.md`.
5. Run the repository's managed `devtools verify` lane in its normal Nix/uv environment before merge.
6. Reparse/rebuild affected Claude Code sessions in the operator environment only after the code has passed that managed gate; this package does not touch a live archive.

## Risks and limitations

- The snapshot manifest says the source worktree was dirty, but supplied branch-delta files are empty and no tracked dirty patch could be reconstructed. This patch therefore targets the named commit, not an unknowable local delta.
- Exact duplicate UUID compatibility needs an exact seen-ID set. Memory is `O(unique UUIDs)` for each streamed source invocation. No raw record bytes are retained, but this is not constant-space deduplication.
- The implementation preserves current fallback-file semantics. A single `agent-*` artifact is correctly recognized; the existing eager dispatcher itself loses filename-derived agent identity when one file is treated as a multi-session aggregate. This package does not redefine that ambiguous legacy shape.
- Only the privacy-safe fixtures in this package and existing repository tests were used. Operator live daemon, browser capture, secrets, deployed NixOS service, live archive, and the known 128-child production tree were not accessed.
- A full managed verify run is unverified in this container. Pytest plugin autoload hung in the shared environment, so completed pytest runs used plugin autoload disabled and report three unknown-config warnings for the intentionally absent asyncio/timeout plugins.
- A broader selected test campaign reached 50% with no failures before a five-minute external ceiling; it is recorded as incomplete, not passed.
- Full strict mypy dependency traversal timed out. Changed parser and new test pass strict checking with imports skipped; dispatch then reports two known `Returning Any` artifacts at unrelated imported provider-return lines because skipped imports erase those return types.

## Verification performed and remaining

Performed:

- apply-ready patch generated from a temporary Git index against the named commit;
- `git apply --check` and actual `git apply` in a clean detached worktree;
- six new laws passed in the clean applied worktree;
- final focused regression set: `164 passed`;
- Ruff formatting and changed-file lint: passed;
- `git diff --check`: passed;
- `compileall` over changed production/tests: passed;
- strict mypy with skipped imports on the changed parser and new test: passed;
- ZIP validation, member listing, patch scan, SHA-256, and byte size are performed after these documents are written and reported in the final chat response.

Remaining for the operator environment:

- managed `devtools verify` / CI with the repository's complete locked plugin set;
- full strict mypy traversal in the managed environment;
- live archive impact quantification and controlled reparse/rebuild for affected Claude Code sessions;
- optional scale campaign measuring UUID-state memory on representative multi-GiB files.

## Further iteration value

For this delivered slice, another iteration should be a small repair if managed CI reveals an environment-specific typing, plugin, or integration mismatch. A substantial second pass would be justified only to broaden the contract: spill-backed exact UUID deduplication, malformed/truncated-tail append/restart campaigns, generated Workflow prompt provenance beyond `agent-*` artifacts, or quantified live reparse effects. Those are meaningful additions, not required glue for the current end-to-end behavior.
