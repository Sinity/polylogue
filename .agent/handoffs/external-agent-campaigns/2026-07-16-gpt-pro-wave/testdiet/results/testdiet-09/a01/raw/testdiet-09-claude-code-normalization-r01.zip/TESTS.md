# TESTS — testdiet-09 Claude Code normalization laws

## Oracle design

The new fixtures are reduced privacy-safe Claude Code wire shapes. Expected normalized facts are planted as literal strings, enum values, numeric totals, timestamps, session/message/block IDs, and transcript texts in `tests/unit/sources/test_claude_code_normalization_laws.py`. The oracle does not call Claude parser helpers, ID builders, storage identity helpers, or projection code to calculate expected results.

The principal family fixture intentionally interleaves two sessions. Its main session includes an explicit human prompt, thinking/text/tool-use output, a background acknowledgement, operator command, runtime context, no-UUID interruption protocol row, a duplicate UUID after another session, a foreground tool failure, a late queue-operation completion, and a no-UUID final assistant row carrying a late sidechain marker. This one fixture makes eager/stream divergence observable across identity, topology, events, and tool outcomes.

## Test laws and anti-vacuity mutations

### `test_family_fixture_detector_and_streaming_paths_preserve_one_normalized_identity`

Production dependencies:

- `detect_provider` and detector precedence;
- eager Claude grouping in `_claude_code_grouped_record_specs`;
- iterator lowering in `_claude_code_stream_sessions`;
- `parse_code` / `parse_code_stream`;
- `merge_parsed_session_chunks`;
- `reconcile_code_session_chunks`.

Proof:

- generic transcript remains unclaimed;
- Codex event remains Codex;
- fixture detects as Claude Code;
- eager and stream `ParsedSession` JSON models are exactly equal;
- literal message IDs, roles, message types, origins, timestamps, title, active leaf, sidechain, cost, duration, model set, cwd, block order, tool IDs, token/cache counts, background metadata, event order/payload, and duplicate suppression all match.

Representative mutation/removal that must fail:

- reset record indexes on each contiguous chunk;
- remove the per-session UUID set;
- omit late branch-type merge;
- omit post-merge background reconciliation;
- let Codex/Claude detector precedence drift;
- keep the conflicting duplicate record.

### `test_family_fixture_survives_acquire_parse_store_read_and_action_pairing`

Production dependencies:

- `iter_source_sessions_with_raw` and source emitter;
- `BlobStore` raw capture;
- stream dispatcher and Claude parser;
- `ArchiveStore.write_parsed`;
- archive message/block writer and generated IDs;
- `read_archive_session_envelope`;
- SQL session/message aggregates;
- action relation and tool-use/result pairing.

Proof:

- exact source bytes survive via SHA-256 blob reference and size;
- literal session/message/block IDs survive write/read;
- material origins, token/cache/model columns, error/exit fields, and authored aggregates survive SQL storage;
- background and foreground Bash calls pair to their results by tool ID;
- unmatched Read remains an action with no fabricated result or outcome.

Representative mutation/removal that must fail:

- drop material-origin or usage columns in the writer;
- reorder blocks;
- change deterministic IDs;
- pair tool results only by adjacency;
- discard unmatched tool uses;
- infer a foreground numeric exit code from generic failure prose.

### `test_agent_artifact_topology_prevents_generated_instruction_from_becoming_human`

Production dependencies:

- filename/fallback artifact identity reaching the Claude parser;
- typed material-origin classification;
- agent parent/composed-session topology;
- title selection.

Proof:

- child ID is `parent:agent-fallback`;
- branch is `SUBAGENT` and parent is exact;
- origin-less worker instruction is `GENERATED_CONTEXT_PACK`, never `HUMAN_AUTHORED`;
- assistant output remains assistant-authored;
- no generated instruction becomes the title.

Representative mutation/removal that must fail:

- restore `origin_kind in (None, "human")` as a human rule;
- compute `is_agent` only after messages are classified;
- remove `agent-*` topology input.

### `test_acompact_resume_replayed_prefix_is_stored_once_and_composed[True|False]`

Production dependencies:

- `agent-acompact-*` continuation classification;
- archive prefix-signature alignment;
- session-link writer;
- late unresolved-link repair;
- composed archive read.

Proof under both parent-first and child-first arrival:

- child is a continuation;
- only physical tail position `2` is stored;
- link is `prefix-sharing` with a resolved parent and branch point;
- logical read returns parent prompt, parent answer, and summary once;
- prefix origins remain human/assistant and summary is generated context.

Representative mutation/removal that must fail:

- classify acompact as an ordinary subagent;
- disable prefix alignment;
- retain the replayed prefix physically in the child;
- skip unresolved-link repair when parent arrives later.

### `test_subagent_child_arriving_before_parent_resolves_as_spawned_fresh`

Production dependencies:

- child-first session link creation and repair;
- spawned-fresh subagent inheritance;
- composed read.

Proof:

- child retains both of its own messages;
- link resolves to parent but inheritance remains `spawned-fresh` with no branch point;
- parent prefix is not prepended;
- generated worker prompt remains generated after read.

Representative mutation/removal that must fail:

- infer prefix-sharing from parent linkage alone;
- prepend parent transcript to every child;
- fail to repair unresolved destination IDs.

## Commands actually executed

All pytest commands used Python 3.13 from `/opt/pyvenv`. The shared environment's pytest plugin autoload stalled before useful output, so verified runs used `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` and `-o addopts=''`. This intentionally omits the asyncio/timeout plugins configured in `pyproject.toml`, producing three `PytestConfigWarning` messages; the selected tests are synchronous.

### Final focused regression gate

```bash
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
PYTHONPATH=. \
POLYLOGUE_PYTEST_BASETEMP_ROOT=/mnt/data/work-testdiet09/pytest-tmp/final-focused \
/opt/pyvenv/bin/pytest \
  tests/unit/sources/test_claude_code_normalization_laws.py \
  tests/unit/sources/test_parsers_base.py \
  tests/unit/sources/test_parsers_claude_code_artifacts.py \
  tests/unit/sources/test_compaction.py \
  tests/unit/sources/test_dispatch_payloads.py \
  tests/unit/sources/test_source_laws.py::test_claude_code_stream_payload_does_not_materialize_whole_stream \
  tests/unit/sources/test_source_laws.py::test_claude_code_stream_payload_splits_contiguous_session_groups \
  tests/unit/storage/test_revision_replay.py \
  -q -o addopts=''
```

Result: `164 passed, 3 warnings in 18.22s`.

### Clean-patch application proof

In a detached worktree at `b9052e09103502017c0f510ecc699aac395de23c`:

```bash
git apply --check PATCH.diff
git apply PATCH.diff
git diff --check
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=. \
  POLYLOGUE_PYTEST_BASETEMP_ROOT=/mnt/data/work-testdiet09/pytest-tmp/apply-check \
  /opt/pyvenv/bin/pytest tests/unit/sources/test_claude_code_normalization_laws.py \
  -q -o addopts=''
/opt/pyvenv/bin/ruff check \
  polylogue/sources/dispatch.py \
  polylogue/sources/parsers/claude/__init__.py \
  polylogue/sources/parsers/claude/code_parser.py \
  tests/unit/sources/test_source_laws.py \
  tests/unit/sources/test_claude_code_normalization_laws.py
```

Result: patch check and apply passed; `6 passed, 3 warnings in 4.85s`; Ruff passed.

### Static and syntax checks

```bash
/opt/pyvenv/bin/ruff format <changed Python files>
/opt/pyvenv/bin/ruff check <changed Python files>
git diff --check
/opt/pyvenv/bin/python -m compileall -q \
  polylogue/sources/dispatch.py \
  polylogue/sources/parsers/claude \
  tests/unit/sources/test_claude_code_normalization_laws.py \
  tests/unit/sources/test_source_laws.py
```

Result: passed.

```bash
PYTHONPATH=. /opt/pyvenv/bin/mypy --follow-imports=skip --no-incremental \
  polylogue/sources/parsers/claude/code_parser.py
PYTHONPATH=. /opt/pyvenv/bin/mypy --follow-imports=skip --no-incremental \
  tests/unit/sources/test_claude_code_normalization_laws.py
```

Result: `Success: no issues found` for both changed files.

A strict normal-import mypy attempt initially exposed four real narrowing errors in `_background_notification_from_event`; field-specific guards were added. Re-running full dependency traversal timed out before completion with no further output. A skipped-import check of `dispatch.py` reports two `Returning Any` errors at existing imported provider calls (`hermes_state.parse_state_db_payload` and `beads.parse`) because skipped imports erase their declared return types; neither line is changed by this patch.

### Incomplete broader campaign

A broader invocation adding all of `tests/unit/sources/test_source_laws.py` reached 50% with no failure output before a five-minute external command ceiling. It is not counted as passed.

## Recommended operator verification

Run in the repository's normal managed environment:

```bash
devtools test \
  tests/unit/sources/test_claude_code_normalization_laws.py \
  tests/unit/sources/test_parsers_base.py \
  tests/unit/sources/test_parsers_claude_code_artifacts.py \
  tests/unit/sources/test_compaction.py \
  tests/unit/sources/test_dispatch_payloads.py \
  tests/unit/storage/test_revision_replay.py -q

devtools verify --quick
devtools verify
```

Then perform a controlled reparse/rebuild impact check against an operator-owned archive. These live/deployed checks are unverified here.
