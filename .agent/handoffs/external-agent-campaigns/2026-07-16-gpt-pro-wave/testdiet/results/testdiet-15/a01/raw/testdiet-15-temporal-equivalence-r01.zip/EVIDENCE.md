# EVIDENCE — source, Beads, history, and contradictions

## Authority evidence

The attached project-state archive identifies:

- branch `master`
- commit `b9052e09103502017c0f510ecc699aac395de23c`
- manifest dirty flag `true`

The bundle contains that commit and was used as the Git authority. The supplied branch-delta summary names the same commit as the merge base against `origin/master`, with an empty diff stat and no commits. Its patch, file list, and commit log are all zero bytes.

The supplied current-working-tree tar is not a complete tracked checkout. After stripping its top-level `polylogue/` prefix, comparison with `git ls-files` found:

- 3,741 tracked files in the bundle checkout
- 2,503 regular files in the tar
- 1,239 tracked files omitted from the tar
- one tar-only untracked file (`browser-extension/package-lock.json`)

Omitted tracked roots are predominantly `.agent` (1,228 files), then `.beads` (6), `.claude` (2), and one each of `AGENTS.md`, `flake.lock`, and `uv.lock`. Treating those omissions as a dirty deletion patch would contradict both the archive construction and the empty branch-delta artifacts. Overlaying the tar onto the bundle checkout produced a tracked-clean authority before implementation.

Resolution: `PATCH.diff` is against the named commit. The manifest dirty flag is reported honestly, but no tracked dirty patch is invented.

## Repository instruction evidence

`CLAUDE.md` and `AGENTS.md` define four architecture rings and state that substrate owns meaning while surfaces are leaf adapters. They also direct timestamp-sensitive tests to `tests/infra/frozen_clock.py`, identify `tests/property` as the Hypothesis area, and prefer focused execution over blanket test directories.

`TESTING.md` confirms that raw focused pytest is valid for ad hoc checks and that focused tests are single-process by default. The package follows those constraints and does not create a parallel production temporal layer.

## Source findings

### Parsing contract

`polylogue/core/timestamps.py` currently has two intentionally different behaviors:

- `parse_timestamp` treats naive ISO provider input as UTC, returns UTC for epoch values, and retains a declared non-UTC offset for aware ISO input.
- `canonical_timestamp_text` converts a supported instant to UTC text.
- `parse_archive_datetime` treats naive archive text as UTC but preserves a declared aware offset.

Existing timestamp tests explicitly expect non-UTC parser output to remain aware, not necessarily rewritten to UTC. Therefore, changing low-level parsing to erase provider offsets would violate current source authority. The correct seam is the shared public temporal payload.

### Public temporal projection

`polylogue/surfaces/temporal_evidence.py` is shared by CLI read views, API archive context, context compilation, and devtools temporal projections. Before this patch, it required aware event timestamps but retained whichever offset representation the caller supplied. Bounds were validated but returned in caller representation. Equivalent instants could consequently produce different public JSON/Markdown text even though Python considered them equal.

The same module computes adjacent phase spans by subtracting neighboring timestamped events. Before this patch, the numeric duration carried no semantics label. This was the narrow production defect/seam selected for implementation.

### Filtering/query ranges

The archive query path lowers timestamp bounds to epoch milliseconds and applies closed SQL comparisons (`>=` and `<=`). The storage schema is millisecond-precision. The new real-route survivor therefore uses exact one-millisecond neighbors rather than asserting unrepresentable microseconds in durable storage.

The in-memory public temporal builder also uses a closed interval, implemented by excluding only `occurred_at < since` or `occurred_at > until`.

### Freshness and receipt behavior

`polylogue/archive/query/source_freshness.py` canonicalizes the observation instant and cursor timestamp to UTC, computes exact-source age/stage evidence, and hashes the canonical projection. The new test exercises the full projection, not a helper-only calculation, and verifies equality across frozen implicit time, aware-offset time, declared-naive UTC time, and equivalent cursor wire text.

### Provider duration behavior

`polylogue/sources/parsers/chatgpt.py` treats `finished_duration_sec` as authoritative provider-native elapsed time and multiplies seconds by 1,000. It emits lifecycle payload semantics `provider_reported_elapsed`.

`polylogue/sources/parsers/browser_capture.py` preserves live observation semantics supplied by the capture envelope. Existing fixtures use `dom_observed_wall` and `provider_ui_elapsed`. These are independent evidence classes; none is a model-compute measurement.

### Public consumers

`polylogue/cli/read_views/standard.py` serializes `TemporalEvidenceWindow` directly for JSON and renders event/bucket datetimes with `isoformat()` for Markdown. `polylogue/context/compiler.py`, `polylogue/api/archive.py`, and devtools also consume the shared model. A canonical validator on the model therefore fixes the common public representation without duplicating normalization in each adapter.

## Beads findings

### `polylogue-896y` — open

This production-time-authority audit explicitly says external testdiet-15 has no owning bead and is its local evidence base. It asks for concrete classification rather than a blanket clock rewrite. This package follows that direction: it uses the existing clock seam for freshness and changes only the public representation defect found on the real route.

### `polylogue-cpf.6` — closed

The original proposal for a new core clock seam was superseded by later source inspection. Its close reason records that `frozen_clock_modules("polylogue.core.dates")` already patches the module-level datetime symbol and makes relative-date tests deterministic. A new clock abstraction in this patch would therefore be stale architecture.

### `polylogue-cpf.5` — closed

Temporal provenance must propagate the weakest source rather than laundering weak inputs into `provider_ts`. The new tests avoid making a provider/model authority claim from inferred adjacent timestamps.

### `polylogue-cuxz` — open

Evidence values must preserve independent axes such as authority, temporal source, freshness, and unknown state; absence must not become a numeric or epoch sentinel. The explicit `inferred_event_gap` label and `None` absence survivor align with this direction without attempting the much broader EvidenceValue epic.

### `polylogue-3v1.2` — closed

Acceptance criterion 5 requires provider-reported elapsed duration, DOM-observed wall duration, and inferred message gaps to remain semantically distinct, with no public model-compute claim. Completion notes name the concrete production labels `provider_reported_elapsed`, `provider_ui_elapsed`, and `dom_observed_wall`, and retain the exact `5190 seconds -> 5,190,000 ms` witness. This is the primary duration authority for the package.

### `polylogue-1xc.13` — in progress

The exact-source freshness projection must avoid archive-wide scans and expose a bounded receipt. The new equivalence test asserts `exact_source is True`, `archive_wide_aggregates is False`, equal age, and equal projection digest.

### `polylogue-q30k` — closed/superseded

No absent timestamp may be fabricated as `1970-01-01`. The new absence survivor checks parser, canonical text, and summary-to-temporal-event behavior.

### `polylogue-fnm.3` — closed

Its later notes record exact-boundary acceptance and that missing timestamps never become zero. Those constraints are carried into both the closed-range and absence laws.

### `polylogue-0mu` — closed

Provider/native evidence must not be silently downgraded by a lower-fidelity representation. The package preserves parser/native wire behavior and canonicalizes only the public instant representation, not authority or richness.

### `polylogue-1wtm` — open

The live finding that `engaged_duration_ms` is often a wall-clock tautology is a warning against conflating duration constructs. The patch does not reuse that field and explicitly labels event gaps instead.

## History findings

- `f54e87ea1` — consolidated divergent archive datetime parsers; establishes the shared parser contract.
- `576c4b4f5` — canonicalized archive conversation timestamps in storage.
- `ce2f62ac6`, `d40d00a31` — established/converged projection render specs and the temporal evidence surface route.
- `b6c78adfc`, `f0c1b489b` — exact-source freshness projection and restored contract verification.
- `b054f2ba9` — ChatGPT generation lifecycle evidence and exact duration semantics.
- `392643214` — exact duration boundary behavior for query sequence edges.
- `97459e61d`, `c67fd4539` — stopped timeless rows from being excluded or epoch-pinned in search/query paths.
- `122f28796` — proved existing frozen-clock behavior for relative dates.
- `89b14e587`, `e7c1b2064` — temporal provenance lattice and public time-confidence contract.
- `6c12e9234` — durable-tier timestamp doctrine verification.

These commits support a boundary-focused change, not a replacement timestamp subsystem.

## Test-suite-diet findings

The supplied diet materials repeatedly require:

- a real production route rather than a helper-only test;
- an independent oracle rather than expectations derived from the same helper;
- explicit production dependencies and representative mutations;
- retention of unique historical/boundary witnesses;
- no deletion by survivor workers before independent certification;
- mutation execution in a disposable/restored worktree with receipts.

The package satisfies those proof-form requirements. It uses a standard instant oracle, a real SQLite route, frozen-clock freshness, actual CLI JSON rendering, named mutations, and three executed temporary production mutations. It proposes no deletion.

## Contradictions and resolutions

1. **Manifest dirty flag vs. empty tracked delta**  
   Resolution: report both; target the reproducible named commit and do not fabricate omitted-file deletions.

2. **Mission asks for normalization vs. parser tests preserve offsets**  
   Resolution: preserve provider/archive parser representation and normalize at the shared public temporal surface.

3. **Older Bead plan requested a new clock seam vs. later close evidence says existing seam works**  
   Resolution: follow later Bead notes and current source; use `frozen_clock_modules`.

4. **Microsecond mission cases vs. millisecond durable schema**  
   Resolution: microsecond laws at parse/surface/order/span layers; one-millisecond exact witnesses for the real archive query route.

5. **Generic duration number vs. multiple evidence meanings**  
   Resolution: add only the explicit `inferred_event_gap` label to phase spans and retain existing provider/DOM/UI labels untouched.

## Dominated-deletion assessment

No deletion is proposed. The exact witnesses are intentionally non-repetitive:

- leap/month rollover and half-hour offset;
- year rollover, +14:00, and `.999999` precision;
- declared-naive provider input;
- fractional numeric epoch;
- DST repeated wall time;
- DST skipped wall time;
- durable one-millisecond closed boundary;
- absent timestamp.

Any consolidation/deletion should be certified independently after the survivor patch is applied, as required by the supplied diet workflow.
