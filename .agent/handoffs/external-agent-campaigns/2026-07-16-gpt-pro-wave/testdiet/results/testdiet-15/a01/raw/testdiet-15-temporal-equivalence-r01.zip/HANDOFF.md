# HANDOFF — testdiet-15 equivalent-instant temporal behavior

Job: `testdiet-15`  
Result: `testdiet-15-temporal-equivalence-r01.zip`

## Mission completed

This draft implements a coherent temporal survivor layer across the existing Polylogue production routes rather than introducing a separate temporal framework. It makes every instant exposed by the shared temporal evidence payload use one UTC representation, keeps low-level provider/archive parsing contracts intact, labels adjacent-event spans as inferred gaps, and adds independent-oracle tests for equivalent instants, exact closed intervals, ordering, freshness receipts, provider duration units, absent timestamps, DST transitions, and public rendering.

The production change is deliberately narrow. Provider wire values may still preserve their declared offset where existing parser contracts require that behavior. Canonicalization occurs at the shared public temporal projection boundary, where equivalent instants must no longer serialize differently.

## Snapshot identity and reconstruction

Authority was reconstructed from the supplied Polylogue project-state archive.

- Branch: `master`
- Commit: `b9052e09103502017c0f510ecc699aac395de23c`
- Commit date: `2026-07-17T08:28:35+02:00`
- Commit subject: `fix(daemon): bound raw maintenance admission (#2975)`
- Author: `Sinity <ezo.dev@gmail.com>`
- Manifest source: `polylogue-manifest.json`
- Git source: `polylogue-all-refs.bundle`
- Current-working-tree source: `polylogue-working-tree.tar.gz`

The manifest reports `dirty: true`, but all three branch-delta artifacts (`polylogue-branch-delta.patch`, `polylogue-branch-delta-files.txt`, and `polylogue-branch-delta-log.txt`) are zero bytes. The current-working-tree tar intentionally omits 1,239 tracked paths, overwhelmingly `.agent/`, plus `.beads/`, `.claude/`, `AGENTS.md`, `flake.lock`, and `uv.lock`; it also contains one untracked `browser-extension/package-lock.json`. I therefore reconstructed the authority by checking out the bundle commit and overlaying the current-working-tree tar without interpreting archive omissions as deletions. That reconstruction was tracked-clean before this implementation. No recoverable tracked dirty patch was available, so `PATCH.diff` targets the named commit exactly.

## Evidence inspected

Repository instructions and architecture:

- `CLAUDE.md`, `AGENTS.md`, and `TESTING.md`
- substrate-first semantics and leaf surface adapters
- focused pytest policy, existing Hypothesis property suite, `tests/infra/frozen_clock.py`, and clock-hygiene lint

Production dependencies followed:

- `polylogue/core/timestamps.py`
- `polylogue/core/dates.py`
- `polylogue/surfaces/payloads.py`
- `polylogue/surfaces/temporal_evidence.py`
- `polylogue/archive/query/source_freshness.py`
- `polylogue/archive/query/spec.py` and the SQLite range-lowering path
- `polylogue/storage/sqlite/archive_tiers/archive.py`
- `polylogue/sources/parsers/chatgpt.py`
- `polylogue/sources/parsers/browser_capture.py`
- `polylogue/cli/read_views/standard.py`
- `polylogue/context/compiler.py`
- `polylogue/api/archive.py`

Relevant existing tests and infrastructure:

- timestamp guards and archive datetime contracts
- temporal evidence builder and CLI read-view tests
- source-freshness fixture/receipt tests
- ChatGPT and browser-capture parser tests
- `SessionBuilder` and real SQLite archive query fixtures
- frozen-clock fixture and shared strategy package

Relevant Beads records:

- `polylogue-896y`: production time-authority audit; explicitly identifies external testdiet-15 as lacking an owning bead
- `polylogue-cpf.6`: later evidence supersedes the proposed new core clock seam; existing module-symbol frozen-clock patching is sufficient
- `polylogue-cpf.5`: weakest temporal provenance must not be laundered
- `polylogue-cuxz`: preserve temporal source, unknowns, authority, freshness, and public evidence axes
- `polylogue-3v1.2`: provider-reported elapsed, provider UI elapsed, DOM-observed wall time, and inferred gaps are distinct and must never be called model compute
- `polylogue-1xc.13`: exact-source freshness and receipt constraints
- `polylogue-q30k`: no epoch-zero absence sentinel
- `polylogue-fnm.3`: exact duration boundary and missing timestamps remain missing
- `polylogue-0mu`: newest/richer provider evidence must not be silently downgraded
- `polylogue-1wtm`: warning that tautological wall/engaged duration constructs are not independent measurements

Relevant history inspected:

`f54e87ea1`, `576c4b4f5`, `ce2f62ac6`, `d40d00a31`, `b6c78adfc`, `f0c1b489b`, `b054f2ba9`, `392643214`, `97459e61d`, `c67fd4539`, `122f28796`, `89b14e587`, `e7c1b2064`, and `6c12e9234`.

Test-suite-diet evidence inspected included the architecture, proof-form, execution, survivor-law, mutation-certification, and real-route guidance in the supplied `testsuite_diet` archive.

## Mechanism

### One public instant model

`polylogue/surfaces/temporal_evidence.py` now defines one Pydantic `Annotated` datetime type with an after-validator that:

1. rejects naive or otherwise non-aware values;
2. converts every accepted value to UTC;
3. is used by event timestamps, bounds, buckets, activity bands, and phase-span endpoints.

The temporal builder normalizes `since` and `until` before selection and returns those normalized bounds. Its interval remains explicitly closed: `occurred_at >= since` and `occurred_at <= until`.

This does not alter `parse_timestamp` or `parse_archive_datetime`. Existing tests intentionally require offset-aware parser results to retain the provider/archive offset representation, so changing those parser contracts would be a stale and unnecessarily broad rewrite.

### Duration semantics remain separate

`TemporalPhaseSpan` gains the additive literal field:

```text
duration_semantics = "inferred_event_gap"
```

That makes adjacent-event subtraction explicit evidence rather than an unlabeled duration that a consumer could mistake for provider elapsed time or model compute time. Existing ChatGPT and browser-capture payloads remain unchanged and continue to use:

- `provider_reported_elapsed`
- `provider_ui_elapsed`
- `dom_observed_wall`

Tests assert that none is relabeled as `model_compute`.

### Independent oracle

`tests/infra/strategies/temporal.py` is independent of production temporal helpers. It uses only standard-library `datetime`, `timedelta`, `timezone`, and `Decimal` arithmetic to map supported wire values to integer Unix-epoch microseconds. It does not call Polylogue parsing, canonicalization, query, storage, or surface helpers.

The generated cases select two distinct offsets from a deliberately varied set, including UTC, negative offsets, half-hour/quarter-hour offsets, and the +14:00 extreme. The expected instant is an integer-microsecond value, avoiding local-wall comparisons and binary floating-point timestamps in the oracle.

## Decisions

1. **Canonicalize at the shared public projection boundary, not in provider parsing.** This preserves exact wire/offset behavior where current contracts depend on it while making public output representation-invariant.
2. **Use the existing frozen-clock infrastructure.** `polylogue-cpf.6` records that a new core clock seam was based on stale premises; `frozen_clock_modules("polylogue.core.dates")` is the accepted route.
3. **Test both declared precisions.** Parsing/surface laws retain microseconds. The real SQLite archive query law uses one-millisecond neighbors because the durable archive schema stores epoch milliseconds.
4. **Keep absent timestamps absent.** No zero epoch or synthetic occurrence is introduced.
5. **Use a real storage/query route.** The range survivor writes sessions through `SessionBuilder`, opens `Polylogue`, lowers `since`/`until`, and executes the SQLite query.
6. **Do not add a parallel interval DSL or test-only production API.** The law drives existing typed production interfaces.
7. **Do not delete tests.** No existing test is certified as dominated in this package. The four exact wire pairs each cover a distinct failure dimension, so none is proposed for deletion.

## Changed files

- `polylogue/surfaces/temporal_evidence.py`
  - canonical UTC validation for every public temporal instant
  - normalized public bounds
  - explicit `inferred_event_gap` phase-span semantics
- `tests/infra/strategies/temporal.py`
  - independent epoch-microsecond oracle and equivalent-offset strategy
- `tests/infra/strategies/__init__.py`
  - exports the temporal strategy domain
- `tests/property/test_temporal_equivalence_laws.py`
  - exact and generated equivalent-instant survivor laws
  - real SQLite closed-range route
  - DST fold/gap, ordering, precision, and absence laws
- `tests/unit/archive/test_source_freshness.py`
  - frozen-clock, aware-offset, declared-naive, and offset cursor-wire receipt equivalence
- `tests/unit/cli/test_query_verbs_runtime.py`
  - actual CLI temporal JSON route renders non-UTC inputs as UTC
- `tests/unit/sources/test_parsers_chatgpt.py`
  - equivalent provider timestamps and exact duration-unit/provenance behavior
- `tests/unit/sources/test_browser_capture.py`
  - native, DOM wall, and provider UI duration semantics remain distinct
- `tests/unit/surfaces/test_temporal_evidence.py`
  - adjacent phase spans expose inferred-gap semantics

`FILES/` is omitted because the unified diff fully and unambiguously carries every change.

## Acceptance matrix

| Mission behavior | Production route exercised | Survivor evidence | Result |
|---|---|---|---|
| Parsing equivalent instants | `core.timestamps.parse_timestamp` and `canonical_timestamp_text` | four exact wire pairs plus 80 generated offset pairs against independent epoch-microsecond oracle | pass |
| Naive/aware provider inputs | parser declaration that naive ISO means UTC | exact naive/Z pair; freshness `now` naive/aware pair | pass |
| Filtering and ranges | temporal window builder plus real `Polylogue.filter().since().until().list_summaries()` SQLite path | closed same-instant surface range and millisecond before/at/after archive rows | pass |
| Start/end inclusivity | `_in_window` and SQLite `>=`/`<=` lowering | event exactly at both bounds; exact archive row at both bounds | pass |
| Ordering | shared temporal window sort | equal instant represented with different offsets orders by `event_id`; +1 microsecond remains later | pass |
| Freshness | `project_named_source_freshness` | frozen clock, UTC+02 aware now, declared-naive UTC now, and equivalent offset cursor wire produce equal full projections | pass |
| Receipts | exact-source freshness receipt/digest | receipt remains exact-source, avoids archive-wide aggregate, preserves age and projection digest | pass |
| Provider durations | ChatGPT native generation parser | `finished_duration_sec=5190` remains exactly `5,190,000 ms` across offset representations | pass |
| Observed/inferred semantics | browser capture and temporal phase spans | three native/DOM/UI labels stay distinct; adjacent span is `inferred_event_gap`; none is model compute | pass |
| Public rendering | shared Pydantic payload, `to_json`, and actual CLI temporal JSON route | equivalent instants produce byte-equal model JSON; non-UTC summaries render with `Z` | pass |
| DST fold | parser absolute comparison | repeated New York 01:30 with `-04:00` and `-05:00` remains one hour apart | pass |
| DST gap | phase-span calculation | `01:59:59.999999-05:00` to `03:00:00-04:00` is one microsecond, not one wall hour | pass |
| Leap/month/year boundaries | parser/canonical text | leap-day/month and year/+14:00 exact wire pairs | pass |
| Subsecond precision | parser, ordering, phase span | 6-digit exact wires, generated microseconds, +1 microsecond ordering, one-microsecond DST gap | pass |
| Missing timestamp | parser and summary projection | `None` remains `None`; no synthetic temporal event or epoch-zero value | pass |

## Apply order

From a clean checkout of `b9052e09103502017c0f510ecc699aac395de23c`:

```bash
git apply --check PATCH.diff
git apply PATCH.diff
```

Then run the focused verification from `TESTS.md`. No migration, generated-file refresh, or manual file copy is required.

## Verification performed

- clean patch whitespace check
- Ruff over all changed Python files
- mypy over all changed production/test modules
- repository test-clock-hygiene lint
- 332-test focused route suite
- three temporary production mutation trials, each observed failing and then restored
- fresh detached worktree `git apply --check`
- patch application into that fresh worktree
- 18-test post-application smoke suite in the fresh worktree

Exact commands and outputs are recorded in `TESTS.md`.

## Risks and limitations

- The full repository suite, integration suite, browser-extension JavaScript suite, live daemon, live browser, operator archive, secrets, and NixOS deployment were not available or run. They remain **unverified**.
- The additive `duration_semantics` field changes serialized `TemporalPhaseSpan` objects. Consumers that reject unknown/additive fields instead of following the project’s payload evolution rules may need adjustment.
- Canonical UTC public output is an intentional representation change. A consumer that improperly treated the original offset as semantic public data will now receive the equivalent UTC representation; parser-level wire preservation remains available internally.
- The real durable query law proves the schema’s millisecond precision, while parser/surface laws prove microseconds. It does not claim the archive schema stores microseconds.
- This package does not exhaustively add equivalent-wire fixtures to every provider parser or every CLI/MCP/API/HTTP renderer. It establishes and tests the shared projection seam plus representative real routes.
- The archive manifest’s `dirty: true` state cannot be reconstructed as a tracked patch from the supplied branch-delta artifacts. The patch therefore targets the named commit, which is the only reproducible code authority.

## Remaining verification

A maintainer should run the repository-managed affected test lane and, before merge, the project’s normal quick/full gate on a network-complete environment. A browser-extension run is useful because the package asserts the Python-side semantics already emitted by the extension but does not execute JavaScript capture.

## Value of another iteration

A CI compatibility finding would likely require only a **small repair**: an import/version adjustment, a payload golden update, or a consumer accepting the additive phase-span field.

A **substantial second pass** could add equivalent-instant fixtures across more provider formats, explicit MCP/API/HTTP golden parity, Markdown golden output, browser-extension JavaScript lifecycle tests, and broader mutation certification. That could add meaningful breadth, but it would not replace the central mechanism delivered here: one public UTC instant model, explicit inferred-gap semantics, independent-oracle laws, and representative real-route proofs.
