# TESTS — temporal equivalence survivor design and receipts

## Proof design

The suite combines exact historical/provider wire witnesses, generated equivalent-offset cases, a standard-library oracle, real storage/query execution, frozen-clock freshness, and public rendering. Expected instants do not come from production helpers under test.

### Independent oracle

`tests/infra/strategies/temporal.py` maps supported inputs to integer Unix-epoch microseconds using:

- ISO parsing from the Python standard library
- explicit UTC interpretation for declared-naive provider inputs
- `timedelta` arithmetic from an aware epoch
- `Decimal` with explicit half-even rounding for numeric wires

It does not import Polylogue temporal code.

### Exact unique provider wire witnesses

| Witness | Wire A | Wire B | Unique obligation |
|---|---|---|---|
| leap-day/month boundary | `2024-02-29T23:59:59.123456Z` | `2024-03-01T05:29:59.123456+05:30` | leap day, month rollover, half-hour offset, microseconds |
| year boundary/max positive offset | `2024-12-31T23:59:59.999999Z` | `2025-01-01T13:59:59.999999+14:00` | year rollover, +14:00 extreme, maximum microsecond |
| declared-naive UTC provider input | `2024-02-29T23:59:59.123456` | `2024-02-29T23:59:59.123456Z` | current naive-provider interpretation contract |
| fractional epoch provider wire | `1709251199.123456` | `2024-02-29T23:59:59.123456Z` | numeric/ISO equivalence and subsecond unit fidelity |

These examples are not proposed for consolidation because each carries a distinct boundary or representation obligation. No existing tests are proposed for deletion by this package.

## Survivor inventory

### `tests/property/test_temporal_equivalence_laws.py`

- `test_exact_provider_wire_witnesses_name_the_same_standard_instant`
  - Production dependency: `parse_timestamp`, `canonical_timestamp_text`
  - Oracle: integer epoch microseconds
  - Kills: timezone strip, local-time interpretation, precision truncation

- `test_parse_timestamp_matches_independent_standard_instant`
  - Production dependency: `parse_timestamp`
  - 80 generated cases with two distinct offsets per instant
  - Kills: offset stripping and local-wall equality/comparison

- `test_closed_window_and_public_rendering_are_representation_invariant`
  - Production dependency: `TemporalEvidenceEvent`, `build_temporal_evidence_window`, Pydantic JSON serialization
  - 60 generated cases
  - Explicit interval rule: closed `[since, until]`
  - Kills: exclusive lower/upper comparator, public offset leakage, local-wall sorting

- `test_equal_instants_order_by_event_id_without_truncating_subseconds`
  - Production dependency: shared temporal sort
  - Kills: unstable representation-based order, precision truncation

- `test_dst_fold_witnesses_remain_distinct_absolute_instants`
  - Production dependency: parser and aware comparison
  - Kills: naive local-wall comparison that collapses both 01:30 values

- `test_dst_gap_adjacent_events_expose_an_inferred_one_microsecond_gap`
  - Production dependency: `_phase_spans` through the public builder
  - Kills: local-wall subtraction, precision truncation, semantic relabeling as model compute

- `test_absent_provider_timestamps_remain_absent`
  - Production dependency: parser, canonicalizer, summary-to-event projection
  - Kills: epoch-zero or synthetic-time fallback

- `test_archive_query_closed_range_is_inclusive_and_offset_invariant`
  - Production dependency: `SessionBuilder` -> archive SQLite -> `Polylogue.filter()` -> query lowering -> `list_summaries()`
  - Explicit storage precision: one millisecond before/at/after
  - Kills: SQL `>`/`<` boundary mutation, offset stripping, local-wall range comparison

### `tests/unit/archive/test_source_freshness.py`

- `test_equivalent_observation_instants_produce_identical_freshness_receipts`
  - Production dependency: `project_named_source_freshness`
  - Existing infrastructure: `frozen_clock_modules("polylogue.core.dates")`
  - Inputs: frozen implicit now, UTC+02 aware now, declared-naive UTC now, offset ISO cursor wire
  - Kills: local-wall age calculation, offset-dependent digest, non-exact receipt path

### `tests/unit/cli/test_query_verbs_runtime.py`

- strengthened `test_read_view_temporal_projects_selected_summaries`
  - Production dependency: actual CLI read-view dispatcher and JSON renderer
  - Inputs: +05:30 and +02:00 summary timestamps
  - Kills: removal of the shared public UTC validator, which would leak offsets to CLI JSON

### `tests/unit/sources/test_parsers_chatgpt.py`

- `test_chatgpt_generation_timing_is_invariant_to_equivalent_provider_timestamp_wires`
  - Production dependency: ChatGPT native parser and generation lifecycle event construction
  - Inputs: equivalent UTC, +02:00, and +09:00 start/end wires
  - Required unit: `finished_duration_sec=5190` -> `5,190,000 ms`
  - Required semantics: `provider_reported_elapsed`
  - Kills: duration-unit mutation, offset-strip/local-wall calculation, relabeling as wall/inferred/model compute

### `tests/unit/sources/test_browser_capture.py`

- strengthened `test_browser_capture_preserves_live_and_native_generation_measurements`
  - Production dependency: browser-capture parser delegation/reconciliation
  - Required distinct meanings: `provider_reported_elapsed`, `dom_observed_wall`, `provider_ui_elapsed`
  - Kills: collapsing all durations to one generic or model-compute label

### `tests/unit/surfaces/test_temporal_evidence.py`

- strengthened `test_temporal_window_computes_adjacent_phase_spans`
  - Production dependency: shared phase-span builder
  - Kills: removal or relabeling of `inferred_event_gap`

## Environment setup facts

Python: `3.13.5`  
uv: `0.10.0`

The first `uv run pytest` created a production-only environment, so collection lacked Hypothesis. That was an environment-bootstrap result, not a test result.

`uv sync --extra dev --frozen` was attempted and failed because the environment could not resolve a locked `files.pythonhosted.org` artifact (`genson`). No lock update was retained; an incidental `uv.lock` URL rewrite was restored immediately.

To execute meaningful local checks, the already-ignored `.venv` was populated with the minimum declared test/static dependencies, including pytest, Hypothesis, pytest-asyncio, pytest-randomly, pytest-benchmark, pytest-timeout, pytest-xdist, Ruff, mypy, and hypothesis-jsonschema. No dependency or lock file is in `PATCH.diff`.

## Baseline before implementation

```bash
.venv/bin/pytest -q -p no:randomly \
  tests/unit/surfaces/test_temporal_evidence.py \
  tests/unit/core/test_timestamp_guards.py
```

Result: `102 passed in 8.88s`.

## Final focused route suite

```bash
.venv/bin/pytest -q -p no:randomly \
  tests/property/test_temporal_equivalence_laws.py \
  tests/unit/core/test_timestamp_guards.py \
  tests/unit/surfaces/test_temporal_evidence.py \
  tests/unit/archive/test_source_freshness.py \
  tests/unit/sources/test_parsers_chatgpt.py \
  tests/unit/sources/test_browser_capture.py \
  tests/unit/cli/test_query_verbs_runtime.py \
  tests/unit/devtools/test_temporal_read_profile.py
```

Result: `332 passed in 10.49s`.

An earlier run of the same production areas reached `267 passed` and five setup errors because `pytest-xdist` had not yet been installed and `tests/conftest.py` requires its `worker_id` fixture. After installing the project-declared plugin, the unchanged narrower command passed `272 passed in 10.74s`. The setup errors were not code failures.

## Static and policy verification

```bash
git diff --check

.venv/bin/ruff check \
  polylogue/surfaces/temporal_evidence.py \
  tests/infra/strategies/__init__.py \
  tests/infra/strategies/temporal.py \
  tests/property/test_temporal_equivalence_laws.py \
  tests/unit/archive/test_source_freshness.py \
  tests/unit/cli/test_query_verbs_runtime.py \
  tests/unit/sources/test_browser_capture.py \
  tests/unit/sources/test_parsers_chatgpt.py \
  tests/unit/surfaces/test_temporal_evidence.py

.venv/bin/mypy \
  polylogue/surfaces/temporal_evidence.py \
  tests/infra/strategies/temporal.py \
  tests/property/test_temporal_equivalence_laws.py \
  tests/unit/archive/test_source_freshness.py \
  tests/unit/cli/test_query_verbs_runtime.py \
  tests/unit/sources/test_browser_capture.py \
  tests/unit/sources/test_parsers_chatgpt.py \
  tests/unit/surfaces/test_temporal_evidence.py

.venv/bin/python -m devtools.verify_test_clock_hygiene
```

Results:

- `git diff --check`: pass
- Ruff: `All checks passed!`
- mypy: `Success: no issues found in 8 source files`
- clock hygiene: `test files scanned: 901`, `violations: 0`

## Anti-vacuity mutation receipts

Each mutation was made temporarily in the real production file, the named survivor was run, and the file was restored before continuing. A post-restore property/parser run passed `12 passed in 1.78s`; the final 332-test run also passed.

### 1. Public offset leak

Temporary mutation in `polylogue/surfaces/temporal_evidence.py`:

```diff
- return value.astimezone(UTC)
+ return value
```

Command:

```bash
.venv/bin/pytest -q -p no:randomly \
  tests/property/test_temporal_equivalence_laws.py::test_closed_window_and_public_rendering_are_representation_invariant
```

Observed result: exit `1`, one failed. Hypothesis falsified the law with equivalent `-12:00` and `-08:00` representations of epoch microseconds `978307200000000`; public payloads differed.

### 2. Exclusive lower boundary

Temporary mutation in `_in_window`:

```diff
- if since is not None and occurred_at < since:
+ if since is not None and occurred_at <= since:
```

Same survivor command as above.

Observed result: exit `1`, one failed. The event exactly at the bound was excluded and `event_count` became `0` instead of `1`.

### 3. Provider duration-unit mutation

Temporary mutation in `polylogue/sources/parsers/chatgpt.py`:

```diff
- elapsed_ms = round(finished_sec * 1000)
+ elapsed_ms = round(finished_sec)
```

Command:

```bash
.venv/bin/pytest -q -p no:randomly \
  tests/unit/sources/test_parsers_chatgpt.py::test_chatgpt_generation_timing_is_invariant_to_equivalent_provider_timestamp_wires
```

Observed result: exit `1`, one failed. The parser produced `5190` where the contract requires `5190000` milliseconds.

Mutation logs retained during construction were not placed in the result ZIP because `TESTS.md` carries the exact mutation and observed failure, while the deliverable contract requests the cohesive patch/evidence package rather than temporary shell artifacts.

## Fresh-checkout patch verification

A detached worktree at the exact snapshot commit was created. Then:

```bash
git apply --check /mnt/data/work15/package/PATCH.diff
git apply /mnt/data/work15/package/PATCH.diff
git diff --check
PYTHONPATH=. /mnt/data/work15/authority/.venv/bin/python -m pytest -q -p no:randomly \
  tests/property/test_temporal_equivalence_laws.py \
  tests/unit/surfaces/test_temporal_evidence.py \
  tests/unit/cli/test_query_verbs_runtime.py::test_read_view_temporal_projects_selected_summaries
```

Results:

- `git apply --check`: pass
- apply: pass
- post-apply whitespace check: pass
- post-apply smoke: `18 passed in 4.26s`

## Unverified checks

- complete repository test suite
- managed `devtools verify`/full release gate in a network-complete environment
- integration/benchmark/scale tiers
- browser-extension JavaScript tests
- live daemon, browser, archive, secrets, or NixOS deployment

No claim in this package depends on those unavailable checks.
