# testdiet-10 handoff: Claude web normalization laws

## Mission and outcome

This package implements one shared Claude web normalization mechanism used by both direct Claude exports and browser-capture parsing. It preserves provider-native conversation/message identity, parent lineage, sibling variants, active-path evidence, model/effort/thinking configuration, structured blocks, Claude artifacts and citations, attachments, timestamps, status, end-turn state, and duration. Authenticated browser captures delegate to the retained native payload and use the envelope only for missing optional metadata and acquired attachment bytes. DOM-only captures use the same message normalizer while declaring degraded fidelity.

The patch is intentionally substrate-first. It changes the existing parser seam and browser-capture adapter; it does not add a second conversation identity, a parallel framework, or any dependency on current DOM selectors.

## Snapshot identity and patch base

Authoritative input: the supplied Polylogue project-state archive `00-polylogue-all.tar(27).gz`.

The archive manifest at `polylogue-manifest.json` records:

- generated at: `2026-07-17T105328Z`
- source path at generation: `/realm/project/polylogue`
- branch: `master`
- commit: `b9052e09103502017c0f510ecc699aac395de23c`
- dirty: `true`

The bundled Git refs resolve the same commit as `HEAD`, `origin/master`, and `origin/HEAD`. The commit subject is `fix(daemon): bound raw maintenance admission (#2975)`.

The supplied `polylogue-branch-delta.patch` is zero bytes, its branch-delta report contains no commits or diff stat, and overlaying the supplied working-tree payload onto a checkout of the named commit produced no tracked-file difference. Therefore the only reproducible patch base available in the archive is commit `b9052e09103502017c0f510ecc699aac395de23c` plus a byte-equivalent supplied working tree. The manifest's `dirty=true` state cannot be reconstructed from the supplied artifacts. This is a source-authority limitation, not silently treated as a clean operator worktree claim.

## Inspected authority

The implementation followed these repository surfaces beyond the obvious parser files:

- root `CLAUDE.md`, especially substrate ownership, computed native identity, and detector tightness order;
- `polylogue/sources/dispatch.py` detection, recursive lowering, and parser routing;
- `polylogue/browser_capture/models.py` typed envelope/turn/attachment contracts;
- `polylogue/sources/parsers/base_models.py` typed message, block, attachment, web-construct, session-event, branch, status, and configuration fields;
- `polylogue/sources/parsers/base_support.py` shared block and attachment extraction behavior;
- `polylogue/sources/parsers/browser_capture.py` native delegation, fidelity flags, capture events, and attachment-byte merge;
- `polylogue/sources/parsers/claude/{common.py,ai_parser.py}` and the retained Claude design-chat route;
- `browser-extension/src/content/claude.js` and `browser-extension/src/backfill/providers.js`, including authenticated `tree=True`, `render_all_tools=true`, `consistency=strong` capture and `native_full` versus `dom_degraded` declarations;
- the Claude AI v1 session schema and privacy-safe generated representatives `sample-00.json` and `sample-01.json`;
- existing dispatch, browser-capture, parser catalog, parser contract, schema-driven, provider contract, storage roundtrip, and tool-result role tests;
- relevant Beads and source/history evidence summarized in `EVIDENCE.md`;
- the supplied, explicitly slightly stale source-normalization test-suite packet, used as methodology rather than code authority.

## Mechanism

### Shared Claude evidence normalization

`normalize_chat_messages()` now forms one provider-family normalization seam. It accepts structured Claude records without dividing them into strict-Pydantic and loose fallback behavior. For each provider message it records:

- native message ID, with a typed degraded flag when no ID exists;
- parent ID aliases and explicit position/branch/variant/active fields when supplied;
- role, visible text, creation/update timestamps, model, effort, duration, delivery status, end-turn, and thinking configuration;
- structured content blocks and message-scoped attachments.

Duplicate native IDs are resolved deterministically to the richest structured record and produce both an ingest diagnostic and a session diagnostic event. Raw source evidence remains authoritative and available to reparsing; the normalizer does not fieldwise combine potentially distinct revisions.

Lineage depth is computed iteratively, so long trees do not hit Python recursion limits. Sibling rank is derived from explicit provider variant/branch fields when present and otherwise from stable timestamp/native-ID evidence, independent of input record order. A detected parent cycle degrades with `degraded:claude-lineage-cycle` instead of inventing a valid tree.

Flat legacy records retain source order only when lineage, explicit positions, and usable timestamps cannot establish chronology. This preserves the old flat-export contract without allowing array order to override structured tree evidence.

Active-path facts are claimed only from explicit active leaf/path evidence or a uniquely terminal lineage. Multiple unlabelled terminal branches remain unknown. A flat legacy sequence remains fully active with its final ordered message as leaf for compatibility.

### Edits and update evidence

An explicit provider revision/edit marker (`version_uuid`, revision ID, edited marker, or edited timestamp) produces a `message_revision` session event. A changed provider `updated_at` without such a marker produces neutral `provider_message_update` evidence. This preserves timestamps and status without guessing that every provider update was a user edit.

Session- and message-level model/effort/thinking settings produce typed `model_configuration` events. Message-specific model/effort values override session defaults. Session status becomes `provider_session_status` evidence.

### Content blocks, citations, and Claude artifacts

Known Claude block types continue through existing typed block extraction. Thinking, tool use, tool result, text, image/document, token-budget, voice-note, and code evidence remain structured.

Text-block citations become typed `content_reference` web constructs, including a valid zero `start_index`. Claude artifact tool inputs with `application/vnd.ant.*` MIME types become typed `canvas` constructs while retaining the normal tool-use block and input.

An unknown provider block type is not reinterpreted from display text. It creates a non-semantic structural block witness containing the provider type and `raw_preserved_in_source=true`; the retained raw source remains the authority for opaque fields.

Messages are emitted when they have text, blocks, or attachments. Attachment-only and block-only turns therefore survive normalization.

### Direct Claude export route

`parse_ai()` now sends ordinary Claude web payloads through the shared normalizer while retaining the existing design-chat parser. It normalizes session identity/title/timestamps/kind, model and thinking configuration, current leaf aliases, top-level and message attachments, status events, duration, model inventory, and diagnostics.

The former strict-versus-loose split was removed because it created two normalization contracts: strict records lost structured/lineage facts while loose records followed different behavior. The public `ClaudeAISession`/`ClaudeAIChatMessage` models and their tests remain; they were not deleted or repurposed.

### Authenticated browser-capture route

For a Claude envelope carrying `raw_provider_payload.chat_messages`, the parser:

1. delegates session semantics to the direct Claude parser;
2. fills only missing optional title/timestamps/session-model evidence from the same envelope;
3. never replaces the native payload's conversation ID or message-specific model;
4. merges envelope-acquired bytes into matching native attachment rows while preserving native size, origin, provider file/drive IDs, name, MIME type, and message association;
5. adds browser capture/session-kind/events and `native_full` fidelity evidence.

A test deliberately gives the envelope a conflicting conversation ID and capture ID. The result retains the native payload ID, proving that the envelope does not create a second browser conversation identity.

For a Claude envelope without a native payload, typed turns are mapped into the same Claude normalizer. Typed turn identity overrides any echoed provider metadata. Lineage, model/effort/status, attachment-only turns, and acquired bytes survive, while the result carries explicit DOM/compact degraded fidelity. The fallback does not pretend to reconstruct native thinking or tool blocks absent from the projection.

## Decisions

- Keep provider-native conversation and message identity authoritative; browser envelope and capture IDs are acquisition metadata, not replacement identity.
- Normalize direct exports, authenticated native captures, and DOM fallback through one Claude message-evidence seam, while preserving the existing design-chat route.
- Infer active lineage only from explicit provider evidence or a unique terminal chain; do not choose among ambiguous siblings from record order.
- Preserve flat legacy array order only when no lineage, explicit position, or timestamp evidence exists.
- Distinguish explicit revisions from generic provider updates; an update timestamp alone does not prove an edit.
- Enrich native attachments with acquired bytes without replacing native metadata, IDs, or associations.
- Represent unknown blocks as structural witnesses backed by retained raw source rather than guessing semantics from rendered text.
- Diagnose duplicate IDs and cycles, choosing deterministic bounded behavior rather than fabricating a merged revision or recursive tree.

## Changed files

The unified patch changes five files: 1,633 insertions and 167 deletions.

- `polylogue/sources/parsers/claude/common.py`: shared message-evidence model; deterministic lineage/variant/active-path normalization; model/thinking/update/status events; rich block/artifact/citation support; attachment-only survival; diagnostics.
- `polylogue/sources/parsers/claude/ai_parser.py`: one ordinary Claude web route through the shared normalizer; session metadata/status/top-level attachment integration.
- `polylogue/sources/parsers/browser_capture.py`: native optional-metadata fill, native-authoritative attachment-byte enrichment, Claude DOM fallback through the shared normalizer, fidelity preservation.
- `tests/unit/sources/test_claude_web_normalization.py`: six privacy-safe real-route and storage-roundtrip laws.
- `tests/unit/sources/test_parsers_claude_ai_catalog.py`: updates one now-stale comment describing the removed strict/loose parser split; test behavior is unchanged.

No existing test or helper was deleted. No `FILES/` directory is included because `PATCH.diff` is complete and unambiguous. No dominated local test snapshot is proposed for deletion in this package; any future subtraction should be independently certified against the new route-level laws.

## Acceptance matrix

| Mission obligation | Implementation evidence | Verification state |
| --- | --- | --- |
| Conversation identity | Native export ID; browser envelope decoy cannot replace it | Implemented and tested |
| Message identity | Native IDs and typed missing-ID degradation | Implemented and tested through route/roundtrip |
| Edits | Explicit revision markers become `message_revision`; timestamp-only updates stay neutral | Implemented and tested |
| Variants/branches | Parent graph, stable sibling rank, branch/variant, reorder invariance | Implemented and tested |
| Active path/leaf | Explicit leaf ancestry; unique-terminal inference; ambiguity remains unknown | Implemented and tested |
| Model/effort/thinking | Session defaults, per-message overrides, typed configuration events | Implemented and tested |
| Content block types | Thinking/tool/text and existing shared block types | Implemented and tested |
| Claude artifacts/citations | `canvas` and `content_reference`, including index zero | Implemented and tested |
| Attachments | Message/session/attachment-only rows; acquired bytes enrich without metadata replacement | Implemented and tested |
| Timestamps/status/end-turn/duration | Normalized session/message timestamps, status fields/events, duration sum | Implemented and tested |
| Native versus fallback fidelity | Native payload preferred; stale DOM ignored; fallback declares degraded and lacks unavailable native blocks | Implemented and tested |
| Ambiguous detector shape | Browser envelope also contains a ChatGPT-like `mapping` decoy | Implemented and tested |
| Real lower/parser route | Tests call `detect_provider()` and `parse_payload()`; storage test writes and hydrates | Implemented and tested |
| Long/cyclic lineage | 1,100-node route and cycle diagnostic | Implemented and tested |
| Live authenticated Claude canary | Requires operator browser/account/receiver | `unverified` |
| Live daemon/archive/NixOS deployment | Not available in the supplied snapshot environment | `unverified` |

## Apply order

From a checkout whose `HEAD` is exactly `b9052e09103502017c0f510ecc699aac395de23c`:

```bash
git status --short
git apply --check PATCH.diff
git apply PATCH.diff
git diff --check
```

Then run the focused verification commands recorded in `TESTS.md`. The patch was generated with full Git blob indexes and validated against a clean detached worktree at the named commit.

If applying to a worktree that contains an operator dirty patch not present in the supplied archive, first preserve that patch and resolve overlap manually; this package cannot account for missing bytes.

## Verification performed and remaining

Performed in the supplied container against Python 3.13.5:

- Python byte compilation: passed for all changed Python files.
- Ruff format check: passed for all changed Python files.
- Ruff lint: passed for all changed Python files.
- Mypy: passed for all changed Python files.
- Focused detector/lower/parser/browser/storage compatibility matrix: `157 passed in 5.24s`.
- Provider contracts, schema-driven tests, and tool-result role compatibility: `44 passed in 3.26s`.
- Claude source-law attachment metadata and extracted-byte witnesses: `2 passed in 0.68s`.
- Privacy-safe generated Claude representatives: both detected and parsed; `sample-00` produced 3 messages/20 attachments/1 event, `sample-01` produced 6 messages/29 attachments/2 events.
- Patch apply check on a clean detached worktree: passed.
- Applied-file SHA-256 comparison against the implementation worktree: all five files matched.
- New route/catalog tests in the clean applied worktree: `18 passed in 2.10s`.

The property-based Claude bundle-cardinality case did not complete in the final environment. A forced 10-second diagnostic timeout showed the main thread inside `SyntheticCorpus.generate()` schema generation, before `parse_payload()` was reached. Longer isolated and aggregate attempts also exceeded their command limits. This is recorded as incomplete rather than a pass or parser failure.

## Risks and limitations

- The archive claims an unavailable dirty state. The patch is apply-ready only against the reproducible commit/tree described above.
- Duplicate message IDs are diagnosed and resolved deterministically to one richest record; they are not fieldwise merged because doing so could fabricate a hybrid revision. The raw retained payload remains available for a future provider-specific rule.
- Unknown blocks receive a structural witness, not a guessed semantic type. Consumers needing opaque fields must consult retained raw evidence or add a declared typed projection.
- Multiple terminal branches without an explicit active leaf remain unknown. This is intentional and may expose previously hidden ambiguity to downstream consumers.
- DOM fallback cannot recover thinking/tool/artifact blocks that the envelope never captured. Its degraded flag is part of the contract, not a promise of native equivalence.
- Browser-extension JavaScript tests were not run because `browser-extension/node_modules` was absent. No JavaScript source was changed.
- No focused mutation runner was executed. Each new law names the production dependency and representative mutation it is designed to kill; actual mutation receipts remain future verification.
- No live authenticated Claude endpoint, extension service worker, receiver daemon, operator archive, secrets, NixOS deployment, or current operator worktree was accessed. Those checks are `unverified`.

## Value of another iteration

A small repair pass could add value by running the existing extension Vitest suite after installing its locked dependencies, repairing or isolating the unrelated synthetic-corpus generation stall so the final Claude bundle law completes, and executing focused mutations over the changed normalization functions. Those steps would improve verification receipts without materially changing the design.

A substantial second pass would require new authority: sanitized exact payloads from current authenticated Claude web captures across account/configuration variants, plus an operator-approved live browser/receiver/archive canary. That could justify additional provider aliases, explicit duplicate-ID revision coalescing, or schema evolution. Without that evidence, a broad second implementation pass is more likely to guess at provider semantics than improve this cohesive patch.
