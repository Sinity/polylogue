# testdiet-10 test design and execution

## Test strategy

The new suite uses privacy-safe structured Claude fixtures with independently planted facts. It exercises production detection, recursive lowering, provider parser dispatch, browser-envelope validation/delegation, typed parser output, and archive write/hydration. Expected branch, model, block, attachment, and status facts are authored directly in the test rather than computed by Claude parser helpers.

The central fixture varies:

- provider-native conversation and message IDs;
- a user root with two assistant siblings representing an obsolete and selected variant;
- reordered source records;
- explicit current leaf and parent chain;
- session model/effort/thinking defaults and a message-specific model/effort/thinking override;
- thinking, tool-use artifact, text citation, and an unsupported provider block;
- message and session attachments;
- an attachment-only active leaf;
- creation/update timestamps, status, end-turn, duration, and explicit revision ID;
- missing optional session metadata in the native payload;
- a browser envelope with stale DOM text, acquired attachment bytes, a conflicting conversation identity, and an ambiguous top-level ChatGPT-like `mapping` shape;
- a DOM-only envelope that necessarily lacks native thinking/tool evidence.

## New tests and anti-vacuity dependencies

### `test_claude_export_normalization_survives_record_reordering`

Production route: `dispatch.detect_provider` -> `dispatch.parse_payload` -> Claude lowering -> `claude.ai_parser.parse_ai` -> `claude.common.normalize_chat_messages`.

Proves native identity, stable parent-derived positions, sibling branch/variant rank, active ancestry, attachment-only emission, model override, effort, status, end-turn, duration, model inventory, thinking configuration, artifact canvas, citation offsets including zero, unknown-block witness, session/message attachments, update/revision events, and source-record reorder invariance.

Representative mutations that must fail:

- remove parent graph handling or force every variant to zero;
- derive siblings from input order rather than stable provider evidence;
- drop session/message thinking metadata;
- filter messages solely on visible text;
- flatten all blocks to display text;
- treat zero citation index as missing;
- label every `updated_at` change as a revision.

### `test_authenticated_browser_capture_uses_native_payload_and_enriches_attachment`

Production route: browser-capture detector precedence -> browser envelope validation -> native Claude delegation -> optional metadata fill -> attachment merge -> capture events/fidelity.

The envelope deliberately also has a ChatGPT-like `mapping`, stale DOM turns, and a conflicting `provider_session_id`/`capture_id`. The native payload must win for conversation/message facts. Acquired bytes must enrich the native attachment while its provider file ID, size, name, MIME type, message association, and OAuth origin survive.

Representative mutations that must fail:

- move browser-capture detection behind the looser ChatGPT mapping detector;
- parse projected DOM turns when a native Claude tree exists;
- replace native conversation identity with the envelope identity;
- replace a native attachment row wholesale when adding acquired bytes;
- remove `native_full` fidelity evidence.

### `test_native_browser_envelope_supplies_only_missing_optional_metadata`

Production route: native Claude delegation plus `_merge_envelope_native_metadata`.

The native payload omits optional title, timestamps, session model/effort/thinking. The envelope fills title/timestamps/session model, while the message-specific native model remains authoritative and no second conversation identity is created.

Representative mutations that must fail:

- never fill optional native omissions;
- overwrite message-specific native model with the envelope session model;
- create duplicate session-level model events;
- replace provider-native identity during metadata fill.

### `test_claude_dom_fallback_keeps_identity_lineage_and_declares_degraded_fidelity`

Production route: browser-capture detector -> typed DOM envelope -> Claude fallback turn mapping -> shared normalizer.

Proves typed turn identity, parent/variant/active facts, status/end-turn, attachment-only leaf, acquired bytes, and explicit DOM degradation. It compares native and fallback block inventories to prove fallback does not claim unavailable thinking/tool evidence.

Representative mutations that must fail:

- route Claude DOM turns through the old generic flat parser;
- flatten lineage or force all active-path values true;
- discard attachment-only turns;
- mark DOM fallback as native full;
- synthesize thinking/tool blocks from display text.

### `test_claude_lineage_walk_is_iterative_and_cycle_diagnostic`

Production route: direct detection/lowering/parser with the shared lineage walker.

A 1,100-message chain proves the production walk is iterative and position/leaf facts reach the final turn. A two-node cycle proves bounded degradation and no invented leaf.

Representative mutations that must fail:

- restore recursive depth traversal (exceeds the ordinary Python recursion limit);
- remove cycle detection or cycle ingest diagnostics;
- invent a terminal active leaf for a closed cycle.

### `test_claude_normalization_survives_archive_write_and_hydration`

Production route: raw bytes -> parser roundtrip helper -> archive writer -> SQLite physical rows -> hydrated domain session.

Proves branch/variant, active path/leaf, parent linkage, status, end-turn, model, configuration/revision events, rich blocks, and attachment-only material survive beyond a parser return object.

Representative mutations that must fail:

- populate parser-only fields that the writer drops;
- collapse variants during storage;
- omit parent resolution, status/end-turn, session events, blocks, or attachment association;
- make the test assert only the immediate `ParsedSession`.

## Existing compatibility witnesses retained

No existing test or helper was deleted. The run includes existing browser native/fallback tests, dispatch ordering and payload lowering, base Claude helper contracts, Claude semantic catalog tests, parser contract tests, provider contracts, schema-driven samples, and Anthropic tool-result role reclassification.

One stale comment in `test_parsers_claude_ai_catalog.py` was updated because it described the removed strict-Pydantic/loose-fallback split. Assertions and fixture behavior were not weakened.

No dominated test deletions are proposed in this package. Future subtraction would need separate responsibility/diagnostic enumeration and mutation evidence.

## Commands and results

All Python commands used the repository virtual environment directly (`.venv/bin/...`) to avoid modifying `uv.lock`.

### Compile, format, lint, type check, and focused compatibility matrix

```bash
.venv/bin/python -m py_compile \
  polylogue/sources/parsers/claude/common.py \
  polylogue/sources/parsers/claude/ai_parser.py \
  polylogue/sources/parsers/browser_capture.py \
  tests/unit/sources/test_claude_web_normalization.py \
  tests/unit/sources/test_parsers_claude_ai_catalog.py

.venv/bin/ruff format --check \
  polylogue/sources/parsers/claude/common.py \
  polylogue/sources/parsers/claude/ai_parser.py \
  polylogue/sources/parsers/browser_capture.py \
  tests/unit/sources/test_claude_web_normalization.py \
  tests/unit/sources/test_parsers_claude_ai_catalog.py

.venv/bin/ruff check \
  polylogue/sources/parsers/claude/common.py \
  polylogue/sources/parsers/claude/ai_parser.py \
  polylogue/sources/parsers/browser_capture.py \
  tests/unit/sources/test_claude_web_normalization.py \
  tests/unit/sources/test_parsers_claude_ai_catalog.py

.venv/bin/mypy \
  polylogue/sources/parsers/claude/common.py \
  polylogue/sources/parsers/claude/ai_parser.py \
  polylogue/sources/parsers/browser_capture.py \
  tests/unit/sources/test_claude_web_normalization.py \
  tests/unit/sources/test_parsers_claude_ai_catalog.py

.venv/bin/pytest -q \
  tests/unit/sources/test_claude_web_normalization.py \
  tests/unit/sources/test_browser_capture.py \
  tests/unit/sources/test_dispatch_ordering.py \
  tests/unit/sources/test_dispatch_payloads.py \
  tests/unit/sources/test_parsers_base.py \
  tests/unit/sources/test_parsers_claude_ai_catalog.py \
  tests/unit/sources/test_parser_contract_v1.py \
  -p no:randomly -p no:random-order -x
```

Results:

- byte compilation: passed;
- Ruff format: `5 files already formatted`;
- Ruff lint: `All checks passed!`;
- mypy: `Success: no issues found in 5 source files`;
- pytest: `157 passed in 5.24s`.

The catalog comment-only change was separately checked by Ruff and exercised in an 18-test Claude route/catalog run.

### Provider/schema/tool-role compatibility

```bash
.venv/bin/pytest -q \
  tests/unit/sources/test_provider_contracts.py \
  tests/unit/sources/test_schema_driven.py \
  tests/unit/sources/test_tool_result_role_reclassification.py \
  -p no:randomly -p no:random-order -x
```

Result: `44 passed in 3.26s`.

### Existing Claude attachment source laws

```bash
.venv/bin/pytest -q \
  tests/unit/sources/test_source_laws.py::test_source_iteration_preserves_claude_attachment_metadata_contract \
  tests/unit/sources/test_source_laws.py::test_source_iteration_preserves_claude_extracted_attachment_payload \
  -p no:randomly -p no:random-order -x
```

Result: `2 passed in 0.68s`.

### Privacy-safe generated representatives

A direct script loaded both checked-in Claude AI representatives, called `detect_provider()` and `parse_payload()`, asserted one session, and printed normalized counts.

Results:

- `sample-00.json`: provider `claude-ai`, 3 messages, 20 attachments, 1 event, no ingest flags;
- `sample-01.json`: provider `claude-ai`, 6 messages, 29 attachments, 2 events, no ingest flags.

### Patch applicability and applied-tree execution

`PATCH.diff` was generated through an isolated Git index so the untracked new test file is represented as a real new-file diff. A clean detached worktree was created at `b9052e09103502017c0f510ecc699aac395de23c`.

Performed there:

```bash
git apply --check PATCH.diff
git apply PATCH.diff
git diff --check
```

All passed. SHA-256 hashes of all five applied files matched the implementation worktree. The following applied-tree test then passed:

```bash
/mnt/data/polylogue-git/.venv/bin/pytest -q \
  tests/unit/sources/test_claude_web_normalization.py \
  tests/unit/sources/test_parsers_claude_ai_catalog.py \
  -p no:randomly -p no:random-order -x
```

Result: `18 passed in 2.10s`.

## Incomplete and unverified checks

### Property-based Claude bundle cardinality

The isolated case was invoked directly, including longer command limits. It did not complete in the final run. A diagnostic run used pytest-timeout at 10 seconds and produced a main-thread stack in:

`tests/infra/strategies/providers.py:provider_export_strategy` -> `SyntheticCorpus.generate()` -> synthetic schema runtime generation.

The stack had not reached `parse_payload()`. A manual fixed-seed script generated 10-message Claude sessions in roughly 0.09-0.17 seconds and parsed four-session bundles in roughly 0.002 seconds, but that does not replace the full Hypothesis law. Final status: incomplete due to an unrelated/non-parser synthetic generator stall.

Aggregate source-law invocations also exceeded local command limits without a final report. They are not claimed as passing.

### Not executed

- browser-extension Vitest/ESLint: `browser-extension/node_modules` was absent; no JavaScript source changed;
- focused `mutmut` campaign: not executed;
- full repository `devtools verify`: not executed;
- live authenticated Claude capture and backfill;
- live receiver/daemon/blob acquisition;
- operator archive, current worktree, secrets, or NixOS deployment.

Every item above is `unverified`, not inferred from unit tests.
