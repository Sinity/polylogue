# testdiet-10 evidence record

## Authority order used

1. The mission prompt defines the requested outcome and package contract.
2. The supplied July 17 project-state snapshot is code authority.
3. Root repository instructions and current typed interfaces constrain architecture.
4. Complete relevant Beads records provide intent and known trust failures; later notes supersede older descriptions.
5. Current source and history resolve stale path/API descriptions.
6. The supplied July 16 “slightly stale” test-suite packet contributes testing methodology only; it does not override current code.

## Snapshot and reproducibility findings

The supplied manifest identifies `master` at `b9052e09103502017c0f510ecc699aac395de23c`, generated `2026-07-17T105328Z` from `/realm/project/polylogue`, with `dirty=true`.

Contradictory/missing evidence:

- `polylogue-branch-delta.patch` is zero bytes;
- the branch-delta report names the same merge base and has no commits/diff stat;
- the supplied working-tree tar, overlaid on the commit checkout, produced no tracked difference.

Conclusion: the snapshot proves the named commit/tree but does not contain the dirty patch indicated by the manifest. The implementation and unified diff therefore target the reproducible commit. No claim is made about an unavailable operator dirty worktree.

## Repository architecture evidence

Root `CLAUDE.md` states that source detection and parsing are substrate semantics, identity is computed from origin/native IDs, and detectors run in tightness order. Browser-capture must precede loose provider dict-key checks or an earlier parser can steal the record. `_lower_payload_specs` recursively lowers bundles/grouped streams and `_parse_lowered_spec` routes concrete parsers.

Typed parser contracts already contain the fields needed by the mission:

- message native ID and parent native ID;
- position, branch index, variant index, active path, active leaf;
- model name, effort, duration, delivery status, end-turn;
- structured blocks and web constructs;
- attachments with native file/drive IDs and transport-only inline bytes;
- session events, active leaf, models used, ingest flags, timestamps, and duration.

This made a new DTO or parallel normalization framework unnecessary.

## Production-route findings

### Detector/lower/parser order

`polylogue/sources/dispatch.py` checks the browser-capture document shape before looser provider shapes. Claude web payloads are later recognized by `chat_messages`. Tests therefore need an envelope that also looks plausible to a loose detector; a top-level ChatGPT-like `mapping` decoy is used.

### Browser extension capture

`browser-extension/src/content/claude.js` labels DOM-only capture `capture_fidelity: "dom_degraded"`.

`browser-extension/src/backfill/providers.js` constructs browser envelopes with `raw_provider_payload` and defaults to `native_full`. Its Claude adapter requests:

- `tree=True`;
- `rendering_mode=messages`;
- `render_all_tools=true`;
- `consistency=strong`.

The raw provider payload is therefore the strongest available conversation/message/block evidence. Projected turns are useful for acquisition and fallback but are not a second identity authority.

### Existing parser gap

Before this patch, ordinary Claude parsing had two paths:

- strict `ClaudeAISession` validation, which emitted only text-bearing messages and did not normalize parent/branch/variant/active/configuration/status/end-turn evidence;
- a loose helper fallback with similarly flat positions/variants and text filtering.

Attachment-only and structured block-only turns could disappear. Browser native delegation preserved the raw payload boundary, but the delegated parser discarded most of the tree evidence. The generic browser fallback was flat and provider-neutral.

The checked-in Claude catalog test also contained a comment describing the strict/loose split. The patch updates only that stale comment after replacing the split with one shared normalizer.

### Attachment merge gap

The native browser route merged an envelope attachment by replacing the native row whenever acquired inline bytes existed. That could lose native provider file/drive IDs, original size, origin classification, or other metadata. The corrected merge keeps the native row authoritative and adds bytes/fills omissions.

### Rich evidence already supported

`base_support.content_blocks_from_segments()` already supports thinking, tool use, tool result, image/document, token budget, voice note, and code blocks. `ParsedWebConstruct` already supports canvas and content-reference fields. The implementation extends Claude projection at this existing typed seam rather than inventing provider bags.

## Claude schema and representative evidence

The historical Claude AI v1 session schema includes:

- conversation `uuid`, `name`, summary, timestamps, account, and `chat_messages`;
- message `uuid`, sender, text/content, timestamps, attachments/files, and `parent_message_uuid`;
- segment types including text, thinking, tool use, and tool result;
- artifact MIME evidence such as `application/vnd.ant.code` and `application/vnd.ant.react`;
- citation structures.

The privacy-safe generated representatives contain richer and unknown content shapes, including tool inputs and optional metadata variance. They were parsed as smoke evidence after the implementation. Unknown provider block types are not semantically guessed; a structural witness points back to retained raw source evidence.

A schema/model tension exists: the old `ClaudeAIChatMessage` model requires top-level text, while native tree payloads and browser evidence can contain structured or attachment-only material. Current production capture and mission requirements win; the public model remains for its existing uses/tests, while ordinary parsing no longer uses it as a gate.

## Beads findings

### `polylogue-yyvg.4` — provider-native identity

Requires one authoritative provider conversation/message identity contract, branch/variant context, resilience to reordering/branch changes/missing IDs, and typed degraded/unknown behavior. DOM ordinal or visible text alone must not authorize durable identity. This supports native IDs, explicit degradation, stable variant ranking, and the envelope-ID conflict witness.

### `polylogue-2qx` — source admission/fidelity/provenance

Requires tight detector ambiguity fixtures, declared identity/collision policy, normalized constructs, ignored/degraded material, and unknown as the safe fallback. This supports browser precedence, explicit native/DOM fidelity, unknown-block structural preservation, and no unsupported active-branch claim.

### `polylogue-0mu` — DOM fallback cannot overwrite richer sessions

Documents the trust failure where DOM fallback can overwrite richer native/GDPR evidence. This supports native payload preference, stale DOM rejection, and degraded fallback flags.

### `polylogue-83u.1` and `polylogue-83u.3` — attachment bytes

Require embedded/acquired browser attachment bytes to flow through `ParsedAttachment.inline_bytes` while honest unfetched/native metadata remains intact. This supports envelope byte enrichment and the anti-replacement assertions.

### `polylogue-866e` and `polylogue-g9f2` — lineage/order independence

Require sibling variants and lineage state to be deterministic across order/interleaving and mutation-sensitive. Although these Beads primarily own archive write-path lineage, their invariant supports order-independent parser sibling ranking and a storage roundtrip oracle rather than parser-only assertions.

### `polylogue-zkmi` — detector dead code/ordering clarity

Shows detector reachability/order is a known source trust concern even where current behavior appears functionally correct. This supports an explicit ambiguous-shape witness rather than assuming dispatch order.

### `polylogue-rii.4` — cloud/web exact evidence

Requires exact retained provider bytes, stable native IDs, lifecycle/messages/tools/artifacts, revision-aware update behavior, fidelity census, and distinct controller/provider identities. It is broader than this task, but supports raw native authority and neutral handling where update semantics are not explicit.

## History inspected

- `c4b3c08b6f2f47b0c65a6c223941540326260314` — `fix(browser-capture): prefer native Claude payloads (#2371)`. Establishes native Claude delegation as intentional production behavior.
- `bad677ebb6c92bda2a474c9ba647ca6352d99712` — `feat(capture): materialize rich web constructs (#2378)`. Establishes typed rich constructs as the existing substrate.
- `c9077590a279037c530dd309f37b886f9052c594` — `fix(ingest): preserve richer browser captures`. Reinforces no evidence downgrade.
- `b054f2ba95725c0b1e57b7c13b5898a5b359d049` — `feat(browser): preserve ChatGPT generation lifecycle evidence (#2944)`. Provides a current precedent for preserving provider lifecycle/configuration evidence through browser capture.
- `07ea5f2d0c760f00dde0e79928b35ab81ac98e59` — `feat(browser): run resumable provider-aware backfills (#2771)`. Confirms provider-aware authenticated backfill is a production route.

No hidden implementation branch containing a newer Claude normalizer was found in the supplied refs.

## Existing test evidence inspected

Relevant existing suites include:

- `test_browser_capture.py`: native Claude delegation, loose native Claude shape, attachment preservation/bytes, fidelity, capture events;
- `test_dispatch_ordering.py` and `test_dispatch_payloads.py`: detector/lowering precedence;
- `test_parsers_base.py`: Claude segment extraction, attachments, flat compatibility;
- `test_parsers_claude_ai_catalog.py`: provider semantic block catalog;
- `test_parser_contract_v1.py`: typed parser contract;
- `test_provider_contracts.py` and `test_schema_driven.py`: provider/model/schema compatibility;
- `test_tool_result_role_reclassification.py`: Anthropic protocol role compatibility;
- source-law attachment and bundle-cardinality cases;
- pipeline/storage helpers used by the new archive write/hydration witness.

These tests constrained the implementation. In particular, a flat legacy fixture expects every row to remain active-path and source order to survive when no better ordering evidence exists. The shared normalizer retains that contract while using graph evidence for tree payloads.

## Slightly stale test-suite packet

`areas/source-normalization.md` recommends organizing tests around public laws rather than parser classes, including:

- tightest detector wins for ambiguous shapes;
- bundle/split/order transformations;
- independent planted facts;
- parser material surviving acquire/parse/store/read;
- preserving unique provider quirks and diagnostics.

`05-systematic-coverage.md` emphasizes mutation sensitivity, independent semantic models, reorder metamorphic laws, historical privacy-safe witnesses, and strict criteria before deleting dominated tests.

`08-capability-map.md` specifically calls for one provider-family blueprint through real detection/lowering/parser with ambiguity negatives and independent facts.

The new tests follow that methodology, but current source APIs and routes were used wherever the packet could be stale.

## Contradictions and resolutions

1. Manifest dirty state versus no supplied delta: resolved by targeting the exact reproducible commit and recording the missing patch as a limitation.
2. Old strict Claude schema/model versus native structured/attachment-only payloads: resolved by retaining the public model but removing it as the ordinary parser gate.
3. Browser envelope identity versus raw native identity: resolved in favor of raw native ID; the envelope only fills optional metadata from the same capture and contributes acquired bytes.
4. `updated_at` versus edit semantics: resolved by preserving neutral provider-update evidence unless Claude supplies an explicit edit/revision marker.
5. Unknown block display text versus raw semantics: resolved by a non-semantic structural witness and retained raw authority.
6. Multiple terminal branches versus selected branch: resolved as unknown without explicit or uniquely terminal evidence.
7. Slightly stale test plan paths versus current source: current source wins; no API/helper was invented to match the plan.

## Rejected approaches

- Coupling the parser to current Claude DOM selectors.
- Parsing stale projected turns when a full native tree exists.
- Treating envelope `provider_session_id` as a second conversation identity.
- Keeping strict and loose parser branches with divergent semantics.
- Assigning branch/variant from record array order.
- Selecting the last record as active in a branched tree.
- Dropping textless messages.
- Replacing native attachment metadata to add acquired bytes.
- Guessing unknown block type or edit meaning from display text/timestamp alone.
- Adding a new provider-meta bag, new framework, or alternate archive write path.
