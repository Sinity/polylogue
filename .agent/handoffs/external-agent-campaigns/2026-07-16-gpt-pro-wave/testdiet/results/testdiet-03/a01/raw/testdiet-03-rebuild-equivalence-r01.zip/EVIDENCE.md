# EVIDENCE — testdiet-03 incremental/rebuild equivalence

## Snapshot authority

`polylogue-manifest.json` and `polylogue-overview.json` identify the snapshot as `master` at `f654480cadb7cc4c194704e24dfd483199547b35`, generated `2026-07-17T043202Z`, with `dirty=true`.

`polylogue-branch-delta.md` identifies `origin/master` as the base, the same commit as merge base, and contains neither a diff stat nor branch-only commits. The manifest's branch patch artifact is zero bytes.

The snapshot export does not contain a trustworthy `git status --porcelain` receipt. A byte comparison found no differences among the 2,501 tracked paths present in the extracted working-tree subset, but 1,238 tracked hidden/export-excluded paths were absent from that subset. Therefore the exact dirty-path identity is unknown. The result uses the named commit as the only safe patch base and validates from clean clones.

The test-suite dossier itself names an older `git_head` (`21f78b4db2ba62ff44b5f16dfab96067bc249b4c`). The mission explicitly says current source wins, so that dossier head is treated as stale planning metadata rather than patch authority.

## Repository rules

`CLAUDE.md` / `AGENTS.md` establishes these constraints used by the implementation:

- Polylogue is a local single-writer archive.
- `source.db` and `user.db` are durable; `index.db` is rebuildable.
- User assertions are durable, irreplaceable overlay state and are excluded from content-hash idempotency.
- Derived schema changes use canonical DDL and rebuild/blue-green replacement, not a migration chain.
- The daemon is the ordinary sole SQLite writer; isolated maintenance routes use explicit ownership/exclusion protocols.
- Focused `devtools test` and affected verification are preferred over blanket test-suite execution.

The patch does not change schema, durable migration state, generated topology files, or public surfaces.

## Derived-freshness decision

`architecture/05-derived-freshness.md` says a derived value is current only when its exact source identity and recipe identity match and its successful result belongs to the active generation. Counts, timestamps, generation alone, and boolean stale flags are insufficient.

Its `DerivationKey` has four computational components: subject/grain, exact source identity, recipe identity, and output contract. Attempt generation, producer/resource identity, timings, and result integrity are separate receipt data. Privacy, authorization, retention, and deletion eligibility are lifecycle metadata rather than computational identity.

It requires incremental, targeted repair, full rebuild, synchronous/asynchronous, and restarted routes to converge for a fixed source snapshot and recipe, with operational differences restricted to explicitly excluded attempt fields.

For FTS it explicitly rejects row-count proof and proposes a future `messages_fts_identity` ledger. For insights it warns that a session content hash alone is insufficient when user assertions, topology, pricing, or global archive state are inputs.

The survivor follows this decision by comparing exact durable evidence, parser census, revision heads, schema/recipe contracts, output schemas, and public facts while keeping generation and historical attempts separate. It also plants equal-count FTS corruption to make the count-only alternative fail conceptually.

## Production rebuild route

`polylogue/cli/commands/maintenance/_rebuild_index.py::rebuild_index_command` is the authoritative wrapper. For a full rebuild it:

1. acquires `RebuildLease` and refuses a running daemon;
2. captures `source_revision_snapshot`;
3. creates an `IndexGenerationStore` inactive generation;
4. calls `rebuild_index_from_source` with owned generation identity;
5. calls `repair_session_insights` against the same owned generation;
6. rejects source-snapshot drift;
7. checks candidate readiness;
8. promotes atomically unless `--no-promote` was requested;
9. discards an inactive generation on failure.

`polylogue/maintenance/replay.py::rebuild_index_from_source` delegates retained-byte replay to `backfill_historical_revision_evidence`. Its `materialize` argument is currently discarded; insight materialization is an explicit next stage in the CLI wrapper. The test mirrors this real sequence instead of assuming replay alone builds insights.

`polylogue/sources/revision_backfill.py::backfill_historical_revision_evidence` expands selected raws to complete logical authority cohorts, records parser census, classifies revision plans, parses retained materials, and applies revision replay through `ArchiveStore`. This is the same semantic authority route used for targeted and full replay.

`polylogue/storage/index_generation.py::IndexGenerationStore.create` initializes an isolated index root and symlinks durable/support tiers including `source.db` and `user.db`; `promote` atomically swaps the public `index.db` pointer and records state. This is why overlay preservation is a rejoin operation rather than a content copy.

`polylogue/storage/repair.py::repair_session_insights` can open an owned inactive generation and calls the canonical session-insight rebuild machinery. `polylogue/storage/insights/session/rebuild.py::_materialize_thread_spine_sync` reconstructs `thread_sessions` from analytics `record.session_ids`, whose lineage builder emits the root before descendants.

## Defect discovered by the survivor

Before the patch, `_refresh_thread` selected every member with:

```sql
ORDER BY sort_key_ms IS NULL, sort_key_ms, session_id
```

For the planted parent and child, both `sort_key_ms` values are `1784196000000`; lexical session ID ordering puts `codex-session:lineage-child` before `codex-session:lineage-parent`. Incremental refresh therefore wrote child position 0 and root position 1.

The insight rebuild constructs the thread from parent relationships and emitted `lineage-parent` before `lineage-child`. Canonical equality failed only in `thread_sessions`, proving a real cross-route semantic mismatch rather than a row-count or timestamp mismatch.

The patch changes the ordering to:

```sql
ORDER BY session_id != ?, sort_key_ms IS NULL, sort_key_ms, session_id
```

with the root ID bound as the first ordering discriminator. Existing non-root order and optimized update paths remain unchanged.

## Existing source history

Relevant commits in the supplied all-refs history include:

- `e717f48afefe7aae972c78bc3c4debe9ccf9cd11` — `perf(storage): bound thread refresh cost for large reordering appends (#2748)`
- `a2bbd25d6a315791430e11191c3b2070cdfdbe2f` — `fix(storage): add offline index generation promotion (#2685)`
- `6a579d09021c9b0ed128287ace51cdff077cd5b7` — `fix(storage): enforce monotonic raw revision replay (#2684)`
- `0653ebdeb0a189d8a8207e3bb33bd08f9e70f5f1` — `fix(storage): unify cross-route revision authority (#2716)`
- `d6501ac4615efa30cb0e2413c97614a4bf44b253` — `fix(storage): make raw replay batches component-aware (#2915)`
- `b55f3fd9697083d44466613091604a21c7324ae6` — `fix(lineage): compose sibling variants canonically (#2922)`
- `e4be6121677829e8c87ddf4ced9748125fcb7209` — `feat(ops): fast-forward index v36 without raw replay (#2931)`
- `593ef3c626b89a4f9e02d400b1aad0fb69a03c55` — `feat(storage): conserve raw authority replay plans (#2961)`
- `d17ded51b3439ea7faec0b4931889a1185f619fc` — `feat(storage): unify raw authority frontier convergence (#2962)`

These commits show that revision replay, generation promotion, lineage, and thread refresh are established production mechanisms. The patch composes them; it does not introduce substitutes.

## Beads findings

`polylogue-9rw0` is open P1 and requires source-backed replay equivalence proof for derived fast-forwards. Its acceptance demands canonical material comparison and rejection when replay is bypassed or mismatched. This survivor supplies a direct source-replay equivalence witness for the current rebuild route, but it does not implement the broader fast-forward transition receipt.

`polylogue-b5l` is open P1 and defines one derived-tier transition lifecycle: plan, build into an inactive generation, prove, activate, observe, and reap. `polylogue-b5l.1` is open P1 and specifically requires a killed/resumed raw replay to converge to clean-rebuild parity while retaining exact cursor/authority semantics. The survivor covers final semantic parity and distinct receipts, but not committed batch-cursor crash resume or live exclusivity.

`polylogue-1xc.14.1` is in progress P1 and owns privacy-safe archive-scale WorkloadProfiles and real-route generated canaries. The supplied dossier lists it as an upstream prerequisite, but no realized workload artifact exists. This test therefore uses a minimal provider-native canary with an independent oracle and does not pretend to satisfy archive-scale distribution or receipt requirements.

`polylogue-1xc.12` is open P1 and owns exact FTS identity, rowid-reuse detection, drift gauges, and trigger state-machine proof. Its design explicitly says equal counts are insufficient. The present same-row-count stale mutation is aligned with that law but does not preempt the planned ledger/schema work.

`polylogue-wmsc` is open P1 and owns the shared storage-neutral `DerivationKey` value semantics for embeddings, with conditional terminal writes by exact key and generation. The test uses a local witness shaped by the architecture decision rather than adding the production protocol ahead of that owner.

`polylogue-f2qv.5` is closed P1. It moved provider-usage projection into version-gated session-insight self-healing. This supports including `session_model_usage`, `session_provider_usage_events`, and insight materialization stamps in the canonical comparison.

`polylogue-w79` is closed and records the performance sensitivity of `_refresh_thread` and targeted rebuild materialization. It is the reason the production repair preserves the unchanged-membership, suffix-append, and changed-span fast paths and why their existing tests remain certification requirements.

`polylogue-303r.7` remains open and defines the complete model-effect recipe key for embeddings. `polylogue-1dk1` is closed after moving remaining generation-bound embedding reconciliation proof into the broader transition acceptance. Neither is silently claimed by this non-embedding canary.

## Dossier contradictions and resolution

The dossier is marked `prepared-not-execution-grade`, reports zero realized sensitivity artifacts, and proposes two tests: public-fact parity and overlay identity. The mission asks for the largest coherent implementation and one realized workload identity. The patch combines both obligations in one survivor so the overlay assertion is made across the same actual generation transition rather than in an isolated unit test.

The dossier lists `devtools/index_fast_forward.py` as an authoritative route, while current source and the mission target the raw-evidence rebuildable index route. The patch follows `_rebuild_index.py`, `rebuild_index_from_source`, revision backfill, insight repair, and `IndexGenerationStore`; it does not add or substitute a fast-forward harness.

The architecture describes exact FTS and embedding ledgers that are not yet present at this snapshot. The patch records this gap and tests only claims supported by current code. It does not turn an architecture recommendation into an invented API.

The manifest says the snapshot is dirty but supplies no exact dirty patch. The result resolves that contradiction by naming the uncertainty and producing an apply-ready diff against the immutable commit instead of pretending the dirty working tree is known.

## Evidence that would falsify this design

The design should be rejected or revised if any of the following is observed during integration:

- `PATCH.diff` does not apply to the named commit.
- The maintenance command no longer composes replay, explicit insight repair, snapshot check, readiness, and promotion in the inspected order.
- `IndexGenerationStore.create` no longer rejoins `user.db` or changes durable-tier ownership semantics.
- The independent planted facts do not match the provider parser contracts at the named snapshot.
- A full insight rebuild intentionally defines child-before-root `thread_sessions` order, contrary to its analytics `session_ids` and existing root-spine semantics.
- Existing optimized thread-refresh tests regress.
- The same-count stale FTS mutation survives selected replay while the route still claims exact readiness.
- The candidate is promoted despite source snapshot drift or blocked readiness in the production wrapper.
