# TESTS — testdiet-03 incremental/rebuild equivalence

## Survivor

The patch adds:

```text
tests/unit/storage/test_incremental_rebuild_equivalence.py::test_incremental_restart_and_fresh_generation_rebuild_are_equivalent
```

This is one end-to-end storage survivor rather than a set of disconnected mocks. It uses a temporary split archive and the production durable writer, revision authority replay, insight repair, inactive-generation store, source snapshot, search reader, and atomic promotion path.

## Test design

### Planted provider facts

The ChatGPT payload contains a root, one user message, two assistant siblings, and `current_node = a-new`. The expected active-path facts are declared independently: the user and `a-new` are active, `a-old` remains archived but inactive, and `a-new` is the leaf. The user message carries an attachment with only a native ID and filename, so the expected attachment contract includes explicit unknown values.

The Codex payload set contains parent-v1, parent-v2, and child. Parent-v2 is asserted to start with the exact bytes of parent-v1 and appends one assistant response item. The child has a parser-native parent reference. The expected authority result is parent-v1 superseded by parent-v2 at generation 1, with the child linked as a continuation under the parent root.

### Route progression

The first increment writes and replays ChatGPT plus parent-v1. A user tag is then written to `user.db`, and the test proves the source snapshot and ChatGPT content hash did not change.

The targeted update writes parent-v2 plus child and selects only those terminal raw IDs. Production cohort expansion must still include the predecessor required to classify authority. After insight repair, the test captures `targeted_key` and `targeted_facts` and checks the independent planted oracle.

The stale mutation replaces one FTS row's text with `staleonlytoken` using the same rowid and preserving the total FTS row count. It also poisons one profile's `message_count` and its `session_profile` materializer version. This defeats row-count and boolean-only freshness assertions.

The restart sets `parsed_at_ms = NULL` on all four durable raw rows, then schedules only the final ChatGPT raw, parent-v2, and child. Revision selection must expand to the complete cohorts, replace stale dependents, and retain the earlier incremental attempt receipt. After insight repair, the exact key and facts must equal the targeted snapshot captured before corruption.

The rebuild creates an owned inactive generation with the final source snapshot, invokes `rebuild_index_from_source` over the same retained raw IDs, and invokes `repair_session_insights` against that owned generation. The source snapshot must remain unchanged during the build. The candidate remains inactive while compared, then is promoted and re-read through the active pointer.

### Independent oracle

`_assert_planted_contract` states expected facts directly from the input payloads and transform invariants. It checks:

- exact session parent/root/raw/branch/active-leaf/message-count values;
- exact message parent, role, branch variant, active-path, and leaf flags;
- canonical and inactive branch blocks;
- attachment unknowns and native identity;
- resolved continuation link and evidence JSON;
- accepted revision heads and parent supersession decisions;
- insight profile counts, attachment counts, `NULL` overlay tags, and materializer version;
- all nine expected materialization types for all three sessions;
- root-first thread analytics and public search/absence behavior.

Nothing in the oracle is copied from the incremental or rebuild output.

### Canonical comparison

The canonical projection compares all non-volatile columns in these derived tables:

```text
sessions
messages
blocks
attachments
attachment_refs
attachment_native_ids
session_links
raw_revision_heads
session_profiles
session_latency_profiles
session_work_events
session_phases
session_model_usage
session_provider_usage_events
session_tag_rollups
insight_materialization
threads
thread_sessions
```

It also compares the current semantic decision per `(raw_id, session_id)` from `raw_revision_applications`, plus public search hits for the canonical, stale, and absent tokens. Explicit volatile timing columns are excluded; source/recipe/materializer stamps beside them remain included.

The derivation witness compares subject/source bindings, source snapshot, durable raw evidence, parser census, index schema and actual user version, FTS DDL/tokenizer contract, insight materializer version, parser recipe set, and complete output table schemas.

Attempt receipts are intentionally not canonical facts. They retain route, physical path and inode, generation/owner/state, and all revision-application IDs. The incremental route must have one additional historical parent-v1 selection receipt.

## Production dependencies and failure meaning

`ArchiveStore.write_raw_payload`

A bypass or fabricated fixture would stop proving durable blob/raw identity. The test verifies the raw row's blob SHA-256 and byte size against the planted provider bytes.

`backfill_historical_revision_evidence`

This owns complete-cohort expansion, parser census, authority classification, replacement, and raw application receipts. Removing cohort expansion would make selected predecessor/supersession facts or replay counts fail. Removing replacement/FTS-trigger effects would preserve `staleonlytoken` and lose `quartzneedle`.

`repair_session_insights`

This owns the profile and materialized insight outputs. Omitting it from the rebuild stage must leave required profile/materialization rows missing or stale and fail both the planted oracle and canonical equality.

`IndexGenerationStore.create` and `promote`

These own an isolated inactive index, durable-tier symlink rejoin, state receipts, and atomic pointer promotion. Reusing the active index would fail path/inode/generation assertions. Losing the `user.db` link would fail the overlay assertion. Skipping promotion would fail active state and pointer assertions.

`_refresh_thread`

This owns incremental `thread_sessions` order. Restoring the old query order makes the child sort before the root when both timestamps are equal, while full insight rebuild emits the root first.

## Anti-vacuity mutation executed

The final test file was copied into a clean clone of the named snapshot without the production change. The run failed as required:

```text
1 failed in 1.40s
```

The relevant canonical difference was:

```text
incremental thread_sessions:
  (codex-session:lineage-parent, codex-session:lineage-parent, 0)
  (codex-session:lineage-parent, codex-session:lineage-child, 1)

rebuild thread_sessions before the fix:
  (codex-session:lineage-parent, codex-session:lineage-child, 0)
  (codex-session:lineage-parent, codex-session:lineage-parent, 1)
```

The patch's `ORDER BY session_id != ?` repair makes the root position stable and the survivor pass.

## Additional mutations the survivor must kill

These were not injected into production source during this pass, but their failing assertions are concrete:

1. Omit `repair_session_insights` after source replay in `_rebuild_index.py`, or make it a no-op. `_assert_planted_contract` will fail on absent/stale profiles, 27 materialization rows, and thread analytics; canonical tables will differ.
2. Disable full-session dependent replacement or the relevant FTS trigger during selected replay. The equal-count stale row will remain, `search_blocks('staleonlytoken')` will stay non-empty, and the canonical token will remain absent.
3. Remove complete-cohort expansion from selected revision replay. Parent-v1 classification/receipt and the final accepted parent-v2 head will no longer match the planted authority contract.
4. Fold the user tag into session content hashing or copy it into raw workload identity. The pre/post-overlay content-hash or source-snapshot equality will fail.
5. Rebuild into the active index instead of an owned generation. Physical attempt-receipt and inactive-state assertions will fail.

## Commands and results

Changed-file formatting and lint:

```bash
.venv/bin/ruff format --check \
  polylogue/storage/sqlite/archive_tiers/write.py \
  tests/unit/storage/test_incremental_rebuild_equivalence.py
.venv/bin/ruff check \
  polylogue/storage/sqlite/archive_tiers/write.py \
  tests/unit/storage/test_incremental_rebuild_equivalence.py
git diff --check
```

Result: passed.

Managed focused test:

```bash
POLYLOGUE_PYTEST_TMPFS=0 POLYLOGUE_PYTEST_WORKERS=0 \
  .venv/bin/python -m devtools test \
  tests/unit/storage/test_incremental_rebuild_equivalence.py
```

Result: `1 passed in 2.04s`, pytest-randomly seed `2540894808`.

Determinism repetitions against the final test:

```text
seed=1  1 passed in 1.32s
seed=2  1 passed in 1.24s
seed=3  1 passed in 1.27s
seed=4  1 passed in 1.30s
seed=5  1 passed in 1.48s
```

Focused existing regression selection:

```bash
.venv/bin/pytest -q \
  tests/unit/storage/test_archive_tiers_write.py::test_archive_tiers_writer_resolves_parent_link_when_parent_already_exists \
  tests/unit/storage/test_archive_tiers_write.py::test_refresh_thread_fast_path_keeps_current_thread_membership \
  tests/unit/storage/test_archive_tiers_write.py::test_refresh_thread_appends_suffix_without_rebuilding_membership \
  tests/unit/storage/test_archive_tiers_write.py::test_refresh_thread_reorder_only_touches_changed_span \
  tests/unit/storage/test_session_insight_refresh.py::test_full_rebuild_restores_thread_spine_membership_and_markers \
  tests/unit/sources/test_revision_backfill.py::test_historical_backfill_selects_prefix_newest_independent_of_acquisition_order \
  tests/unit/storage/test_index_generation.py
```

Result: `17 passed in 4.71s`.

Broader related regression files:

```bash
.venv/bin/pytest -q \
  tests/unit/storage/test_archive_tiers_write.py \
  tests/unit/storage/test_session_insight_refresh.py \
  tests/unit/sources/test_revision_backfill.py \
  tests/unit/storage/test_index_generation.py
```

Result: `112 passed in 20.45s`.

Clean application proof:

```bash
git checkout f654480cadb7cc4c194704e24dfd483199547b35
git apply --check PATCH.diff
git apply PATCH.diff
git diff --check
git apply --reverse --check PATCH.diff
ruff format --check <changed files>
ruff check <changed files>
pytest -q tests/unit/storage/test_incremental_rebuild_equivalence.py
```

Result: all checks passed; final applied-clone test `1 passed in 1.66s`.

Managed harness environment note:

The first unmodified `devtools test` invocation exited 125 because `/dev/shm` had only 64 MiB free and the harness correctly refused an implicit disk fallback. The explicit repository-supported `POLYLOGUE_PYTEST_TMPFS=0` override made the managed run use `/realm/tmp` and pass.

Type-check note:

```bash
.venv/bin/mypy \
  polylogue/storage/sqlite/archive_tiers/write.py \
  tests/unit/storage/test_incremental_rebuild_equivalence.py
```

This did not finish within 120 seconds and emitted an existing unrelated error in `polylogue/archive/query/predicate.py:329`. It is recorded as unverified/failed, not as a pass.

## Existing checks proposed for later certification

Keep, do not delete, the existing thread fast-path and changed-span tests in `test_archive_tiers_write.py`. They protect the performance-sensitive implementation choices surrounding this new root-order invariant.

Keep `test_full_rebuild_restores_thread_spine_membership_and_markers`; it proves a full insight rebuild reconstructs the topology-owned spine and materialization markers, while the new survivor proves cross-route exact ordering for the canary.

Keep `test_historical_backfill_selects_prefix_newest_independent_of_acquisition_order`; it is a narrow authority-law witness and is not dominated by the larger route composition test.

Keep the complete `test_index_generation.py` lifecycle suite. The survivor observes one successful generation path but does not replace lease exclusion, stale-owner, failure discard, recovery, sidecar, or symlink edge cases.

Keep exact FTS trigger/repair tests, especially equal-count and rowid-reuse witnesses as they land under `polylogue-1xc.12`. The survivor is a composition proof, not a replacement for domain-local trigger state machines.

No dominated deletion is proposed in this package. After local certification and sensitivity runs, a separate test-diet decision may evaluate narrow happy-path rebuild examples, but none should be removed based only on this draft.
