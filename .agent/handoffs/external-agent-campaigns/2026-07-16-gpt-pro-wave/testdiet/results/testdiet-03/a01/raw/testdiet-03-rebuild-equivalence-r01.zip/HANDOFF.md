# HANDOFF — testdiet-03 incremental/rebuild equivalence

## Mission and result

This package implements one source-grounded survivor for Polylogue's incremental, targeted-update, restarted-reprocess, and fresh-generation rebuild routes. It uses retained raw evidence as the authority, derives its expected facts from planted provider-native inputs, binds derived equivalence to exact source and recipe evidence, keeps user-tier overlay state outside content identity, and verifies the rebuilt candidate again after atomic promotion.

The implementation also repairs a production ordering defect found by the survivor. When a root session and its continuation had equal sort timestamps, incremental topology refresh could put the child at `thread_sessions.position = 0`, while full insight rebuild emitted the root first. `_refresh_thread` now makes the root the first ordering key and preserves the existing chronological/session-ID order for every non-root member.

No schema, migration, alternate rebuild harness, or new public API is introduced. No existing test or helper is removed.

## Snapshot identity

The supplied snapshot manifest was generated at `2026-07-17T043202Z` and identifies:

- project: `polylogue`
- branch: `master`
- commit: `f654480cadb7cc4c194704e24dfd483199547b35`
- manifest dirty flag: `true`
- branch delta against `origin/master`: merge base at the same commit, zero-byte patch, no branch-only commits

The exporter did not preserve a usable Git porcelain record naming the dirty paths. Its working-tree archive also omitted part of the tracked hidden workspace, so the exact dirty-file set cannot be reconstructed safely. This patch therefore targets the immutable commit named above and was produced and re-applied in fresh clones at that commit. The supplied repository and context archives are not included in this result.

## Evidence inspected

Repository instructions and architecture:

- `CLAUDE.md` / `AGENTS.md`
- `architecture/05-derived-freshness.md`
- `dossiers/incremental-rebuild-equivalence.md`

Production source followed through the real route:

- `polylogue/cli/commands/maintenance/_rebuild_index.py`
- `polylogue/maintenance/replay.py`
- `polylogue/sources/revision_backfill.py`
- `polylogue/storage/index_generation.py`
- `polylogue/storage/repair.py`
- `polylogue/storage/insights/session/rebuild.py`
- `polylogue/storage/insights/session/threads.py`
- `polylogue/storage/sqlite/archive_tiers/archive.py`
- `polylogue/storage/sqlite/archive_tiers/bootstrap.py`
- `polylogue/storage/sqlite/archive_tiers/write.py`
- canonical index DDL and runtime materializer-version definitions

Existing tests inspected and retained:

- `tests/unit/storage/test_archive_tiers_write.py`
- `tests/unit/storage/test_index_generation.py`
- `tests/unit/storage/test_session_insight_refresh.py`
- `tests/unit/storage/test_session_insight_rebuild_progress.py`
- `tests/unit/sources/test_revision_backfill.py`
- FTS repair and derived-surface tests found under `tests/unit/storage/`

Relevant Beads records inspected from the supplied complete export:

- `polylogue-9rw0`
- `polylogue-b5l` and `polylogue-b5l.1`
- `polylogue-1xc.14.1`
- `polylogue-1xc.12`
- `polylogue-wmsc`
- `polylogue-f2qv.5`
- `polylogue-w79`
- `polylogue-303r.7`
- `polylogue-1dk1`

Relevant path history included raw-replay authority, inactive-generation promotion, insight rebuilding, lineage composition, and bounded thread refresh work. Exact findings and commit IDs are in `EVIDENCE.md`.

## Implemented mechanism

The survivor plants two provider-native workloads in one isolated archive.

The ChatGPT export is a branching conversation with one user node, two assistant variants, an explicit active leaf, and an attachment whose MIME type, size, URL, caption, and blob are unknown. This makes active-path, inactive-branch, attachment, and absence semantics observable.

The Codex workload contains a parent raw revision, a strict byte-prefix extension of that parent, and a child session carrying a continuation reference to the parent. This exercises revision-head selection, predecessor/superseded receipts, parent/root lineage, and thread materialization.

The route sequence is:

1. Initialize the actual split archive and write the first retained raw payloads through `ArchiveStore.write_raw_payload`.
2. Incrementally replay them through `backfill_historical_revision_evidence`.
3. Add a durable user tag and prove that neither `source_revision_snapshot` nor the ChatGPT session content hash changes.
4. Write the parent prefix extension and child, run targeted cohort replay, repair insights, and capture the targeted route's exact derivation key and canonical facts.
5. Poison one FTS row with different text while preserving the FTS row count; also set one profile count to `999` and downgrade its `session_profile` materializer stamp to `0`.
6. Mark retained raws as needing restarted parsing, replay a selected terminal set, and repair insights. Assert that the restarted route returns to the targeted route's exact key and facts.
7. Create a real owned inactive `IndexGenerationStore` generation, replay all retained evidence through `rebuild_index_from_source`, and invoke the same session-insight repair stage used by the production maintenance command.
8. Compare the inactive candidate with the restarted incremental index, then promote it and repeat the public fact, derivation-key, source-snapshot, and overlay assertions through the active `index.db` pointer.

The `DerivationKeyWitness` contains the exact subject/source bindings, durable source snapshot, selected durable source evidence, parser census/fingerprint evidence, index schema version, actual SQLite user version, FTS table/tokenizer contract, insight materializer version, parser recipe set, and the complete table-column output contract. Generation and attempt identity are deliberately separate.

Canonical facts include complete non-volatile rows from sessions, messages, blocks, attachment tables, lineage links, revision heads, session and aggregate insight tables, threads, and `thread_sessions`; current revision decisions; and public FTS results for the canonical token, the planted stale token, and a definitely absent token. Volatile attempt/materialization timestamps are excluded by explicit column name, while adjacent semantic stamps remain compared.

The expected oracle is independent of either route. `_assert_planted_contract` derives exact identities and values from the planted inputs and declared transform invariants. The test never serializes one production result as the expected value for the other.

Distinct attempts remain observable. The incremental route retains the earlier parent-v1 selected receipt, while a clean generation contains only final cohort receipts. The current revision decisions agree, but route, path, inode, generation ID, owner ID, generation state, and historical receipt set remain distinct.

The user tag remains in durable `user.db`. `IndexGenerationStore.create` rejoins that tier through the generation root's symlink. The tag is not inserted into raw payload hashes or the session content hash, and the current session-profile projection deliberately remains `tags_json = NULL` for this canary.

## Decisions

The production change is intentionally narrow. It enforces the existing invariant that the thread root occupies position zero without changing sibling ordering, the bounded unchanged-membership fast path, suffix append optimization, or changed-span reorder optimization.

The test calls the same production functions and owned-generation interfaces as the maintenance command rather than invoking its Click adapter. This gives precise observation and corruption control without inventing a second rebuild implementation. The command's daemon refusal, archive-wide `RebuildLease`, readiness rendering, and CLI formatting remain covered by their existing focused suites.

No FTS identity ledger was invented. `polylogue-1xc.12` still owns that future schema work. The present survivor binds FTS equivalence to exact durable block/source facts, the current FTS DDL/tokenizer recipe, and public search results, while deliberately demonstrating why row-count parity is insufficient.

No universal derivation or attempt table was added. That would contradict `architecture/05-derived-freshness.md` and the active `polylogue-wmsc`/`polylogue-1xc.12` ownership split.

## Changed files

`polylogue/storage/sqlite/archive_tiers/write.py`

- Adds the root discriminator to `_refresh_thread` ordering and its SQL bind tuple.

`tests/unit/storage/test_incremental_rebuild_equivalence.py`

- Adds the 1,132-line real-route survivor, independent planted oracle, exact derivation witness, stale-dependent mutation, overlay proof, distinct attempt receipts, inactive-generation comparison, and post-promotion proof.

`FILES/` is omitted because `PATCH.diff` fully and unambiguously describes both changes.

## Acceptance matrix

| Obligation | Evidence in patch | Result |
| --- | --- | --- |
| Replay one realized workload identity through incremental/update/restart and rebuild | One test executes all routes over the same four retained raw IDs | Satisfied |
| Independent planted expected facts | `_assert_planted_contract` names exact provider-derived sessions, messages, blocks, attachment, lineage, revision, insight, thread, search, and absence facts | Satisfied |
| Targeted and restarted convergence | Targeted key/facts are captured before corruption and exactly recovered after restart | Satisfied |
| Exact source identity | Source snapshot, raw rows, blob hash/size, accepted heads, content hashes, parser census, and subject/source bindings are compared | Satisfied |
| Exact recipe identity and output contract | Index schema/user version, FTS DDL/tokenizer, materializer version, parser recipe, and table schemas are compared | Satisfied for the implemented domains |
| Active-generation requirement | Candidate is asserted inactive while compared, then promoted and revalidated through the active pointer | Satisfied |
| Session/message/block identity and active path | Exact planted session and branch-message assertions plus canonical table equality | Satisfied |
| Attachments and unknown semantics | Missing metadata remains `NULL`, byte count `0`, blob unknown, status `unfetched`; absent searches return empty | Satisfied |
| Lineage and thread facts | Parent/root/link evidence and both analytics/thread-spine rows are compared | Satisfied |
| Search and stale-dependent repair | Same-count poisoned FTS row is replaced; canonical token returns and stale token disappears | Satisfied |
| Materialized insights | Exact profile, rollup, materialization, thread, and related table rows/stamps are compared | Satisfied |
| User overlay excluded from workload identity | Tag survives/rejoins while source snapshot and session hash remain unchanged | Satisfied |
| Distinct attempt receipts | Incremental historical receipt remains extra; route/generation/path/inode receipts differ | Satisfied |
| Anti-vacuity production mutation | Reverting root-first ordering makes the survivor fail on `thread_sessions` positions | Demonstrated |
| Durable/derived schema rules | No schema change or migration; source/user remain durable and index remains rebuildable | Satisfied |
| Existing checks retained | No test/helper deletion; certification candidates named in `TESTS.md` | Satisfied |

## Apply order

Apply to a clean checkout of the named commit:

```bash
git checkout f654480cadb7cc4c194704e24dfd483199547b35
git apply --check PATCH.diff
git apply PATCH.diff
git diff --check
```

Then run the focused gate:

```bash
POLYLOGUE_PYTEST_TMPFS=0 POLYLOGUE_PYTEST_WORKERS=0 \
  .venv/bin/python -m devtools test \
  tests/unit/storage/test_incremental_rebuild_equivalence.py
```

Run the existing related regression slice listed in `TESTS.md` before integration. No generated topology file is required because the new file is under `tests/`, not `polylogue/`, and there is no schema change.

## Verification performed

- Ruff format check and Ruff lint on both changed files: passed.
- `git diff --check`: passed.
- Managed focused test with Python 3.13.5 / pytest 9.1.1: `1 passed in 2.04s`.
- Final survivor repeated under pytest-randomly seeds 1–5: five passes, each between 1.24s and 1.48s.
- Related existing regression slice: `17 passed in 4.71s`.
- Broader related files (`test_archive_tiers_write.py`, `test_session_insight_refresh.py`, `test_revision_backfill.py`, `test_index_generation.py`): `112 passed in 20.45s`.
- Final patch applied in a second fresh clone at the named commit; forward check, apply, `git diff --check`, reverse check, Ruff, and survivor all passed (`1 passed in 1.66s`).
- Anti-vacuity run with the final test but without the production ordering fix: failed as required (`1 failed in 1.40s`), with root/child positions reversed between incremental and rebuild facts.
- The default managed test invocation first refused to run because the container exposed only 64 MiB free in `/dev/shm`. Re-running with the repository-supported disk scratch override passed; the refusal is environmental evidence, not a product failure.
- A focused MyPy invocation did not complete within 120 seconds and emitted an unrelated existing error at `polylogue/archive/query/predicate.py:329` (`object` supplied where `Literal['and', 'or']` is expected). It is not counted as passing verification.

## Risks and remaining verification

The survivor is a deterministic, production-shaped canary, not a live-scale archive proof. It does not access an operator daemon, browser, real archive, secrets, current worktree, or NixOS deployment. Those checks remain unverified.

The production ordering repair proves the chosen root/child tie case and preserves existing sibling-order behavior. It is not a general proof that every arbitrary deep/branching topology order is canonical across every writer. A larger second pass could add a multi-depth/multi-sibling canary and, if it exposes another mismatch, centralize thread-member ordering across topology and insight materializers.

Embeddings are outside this chosen canary. Exact embedding `DerivationKey`/generation semantics remain owned by open `polylogue-wmsc` and `polylogue-303r.7`; orphan-generation reconciliation is separately covered by `polylogue-1dk1`. This patch makes no claim of embedding-route equivalence.

The future `messages_fts_identity` ledger from open `polylogue-1xc.12` does not exist at this snapshot. The survivor therefore proves exact public output and recipe-bound convergence for its planted rows, not archive-wide identity-ledger completeness.

The maintenance Click wrapper's lease acquisition, daemon refusal, readiness postflight, and failure cleanup were inspected but are not invoked by this test. Existing generation and maintenance tests remain necessary certification witnesses.

The exact snapshot dirty paths remain unknown because the exporter recorded only `dirty=true`. Integration must apply against the named commit or independently reconcile any operator worktree changes.

## Value of another iteration

A small repair pass is unlikely to add meaningful value unless integration exposes a patch-context or style issue; the patch is already clean-applied and executed from a second clone.

A substantial second pass could add real value by extending the canary to multi-level and multi-sibling lineage, executing a temporary omission of the insight stage and a stale-FTS replacement mutation in addition to the demonstrated ordering mutation, and running the repository's full testmon-selected verification in its normal host environment. A live-scale or sanitized WorkloadProfile-based proof would be a separate substantial certification effort, not a cosmetic revision.
