# TESTS — public fact survivor design and receipts

## Survivor

Primary test:

`tests/unit/surfaces/test_public_fact_parity.py::test_session_profile_fact_survives_repository_facade_cli_and_daemon_http`

The test builds one real workspace archive with the existing `ArchiveScenario` fixture API. It materializes two profiles in one rebuild, then inserts one additional session after the rebuild to create an honest unmaterialized state.

Selected profile facts:

- identity: `claude-code-session:ext-public-fact-selected`;
- public origin: `claude-code-session`;
- title: `Selected profile fact`;
- message count: 3;
- substantive count: 1;
- attachment count: 1;
- tool-use count: 1;
- thinking count: 1;
- word count: 9;
- input high-water mark source: `provider_ts`;
- public time confidence: `recorded`.

The assistant messages explicitly include both text blocks and tool/thinking blocks. During implementation, an initial fixture version supplied only custom tool/thinking blocks, which correctly replaced the default text blocks and produced two profile words. That was a fixture-authoring error, not a product stale-model defect. The final scenario preserves its text blocks explicitly and asserts the independently authored nine-word total.

## Production dependencies exercised

### Repository

`RepositorySurface.session_profile_insight` calls:

1. `Polylogue.repository` to obtain the real `SessionRepository`;
2. `SessionRepository.get_session_profile_record(session_id)`;
3. `SessionProfileInsight.from_record(record, tier="evidence")`.

This is deliberately separate from the pre-existing façade-backed lifecycle/query methods on the adapter. Removing the repository call or substituting the façade makes the stated dependency false and should be rejected in review.

### Public Python façade

`FacadeSurface.session_profile_insight` calls `Polylogue.get_session_profile_insight`. The route reads the archive-backed insight projection rather than a test model or direct SQL row.

### CLI

`CLISurface.session_profile_payloads` invokes the production Click root:

`polylogue --origin ORIGIN analyze insights profiles --tier evidence --limit 50 --format json`

It parses the public JSON result with existing JSON-contract helpers and verifies the envelope total matches returned items.

### Daemon HTTP

`DaemonHTTPSurface` starts `DaemonAPIHTTPServer` with `DaemonAPIHandler`, performs a real HTTP GET, parses successful and error JSON, and closes the server/thread. The selected route is:

`GET /api/insights/sessions/{encoded-session-id}?include=profile`

No handler method, response helper, or internal function is invoked directly by the survivor.

## Semantic normalization

`SessionProfileFacts` ignores surface-local envelope names and compares semantic values. `MaterializationProvenanceFacts` normalizes ISO timestamps to epoch milliseconds so `Z` versus `+00:00` and equivalent serialization differences do not matter. Pydantic models and JSON mappings use the same independent normalizer.

The daemon profile body legitimately differs from the insight model envelope. The normalizer reads identity and evidence counts from that body and provenance from the new sibling field; it does not require byte-for-byte or field-order equality.

## Selection and absence states

The same rebuild contains a ChatGPT decoy. Querying the CLI with `--origin claude-code-session` must return only the selected profile; querying `--origin chatgpt-export` must return the decoy. This catches dropped root-filter forwarding without a mock.

The Codex session is inserted after materialization:

- repository and façade return `None` for the absent profile;
- CLI returns an empty profile collection for `codex-session`;
- daemon HTTP returns 200 with a `q-missing` profile panel, `materialized: false`, `profile: null`, and `provenance: null`.

A totally unknown ref returns `None` on repository/façade and a typed daemon 404 envelope with `error: not_found`. The CLI has no single-profile-by-ref route, so no synthetic CLI error path was invented.

## Anti-vacuity mutation

Executed mutation:

```diff
- input_high_water_mark_source=materialization.input_high_water_mark_source,
- time_confidence=time_confidence_for_source(materialization.input_high_water_mark_source),
+ input_high_water_mark_source=None,
+ time_confidence="unknown",
```

Location: `polylogue/storage/sqlite/archive_tiers/archive.py::_archive_provenance`.

Expected dependency: archive-backed CLI and daemon projection must retain the same stored provenance as the repository record route.

Execution result: **failed as intended**. The survivor reported repository provenance `input_high_water_mark_source='provider_ts', time_confidence='recorded'` while archive-backed projections produced `None/'unknown'`. Mutation command exit was 1. The file was restored byte-for-byte, `git diff --check` passed, and the final survivor passed.

Other named mutations covered by assertions:

- remove CLI root `--origin` forwarding: the decoy enters the selected result;
- omit daemon profile provenance or use a local reduced model: semantic comparison fails;
- coerce an existing unmaterialized session to 404: `q-missing` assertions fail;
- map unknown refs to a successful empty panel: typed 404 assertions fail;
- drop one text block, tool block, thinking block, or attachment from materialization: the corresponding count fails.

## Commands and results

Environment note: the host tmpfs was only 64 MiB, so all pytest commands used a disk-backed base temp directory:

```bash
export POLYLOGUE_PYTEST_TMPFS=0
export POLYLOGUE_PYTEST_BASETEMP_ROOT=/tmp/testdiet07/pytest
```

### Final affected-area suite

```bash
.venv/bin/python -m devtools test \
  tests/unit/surfaces \
  tests/unit/daemon/test_insights_browser_endpoint.py \
  tests/unit/core/test_temporal_confidence.py \
  tests/unit/storage/test_insight_provenance.py \
  tests/unit/cli/test_insights.py::test_insights_profiles_json \
  tests/unit/api/test_facade_contracts.py::test_archive_tiers_api_session_profiles_read_index_tier \
  tests/unit/core/test_facade_api.py::TestPolylogueArchiveInsights::test_durable_session_insights_are_publicly_queryable \
  -q
```

Result: **172 passed in 3.87s**; devtools step completed successfully.

### Final survivor after mutation restoration

```bash
.venv/bin/python -m devtools test \
  tests/unit/surfaces/test_public_fact_parity.py -q
```

Result: **1 passed in 1.46s**.

### Static checks

```bash
.venv/bin/ruff check \
  polylogue/daemon/http.py \
  polylogue/storage/sqlite/archive_tiers/archive.py \
  tests/infra/semantic_facts.py \
  tests/infra/surfaces.py \
  tests/unit/cli/test_insights.py \
  tests/unit/daemon/test_insights_browser_endpoint.py \
  tests/unit/surfaces/test_public_fact_parity.py
```

Result: **passed**.

```bash
.venv/bin/ruff format --check \
  polylogue/daemon/http.py \
  polylogue/storage/sqlite/archive_tiers/archive.py \
  tests/infra/semantic_facts.py \
  tests/infra/surfaces.py \
  tests/unit/cli/test_insights.py \
  tests/unit/daemon/test_insights_browser_endpoint.py \
  tests/unit/surfaces/test_public_fact_parity.py
```

Result: **7 files already formatted**.

```bash
.venv/bin/mypy \
  polylogue/daemon/http.py \
  polylogue/storage/sqlite/archive_tiers/archive.py \
  tests/infra/semantic_facts.py \
  tests/infra/surfaces.py \
  tests/unit/surfaces/test_public_fact_parity.py \
  tests/unit/cli/test_insights.py \
  tests/unit/daemon/test_insights_browser_endpoint.py
```

Result: **Success: no issues found in 7 source files**.

```bash
git diff --check
```

Result: **passed with no output**.

### Independent patch-application receipt

`PATCH.diff` was applied with its index metadata to a second detached worktree created directly at `b9052e09103502017c0f510ecc699aac395de23c`:

```bash
git apply --index /tmp/testdiet07/package/PATCH.diff
git diff --cached --check
```

Result: **applied cleanly**; the staged tree contained exactly the six modified files and one added survivor file named in this package, and the cached diff check passed with no output.

The full affected-area command above was then rerun from that independently patched worktree using the same environment variables.

Result: **172 passed in 4.49s**. The standalone survivor also passed there: **1 passed in 2.15s**.

### Broader changed-area observation

```bash
.venv/bin/python -m devtools test \
  tests/unit/cli/test_insights.py \
  tests/unit/daemon/test_insights_browser_endpoint.py \
  tests/unit/core/test_temporal_confidence.py \
  tests/unit/storage/test_insight_provenance.py \
  tests/unit/surfaces/test_public_fact_parity.py -q
```

Result: **115 passed, 2 failed**. The only failures were:

- `tests/unit/cli/test_insights.py::test_insights_status_json`
- `tests/unit/cli/test_insights.py::test_insights_status_plain`

Both expect `ready`; the fixture currently returns `degraded` with two materialized profile rows.

### Clean-snapshot baseline reproduction

The same two tests were run in a clean detached worktree at `b9052e09103502017c0f510ecc699aac395de23c` before applying this patch.

Result: **2 failed in 1.68s** with the same `degraded` versus expected `ready` mismatch. They are pre-existing snapshot drift, not regressions introduced here. This package does not weaken readiness or rewrite the unrelated assertions.

## Mock-forwarding and snapshot tests: preserve, then certify dominance

No existing tests or helpers were deleted.

Candidates partially dominated by the new survivor, but retained pending independent local certification:

- `tests/unit/cli/test_insights.py::test_insights_profiles_json` — the survivor now covers real CLI filtering, identity, counts, tier, and complete provenance. The local test remains useful for a compact command-specific schema diagnostic.
- `tests/unit/daemon/test_insights_browser_endpoint.py::TestEmptyPayloads::test_empty_profile_panel_is_q_missing` — the survivor covers the same empty state through real HTTP. The helper test remains a cheap, precise unit diagnostic.
- daemon/web route snapshot or DOM smoke assertions that only prove the route exists or spell current reader source — do not delete until the replacement reader suite proves the stable HTTP obligation and the rewrite owner certifies removal.

MCP mock-forwarding tests are **not deleted and not yet claimed as dominated**, because the current MCP implementation is explicitly being replaced:

- `tests/unit/mcp/test_tool_contracts.py::TestInsightTools::test_session_profile_tool_uses_archive_insight_contract`
- `tests/unit/mcp/test_contract_evidence.py::TestToolErrorEnvelopes::test_session_profile_missing_returns_not_found_envelope`

Transfer to the `polylogue-t46.8`/`.1` replacement suite:

1. use the same planted archive state through the rewritten public MCP transport/resource, not a mocked façade;
2. compare the same identity/origin/count/provenance fact set;
3. declare whether the result is an object resource or a `read/get` projection;
4. distinguish existing-unmaterialized (`q-missing`/typed unavailable) from unknown session (`not_found`);
5. preserve stable result/object refs, pagination policy where applicable, role discovery, cancellation, and bounded response behavior;
6. fail when the replacement adapter drops origin projection, provenance, or the typed absence distinction.

## Remaining verification

Unverified in this package:

- full pytest suite;
- generated docs, OpenAPI, MCP reference, and other generated-surface synchronization;
- `devtools verify --quick` and `devtools verify --all`;
- package/install/Nix checks;
- live daemon process or operator archive;
- browser/Playwright/component rendering;
- current or rewritten MCP transport;
- live mutation against an operator worktree.
