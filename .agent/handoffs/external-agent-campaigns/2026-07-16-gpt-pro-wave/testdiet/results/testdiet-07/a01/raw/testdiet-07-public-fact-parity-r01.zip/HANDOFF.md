# HANDOFF — testdiet-07 public fact parity

## Operator report

This package implements one real cross-surface survivor around Polylogue's materialized **session-profile insight**. The selected fact is read from one authored archive state through the true `SessionRepository` record route, the public async `Polylogue` façade, the descriptor-routed Click CLI, and the production daemon HTTP server. The test normalizes semantic meaning rather than bytes and compares identity, public `Origin`, evidence counts, materialization provenance, selected semantic tier, filter behavior, and absence/error states.

The survivor exposed and repairs two production projection defects. First, the archive-backed insight projector discarded the already-persisted `input_high_water_mark_source`, so API/CLI archive reads downgraded a provider timestamp from `recorded` to `unknown`. Second, the daemon profile panel promised a provenance summary in its own docstring but omitted that summary, while its shared serializer also omitted the high-water mark, source, and time-confidence fields. The patch forwards the stored fields through the canonical archive provenance model and has daemon HTTP obtain provenance from `SessionProfileInsight.from_record` rather than recomputing domain facts.

The current MCP tool family and current web reader are active rewrite boundaries. This package does not add aliases, improve private FastMCP-registration tests, or pin obsolete DOM behavior. It records precise obligations for the MCP verb/resource rewrite and replacement web reader while strengthening only the stable HTTP substrate they consume.

## Snapshot identity and authority

The supplied project-state archive is the code authority used for this patch.

- Project: `polylogue`
- Snapshot source recorded by the archive: `/realm/project/polylogue`
- Branch: `master`
- Commit: `b9052e09103502017c0f510ecc699aac395de23c`
- Subject: `fix(daemon): bound raw maintenance admission (#2975)`
- Author: `Sinity <ezo.dev@gmail.com>`
- Commit date: `2026-07-17T08:28:35+02:00`
- Snapshot generated: `2026-07-17T105328Z`
- Manifest dirty flag: `true`
- Branch delta against `origin/master`: empty; merge base equals the snapshot commit

Authority reconstruction used `polylogue-all-refs.bundle` plus `polylogue-working-tree.tar.gz`. The reconstructed tracked tree matched the named commit before this implementation; the only supplied-tree difference observed by Git was ignored `browser-extension/package-lock.json`. The manifest's dirty bit remains important provenance, but the archive contains no non-empty tracked branch patch to preserve or name. This patch is therefore against the named commit and does not claim to reproduce an unavailable pre-snapshot tracked dirty patch.

Input integrity:

- `00-polylogue-all.tar(24).gz`: SHA-256 `c895e9096613dada7fa0e8c65dbdc768f88b118d6c096fabb1d5c83215e9515f`, 91,282,283 bytes
- `00-slightly-stale-context-testsuite-diet.tar(24).gz`: SHA-256 `d4fa7fc31c70ff30db076e526836ffc81b8124d3f54c7add5e58d3f57c9dcbff`, 934,006 bytes
- `07-public-fact-parity.md`: SHA-256 `e7f3c25e3f55b64b777c1876e4cd4d220a5208551902663d15e254ae092d5316`, 6,501 bytes

## Evidence inspected

Repository guidance and architecture:

- `CLAUDE.md`
- `architecture/07-evidence-provenance-and-public-algebra.md`
- `13-bead-derived-test-laws.md`, especially L18–L20
- `areas/harness-and-fixtures.md`
- `areas/rewrite-boundaries.md`
- `dossiers/exact-query-selection.md`

Production source and contracts:

- `polylogue/insights/archive.py`
- `polylogue/insights/archive_models.py`
- `polylogue/insights/temporal_source.py`
- `polylogue/storage/insights/materialization.py`
- `polylogue/storage/insights/session/records.py`
- `polylogue/storage/insights/session/rebuild.py`
- `polylogue/storage/insights/session/profiles.py`
- `polylogue/storage/sqlite/archive_tiers/archive.py`
- `polylogue/api/archive.py`
- `polylogue/api/insights.py`
- `polylogue/insights/registry.py`
- `polylogue/cli/click_app.py` and the generic insight command path
- `polylogue/daemon/http.py`
- `polylogue/daemon/route_contracts.py`
- `polylogue/daemon/web_shell.py`
- `polylogue/mcp/server_insight_tools.py`

Test infrastructure and existing tests:

- `tests/infra/archive_scenarios.py`
- `tests/infra/semantic_facts.py`
- `tests/infra/surfaces.py`
- `tests/infra/json_contracts.py`
- `tests/unit/core/test_temporal_confidence.py`
- `tests/unit/storage/test_insight_provenance.py`
- `tests/unit/api/test_facade_contracts.py`
- `tests/unit/core/test_facade_api.py`
- `tests/unit/cli/test_insights.py`
- `tests/unit/daemon/test_insights_browser_endpoint.py`
- `tests/unit/daemon/test_web_reader.py`
- `tests/unit/mcp/test_tool_contracts.py`
- `tests/unit/mcp/test_contract_evidence.py`

Beads and history:

- `polylogue-cuxz.2` — EvidenceValue declaration core, open
- `polylogue-1xc.14.1` — archive workload profiles, in progress
- `polylogue-t46.8` and `polylogue-t46.8.1` — MCP verb-algebra rewrite, open
- L20 witness Beads including `polylogue-rsad`, `polylogue-bby.7`, `polylogue-6o9b`, `polylogue-vh57`, and `polylogue-f57q`
- Commit `e7c1b2064626f5c093306c9fe1e882e2acab408b`, `feat(insights): define time-confidence provenance contract (#2786)`
- Commit `ac9cfeb0b2614140c940ad44b637c0689d939202`, which introduced the archive materialization projection family
- Current path logs and blame for the archive projector and daemon profile panel

The history for #2786 is especially decisive: its commit message explicitly deferred forwarding the stored high-water-mark source through the storage-owned `ArchiveStore` projection. The patch closes that named gap.

## Mechanism

### Query

The survivor authors one selected Claude Code session profile and one ChatGPT decoy in a single archive, runs one real insight rebuild, then adds a Codex session after the rebuild. That produces three independent states without a parallel expected-output catalog:

1. selected and materialized;
2. same materialization, different origin, used to catch dropped CLI root filtering;
3. existing session with no materialized profile, used to distinguish `q-missing` from an unknown ref.

The repository and façade query by exact session identity. The CLI uses its public root `--origin` filter and the `analyze insights profiles` command. Daemon HTTP uses `GET /api/insights/sessions/{id}?include=profile` against a real in-process `DaemonAPIHTTPServer`.

### Projection

`SessionProfileInsight.from_record` remains the canonical public record projection. The archive-backed list projection now forwards the same stored high-water-mark value/source and derives `time_confidence` through the existing temporal-source contract. Inference and enrichment provenance copy the resulting base fields rather than silently losing them.

Daemon HTTP still hydrates the domain `SessionProfile` for its reader-local profile body. It separately projects the same record through `SessionProfileInsight.from_record(..., tier="evidence")` and serializes only that canonical provenance into the HTTP panel. It does not derive or repair counts, origin, or timestamps locally.

### Render and comparison

New test-only fact types in `tests/infra/semantic_facts.py` normalize Pydantic models, CLI JSON, and the daemon panel into `SessionProfileFacts` and `MaterializationProvenanceFacts`. ISO timestamps are normalized to epoch milliseconds; route envelopes and JSON formatting are ignored. The comparison includes:

- `session_id` and `logical_session_id`;
- public `origin` and title;
- message, substantive, attachment, tool-use, thinking, and word counts;
- materializer version and materialization timestamp;
- source update timestamp and sort key;
- input high-water mark and its source;
- public `time_confidence`.

No production presentation code is centralized. The normalizer is test infrastructure only.

## Decisions

1. **Selected fact family:** session profile at the `evidence` tier. It already carries stable identity, public origin, multiple independently planted counts, and materialization provenance across every stable route in scope.
2. **Fixture authority:** reuse `ArchiveScenario`, `ScenarioMessage`, content-block helpers, real SQLite materialization, and the existing workspace fixtures. No seeded-database framework, expected-output catalog, or product-side test hook was added.
3. **Canonical provenance:** use existing `ArchiveInsightProvenance` and `time_confidence_for_source`; do not introduce the still-open `EvidenceValue`/`FactFamilySpec` API.
4. **Daemon shape:** add a sibling `provenance` field to the profile panel and explicit `None` for `q-missing`. This is additive and fulfills the panel's existing documented contract.
5. **MCP boundary:** do not add a real-route test to the obsolete `session_profile` tool. Its same-name mock-forwarding tests remain. The replacement declaration must own exact identity/origin/count/provenance parity and must distinguish existing-unmaterialized from unknown session rather than coercing both to `not_found`.
6. **Web boundary:** preserve the HTTP envelope consumed by the reader. The replacement component/Playwright suite must assert rendered identity/count/provenance policy, explicit loading/`q-missing`/404 states, and sanitization; no current JavaScript/CSS/source-spelling assertion was strengthened.

## Changed files

- `polylogue/storage/sqlite/archive_tiers/archive.py`
  - forwards input high-water mark, source, and time confidence through archive provenance;
  - carries those fields into inference/enrichment provenance;
  - preserves the source in archive-row-to-profile-record conversion.
- `polylogue/daemon/http.py`
  - completes the shared public provenance serializer;
  - includes canonical provenance in materialized profile panels;
  - emits `provenance: null` for `q-missing`;
  - obtains provenance from `SessionProfileInsight.from_record`.
- `tests/infra/semantic_facts.py`
  - adds semantic profile/provenance normalizers and equality assertion.
- `tests/infra/surfaces.py`
  - adds explicit real repository, façade, CLI, and daemon profile adapters;
  - corrects the repository adapter description for this selected path.
- `tests/unit/surfaces/test_public_fact_parity.py`
  - adds the real-route survivor and its selected/decoy/unmaterialized states.
- `tests/unit/cli/test_insights.py`
  - updates the existing contract assertion from the known-safe fallback to the now-preserved `provider_ts`/`recorded` fact.
- `tests/unit/daemon/test_insights_browser_endpoint.py`
  - pins explicit missing provenance in the `q-missing` panel.

No complete replacement files are included because `PATCH.diff` is unambiguous.

## Acceptance matrix

| Obligation | Implementation/proof | Status |
| --- | --- | --- |
| Named snapshot and source authority | Manifest, bundle, working-tree overlay, branch delta, Git identity recorded | complete |
| One selected semantic fact | One materialized session profile with independent attachment/tool/thinking/text evidence | complete |
| True repository route | Direct `SessionRepository.get_session_profile_record` then canonical projector | complete |
| Public Python API | `Polylogue.get_session_profile_insight` | complete |
| Stable CLI | Real Click `analyze insights profiles --tier evidence --format json` | complete |
| Daemon HTTP | Real `DaemonAPIHTTPServer` and public profile route | complete |
| Identity and object contract | IDs, kind, contract version, and tier asserted | complete |
| Public origin vocabulary | `claude-code-session`, `chatgpt-export`, `codex-session`; no provider-token substitution | complete |
| Counts | 3 messages, 1 substantive, 1 attachment, 1 tool use, 1 thinking, 9 words | complete |
| Provenance | HWM, source `provider_ts`, confidence `recorded`, source update, sort key, materialization identity | complete |
| Filter semantics | decoy origin proves CLI root filter forwarding | complete |
| Existing but unmaterialized | repository/façade `None`, CLI empty list, daemon 200 `q-missing` with null profile/provenance | complete |
| Unknown ref | repository/façade `None`; daemon typed 404 `not_found` envelope | complete for applicable routes |
| Meaning rather than bytes | independent semantic normalization of model/CLI/HTTP shapes | complete |
| Mutation sensitivity | executed archive-provenance-drop mutation fails survivor | complete |
| Patch application | applied with index metadata to an independent detached snapshot worktree; affected suite rerun | complete |
| Current MCP route | not strengthened; exact replacement obligations recorded | transferred to rewrite |
| Current web reader | HTTP substrate repaired; DOM/component obligations recorded | transferred to rewrite |
| Full repository suite | not run | unverified |
| Live daemon/browser/NixOS/archive | not accessed or claimed | unverified |

## Apply order

1. Check out commit `b9052e09103502017c0f510ecc699aac395de23c` or a descendant where the touched hunks remain unchanged.
2. Apply `PATCH.diff` with `git apply --index PATCH.diff` or `git apply PATCH.diff`.
3. Run the focused survivor and affected-area suite listed in `TESTS.md` with tmpfs disabled when the host `/dev/shm` is small.
4. Run project-required generated-surface and full verification gates in the operator's normal environment.
5. Do not delete the mock-forwarding or snapshot candidates listed in `TESTS.md` until independent local dominance certification and, for MCP/web, the owning rewrite have landed.

## Verification performed

The final source state passed:

- focused real-route/affected-area suite: **172 passed**;
- final survivor after restoring the deliberate mutation: **1 passed**;
- Ruff lint: passed;
- Ruff format check: passed;
- targeted strict mypy: passed with no issues in seven changed Python files;
- `git diff --check`: passed;
- independent `git apply --index` to a second detached worktree at the named commit: applied cleanly; cached diff check passed;
- independently patched worktree affected-area suite: **172 passed in 4.49s**; standalone survivor: **1 passed in 2.15s**;
- deliberate provenance-drop mutation: survivor failed as intended;
- clean-snapshot baseline reproduction: the two unrelated insight-readiness tests fail on the unmodified commit with `degraded` versus stale expected `ready`.

`TESTS.md` contains exact commands and results.

## Risks, limitations, and remaining work

- The shared `EvidenceValue` and `FactFamilySpec` kernel named by the architecture is not present in this snapshot; `polylogue-cuxz.2` is open. This patch uses the existing typed provenance contract and does not invent that future API.
- The context packet says to treat `polylogue-1xc.14.1` as completed, but the current Bead is `in_progress`. The survivor therefore uses the existing independent `ArchiveScenario` path instead of claiming the unrealized workload-profile/C-03 fixture as authority.
- Current MCP collapses a missing profile and unknown session through `None` into one `not_found` envelope. Repair belongs to `polylogue-t46.8`/`.1`, not to a compatibility alias here.
- The current web reader consumes the daemon profile panel but does not render the new provenance sibling. That presentation decision and its accessibility/security tests belong to the reader rewrite.
- The daemon provenance serializer is shared by profile/timeline/phase/thread panels, so its added fields are additive on those panels too. Their values already exist on the typed provenance models; this package does not add separate cross-kind survivor cases.
- The full repository suite, generated docs/OpenAPI checks, `devtools verify --quick/--all`, installed package, live daemon, real browser, MCP transport, NixOS deployment, and operator archive were not run or accessed.
- Two existing CLI readiness tests fail on the clean snapshot and on the patched tree because the fixture now reports `degraded` while the assertions expect `ready`. They were not changed because the failure predates and is unrelated to this provenance/parity patch.

A same-snapshot repair iteration would add **small value, plausibly 5–15%**: review-driven naming reductions, an additional archive insight-kind provenance case, or generated-schema confirmation. A **substantial second pass, plausibly 30–50% additional mission coverage**, becomes worthwhile only after the EvidenceValue/declaration kernel and MCP/web rewrites land; it could then run the same fact algebra through the replacement MCP transport/resource and replacement DOM/Playwright route instead of preserving obligations in prose.
