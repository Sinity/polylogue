# EVIDENCE — source, Beads, history, and contradictions

## Authority chain

The project-state archive records `master` at commit `b9052e09103502017c0f510ecc699aac395de23c`, generated on July 17, 2026. The all-refs bundle resolves `master` and `origin/master` to that commit. The branch-delta files are empty. The working-tree archive was overlaid on a repository reconstructed from the bundle; before implementation, tracked Git state matched the commit while ignored `browser-extension/package-lock.json` was present. Therefore `PATCH.diff` is generated against the named commit.

The archive manifest says `dirty=true`. Because no tracked delta is present in the branch patch or reconstructed tracked tree, that flag cannot be converted into an additional apply-ready preexisting patch. The handoff preserves the contradiction rather than inventing one.

## Controlling architecture

`architecture/07-evidence-provenance-and-public-algebra.md` establishes:

- one canonical fact model per domain;
- independent `Query × Projection × Render` stages;
- surface omission only by declared size/privacy policy;
- no adapter-local semantic repair or strengthening;
- `Origin` as the public session/source vocabulary;
- materialization time must not masquerade as event time;
- current MCP and current web reader are rewrite boundaries.

`13-bead-derived-test-laws.md` L20 states that stable repository, CLI, daemon HTTP, and supported adapters must expose the same selected object, semantic facts, completeness, phase, and typed error, with presentation differences allowed only when facts do not change. Its generalized proof is one planted state table through real routes normalized to an independent fact algebra. It explicitly transfers current MCP/web cases to their rewrites.

The patch follows that split:

- query selection uses exact identity or the public CLI origin filter;
- projection uses existing repository/facade/insight contracts;
- rendering remains surface-local;
- comparison lives only in test infrastructure.

## Production trace and defect

### Stored authority

Session insight materialization persists:

- `input_high_water_mark_ms`;
- `input_high_water_mark_source`;
- source update/sort values;
- materializer identity and row count.

The session rebuild path classifies a provider-backed `updated_at` as `provider_ts`. `time_confidence_for_source("provider_ts")` is the existing public rule for `recorded`.

### Canonical record projection

`polylogue/insights/archive.py::_record_provenance` already forwards `input_high_water_mark`, `input_high_water_mark_source`, and `time_confidence_for_record`. `SessionProfileInsight.from_record` also projects stored provider identity through the public origin mapping. The true repository record path therefore retained the full fact.

### Archive-backed list/API/CLI projection

`polylogue/storage/sqlite/archive_tiers/archive.py::_archive_provenance` forwarded only materializer version, materialization time, source update, and source sort key. It omitted the stored HWM, source, and time confidence. `_session_profile_record_from_archive_row` separately hard-coded `input_high_water_mark_source=None` even though the materialization record carried the field.

Consequences before the patch:

- repository record projection could produce `provider_ts` / `recorded`;
- archive-backed façade/CLI paths could produce `None` / `unknown`;
- a route could preserve the timestamp value while losing the clock authority that gives it meaning.

This is semantic disagreement, not formatting variance.

### Daemon HTTP projection

`polylogue/daemon/http.py::_profile_panel_payload` has stated since its introduction that it adds a readiness chip and provenance summary, but the returned mapping contained only readiness, materialized state, and the hydrated profile body. The shared `_provenance_dict` used by other insight panels also omitted HWM, source, and time confidence.

The handler read the full profile record, hydrated a reduced domain profile, and sent only that reduced body. The patch keeps the body but projects provenance from `SessionProfileInsight.from_record`; this reuses canonical semantics rather than reconstructing facts in HTTP code.

### CLI and daemon applicability

The CLI profile command is routed through the production descriptor/registry machinery and returns typed insight models. The daemon route is registered at `/api/insights/sessions/:id` and distinguishes an existing session with absent profile materialization (`q-missing`) from an unknown session (404). The survivor exercises both routes end to end.

## Historical witness

Commit `e7c1b2064626f5c093306c9fe1e882e2acab408b`, `feat(insights): define time-confidence provenance contract (#2786)`, added the public time-confidence fields to record adapters and tests. Its commit message explicitly says:

- storage-owned `ArchiveStore` projection still needed to forward the already-stored high-water-mark source into API/CLI/MCP archive reads;
- the then-current default to `None` was safe but prevented recorded/estimated values from reaching live surfaces;
- that storage path was deferred because it belonged to another lane.

The current patch implements that deferred forwarding. It does not change the temporal-confidence lattice.

Blame also shows the daemon profile panel's provenance-summary docstring and omission originated together, making the new field fulfillment of an existing intended contract rather than a new fact family.

## Beads and current-state contradictions

### EvidenceValue kernel

`polylogue-cuxz.2` is open. Its acceptance criteria require independent value state, authority, enumeration, coverage, time confidence, freshness, and calibrated confidence across public projections. The snapshot does not contain the proposed `EvidenceValue`/`FactFamilySpec` kernel. This patch does not invent it; it repairs one existing provenance axis through existing models.

### Workload-profile prerequisite

The stale context packet says to treat `polylogue-1xc.14.1` as completed. The current Bead export marks it `in_progress`. Its broader correlated workload-profile and C-03 canary authority is therefore not assumed. The test reuses existing independent `ArchiveScenario` fixtures and real materialization instead of creating a parallel workload-profile catalog or claiming an unrealized upstream receipt.

### MCP rewrite

`polylogue-t46.8` and `.1` are open and own replacement of the 103-tool surface with a protocol-native declared verb/resource/prompt algebra. `areas/rewrite-boundaries.md` forbids improving current private-registration, same-name mock-forwarding, and `EXPECTED_TOOL_NAMES` tests. Current `server_insight_tools.py::session_profile` calls the façade and converts every `None` to `not_found`, so it cannot preserve the daemon's existing-unmaterialized versus unknown-ref distinction.

Exact transferred obligation: the replacement MCP read/resource must project the same selected profile fact, object/ref identity, public origin, counts, and provenance through a real archive and public transport; it must declare and test the two absence states. No compatibility alias is added here.

### Web rewrite

The current `web_shell.py` fetches `/api/insights/sessions/{id}` and renders profile counts/readiness, but it does not render the new provenance sibling. The rewrite boundary says to preserve HTTP substrate behavior and move DOM, navigation, sanitization, accessibility, loading/error, and large-transcript tests to the replacement reader. This patch repairs the substrate only.

### L20 historical witnesses

The L20 Beads explain why a cross-surface survivor is warranted:

- `polylogue-bby.7`: list-emitted refs could 404 at detail;
- `polylogue-6o9b`: DB-backed and archive-backed daemon detail paths flatten message text differently;
- `polylogue-vh57`: advertised text rendering once failed dispatch;
- `polylogue-f57q`: preview/apply phase counts can misstate semantics;
- `polylogue-rsad`: current MCP response ergonomics and completeness remain problematic despite its closed status notes.

The selected profile fact avoids those unrelated domains while exercising the same class of surface disagreement.

## Test-infrastructure findings

`tests/infra/surfaces.py::RepositorySurface` was described as a repository surface but used the `Polylogue` façade for all existing methods. The patch does not rewrite the entire harness. It adds one explicit selected-fact method that calls the real `SessionRepository`, and updates the docstring to distinguish that method from retained compatibility behavior.

`tests/infra/semantic_facts.py` was already the authoritative home for cross-surface semantic normalization. Extending it with typed profile/provenance facts follows the existing architecture and avoids a parallel oracle module.

The fixture false lead was instructive: custom content-block tuples replace default text blocks. An early version therefore made profile counts appear stale across routes. Adding explicit text blocks restored the intended authored fact and all routes agreed. No production count algorithm was changed.

## Baseline test drift

The broad affected-file run found two readiness failures. Re-running exactly those tests in the clean snapshot produced the same failures:

- JSON status expected `ready`, observed `degraded`;
- plain status expected `Insight Readiness: ready`, observed `Insight Readiness: degraded`.

The degraded payload still reports two profile rows and `profile_rows_ready=True`; the mismatch is unrelated expectation drift. The patch leaves it visible and unchanged.

## Scope conclusion

The source, history, and Beads converge on a narrow coherent implementation:

1. preserve already-stored temporal-source provenance in the archive projection;
2. expose canonical provenance through stable daemon HTTP;
3. prove one selected profile fact across real repository/façade/CLI/HTTP routes;
4. transfer MCP/web obligations without strengthening implementations scheduled for replacement.

No public API, product contract, fixture framework, renderer registry, or future EvidenceValue type was invented.
