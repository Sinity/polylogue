# HANDOFF — testdiet-12 Gemini and AI Studio/Drive normalization laws

## Mission completed

This revision implements an apply-ready normalization slice for two distinct Google wire families:

- local Gemini CLI session documents (`Provider.GEMINI_CLI`); and
- AI Studio/Drive chunked-prompt documents routed as either `Provider.GEMINI` or `Provider.DRIVE`.

The implementation deliberately preserves the non-injective public mapping in which both `GEMINI` and `DRIVE` resolve to `Origin.AISTUDIO_DRIVE`. It does not use an origin rename as an identity oracle. The provider token remains on `ParsedSession.source_name`, while the existing source-family and capture-mode mechanisms retain the distinctions that are actually knowable.

The patch covers detector tightness, conversation and turn identity, branch lineage, authoredness, model configuration, thought/text/code/tool-result blocks, Drive and inline artifacts, timestamps, token usage, delivery status, Gemini CLI project/subagent semantics, and nested Drive-like lowering through `detect_provider()` and `parse_payload()`.

## Snapshot identity and patch base

- Repository branch: `master`
- Commit: `b9052e09103502017c0f510ecc699aac395de23c`
- Commit date: `2026-07-17T08:28:35+02:00`
- Commit subject: `fix(daemon): bound raw maintenance admission (#2975)`
- Snapshot generated: `2026-07-17T105328Z`
- Patch base: the exact commit above

Identity was established from the supplied all-refs Git bundle, `polylogue-overview.json`, `polylogue-manifest.json`, the branch-delta artifacts, and the supplied working-tree capture.

The snapshot metadata says `dirty: true`, but the supplied branch-delta patch, file list, and log are all empty. A byte-level comparison of the working-tree capture against the named commit found:

- 3,741 tracked file/symlink entries at the commit;
- 2,503 supplied tracked entries, all 2,503 byte-identical to the commit;
- zero supplied tracked mismatches;
- 1,238 tracked entries omitted from the capture, primarily `.agent/` (1,228), plus `.beads/` (6), `.claude/` (2), `flake.lock`, and `uv.lock`;
- one supplied untracked file: `browser-extension/package-lock.json`.

Consequently, there is no supplied tracked dirty patch to preserve or target. Omitted files were not interpreted as deletions. `PATCH.diff` is anchored to the named commit and contains only the implementation in this handoff.

## Evidence inspected

The inspection followed production dependencies beyond the immediate parser files:

- repository guidance: `AGENTS.md`, `CLAUDE.md`, architecture and source-dispatch documentation;
- dispatch and lowering: `polylogue/sources/dispatch.py` and the Drive payload boundary introduced by history commit `9230e9b8f`;
- normalized parser models and session runtime: `polylogue/sources/parsers/base_models.py`, `polylogue/archive/session/runtime.py`, message/material-origin models, and core provider/source/origin mappings;
- AI Studio/Drive parsing: `drive.py`, `drive_support_attachments.py`, `drive_support_blocks.py`, `gemini_message.py`, and `gemini_models.py`;
- Gemini CLI parsing: `local_agent.py`, local source discovery/dispatch tests, and the generated v1 Gemini CLI schema;
- generated schemas: `polylogue/schemas/providers/gemini/versions/v1/elements/session_document.schema.json.gz` and `polylogue/schemas/providers/gemini-cli/versions/v1/elements/session_document.schema.json.gz`;
- checked-in Gemini fixtures, especially the branching, multi-turn, code-execution, thought, and attachment witnesses;
- existing parser, catalog roundtrip, dispatch ordering, schema-driven, null-guard, storage-search, source-law, and fuzz tests;
- Beads `polylogue-4rrv`, `polylogue-2ilz`, `polylogue-zkmi`, and `polylogue-b054.1.1.7`;
- relevant history commits `80983b488`, `311ff4b15`, `1256485a2`, `59b179c5f`, `1618887c1`, and `9230e9b8f`;
- the supplied test-suite diet’s source-normalization, tight-detector, independent-oracle, reorder, nesting, and mutation-proof requirements.

Detailed findings and contradictions are in `EVIDENCE.md`.

## Mechanism implemented

### Tight detection and real lowering

`drive.looks_like()` is now the auto-detection predicate used by dispatch. It requires a role/author plus a meaningful AI Studio chunk content field, rather than claiming every record with a `chunks` list. An explicit Gemini/Drive route remains deliberately more tolerant through `drive.has_chunk_container()`, so partially malformed exports can still be salvaged when the caller already knows the provider.

A one-document Gemini CLI stream is detected by its stronger local-session signature before weaker sequence shapes. The established Claude-Code-before-Codex sequence precedence remains unchanged; an earlier broad shortcut was rejected by regression tests and narrowed to Gemini CLI only.

Drive lowering now distinguishes a raw chunk sequence from wrapped session documents, descends nested list/document wrappers, and recurses list values under `sessions`. It does not reinterpret arbitrary records as chunks.

### Conversation, source, and turn identity

The parser preserves the explicit provider token as `ParsedSession.source_name`. Parsing identical AI Studio bytes with `Provider.GEMINI` and `Provider.DRIVE` therefore keeps distinct source families even though both resolve to the same public origin.

Native session IDs and message IDs survive directly. Missing message IDs retain the existing deterministic source-position fallback (`chunk-<source index>`). Reordering records therefore preserves native identities while intentionally changing only fallback identities for records that supplied no native ID.

Branch lineage accepts explicit `branchParent` strings or objects using `id`, `promptId`, or `messageId`. It also infers a child’s parent from parent-side `branchChildren` declarations when exactly one distinct parent declares that child. Explicit child-side metadata wins. Conflicting parent declarations remain unset rather than becoming order-dependent.

### Authoredness and material origin

No new authoredness rule was invented. AI Studio/Drive export sessions continue through the existing `ParsedSession` normalization that upgrades user turns to `HUMAN_AUTHORED` for non-runtime export sources. Local Gemini CLI is a runtime-root source, so its user turns remain `UNKNOWN`; assistant and tool-result material retain their existing typed origins.

### Model configuration, timestamps, usage, and status

AI Studio `runSettings` is retained in a `model_config` session event. Its model supplies the session model set and a per-message fallback; message-level model fields still override it. `systemInstruction` is lowered to `instructions_text`. Session and message timestamps use native fields and existing deterministic timestamp selection.

AI Studio `tokenCount` becomes role-appropriate message input/output tokens and a source-message-linked `token_count` event. `finishReason` and `errorMessage` become typed delivery/end-turn facts.

Gemini CLI preserves all observed token lanes. Its raw `input` value is treated as cache-inclusive, matching the archive’s disjoint-token invariant and the existing Codex precedent: uncached input is `max(input - cached, 0)`, cache reads remain separate, and output/thought/tool/total values survive in a per-message event together with the original wire dictionary. Legacy generic usage dictionaries retain their prior fallback behavior.

### Thought, output, code, and tool blocks

AI Studio now lowers top-level and part-level thoughts, thought signatures/budgets, text, executable code, code execution results, and explicit error blocks. Code-result `outcome`, `status`, explicit error fields, and exit codes determine `ParsedContentBlock.is_error` and `exit_code` without treating every tool result as a success.

Gemini CLI now reads thought `description`, `subject`, and timestamp; tool `args`; `functionResponse` output/error records; rich `resultDisplay` fallbacks; and status-only successful calls. Tool-use and tool-result blocks share the provider tool ID.

### File and Drive artifacts

The Drive path preserves native Drive document identifiers and adds explicit Drive image/audio/video attachment kinds. It also retains top-level inline files/images, part-level `inlineData`, and part-level `fileData` links, including MIME type, decoded inline bytes when valid base64, source URL/name, and deterministic attachment IDs. Message blocks use image typing only for explicit image forms or image MIME types; `inlineData` is not generalized into an image-only product rule.

Base64 payload bytes are removed from normalized block metadata while remaining available in the typed attachment’s `inline_bytes` for blob storage. AI Studio’s wire-specific attachment handling is not generalized to ChatGPT or to a product-wide attachment-token rule.

### Gemini CLI session semantics

`projectHash` now lands in `provider_project_ref`; `directories` land in `working_directories`; observed message models populate `models_used`; and `kind: subagent` becomes `BranchType.SUBAGENT`. `main` and legacy `chat` remain ordinary sessions.

## Decisions

1. **Provider-to-origin remains non-injective.** The patch preserves provider source identity and does not pretend bytes can reveal an acquisition mode that was not present in the document.
2. **Auto-detection is strict; explicit routing is tolerant.** This avoids detector capture while retaining recovery behavior for a known provider.
3. **Lineage is deterministic.** Explicit child metadata wins; unique reverse declarations may fill a gap; ambiguous declarations do not select a first record.
4. **Normalized token lanes are disjoint.** The original Gemini CLI token dictionary is also retained in the event so future semantic corrections do not require source-byte loss.
5. **No parallel parser/test framework was introduced.** Tests enter through the production dispatch/parser route and use existing typed models.
6. **No schema migration is required.** All target fields already exist in parsed/session models. Existing archived sessions need reparse/re-ingest to gain the new normalized projections.
7. **No existing tests or helpers are deleted.** No local deletion is proposed: catalog, schema, dispatch, source-law, and fuzz tests each retain distinct compatibility evidence.

## Changed files

| File | Change |
|---|---|
| `polylogue/sources/dispatch.py` | Wires the tight Drive detector, restores one-document Gemini CLI specificity, distinguishes raw chunk lists from wrapped sessions, and recursively lowers nested Drive/session containers. |
| `polylogue/sources/parsers/drive.py` | Adds strict/tolerant shape predicates; native branch lineage; model config/instructions; model, timestamp, token, status, and end-turn survivors. |
| `polylogue/sources/parsers/drive_support_attachments.py` | Adds Drive media, inline image/data, and linked file-data artifacts with deterministic IDs, MIME/source facts, deduplication, and correct block typing. |
| `polylogue/sources/parsers/drive_support_blocks.py` | Interprets code/tool outcomes, explicit errors, statuses, and exit codes. |
| `polylogue/sources/parsers/local_agent.py` | Adds Gemini CLI project/subagent/directories/models, complete token events, richer thoughts, tool args, function responses, failures, and status-only results. |
| `polylogue/sources/providers/gemini_message.py` | Extends typed extraction for part thoughts, code/results, Drive media, inline/file data, errors, and privacy-safe metadata. |
| `polylogue/sources/providers/gemini_models.py` | Declares observed part-level thought, attachment, code, and result fields. |
| `tests/unit/sources/test_gemini_drive_normalization_laws.py` | Adds eight privacy-safe, literal-oracle, production-route laws with named representative mutations. |

## Acceptance matrix

| Requirement | Implemented evidence | Test law |
|---|---|---|
| Tight detection and detector order | Role/content signature, empty/generic list rejection, ChatGPT and Gemini CLI stronger-shape precedence | `test_detector_order_is_tight_and_one_document_streams_keep_specificity` |
| Conversation/source identity | Native session ID and explicit provider token retained across GEMINI/DRIVE origin collapse | `test_provider_tokens_survive_the_non_injective_origin_collapse` |
| Turn identity and reorder | Native IDs/timestamps/parents/tokens/block kinds are literal and reorder-stable; missing IDs use source position | `test_native_turn_facts_survive_reordering_while_missing_ids_use_source_position` |
| Ambiguous lineage | Conflicting parent-side declarations remain unset in both orders | `test_ambiguous_branch_child_declarations_do_not_invent_a_parent` |
| Authoredness/material origin | AI Studio export user becomes human-authored; CLI runtime user remains unknown; assistant/tool origins remain typed | AI Studio and CLI composed laws |
| Model configuration | `runSettings`, model event, model fallback/override, system instruction, session model set | AI Studio composed law |
| Thought/output/tool blocks | Top/part thoughts, code, success/failure results, explicit error, CLI args/function responses/status | AI Studio and CLI composed laws |
| File/Drive artifacts | Native Drive IDs/media kinds plus inline image/file/data and linked `fileData` | AI Studio composed law |
| Timestamps, usage, status | Native times, token fields/events, finish/error delivery and end-turn facts | AI Studio identity/composed laws and CLI composed law |
| Nested Drive lowering | Nested lists and `sessions` wrappers dispatch to two sessions through `parse_payload()` | `test_nested_drive_like_wrappers_lower_through_the_production_dispatch_route` |
| Gemini CLI session semantics | `projectHash`, directories, models, `main`/`subagent`, thought/tool/token details | Two Gemini CLI laws |
| Real storage-facing compatibility | Attachment ID remains searchable after parse/prepare; catalog roundtrip remains green | Existing affected regression set |

## Apply order

From a clean checkout of the named commit:

```bash
git checkout b9052e09103502017c0f510ecc699aac395de23c
git apply --check PATCH.diff
git apply PATCH.diff
git diff --check
```

Then run the commands in `TESTS.md`. No generated topology or schema artifact changes are required because the patch adds no module and changes no storage schema.

Already-ingested sessions will not be rewritten automatically. Reparse/re-ingest retained raw source records when the new normalized fields are required in existing archives.

## Verification performed

- `git apply --check` succeeded against a fresh checkout of the exact snapshot.
- The patch was applied in that checkout and `git diff --check` succeeded.
- The fresh checkout imported `polylogue` from the patched checkout, not from the development workspace.
- The affected regression set passed twice: 417 tests in the development workspace and 417 tests after clean application.
- Eight new normalization laws passed.
- Drive/Gemini plus local-agent seed fuzz corpora passed: 59 tests.
- Existing direct Drive source-law cases passed: 4 tests.
- Ruff format check and Ruff lint passed on all eight changed files.
- Strict mypy passed on all eight changed files.
- Bytecode compilation passed on all eight changed files.
- `git diff --check` passed.

Exact commands and execution caveats are in `TESTS.md`.

## Risks and unverified work

- The fixtures are privacy-safe structured witnesses derived from checked-in generated schemas and existing fixture contracts. No operator live Gemini CLI directory, Drive API, browser, daemon, secrets, NixOS deployment, or current worktree was accessed. Those checks are **unverified**.
- The full repository test suite was not run. The focused affected surface is broad, but unrelated subsystems remain **unverified**.
- The generated Hypothesis node `test_parse_payload_bundle_cardinality_contract[gemini-bundle]` did not complete within a four-minute isolated limit in the ad-hoc Python environment. Bead `polylogue-b054.1.1.7` records successful bounded execution under the repository’s intended xdist/Nix lane, but that exact lane was unavailable here. This node is **unverified**, not reported as passed or as a deterministic product failure.
- An initial run with `pytest-randomly` enabled produced plugin teardown/setup errors (`Seed must be between 0 and 2**32 - 1`). The repository’s own devtools profile disables `randomly` and `random-order`; rerunning with that profile produced the passing results above. This was isolated as a test-plugin/environment failure.
- AI Studio `tokenCount` exposes only one count per chunk, so role-based input/output assignment is the strongest typed projection available from the supplied wire. The raw chunk remains authoritative.
- Historical GEMINI-versus-DRIVE acquisition mode cannot be reconstructed from identical provider bytes. The patch preserves explicit provider tokens on the current parse; durable capture mode remains the authority for future acquired records.

## Value of another iteration

A native repository/Nix/CI pass that runs the full suite and the generated Gemini Hypothesis node would be a **small repair/verification iteration**. It could expose integration defects or require minor test/runtime adjustments, but the production route and clean-apply proof are already coherent.

A **substantial second pass** would pay off only with additional privacy-safe real AI Studio/Drive and Gemini CLI artifacts that demonstrate presently unseen wire variants, or with an explicitly broadened mission to normalize grounding/citation/safety metadata and richer branch-active-path semantics. Without new authority, another implementation pass would mostly duplicate the current schema-derived coverage.
