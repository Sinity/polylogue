# EVIDENCE — source, schema, Beads, history, and contradictions

## Authority hierarchy used

1. The supplied mission defines the requested outcome and package contract.
2. The supplied snapshot commit is the code authority.
3. Current source and generated schemas at that commit override stale plans or historical path descriptions.
4. Later Beads notes and close reasons override older issue wording.
5. Existing tests and checked-in fixtures establish compatibility constraints; new tests do not replace them.

## Snapshot evidence

The supplied overview/manifest identify:

- branch `master`;
- commit `b9052e09103502017c0f510ecc699aac395de23c`;
- dirty flag `true`;
- snapshot generation `2026-07-17T105328Z`.

Git identifies the commit as:

- date `2026-07-17T08:28:35+02:00`;
- subject `fix(daemon): bound raw maintenance admission (#2975)`.

The branch-delta patch, changed-file list, and commit log are each empty. The supplied working-tree capture contains 2,503 tracked entries, all byte-identical to the commit, omits 1,238 tracked entries, and contains one untracked package-lock file. This proves only that the capture is partial and metadata-marked dirty; it does not supply a tracked dirty change. The implementation patch is therefore against the named commit, not an invented local delta.

Input artifact hashes used during inspection:

| Input | SHA-256 |
|---|---|
| `00-polylogue-all.tar(29).gz` | `c895e9096613dada7fa0e8c65dbdc768f88b118d6c096fabb1d5c83215e9515f` |
| `00-slightly-stale-context-testsuite-diet.tar(29).gz` | `d4fa7fc31c70ff30db076e526836ffc81b8124d3f54c7add5e58d3f57c9dcbff` |
| `12-gemini-drive-normalization.md` | `676714959839dca0562f9248e6aefeb4feeb7512de8c9708aba7ad5f9deb563c` |

## Architecture and source findings

### Provider, source family, and origin are different axes

`polylogue/core/sources.py` maps both `Provider.GEMINI` and `Provider.DRIVE` to `Origin.AISTUDIO_DRIVE`. The source registry still assigns distinct families: the Gemini export and Drive-takeout/acquisition fibers are not interchangeable with the public origin.

The parser accepts a provider argument and `ParsedSession.source_name` can retain that exact provider. This is the available document-route identity and is what the patch preserves.

The existing capture-mode work provides a separate acquisition-time authority for future records. Historical byte-identical exports without acquisition metadata remain unknowable and must not be backfilled by shape guessing.

### Authoredness depends on runtime/export context

`ParsedSession` normalization upgrades user turns to `MaterialOrigin.HUMAN_AUTHORED` only for non-runtime export sources. Gemini CLI is registered with a runtime root and therefore must not receive the AI Studio export upgrade. Assistant and tool-result classifications are derived from role/block semantics. The patch relies on this existing mechanism rather than assigning material origin in a provider-specific shortcut.

### Normalized token lanes are disjoint

Archive token and pricing models add input, output, cache-read, and cache-write lanes. The Codex parser already treats raw inclusive input plus cached input as a signal to subtract the cache lane. Gemini CLI’s generated schema exposes `input`, `output`, `cached`, `thoughts`, `tool`, and `total`; the patch follows the same disjoint projection and preserves the raw dictionary in the session event.

### Existing fields support the change

`ParsedSession`, `ParsedMessage`, `ParsedContentBlock`, `ParsedAttachment`, and `ParsedSessionEvent` already expose the required typed fields: provider/session/message IDs, parent IDs, branch type, project ref, working directories, model sets/config events, token lanes, status/end-turn, block outcomes, native attachment IDs, source URLs, and inline bytes. No storage schema or parallel normalized model is needed.

## Generated schema findings

### Gemini CLI v1 schema

The checked-in schema was generated from 27 observed session documents. Relevant root fields include:

- `sessionId`, `projectHash`, `startTime`, `lastUpdated`, `kind`, `summary`, `directories`, and `messages`;
- observed `kind` values `main` and `subagent`;
- per-message `id`, `timestamp`, `type`, `content`, `model`, `thoughts`, `tokens`, and `toolCalls`;
- thought `subject`, `description`, and `timestamp`;
- token fields `input`, `output`, `cached`, `thoughts`, `tool`, and `total`;
- tool-call `id`, `name`, `args`, `status`, `timestamp`, `description`, `displayName`, `result`, and `resultDisplay`;
- result `functionResponse` with `id`, `name`, and `response.output`/`response.error`.

These fields justify the CLI project/subagent, thought, token, tool-input, tool-result, and status changes. The tests intentionally vary missing/empty results and include success, failure, and status-only forms.

### AI Studio/Gemini v1 schema

Relevant root and chunk fields include:

- `chunkedPrompt`, `runSettings`, `systemInstruction`, title/display metadata, and timestamps;
- chunk role/author, IDs, prompt IDs, `branchParent`, and `branchChildren`;
- `text`, `parts`, `isThought`, `thinkingBudget`, and thought signatures;
- top-level and part-level `executableCode` and `codeExecutionResult`;
- Drive document/image/audio/video fields, inline file/image, part `inlineData`, and part `fileData`;
- `tokenCount`, `finishReason`, and explicit error fields.

The checked-in branching fixture uses both child-side and parent-side branch identifiers. This is why the implementation supports both directions but refuses ambiguous reverse inference.

## Existing tests and fixtures inspected

The affected compatibility surface includes:

- `test_dispatch_ordering.py` and `test_dispatch_payloads.py` for detector precedence and payload routing;
- `test_gemini_chunked_prompt_contract.py` and checked-in multi-turn/branching fixtures;
- `test_parsers_drive.py` and `test_parsers_drive_catalog.py` for parser contracts and parse/save/hydrate roundtrips;
- `test_parsers_local_agent.py` and provider-origin regression coverage;
- `test_models.py` for typed provider extraction;
- `test_schema_driven.py`, null-guard properties, and parser seed fuzz targets;
- storage attachment-search preparation;
- direct Drive lowering/source laws.

No existing test or helper was removed. The catalog tests are not dominated by the new composed laws because they cover distinct historical wire cases and storage roundtrips.

## Beads findings

### `polylogue-4rrv` — closed

This work added a source-family disambiguator for reverse lookup and documented the architectural limit: no storage tier originally persisted which GEMINI/DRIVE fiber produced an already-ingested `AISTUDIO_DRIVE` session, and the shared parser/bytes could not recover it. The patch follows that decision by preserving explicit provider context, not reverse-inventing it.

### `polylogue-2ilz` — closed

The follow-up added durable capture-mode evidence before origin collapse for future captures. Its close reason explicitly says pre-migration provenance stays unknown rather than fabricated. This supersedes any stale plan that assumes every historical session can be split.

### `polylogue-zkmi` — open

This issue states that `drive.looks_like()` existed but was dead in top-level dispatch. The patch wires it into `_looks_like_gemini_mapping()` and tightens its structural signature. Because GEMINI and DRIVE are content-indistinguishable, auto-detection still returns the established Gemini provider; explicit Drive routing preserves Drive source identity.

### `polylogue-b054.1.1.7` — closed

This issue records a load/shape-sensitive timeout for the generated `gemini-bundle` Hypothesis node, an isolated 18-second pass, the bounded-strategy repair in PR #2995, and two successful full 8-worker seeds. In the current ad-hoc environment the exact node again did not complete within four minutes. The intended lane’s historical evidence is credible, but the current exact node is still marked unverified here.

## History findings

| Commit | Relevant contract |
|---|---|
| `9230e9b8f` | Rebuilt dispatch and the Drive ingestion boundary; current production routes must be used rather than a side parser. |
| `1618887c1` | Added local agent ingestion and explicitly kept AI Studio distinct from Gemini CLI. |
| `80983b488` | Established chunkedPrompt message extraction and metadata roundtrip contracts. |
| `311ff4b15` | Added first-class native attachment identifiers and upload origin. |
| `59b179c5f` | Added source-family disambiguation for GEMINI/DRIVE reverse lookup. |
| `1256485a2` | Preserved raw AI Studio capture mode before public-origin collapse. |

The current source at `b9052e09` wins where older commit descriptions name paths or behavior that later changed.

## Test-suite diet findings

The supplied diet requires source-normalization laws to:

- use the tightest detector and cover every meaningful structural element;
- plant expected facts independently rather than projecting them from parser output;
- vary ordering, missing metadata, bundles, and nesting;
- prove authoredness, actions/outcomes, attachments, origin, and time;
- identify representative mutations/removals that make each test fail;
- exercise real production routes instead of parallel helper frameworks.

The new law suite follows those requirements. The reorder oracle is a literal native-ID fact map, and the non-injective provider/origin case is asserted from independent provider/source/origin contracts.

## Contradictions resolved

### Dirty snapshot versus no supplied tracked delta

Resolution: target the named commit. The dirty flag is recorded as a limitation; omitted files are not treated as deletions, and the untracked package-lock is not included.

### Same public origin versus distinct provider/source identity

Resolution: retain the explicit provider token and source family while accepting the shared public origin. Use durable capture mode where acquisition-time provenance exists; leave historical unknowns unknown.

### Strict auto-detection versus salvage of malformed explicit input

Resolution: split predicates. `looks_like()` is strict for auto-detection; `has_chunk_container()` is tolerant only after the caller selected GEMINI/DRIVE.

### Parent-side branch metadata versus reorder stability

Resolution: infer only a unique declared parent, let explicit child metadata win, and leave conflicts unset. Never select a first record.

### Generated property lane historically fixed versus current timeout

Resolution: report both pieces of evidence. The exact local node is unverified; no deterministic product failure is claimed, and the historical xdist/Nix pass is not presented as a current local run.

### AI Studio attachment-token limitations versus other products

Resolution: all attachment logic is scoped to the AI Studio/Drive wire and its generated fields. The patch does not infer a ChatGPT or product-wide attachment rule.

## Scope not claimed

- No live daemon, browser, Drive account, Gemini CLI home, secret, NixOS deployment, or operator current worktree was inspected.
- No historical capture mode was reconstructed from bytes.
- No source archive or supplied input is copied into the result package.
- No complete replacement files are needed; `FILES/` is intentionally omitted because the unified diff is unambiguous.
- Grounding, citations, safety ratings, and broader UI semantics remain outside this focused normalization patch unless already retained by existing raw/provider models.
