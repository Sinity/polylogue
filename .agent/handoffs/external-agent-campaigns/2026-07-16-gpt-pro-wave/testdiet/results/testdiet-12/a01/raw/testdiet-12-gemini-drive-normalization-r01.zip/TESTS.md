# TESTS — design, dependencies, mutations, and results

## Proof form

The new suite is `tests/unit/sources/test_gemini_drive_normalization_laws.py`. Its fixtures are synthetic and privacy-safe but shaped from the checked-in Gemini and Gemini CLI generated schemas. Expected facts are literal constants planted independently of parser output. The tests do not compute an expected provider by renaming an origin, and they do not call private parser helpers as the behavior under test.

Every composed law enters through one or both production boundaries:

- `polylogue.sources.dispatch.detect_provider()`; and
- `polylogue.sources.dispatch.parse_payload()`.

That route exercises dispatch ordering, schema-guided lowering, the selected parser, typed provider models, parsed-session normalization, and attachment/block conversion. Existing catalog and storage-search tests extend the proof through save/hydrate and searchable attachment preparation.

## New law inventory

### 1. `test_detector_order_is_tight_and_one_document_streams_keep_specificity`

Production dependencies:

- `dispatch._detect_provider_from_record()` and `_detect_provider_from_sequence()`;
- `drive.looks_like()`;
- `local_agent.looks_like_gemini_cli()`;
- established ChatGPT and sequence detector precedence.

Facts proved:

- a generic empty `chunks` list is not AI Studio;
- role/timestamp without content is not AI Studio;
- a role/text chunk is detected as Gemini;
- a stronger ChatGPT mapping wins an ambiguous shape;
- Gemini CLI wins its one-document stream shape;
- existing sequence precedence is not globally reordered.

Representative anti-vacuity mutation: restore the old `"chunkedPrompt" in record or isinstance(record.get("chunks"), list)` predicate, or move a weak Gemini check ahead of stronger record detectors. The negative and ambiguous assertions fail.

### 2. `test_provider_tokens_survive_the_non_injective_origin_collapse`

Production dependencies:

- `parse_payload()` Drive-like routing;
- `parse_chunked_prompt()` source assignment;
- `provider_to_source()` and `origin_from_provider()`.

Facts proved:

- identical bytes parsed explicitly as GEMINI and DRIVE retain distinct `source_name` tokens and source families;
- both still map to `Origin.AISTUDIO_DRIVE`;
- native conversation identity is unchanged.

Representative anti-vacuity mutation: derive `source_name` back from the public origin or hard-code GEMINI in the parser. One provider/source-family assertion fails.

### 3. `test_ai_studio_normalizes_identity_authorship_config_blocks_artifacts_usage_and_status`

Production dependencies:

- Drive parser/session construction;
- `GeminiMessage` and `GeminiPart` typed extraction;
- Drive attachment and block helpers;
- existing `ParsedSession` authoredness/material-origin normalization.

Facts proved:

- native session/message identity, timestamps, title, instructions, model set and per-message model;
- export user authoredness and assistant/tool-result material origins;
- model-config event and complete `runSettings` preservation;
- top-level and part-level thought metadata;
- code and successful/failed execution results;
- explicit error delivery/end-turn facts;
- role-appropriate `tokenCount` messages/events;
- Drive document/image/audio/video native IDs and kinds;
- inline image, inline file, part inline data, and linked part file data;
- base64 data is absent from normalized block metadata.

Representative anti-vacuity mutations: drop part traversal, map every outcome to success, omit an attachment field, remove model fallback, or bypass existing authoredness normalization. Literal assertions on block kinds, result error state, artifact count/kinds, model facts, or material origin fail.

### 4. `test_native_turn_facts_survive_reordering_while_missing_ids_use_source_position`

Production dependencies:

- native ID selection and positional fallback in `parse_chunked_prompt()`;
- timestamp/model/token/block extraction;
- explicit `branchParent` and unique `branchChildren` inference.

Facts proved:

- a literal native-ID keyed fact map is identical after reversing records;
- parent lineage derived from a unique parent-side declaration survives reordering;
- explicit child-side parent metadata survives;
- records without native IDs use deterministic source-position IDs.

Representative anti-vacuity mutation: use list position as every message ID, infer parent from adjacency, or compute expected facts from the first parse. Native fact-map assertions or the literal expected map fail.

### 5. `test_ambiguous_branch_child_declarations_do_not_invent_a_parent`

Production dependencies:

- `drive._branch_child_parent_map()` as called by the real parser;
- explicit ambiguity policy in `parse_chunked_prompt()`.

Facts proved:

- when two distinct parents declare the same child and the child supplies no explicit parent, normalized parent identity remains unset;
- the result is unchanged when records are reversed.

Representative anti-vacuity mutation: select the first candidate parent or overwrite a candidate in a dictionary. One ordering acquires an invented parent.

### 6. `test_nested_drive_like_wrappers_lower_through_the_production_dispatch_route`

Production dependencies:

- `_lower_payload_specs()`;
- `_lower_drive_like_payload()`;
- `sessions` wrapper handling;
- `parse_payload()` and the Drive parser.

Facts proved:

- nested list and document wrappers lower to two sessions in deterministic encounter order;
- both chunkedPrompt and top-level chunks forms survive;
- provider token, model, message text, and fallback message identity survive.

Representative anti-vacuity mutation: recurse only dictionary values directly under `sessions`, or treat every outer list as one raw chunk list. The session count and identities fail.

### 7. `test_gemini_cli_schema_fields_survive_dispatch_without_export_authorship_upgrade`

Production dependencies:

- Gemini CLI detection and dispatch;
- `parse_gemini_cli()` and `_parse_gemini_message()`;
- token-lane and session-event construction;
- thought/tool helpers;
- existing runtime authoredness rules.

Facts proved:

- session identity/title/timestamps/project/directories/models;
- user material origin remains unknown on runtime data;
- assistant material origin is typed;
- disjoint input/cache lanes plus output/thought/tool/total values and original wire tokens;
- thought description/subject/timestamp;
- tool `args`, successful and failed `functionResponse`, and status-only success.

Representative anti-vacuity mutations: export-upgrade CLI users, ignore `args`, drop function responses, flatten cache-inclusive input, or mark all status-only results as errors. Literal assertions fail.

### 8. `test_gemini_cli_subagent_kind_survives_as_typed_branch_semantics`

Production dependencies:

- Gemini CLI detector kind values;
- `parse_gemini_cli()` session construction;
- existing `BranchType.SUBAGENT` field.

Facts proved:

- `kind: subagent` is detected and becomes typed branch semantics;
- session and project identity survive.

Representative anti-vacuity mutation: keep the historical `kind == "chat"` detector or discard `kind` during parsing. Detection or branch-type assertions fail.

## Execution environment

- Base: exact snapshot commit `b9052e09103502017c0f510ecc699aac395de23c`.
- Test interpreter: isolated Python environment with project runtime/test dependencies installed.
- Repository-compatible plugin profile: `-p no:randomly -p no:random-order --benchmark-disable`.
- Clean-apply import check resolved `polylogue` from `/tmp/testdiet12/apply-check/polylogue/__init__.py`.
- No live daemon, browser, Drive account, Gemini CLI home, secrets, or NixOS deployment was used.

## Commands and results

### Clean apply

```bash
git checkout b9052e09103502017c0f510ecc699aac395de23c
git apply --check PATCH.diff
git apply PATCH.diff
git diff --check
```

Result: passed.

### New laws

```bash
pytest -q -p no:randomly -p no:random-order --benchmark-disable \
  tests/unit/sources/test_gemini_drive_normalization_laws.py
```

Result: `8 passed`.

### Affected regression surface

```bash
pytest -q -p no:randomly -p no:random-order --benchmark-disable \
  tests/unit/sources/parsers/test_origin_regression_pack.py \
  tests/unit/sources/test_dispatch_ordering.py \
  tests/unit/sources/test_dispatch_payloads.py \
  tests/unit/sources/test_gemini_chunked_prompt_contract.py \
  tests/unit/sources/test_gemini_drive_normalization_laws.py \
  tests/unit/sources/test_models.py \
  tests/unit/sources/test_parsers_drive.py \
  tests/unit/sources/test_parsers_drive_catalog.py \
  tests/unit/sources/test_parsers_local_agent.py \
  tests/unit/sources/test_schema_driven.py \
  tests/unit/sources/test_null_guard_properties.py::TestGeminiNonePartsProperty \
  tests/unit/storage/test_archive_search_contracts.py::test_gemini_drive_attachment_id_is_searchable_after_parse_and_prepare
```

Results:

- development workspace: `417 passed in 5.28s`;
- fresh checkout after applying `PATCH.diff`: `417 passed in 8.74s`.

This set includes detector ordering, dispatch payloads, provider-origin regression, checked-in Gemini chunked-prompt witnesses, provider models, Drive and Gemini CLI parsers, Drive catalog parse/save/hydrate roundtrips, schema-driven cases, null guards, and attachment search preparation.

### Parser seed fuzz corpora

```bash
pytest -q -p no:randomly -p no:random-order --benchmark-disable \
  tests/fuzz/fuzz_json_parsers.py::TestParserFuzz::test_drive_parser_corpus \
  tests/fuzz/fuzz_json_parsers.py::TestParserFuzz::test_local_agent_parser_corpus
```

Result after clean apply: `59 passed in 1.01s`.

### Direct Drive lowering/source laws

```bash
pytest -q -p no:randomly -p no:random-order --benchmark-disable \
  tests/unit/sources/test_source_laws.py::test_parse_drive_payload_contract \
  tests/unit/sources/test_source_laws.py::test_parse_drive_payload_recurses_lists_and_detected_payloads
```

Result: `4 passed in 1.14s` in the development workspace.

### Static and structural checks

```bash
ruff format --check <all eight changed files>
ruff check <all eight changed files>
mypy --strict <all eight changed files>
python -m compileall -q <all eight changed files>
git diff --check
```

Results:

- Ruff format: passed, eight files already formatted;
- Ruff lint: passed;
- strict mypy: `Success: no issues found in 8 source files`;
- bytecode compilation: passed;
- diff whitespace check: passed.

A combined 120-second wrapper completed the 417 tests and both Ruff checks, then reached its timeout while mypy was still running. Mypy, compilation, and `git diff --check` were rerun separately and passed; no pass is inferred from the timed wrapper.

## Incomplete or environment-limited checks

### Generated Gemini bundle Hypothesis node

Attempted node:

```bash
pytest -q -p no:randomly -p no:random-order --benchmark-disable \
  'tests/unit/sources/test_source_laws.py::test_parse_payload_bundle_cardinality_contract[gemini-bundle]'
```

Result: did not complete within an isolated 240-second limit in the ad-hoc environment. No pass or deterministic product failure is claimed. Bead `polylogue-b054.1.1.7` records that this node is load/shape sensitive and that bounded strategies passed in the intended xdist/full-seed lane; that lane remains **unverified** here.

### Plugin incompatibility isolated

An initial broad run with `pytest-randomly` enabled produced 134 setup/teardown plugin errors with `Seed must be between 0 and 2**32 - 1` after 244 tests had passed. The repository’s own devtools test profile disables both `randomly` and `random-order`. The same affected surfaces passed under that repository-compatible profile. The failed plugin run is not counted as product verification.

### Not performed

- full repository suite;
- native Nix/devtools full verification lane;
- live Drive/Gemini CLI acquisition;
- daemon/browser/deployment checks;
- tests against operator secrets or current worktree.

All are **unverified**.
