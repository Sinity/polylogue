# Verification limits

## What was run successfully

The implementation was exercised in the container against the supplied snapshot with Python 3.13.5 and pytest 9.0.2.

Successful checks recorded in `TESTS/verification-log.txt`:

- `PYTHONPATH=. pytest -q tests/unit/archive/query/test_execution_control.py`
  - 15 passed.
- Five additional consecutive runs of the same focused file.
  - 75 additional passes.
- A clean-snapshot replay after generating the final patch, followed by the same focused file.
  - 15 additional passes.
- Total recorded focused test executions: 105 passes.
- Every focused run includes 20 repeated deadline interruptions and exact steady-state assertions.
- `python -m py_compile` on all seven changed production/test files.
- Ruff lint on all seven changed files, with `E402` ignored only because `tests/unit/daemon/test_web_reader.py` intentionally has pre-existing imports after module-level pytest marker setup.
- Ruff format check on the two entirely new files.
- `git diff --check` / staged diff whitespace validation.
- `git apply --check` on a pristine archive of the local baseline tree.
- Actual patch application to that pristine tree.
- Byte-for-byte comparison of all seven patched files with the staged implementation worktree.
- `git apply --reverse --check` after clean application.

## Checks attempted but blocked by snapshot omissions

The real MCP query-units route suite was invoked with:

```bash
PYTHONPATH=. pytest -q tests/unit/mcp/test_server_surfaces.py -k query_units -x
```

Collection stopped because the supplied snapshot omits `tests.infra.mcp`.

The real HTTP query-units route suite was invoked with:

```bash
PYTHONPATH=. pytest -q tests/unit/daemon/test_web_reader.py -k query_units -x
```

Collection stopped because the supplied snapshot omits `polylogue.core.identity_law` and the wider package graph.

A full supplied test run was also attempted and stopped at the first collection error because `polylogue.archive.message` is omitted. These are snapshot completeness failures, not passing route/full-suite results. The exact tracebacks and exit codes are preserved in `TESTS/verification-log.txt`.

## What was not available or not claimed

- No operator remote or current master was fetched.
- No rebase onto post-snapshot master was performed.
- No complete repository checkout was available.
- No Nix build, NixOS service, or deployed derivation was run.
- No live MCP client/daemon cancellation protocol was exercised.
- No live browser, browser-capture process, secrets, or private archive was available.
- No HTTP request was sent through the operator’s deployed reverse proxy.
- No production archive or multi-gigabyte incident corpus was used.
- No live RSS, PSS, swap, file-descriptor, thread, or temp-file time series was measured.
- No process profiler, mutation framework, or fault-injection framework was available.
- No generated topology, MCP reference, OpenAPI, or other full-repository rendered artifact was regenerated.
- Paging/spool production and temp-file ownership are absent from this snapshot and belong to the sibling result-delivery slice; cancellation during that stage was not implemented or tested here.

## Required local completion before launch

1. Rebase/apply on current master and resolve the hotspots in `DESIGN/current-master-conflicts.md`.
2. Regenerate topology and all generated surfaces.
3. Run the two production-route tests added by the patch, all existing query-units tests, full unit tests, lint, type checking, and render checks.
4. Exercise real MCP cancellation and health liveness.
5. Exercise direct and proxied HTTP disconnect.
6. Run the fairness, oversized eventual-admission, shutdown, and 1,000-call resource-return procedures in `TESTS/live-scale-verification.md`.
7. Integrate the sibling paging/spool owner into the same execution context and verify temp/spool cleanup before claiming the complete Beads acceptance criterion.

## Interpretation

The focused execution-control substrate is strongly self-verified and the packaged patch cleanly replays on the supplied base. Production-route integration is present in source and route tests are included, but launch readiness remains conditional on full-checkout, current-master, generated-artifact, deployment, and live-scale verification.
