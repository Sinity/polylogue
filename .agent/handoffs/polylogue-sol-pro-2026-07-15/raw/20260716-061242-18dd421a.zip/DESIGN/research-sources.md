# Primary-source research record

Access date for all sources: 2026-07-16.

1. Python `sqlite3` library reference: https://docs.python.org/3/library/sqlite3.html
   - `Connection.interrupt()` may be called from another thread to abort pending database work.
   - `Connection.set_progress_handler(callback, n)` invokes the callback periodically during virtual-machine execution; a nonzero return terminates the query. Passing `None` removes the handler.
   - Project decision: use both exact-connection interrupt and a progress callback, then remove the handler during worker-owned cleanup.

2. SQLite C API, interrupt: https://sqlite.org/c3ref/interrupt.html
   - Describes interruption of operations on a specific database connection and the interrupted result behavior.
   - Project decision: register the exact per-query connection rather than use a process-global cancellation mechanism.

3. SQLite C API, progress handler: https://sqlite.org/c3ref/progress_handler.html
   - Describes periodic callback execution and nonzero callback abort behavior.
   - Project decision: check deadline/cancellation inside SQLite execution rather than only around the Python call.

4. SQLite URI filenames: https://sqlite.org/uri.html
   - Documents `mode=ro` URI behavior.
   - Project decision: production execution calls the repository’s `ArchiveStore.open_existing(..., read_only=True)`, which owns the project-specific read-only tier attachment/profile behavior rather than constructing a parallel raw connection path.

No secondary source controls the implementation. Repository instructions and the complete supplied Beads record are the project-specific authorities.
