# Execution-control design

## Problem boundary

The incident mechanism is not merely “a query lacks a timeout.” Synchronous SQLite work can occupy an MCP event loop or HTTP request thread after the client has stopped waiting, while an unbounded executor or queue accepts more work. Returning a timeout without stopping the actual statement creates false completion, leaked capacity, and continued CPU, I/O, memory, and swap consumption.

The design therefore treats an archive query as one owned transaction with identity, deadline, admission, connection, cancellation, worker, and cleanup state. A transport can signal cancellation, but it cannot declare terminal completion until the worker has stopped and ownership has been released.

## Production invariants

1. One execution has one `QueryExecutionContext` from request compilation through cleanup.
2. The context stores hashes of caller, expression, and plan, never raw sensitive query text.
3. Every active query uses a dedicated read-only archive reader opened inside its worker thread.
4. The exact SQLite connection used by the statement is registered with the context before the operation starts.
5. Cancellation is idempotent and interrupts that exact connection when present.
6. A SQLite progress callback also checks cancellation and monotonic deadline state.
7. The admission lease remains held until the worker has terminated and reader cleanup has run.
8. Reader close, progress-handler removal, connection unregister, lease release, watcher cancellation, and runtime deregistration each have one owner.
9. Queue bounds create retryable backpressure only. Estimated size never rewrites, truncates, limits, or permanently refuses a valid query.
10. MCP and HTTP adapt their cancellation signals into the same context and executor types.

## QueryExecutionContext

`QueryExecutionContext` is a frozen identity object with a private synchronized signal cell. The immutable part contains:

- random execution identity;
- stable or generated retry identity;
- SHA-256-derived caller, query, and plan references;
- workload class and advisory admission units;
- creation time and optional monotonic deadline.

The synchronized cell contains the lifecycle status/history, queue position, timestamps, cancellation event and reason, cleanup flag, safe error type, cancellation waiters from arbitrary event loops, and the exact currently registered connection.

The receipt state vocabulary is:

`created → resumed? → queued → admitted → running → completed`

Terminal alternatives are `cancelled`, `timed_out`, `disconnected`, and `failed`. Shutdown maps to cancellation because it is a cancellation cause rather than a separate externally meaningful completion state.

A caller-supplied retry identity is retained only when it is 16–64 ASCII alphanumeric, hyphen, or underscore characters. Other values are replaced by a safe hash. Raw expressions and plans never enter receipts or runtime snapshots.

## Dedicated SQLite execution

`InterruptibleSQLiteRead` owns a fixed-size `ThreadPoolExecutor`, a `QueryAdmissionController`, an active-context registry, and the archive-reader factory.

The worker performs the full ownership sequence:

1. Check cancellation/deadline before opening.
2. Open `ArchiveStore.open_existing(archive_root, read_only=True, read_timeout=...)` in the worker.
3. Register `archive._conn` with the context.
4. Install `set_progress_handler(context.sqlite_progress, progress_ops)`.
5. Re-check cancellation to close the register/interrupt race.
6. Mark running and invoke the existing semantic operation unchanged.
7. Re-check cancellation before publishing success.
8. Remove the progress handler.
9. Unregister the same connection.
10. Close the archive reader.
11. Map SQLite’s interrupted `OperationalError` to the context’s deadline/disconnect/cancel exception.

The async owner waits on the worker through `asyncio.shield`. If its task is cancelled, it records cancellation, calls `interrupt()`, and continues waiting for the worker to reach terminal cleanup before re-raising `CancelledError`. This is deliberate: cancellation responsiveness must not turn into abandoned work.

A closed-connection race is handled narrowly. If cleanup wins after cancellation snapshots the registered connection, a secondary `sqlite3.ProgrammingError` from `interrupt()` is ignored because the worker has already closed the resource. Other interrupt failures are not blanket-suppressed.

## Deadline and disconnect behavior

Deadlines use `time.monotonic`, not wall-clock time. They are checked while queued, by the async watcher, before and after reader registration, by the SQLite virtual-machine progress callback, and after the semantic operation.

HTTP passes the existing nonblocking peer-disconnect probe to the runtime watcher. A peer close sets the shared context to `disconnected`, invokes `interrupt()`, and lets the existing daemon disconnect suppression consume the resulting `ConnectionAbortedError` without attempting a meaningful response to a gone client.

MCP does not create a second cancel registry. Cancellation of the actual tool task reaches `InterruptibleSQLiteRead.execute`, which updates the same context and waits for exact worker cleanup before propagating `asyncio.CancelledError` to the MCP framework.

## Weighted admission

Admission is thread-safe and event-loop-neutral. Each waiter retains its own loop and future; controller state is protected by a `threading.RLock`. This is necessary because MCP has a long-lived loop while each synchronous HTTP request invokes an independent loop in its request thread.

The default class service cycle is four interactive turns, two standard turns, and one bulk turn. FIFO is enforced at the head of each class queue. Noninteractive work cannot consume the configured interactive reserve. Noninteractive active units from one caller are also capped at normal nonreserved capacity.

When a request is repeatedly bypassed or remains queued past the age threshold, it becomes a drain barrier. New standard/bulk work stops entering; cheap interactive work may continue only inside the reserved capacity while existing work drains. Once active units reach zero, the barrier request is admitted.

A request whose advisory units exceed total capacity is normalized to an exclusive lease equal to total capacity. This makes it wait for a drain and then run alone. It is not rejected because of the estimate. The same normalization applies when noninteractive work needs more than normal nonreserved capacity.

The queue itself is bounded. If a newly appended request cannot be admitted and the waiting bound is already full, it is removed and receives `QueryAdmissionBackpressureError` containing a safe retry identity, queue position, current depth, and maximum depth. This is a transient host-protection response, not a semantic judgment about the query.

## Route integration

The existing `query_unit_request` still compiles filters, offsets, limits, source pipeline, and terminal behavior. The existing `query_unit_envelope` still executes those semantics. The new `query_unit_execution_context` only derives scheduling metadata and a safe plan hash, while `execute_query_unit_request` wraps the existing envelope in the interruptible runtime.

The MCP route adds only a final optional `retry_id`. It returns `query_busy`, `query_timed_out`, or `query_cancelled` error JSON where appropriate. It does not catch `asyncio.CancelledError`, preserving framework cancellation after cleanup.

The HTTP route accepts `X-Polylogue-Query-Retry-ID`, emits execution/retry/status headers, and returns 503 with `Retry-After` for bounded queue pressure, deadline expiry, or server cancellation. The server owns the runtime and closes it with `wait=True`, which cancels active contexts, interrupts live connections, and waits for worker shutdown.

## Defaults in the patch

- query deadline: 30 seconds;
- worker count and admission capacity: 8;
- queue bound: 16 waiting requests;
- interactive reserve: 1 unit;
- SQLite progress interval: 1,000 VM instructions;
- disconnect/deadline watcher interval: 25 milliseconds;
- starvation barrier: 16 bypasses or 2 seconds queued;
- workload estimate: rows up to 25 = interactive/1; larger row pages = standard/2; aggregate or other terminal work = bulk/4.

These values affect scheduling and responsiveness only. They do not change result semantics.

## Rejected alternatives

### `asyncio.wait_for` around synchronous archive code

This times out the waiter but does not stop SQLite. It recreates false terminal completion and resource leakage.

### The default executor or an unbounded submission queue

A default/shared executor couples unrelated work and has no query-specific queue bound. A bounded admission lease before submission is required.

### Releasing admission as soon as the client cancels

The statement could still be executing. Releasing early makes accounting dishonest and allows capacity amplification during an incident.

### Sharing an existing reader or writer connection

SQLite connection ownership and interruption would become ambiguous, and a cancellation could affect another request or writer. Each active query needs a dedicated read-only connection.

### Per-transport timeout/cancel registries

Separate MCP and HTTP state machines drift and race with the worker. Transport code should only translate signals into the archive-layer context.

### Permanent cost or size refusal

Estimates are imperfect and resource bounds are not query semantics. Large valid work is queued and eventually admitted exclusively; only temporary queue pressure is rejected with a retry identity.

### SQL rewriting, implicit limits, or truncation

These would silently change the user’s valid query. The patch leaves expression compilation, filters, terminal action, limit, offset, and result envelope unchanged.

### Process-wide SQLite interrupt or worker termination

Interrupting an arbitrary/shared connection is unsafe, while killing Python worker threads is not supported. Exact connection registration plus SQLite’s progress and interrupt APIs is the narrow mechanism.

## Scope boundary with paging/spooling

The Beads record assigns result paging/spool format to the sibling delivery slice. This snapshot has no production page/spool owner to patch. The context and runtime are designed so a future spool producer can remain inside the same admitted worker/ownership scope, register temp resources with that owner, and delay lease release until spool cleanup. This handoff does not claim cancellation during absent spool production.
