# Executive result

The patch implements a cohesive production execution-control foundation for archive query-units reads without changing valid query semantics.

A query now receives one immutable `QueryExecutionContext` carrying safe identity references, a monotonic deadline, cancellation state, workload class, admission weight, queue position, retry identity, lifecycle history, and ownership of the exact active SQLite connection. The same context is used by MCP and HTTP. MCP task cancellation and HTTP peer disconnect are transport signals into that shared state, not separate timeout systems.

Archive execution moves to a dedicated bounded `ThreadPoolExecutor`. Each admitted worker opens, configures, uses, and closes its own `ArchiveStore.open_existing(..., read_only=True)` connection. It installs a SQLite progress callback, registers the exact connection with the context, and removes the handler, unregisters the connection, closes the reader, releases admission, and marks cleanup in one ownership chain. Cancellation invokes `Connection.interrupt()` and the progress callback independently checks cancellation and deadline state.

Admission is weighted and bounded. It preserves FIFO at each workload-class head, uses a 4:2:1 interactive/standard/bulk service cycle, reserves interactive capacity, tracks noninteractive caller usage, and promotes bypassed or aged work to a drain barrier. A valid estimate larger than instantaneous capacity becomes an exclusive full-capacity admission request; it is never permanently rejected because it is large. Queue overflow is temporary backpressure with a stable retry identity and queue position.

The real MCP `query_units` tool and HTTP `GET /api/query-units` route now consume this foundation. HTTP returns safe execution/retry/status headers and a retryable 503 envelope on bounded-queue pressure. MCP exposes an additive final `retry_id` parameter and returns a structured `query_busy` error with retry identity and queue position.

## Acceptance-criteria matrix

| Criterion | Result in this handoff | Verification status |
|---|---|---|
| 1. Production context, admission, and interruptible read types consumed by a real route; no parallel MCP/HTTP state | Implemented in `polylogue/archive/query/execution_control.py`; consumed through shared helpers by the production MCP and HTTP query-units routes | Production modules compile; clean patch replay passed. Full route suites are authored but cannot collect in the partial snapshot |
| 2. Dedicated read-only SQLite workers; deadline/cancel/disconnect interrupt exact connection | Implemented with per-worker `ArchiveStore.open_existing(read_only=True)`, `set_progress_handler`, registered `interrupt()`, and worker-owned close | Focused deadline, task-cancel, disconnect, read-only, and exact-cleanup tests pass |
| 3. Event-loop heartbeat and cheap-read liveness while expensive work runs | Implemented through worker offload and interactive reserve | Focused heartbeat test and simultaneous bulk/cheap-read test pass; live MCP health endpoint was not available |
| 4. Fair weighted admission, queue/retry observability, large-work eventual admission, no size refusal | Implemented with weighted class cycle, FIFO class heads, reserve, bypass/age barrier, stable retry ID, bounded queue, and exclusive normalization | Fairness, cheap-read reserve, bounded backpressure, cross-loop, and oversized eventual-admission tests pass; real HTTP backpressure test is included but could not collect here |
| 5. Exact cleanup across queued/running/disconnect/failure; repeated calls return to steady state | Reader, handler, connection registration, permit, watcher task, and runtime registry cleanup have one owner and exactly-once release | Queued deadline/cancel, worker failure, closed-connection race, and 20 repeated interruptions pass. Page/spool/temp cleanup is not present in this snapshot; live RSS/PSS/swap checks remain local |
| 6. Safe lifecycle receipts with all required states and no raw expression leakage | Implemented with safe hashes for caller/query/plan and statuses including queued, admitted, running, completed, cancelled, timed_out, disconnected, resumed, and failed | Receipt leakage/history test passes; active runtime snapshots expose only safe receipts |
| 7. Focused, route, fairness, leak, and live-scale validation | Fifteen focused tests plus MCP cancellation and HTTP disconnect/backpressure production-route tests are included | Focused test executed successfully 105 times across recorded runs. Route collection is blocked by omitted snapshot packages. Live-scale verification remains operator work |

## Concrete files changed

- `polylogue/archive/query/execution_control.py`: production context, receipts, fair admission, bounded executor, SQLite interrupt/progress integration, runtime lifecycle, safe observability, and defaults.
- `polylogue/archive/query/unit_results.py`: shared context construction and executor adapter around the existing semantic `query_unit_envelope`.
- `polylogue/mcp/server_tools.py`: real MCP query-units path moved off-loop; task cancellation is allowed to propagate after worker cleanup; retryable backpressure translated into MCP error JSON.
- `polylogue/daemon/http.py`: real HTTP query-units path moved to the shared executor; disconnect probe, retry headers, explicit 503 backpressure/deadline responses, and server-owned shutdown added.
- `tests/unit/archive/query/test_execution_control.py`: fifteen focused execution-control tests.
- `tests/unit/mcp/test_server_surfaces.py`: production MCP route cancellation/off-loop/cleanup test.
- `tests/unit/daemon/test_web_reader.py`: real socket-disconnect and queue-backpressure production HTTP route tests.

## Main residual risks

The change has not been rebased onto the operator’s current master, run against the complete repository, exercised through a live MCP client, tested behind the deployed HTTP proxy, or measured on a production-scale archive. The snapshot lacks the paging/spool implementation assigned to the sibling delivery slice, so cancellation during page/spool production and temp-file cleanup cannot be completed here. Generated topology and MCP reference artifacts must be refreshed in the full checkout. See `VERIFICATION-LIMITS.md` and `DESIGN/current-master-conflicts.md`.
