# Operator live-scale verification plan

This plan must run in the operator environment against a synthetic or approved archive. Do not use private production data in an unapproved cloud worker.

## Preconditions

- Apply/rebase the patch on current master.
- Regenerate topology and generated surfaces.
- Run focused and full repository tests.
- Start the actual MCP daemon and HTTP daemon with production-equivalent SQLite tier layout and deployment proxy.
- Record daemon PID, archive size, SQLite versions, Python version, Nix derivation, worker/queue settings, and whether the proxy buffers or closes upstream connections.

## Baseline resource envelope

Before load, record five samples at one-second intervals:

```bash
PID=<polylogue-pid>
for i in 1 2 3 4 5; do
  date -Ins
  grep -E 'VmRSS|VmHWM|VmSwap|Threads' /proc/$PID/status
  printf 'fds='; find /proc/$PID/fd -maxdepth 1 -type l | wc -l
  printf 'tmp='; find "${TMPDIR:-/tmp}" -maxdepth 1 -type f -name '*polylogue*' -printf '%p %s\n'
  sleep 1
done
```

Store PSS as well when available:

```bash
grep -E 'Pss:|SwapPss:' /proc/$PID/smaps_rollup
```

## Deadline and exact SQLite interruption

Run a deliberately expensive valid recursive or aggregate archive query through the real MCP query-units tool. Use a controlled deadline smaller than natural completion. Record request start, cancellation signal, response/exception time, and the time active runtime receipts/admission return to zero.

Acceptance target: cancellation becomes observable within the project’s agreed SLO, no query worker continues consuming CPU after terminal cleanup, and the receipt is `timed_out` with `cleanup_complete=true`.

## MCP task cancellation and health liveness

While the expensive query is running:

1. Issue MCP health/readiness and a cheap query-units request from a second client.
2. Cancel the expensive tool call using the real MCP protocol/client cancellation path.
3. Measure health and cheap-read latency.
4. Confirm the expensive call propagates cancellation only after worker cleanup.

Acceptance target: health and cheap read stay inside the interactive SLO; no event-loop stall appears in traces; the cancelled execution reaches zero active units.

## HTTP disconnect through deployed proxy

Issue an expensive `GET /api/query-units` through the deployed proxy, wait until the SQLite statement is active, then close the client socket without reading the response. Confirm:

- the upstream handler observes peer disconnect;
- the shared context becomes `disconnected`;
- the exact SQLite connection receives interrupt;
- the worker, progress handler, reader, permit, and task all disappear;
- no noisy broken-pipe traceback is emitted.

Repeat with direct daemon access to separate proxy behavior from application behavior.

## Fairness and cheap-read liveness

Use at least three caller identities:

- caller A continuously submits standard work;
- caller B continuously submits bulk/aggregate work;
- caller C submits one-row or small-page interactive reads every 100 ms.

Record queue position, admitted class, caller ref, start/end time, and status for each safe receipt. Verify:

- FIFO at each class head;
- interactive capacity remains available;
- bulk work eventually runs despite interactive load;
- an oversized valid estimate drains and runs exclusively;
- no caller receives a permanent size/cost refusal;
- temporary overflow returns retry identity and queue position, and retry later succeeds.

## Incident-scale cleanup and resource return

Run at least 1,000 mixed calls with a controlled distribution of completion, queued cancellation, running cancellation, deadline, disconnect, and worker exception. Sample RSS/PSS/swap/fds/threads/temp files throughout and for five minutes after load.

Acceptance requires values to return to the declared steady-state envelope, with no monotonic growth in:

- active receipts or admission units;
- SQLite readers/file descriptors;
- progress handlers or worker tasks;
- thread count beyond bounded pool behavior;
- temporary/spool files once the sibling paging implementation is integrated;
- RSS/PSS/swap beyond the agreed allocator/cache tolerance.

## Shutdown

With one running and one queued expensive request, stop the daemon normally. Confirm shutdown cancels both, interrupts the running connection, never opens a reader for the queued request, waits for cleanup, and exits without a lingering worker process/thread.

## Evidence to retain

Retain command lines, sanitized safe receipts, latency samples, resource time series, process/thread profiles, daemon logs, proxy logs, SQLite/Python versions, and exact Git/Nix revisions. Do not retain raw sensitive query expressions in shared artifacts.
