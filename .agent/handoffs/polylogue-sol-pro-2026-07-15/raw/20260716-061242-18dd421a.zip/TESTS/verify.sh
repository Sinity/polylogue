#!/usr/bin/env bash
set -euo pipefail

BASE_REVISION="76ee0d3842f12920ee71ad06f22b9cd8d2f88730"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
HANDOFF_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
PATCH="$HANDOFF_ROOT/PATCHES/0001-make-archive-queries-interruptible.patch"
SOURCE_CHECKOUT="${1:-}"

if [[ -z "$SOURCE_CHECKOUT" || ! -d "$SOURCE_CHECKOUT/.git" ]]; then
  echo "usage: $0 /path/to/polylogue-git-checkout" >&2
  exit 64
fi
if [[ ! -f "$PATCH" ]]; then
  echo "missing patch: $PATCH" >&2
  exit 66
fi
if ! git -C "$SOURCE_CHECKOUT" cat-file -e "$BASE_REVISION^{commit}" 2>/dev/null; then
  echo "source checkout does not contain required base revision $BASE_REVISION" >&2
  exit 65
fi

TMP_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/polylogue-z9gh1-verify.XXXXXX")"
trap 'rm -rf "$TMP_ROOT"' EXIT
VERIFY_REPO="$TMP_ROOT/repo"

git clone --quiet --no-hardlinks "$SOURCE_CHECKOUT" "$VERIFY_REPO"
git -C "$VERIFY_REPO" checkout --quiet --detach "$BASE_REVISION"

git -C "$VERIFY_REPO" apply --check "$PATCH"
git -C "$VERIFY_REPO" apply "$PATCH"
git -C "$VERIFY_REPO" diff --check

cd "$VERIFY_REPO"
PYTHONPATH=. pytest -q tests/unit/archive/query/test_execution_control.py
python -m py_compile \
  polylogue/archive/query/execution_control.py \
  polylogue/archive/query/unit_results.py \
  polylogue/mcp/server_tools.py \
  polylogue/daemon/http.py \
  tests/unit/archive/query/test_execution_control.py \
  tests/unit/mcp/test_server_surfaces.py \
  tests/unit/daemon/test_web_reader.py

if command -v uvx >/dev/null 2>&1; then
  uvx ruff check --ignore E402 \
    polylogue/archive/query/execution_control.py \
    polylogue/archive/query/unit_results.py \
    polylogue/mcp/server_tools.py \
    polylogue/daemon/http.py \
    tests/unit/archive/query/test_execution_control.py \
    tests/unit/mcp/test_server_surfaces.py \
    tests/unit/daemon/test_web_reader.py
  uvx ruff format --check \
    polylogue/archive/query/execution_control.py \
    tests/unit/archive/query/test_execution_control.py
else
  echo "note: uvx is unavailable; ruff checks skipped" >&2
fi

if [[ "${POLYLOGUE_FULL_ROUTE_TESTS:-0}" == "1" ]]; then
  PYTHONPATH=. pytest -q tests/unit/mcp/test_server_surfaces.py -k query_units
  PYTHONPATH=. pytest -q tests/unit/daemon/test_web_reader.py -k query_units
fi

git apply --reverse --check "$PATCH"
printf 'verification passed on base %s\n' "$BASE_REVISION"
