# Test matrix

## Executed focused tests

`tests/unit/archive/query/test_execution_control.py` contains fifteen self-contained tests that use real `sqlite3` connections and the production execution-control types.

| Test | Behavior protected |
|---|---|
| `test_deadline_interrupts_sqlite_off_event_loop_and_keeps_heartbeat_live` | Recursive SQL is interrupted by deadline; event-loop heartbeat continues; worker thread differs from loop thread; handler/reader/permit cleanup is exact |
| `test_cheap_read_completes_while_bulk_sqlite_statement_is_running` | Interactive reserve and a second dedicated worker keep a cheap read live during expensive bulk SQL |
| `test_surface_task_cancellation_interrupts_once_and_waits_for_cleanup` | Async task cancellation interrupts the exact connection once and does not return before cleanup |
| `test_disconnect_uses_shared_context_and_exact_connection` | Disconnect probe updates the same context and interrupts the registered connection |
| `test_queued_deadline_and_task_cancellation_never_open_reader` | Cancellation/deadline before admission withdraws the waiter and never opens SQLite |
| `test_weighted_fairness_is_fifo_within_class_and_bulk_does_not_starve` | FIFO within class and bounded bypass fairness |
| `test_reserved_unit_keeps_cheap_read_live_behind_noninteractive_work` | Noninteractive work cannot consume the interactive reserve |
| `test_oversized_valid_work_drains_then_gets_exclusive_admission` | Large valid estimates eventually receive exclusive capacity rather than a size refusal |
| `test_bounded_queue_returns_retry_identity_not_size_refusal` | Temporary queue backpressure exposes retry identity/position; a huge request still runs once capacity is available |
| `test_repeated_deadline_interrupts_return_to_declared_steady_state` | Twenty successive incident-style interrupts return reader, handler, registry, queue, and permit counts to zero |
| `test_failure_and_read_only_connection_restore_exact_steady_state` | Worker exceptions release everything; attempted writes fail on read-only connections |
| `test_receipt_hashes_sensitive_text_and_records_resume_cleanup` | No raw query/plan leakage; resumed lifecycle and cleanup receipt are correct |
| `test_cancel_tolerates_worker_cleanup_winning_interrupt_race` | Closed-connection race does not replace a valid cancellation with secondary `ProgrammingError` |
| `test_runtime_rejects_zero_capacity_instead_of_treating_it_as_default` | Invalid zero capacity is rejected explicitly |
| `test_controller_admits_across_distinct_event_loops` | One controller safely serves independent MCP/HTTP-style event loops |

The recorded verification ran this focused file once, repeated it five more times, and ran it after applying the packaged patch to a clean snapshot: 105 passing test executions. Each run includes the twenty-interruption steady-state test.

## Production-route tests added

These tests are part of the patch and target the actual production routes rather than replicas:

- `tests/unit/mcp/test_server_surfaces.py::test_query_units_tool_cancellation_interrupts_production_route`
  - invokes the registered real MCP `query_units` tool;
  - substitutes only the semantic query operation with deliberately expensive recursive SQL;
  - confirms the operation runs off the MCP loop;
  - cancels the actual tool task;
  - asserts runtime/admission cleanup reaches zero.

- `tests/unit/daemon/test_web_reader.py::TestReaderQueryUnits::test_query_units_disconnect_interrupts_production_route`
  - starts the real `DaemonAPIHTTPServer`;
  - sends a real HTTP request over a socket;
  - closes the peer while recursive SQL is active;
  - asserts the worker terminates and runtime/admission cleanup reaches zero.

- `tests/unit/daemon/test_web_reader.py::TestReaderQueryUnits::test_query_units_backpressure_returns_retry_identity_and_queue_position`
  - starts the real server with a one-worker, zero-waiting-slot production runtime;
  - holds one actual query-units request in SQLite;
  - sends a second real HTTP request;
  - asserts 503, `Retry-After`, stable retry identity, queue position, and failed receipt status;
  - closes the first peer and verifies worker termination.

The supplied snapshot omits `tests.infra`, `polylogue.core`, and other package files imported by those existing suites, so these route tests could not collect here. Their exact collection failures are in `verification-log.txt`.

## Mutation expectations

The following mutations should fail focused or route tests in a complete checkout:

- remove `run_in_executor` or execute the operation in the caller loop;
- remove `Connection.interrupt()`;
- remove the SQLite progress callback or stop clearing it;
- release the admission lease before the worker terminates;
- open a writable reader;
- omit queued waiter withdrawal;
- stop reserving interactive capacity;
- reject oversized work permanently;
- leak raw expression/plan text into receipts;
- stop forwarding HTTP disconnect or MCP task cancellation into the shared context;
- omit server-owned runtime shutdown;
- drop retry identity or queue-position headers on HTTP backpressure.

## Commands

Focused snapshot lane:

```bash
PYTHONPATH=. pytest -q tests/unit/archive/query/test_execution_control.py
```

Complete-repository route lanes:

```bash
uv run pytest -q \
  tests/unit/mcp/test_server_surfaces.py::TestArchiveGenericToolSurfaces::test_query_units_tool_cancellation_interrupts_production_route

uv run pytest -q \
  tests/unit/daemon/test_web_reader.py::TestReaderQueryUnits::test_query_units_disconnect_interrupts_production_route \
  tests/unit/daemon/test_web_reader.py::TestReaderQueryUnits::test_query_units_backpressure_returns_retry_identity_and_queue_position
```
