# Polylogue archive-query execution-control handoff

This handoff targets Beads work item `polylogue-z9gh.1`, “Make archive queries interruptible and resource-bounded.” It is scoped to the immutable supplied snapshot at Git revision `76ee0d3842f12920ee71ad06f22b9cd8d2f88730` on branch `feature/browser/adopt-completion-monitors`.

The supplied Git evidence reported a clean tree: `status.txt` contained only the branch line, and both `working-tree.patch` and `staged.patch` were empty. The patch therefore assumes no pre-existing dirty changes in the seven touched paths. It does not modify the operator checkout automatically.

## Read and apply order

1. Read `SUMMARY.md` for the result and acceptance-criteria status.
2. Read `DESIGN/execution-control.md` for invariants, ownership, scheduling, cancellation, and rejected alternatives.
3. Read `DESIGN/current-master-conflicts.md` before rebasing onto any checkout other than the supplied revision.
4. Inspect and apply `PATCHES/0001-make-archive-queries-interruptible.patch`.
5. Run `TESTS/verify.sh /path/to/polylogue` from this extracted handoff. Set `POLYLOGUE_FULL_ROUTE_TESTS=1` when the complete repository and test infrastructure are available.
6. Follow `TESTS/live-scale-verification.md` in the operator environment.
7. Read `VERIFICATION-LIMITS.md` before treating the change as launch-ready.

## Apply manually

```bash
git switch --detach 76ee0d3842f12920ee71ad06f22b9cd8d2f88730
git status --short
git apply --check /path/to/handoff/PATCHES/0001-make-archive-queries-interruptible.patch
git apply /path/to/handoff/PATCHES/0001-make-archive-queries-interruptible.patch

PYTHONPATH=. pytest -q tests/unit/archive/query/test_execution_control.py
```

For a current branch, first create a worktree or topic branch, then apply with three-way assistance if needed:

```bash
git switch -c polylogue-z9gh-1/archive-query-execution-control
git apply --3way /path/to/handoff/PATCHES/0001-make-archive-queries-interruptible.patch
```

Do not retain an older outer timeout wrapper around the patched `query_units` route. A timeout that returns before the SQLite worker reaches terminal cleanup recreates the incident mechanism this change is designed to remove.

## Patch contents

The single atomic patch adds production `QueryExecutionContext`, `QueryAdmissionController`, and `InterruptibleSQLiteRead` types in the archive query layer; moves the real MCP and HTTP query-units execution path onto dedicated read-only SQLite workers; translates MCP task cancellation and HTTP disconnect into one shared context model; adds weighted, bounded, retryable admission; and adds focused and real-route tests.

The patch is atomic because partial application would be unsafe. Admission accounting, exact SQLite connection ownership, worker cleanup, and transport cancellation must land together.

## Full-repository follow-up commands

The supplied snapshot omits files required by the production-route suites and generated projections. In a complete checkout, run at minimum:

```bash
devtools render topology-projection
devtools render topology-status
devtools render all --check
uv run pytest tests/unit/archive/query/test_execution_control.py -q
uv run pytest tests/unit/mcp/test_server_surfaces.py -k query_units -q
uv run pytest tests/unit/daemon/test_web_reader.py -k query_units -q
uv run pytest tests/unit -q
ruff check polylogue tests
mypy polylogue
```

The new MCP `retry_id` parameter is additive and deliberately placed last. Verify generated MCP reference/schema artifacts in the full repository even if `render all --check` does not identify a direct diff.
