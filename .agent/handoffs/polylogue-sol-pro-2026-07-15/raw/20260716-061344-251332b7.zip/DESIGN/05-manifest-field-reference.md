# Durable train manifest field reference

The production encoder writes the exact dataclass field graph plus top-level `manifest_sha256`. Unknown or missing fields fail decoding.

## Top-level identity and lifecycle

| Field | Meaning |
|---|---|
| `manifest_format` | `polylogue.durable-change-train.v1` |
| `train_id` | Stable train identity |
| `tier` | `source` or `user` |
| `current_version` / `target_version` | One contiguous version edge |
| `slot` | Numbered migration slot; must equal target |
| `owner_ref` | Train/reservation owner authority |
| `state` | declared, admitted, reserved, backup-authorized, applied, proven, released, or failed |
| `revision` | Optimistic concurrency token; persisted updates advance exactly one |
| timestamp fields | Ordered lifecycle evidence |
| `proof_refs` | Unique accumulated evidence references |

## Migration and riders

`migration` binds tier/target/slot, resource path, owner, SQL SHA-256, and backup requirement. `riders` contain rider/owner identity, schema object refs, runtime consumers, behavior proof refs, predecessor IDs, and optional trust-floor exception. Separate arrays carry ordering constraints, drop constraints, and row-change allowances.

## Admission and writer authority

`fresh_ddl_parity` stores target versions, migrated/fresh inventory hashes, object differences, evidence ref, and exact-match verdict. `reservation` stores lease identity, absolute archive/tier paths, stopped-daemon and single-writer refs, active/released state, and timestamps.

## Backup and apply evidence

`backup_authorization` distinguishes `additive-no-backup` from `verified-backup`. Verified mode stores absolute manifest/receipt paths and their hashes. `pre_apply_evidence` and apply `pre`/`post` bind tier, version, `quick_check`, schema inventory hash, sorted row counts, and observation time. `migration_result` is the existing runner’s result. `row_parity` records all changed/missing/unauthorized table outcomes.

## Proof and failure

`proof` contains actual post-apply fresh parity, sorted runtime consumer results, restart convergence, complete proof refs, and proof time. `failure` contains phase, prior state, error type/message, observed version, recovery classification, exact required actions, failure time, and retained pre-apply evidence.

## Persistence envelope

`manifest_sha256` is SHA-256 over the canonical JSON object excluding that checksum field. It detects corruption. The filesystem write path adds safe-parent checks, a single-linked `flock` lock, revision validation, mode-0600 temporary output, fsync, atomic replace, and directory fsync.
