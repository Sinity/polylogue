# Exact remaining production actuator wiring

The lifecycle kernel is complete and tested. The current production-style fast-forward actuator is not yet converted to use it. In the supplied snapshot, `devtools/archive_schema_fast_forward.activate_prepared_forward()` acquires `RebuildLease`, verifies the service is stopped, creates rollback clones, and then directly calls `migrate_archive_tier()` for source and user.

The next integrated slice should modify that existing route rather than create a second conductor.

## Required wiring sequence

1. Define the authority directory under existing Polylogue state storage, its ownership/mode, manifest filename convention, active-manifest discovery, completed-train retention, and garbage-collection policy. Discovery must load every source/user manifest strictly and pass all non-released trains into admission/reservation collision checks.

2. Before starting new apply work, load any persisted `BACKUP_AUTHORIZED` or `FAILED` train. Call `reconcile_interrupted_durable_change_train()` while the service remains stopped and the archive-root lease is held. Persist the returned state or the `failed_train` carried by `DurableChangeTrainRecoveryError`.

3. At declaration/admission time, build the fresh target database through the production bootstrap path, migrate a synthetic current database through the checked-in numbered migration, compute `prove_durable_fresh_ddl_parity()`, and persist `DECLARED` then `ADMITTED` with exact revision CAS.

4. Inside the existing `RebuildLease(archive_root)` and after `_require_service_stopped(service)`, persist `RESERVED` separately for source and user. When both tiers depart in one window, use the same reservation ID and owner so the independent trains share the one global lease lawfully.

5. Call `authorize_durable_change_train_backup()` on each live connection using the already verified `backup_manifest`. Persist `BACKUP_AUTHORIZED` before invoking apply. This state write is what makes commit-before-manifest crash recovery possible.

6. Replace each direct `migrate_archive_tier()` call with `apply_durable_change_train()`. Persist `APPLIED` immediately. If `DurableChangeTrainApplyError` is raised, persist `exc.failed_train` before rollback/restore handling and follow its machine-readable required actions.

7. Preserve the actuator’s existing rollback clones and promotion rollback. If restoration changes the durable tier back to current, reconcile the failed manifest against the restored bytes rather than silently resetting state. An indeterminate manifest must continue to block service restart until exact backup restoration is proved.

8. On actual exit from `RebuildLease`, call and persist `record_durable_writer_release()` for every applied or safely failed train. Do not record release while the lease context is still active.

9. Restart the actual configured daemon/service through the project’s existing service actuator. Capture a process/service evidence reference that identifies the stop and subsequent start, not merely a reopened SQLite connection.

10. Add a registry/dispatcher for admitted production consumer probes. Each `DurableRuntimeConsumer` must resolve to a real read/write behavior probe and return `DurableRuntimeConsumerResult` with the exact admitted consumer ID and behavior proof reference. Test-only call sites must remain inadmissible.

11. Reopen each live tier after service restart, compute actual fresh-DDL parity, run all registered consumer probes, and call `capture_durable_restart_convergence()`. Persist `PROVEN`, then `RELEASED`, using revision CAS for every transition.

12. Extend the actuator receipt so it references the final train manifest hash/revision for each tier. The receipt must not duplicate train evidence; it should point to the authority files.

## Additional closure work

The manifest records rider `schema_objects`, but current code does not derive the current→target object delta and allocate every changed object to exactly one rider/drop constraint. Add a canonical delta proof during admission if exact per-rider schema ownership is required as an executable invariant rather than a reviewed declaration.

Add full-tree integration tests around `activate_prepared_forward()` for: source-only departure, user-only departure, shared source+user lease, service-stop refusal, process death after SQLite commit and before `APPLIED`, failed consumer probe after restart, indeterminate restore, and successful receipt linkage.

Run topology/render regeneration only if the lifecycle is later split into a new module. Run the full project gates listed in `VERIFICATION-LIMITS.md` after wiring.

## Done condition for the residual slice

The residual work is complete when no production/operator route directly calls `migrate_archive_tier()` for source/user without a loaded admitted train, every state write is durable before the next irreversible action, a real service restart and real consumer probes are captured, and the final actuator receipt points to released train authority.
