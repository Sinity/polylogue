# Source evidence and decision record

Access date for web sources: 2026-07-16.

## Immutable supplied sources

- Input archive: `polylogue-sol-pro-context-06a62c2cf0789e54.tar.gz`
- Input SHA-256: `06a62c2cf0789e540ff0083cce7d4641d20f125990e5a3101801fd4962d138f7`
- Source revision: `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- Source branch metadata: `feature/browser/adopt-completion-monitors`
- Captured worktree: clean; staged and working-tree patches empty
- Selected Bead: `polylogue-60i5.1`
- Repository instructions: `INSTRUCTIONS/AGENTS.md` and `INSTRUCTIONS/CLAUDE.md`
- Pack report: 171 selected source files, no full-worktree fallback

## Beads authority consulted

The local selected record states that `polylogue-60i5.1` must land one machine-readable `DurableChangeTrain` for source and user, integrate p155 collision keys, canonical inventory, backup verification, stopped-daemon apply, fresh-DDL parity, behavior checks, and restart convergence, without a new migration engine.

The complete relevant records were checked in the exact revision’s `.beads/issues.jsonl`:

- `polylogue-60i5`: one train per tier/target; declare from shipped version; two materially distinct consumers unless a trust-floor exception; one writer; one contiguous migration; authenticated backup; stopped-daemon apply; restart before release; source/user independent.
- `polylogue-60i5.1`: the concrete lifecycle slice and six acceptance criteria reproduced in `SUMMARY.md`.
- `polylogue-p155`: structured `(tier, target schema version, numbered slot)` collision key, both paths/owners in diagnostics, quick-gate and JSON output, replay of the 008 incident.
- `polylogue-ihp0`: canonical inventory should replace hand-maintained durable-tier table universes and migration/fresh DDL should converge.

## Public exact-revision references

- Commit: `https://github.com/Sinity/polylogue/commit/76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- Beads export: `https://raw.githubusercontent.com/Sinity/polylogue/76ee0d3842f12920ee71ad06f22b9cd8d2f88730/.beads/issues.jsonl`

The public repository was used only to inspect exact-revision metadata and complete Beads records omitted from the focused local selection. An attempted full clone inside the container failed because outbound DNS was unavailable; no claim is made that the full checkout or its full dependency graph was executed.

## Existing code anchors used

- `polylogue/storage/sqlite/migration_runner.py`: numbered durable resource loading, backup requirement marker, backup attestation validation, transaction and version checks.
- `polylogue/storage/backup_attestation.py`: authenticated verification receipt authority.
- `devtools/verify_schema_upgrade_lane.py`: existing schema-evolution policy surface.
- `devtools/verify.py`: fast verification step construction.
- `devtools/archive_schema_fast_forward.py`: existing `RebuildLease`, stopped-service check, rollback clone, and direct source/user migration calls; identified as the residual actuator integration point.
- Checked-in source migrations 008 and 009: collision replay fixture.

## Source-supported facts versus implementation decisions

Source-supported facts are the Beads requirements, existing migration/backup/lease behavior, clean source revision, and focused-pack omissions.

Implementation decisions are: place the kernel in the existing runner module; share collision claim code; use immutable dataclasses and strict JSON; persist pre-apply evidence at backup authorization; allow source/user to share only an identical global lease; use row-count parity as the generic baseline; serialize manifest CAS with `flock`; and fail closed on unknown versions.

Proposals, not landed code, are confined to `DESIGN/03-remaining-actuator-wiring.md`.
