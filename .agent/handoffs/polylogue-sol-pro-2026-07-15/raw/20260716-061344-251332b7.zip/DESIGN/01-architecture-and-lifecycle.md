# Architecture and lifecycle

## Integration point

The lifecycle is implemented in `polylogue/storage/sqlite/migration_runner.py`, beside the existing durable migration runner. This keeps one source of truth for migration resource loading, backup requirements, backup receipt validation, WAL checks, version checks, and `BEGIN IMMEDIATE` transaction behavior.

The central rule is: the train grants authority; the existing runner changes bytes.

```python
result = migrate_archive_tier(conn, train.tier, backup_manifest=backup_manifest)
```

The lifecycle verifies that `result.from_version`, `result.to_version`, and `result.applied_versions` describe exactly the train’s one contiguous target. It does not execute migration SQL independently.

## Contention model

Every numbered durable migration becomes a `DurableMigrationClaim` with:

```text
(tier, target_version, numbered_slot, path, owner_ref, sql_sha256, requires_backup)
```

The contention key is `(tier, target_version, numbered_slot)`. Both policy lint and train admission call the same collision implementation, so merge-time and rollout-time ownership cannot drift into separate definitions.

A source train and a user train have independent contention keys and may depart independently. The existing writer lease is archive-root scoped, however. The reservation layer therefore permits both tiers to share one global lease only when `reservation_id` and `owner_ref` are identical. Any second active lease for the same archive root is rejected.

## Manifest structure

`DurableChangeTrain` is immutable and contains:

- identity and ownership: format, train ID, tier, current/target versions, slot, owner, exact migration claim;
- admitted work: riders, schema object refs, production consumers, behavioral proof refs, ordering/drop constraints, row-change allowances, backup plan;
- lifecycle control: state, monotonic revision, declaration/admission/release timestamps;
- writer authority: archive root, exact tier path, reservation ID/owner, daemon-stopped evidence, single-writer evidence, release evidence;
- backup authority: mode, exact live path/version, manifest and receipt paths/hashes, evidence reference;
- database evidence: `quick_check`, version, canonical schema hash, table row census;
- apply evidence: existing runner result, pre/post evidence, row parity, interrupt-recovery flag;
- proof: fresh-DDL parity, exact runtime consumer results, restart convergence, accumulated evidence refs;
- failure: phase, previous state, exception type/message, observed version, classification, exact operator actions, retained pre-apply evidence.

The persisted format is `polylogue.durable-change-train.v1`.

## State transitions

| State | Entry authority | Principal checks | Next state |
|---|---|---|---|
| `DECLARED` | Owner names one contiguous shipped slot and complete initial rider set. | Durable tier; target=current+1; slot=target; migration claim matches. | `ADMITTED` |
| `ADMITTED` | Policy admits exact migration, riders, and fresh DDL. | Live current and canonical target are current; exactly one shipped claim; no collision; runtime-complete riders; fresh parity exact; backup plan present when required. | `RESERVED` |
| `RESERVED` | Existing archive writer lease and stopped daemon are evidenced. | Owner/path binding; one active lease per archive root; source/user sharing only under identical lease identity. | `BACKUP_AUTHORIZED` |
| `BACKUP_AUTHORIZED` | Exact live tier and authenticated backup authority are bound. | Live path/version; existing backup validator; manifest/receipt hashes; pre-apply integrity/schema/row census. | `APPLIED` or `FAILED` |
| `APPLIED` | Existing migration runner committed one exact slot. | Pre-state unchanged since authorization; runner result exact; target version; quick check; row parity. Writer still must be released. | `PROVEN` after writer release and proofs |
| `PROVEN` | Post-apply schema, consumers, and restart have converged. | Actual migrated-vs-fresh inventory; exact admitted consumer result set; released writer; reopened target version/hash; timestamp ordering. | `RELEASED` |
| `RELEASED` | Train proof is complete and final release evidence is recorded. | Proof retained; restart converged; release follows proof. | terminal |
| `FAILED` | Apply or interruption produced an exact failure manifest. | Classification matches observed version; pre-evidence retained; unsafe indeterminate state keeps writer authority. | explicit recovery only |

Riders may be added only while declared. Admission freezes the set. A late rider gets a new train for the next target version; it cannot reopen an admitted or released train.

## Admission and runtime completeness

Each rider must name schema objects, behavior proof references, and at least one production runtime consumer. By default, at least two distinct production references are required. A single-consumer rider needs an explicit trust-floor exception. Test and fixture references are rejected as production consumers. Consumer IDs must be globally unique within the train, and each consumer’s behavior reference must be owned by its rider.

Ordering is represented both by rider predecessor IDs and explicit cross-rider constraints. A cycle check runs before admission. Drop constraints require object identity, ordering, copy-forward proof, and destructive-change consent. Row-change allowances require a table, authority reference, and optionally an exact expected delta.

## Canonical schema and fresh-DDL parity

The canonical inventory is derived from SQLite itself rather than a hand-maintained table set. It enumerates non-internal tables, indexes, triggers, and views and fingerprints:

- normalized stored DDL;
- `table_xinfo` and `foreign_key_list` for tables;
- `index_xinfo` for indexes.

The DDL normalizer collapses layout and comments only outside quoted strings and identifiers. This avoids treating trigger literals `'a  b'` and `'a b'` as equal while still ignoring harmless external formatting differences.

Fresh parity compares both `PRAGMA user_version` values, object membership, per-object fingerprints, and the aggregate inventory hash. Admission requires a matching synthetic migrated/fresh proof. Final proof recomputes parity against the actual post-apply connection and binds it to the post-apply schema hash and the fresh inventory hash admitted earlier.

## Backup and crash-window design

Backup-required SQL is still determined by the existing migration-safety header rule. Authorization calls the existing authenticated backup validator and then records the exact manifest and receipt hashes. Additive no-backup migrations use the existing opt-out marker and are represented explicitly as `additive-no-backup` authority.

The pre-apply database evidence is captured and persisted at authorization, before the runner is called. This is critical for the crash window:

1. manifest says `BACKUP_AUTHORIZED`;
2. SQLite transaction commits;
3. process dies before manifest says `APPLIED`.

On restart, the persisted pre-census remains available. Reconciliation branches only on exact versions:

| Observed version | Classification | Recovery |
|---|---|---|
| declared current | `rolled-back-to-current` | Release old writer authority, return to admitted, reserve and reauthorize before retrying. |
| declared target | `committed-target-unproven` | Never reapply. Capture post evidence and row parity, reconstruct `APPLIED`, then prove runtime/restart. |
| anything else or unreadable | `indeterminate` | Keep daemon stopped and writer authority active; restore the exact authenticated backup before replacement work. |

An indeterminate train cannot record writer release.

## Row parity

The generic proof compares row counts for every pre-existing non-virtual table. Missing tables require an admitted drop constraint. Count changes require an admitted row-change allowance and, when declared, the exact expected delta. New tables are allowed because they had no pre-existing rows to preserve.

This is a bounded generic invariant, not a content hash. It catches common destructive migration failures cheaply but cannot detect value rewrites that preserve counts. The runtime/data proof layer remains required for such changes.

## Runtime and restart proof

`prove_durable_change_train()` requires one passing result for every admitted consumer and no extras. IDs and behavior proof refs must match admission exactly. A caller cannot substitute a different proof contract after apply.

Restart convergence is captured from a reopened SQLite connection. It requires target version, successful `quick_check`, the same schema inventory hash as post-apply, and the complete passing consumer ID set. The writer reservation must already be released, and timestamps enforce authorization→evidence→apply→writer release→restart→proof→train release ordering.

The function validates evidence supplied by an actuator; it does not itself restart a system service or dispatch production probes.

## Persistence and concurrency

The encoder accepts only the typed dataclass graph and writes sorted canonical JSON plus `manifest_sha256`. The decoder rejects missing fields, unknown fields, wrong JSON types, unsupported enums, and checksum mismatch, then reruns all cross-field lifecycle invariants. Recomputing a checksum over semantically inconsistent evidence is insufficient to obtain authority.

Writes require an expected revision. Existing manifests must advance exactly one revision. A safe hidden lock file is opened with `O_NOFOLLOW`, checked as a single-linked regular file, and held with `flock` across revision read, temporary-file fsync, atomic replace, and directory fsync. Authority parents and files may not be symlinked or multiply linked. Temporary manifests are mode 0600.

The checksum and lock protect consistency among cooperating local processes. They are not cryptographic authorization against a hostile user with equal filesystem privileges.
