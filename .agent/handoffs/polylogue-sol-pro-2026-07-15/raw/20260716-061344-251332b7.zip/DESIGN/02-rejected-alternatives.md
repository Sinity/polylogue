# Rejected alternatives and tradeoffs

## A second migration engine

Rejected. A train that parsed and executed SQL separately would duplicate the existing transaction, backup, WAL, version, and resource-loading rules. The lifecycle delegates to `migrate_archive_tier()` and treats its exact `MigrationResult` as apply evidence.

## Encoding authority only in SQL comments or Beads prose

Rejected. SQL headers still express the existing backup opt-out, but they cannot represent rider ownership, runtime consumers, writer reservation, backup receipt binding, recovery state, or restart proof. Beads remains planning evidence, not mutable rollout authority.

## Keeping collision lint separate from lifecycle admission

Rejected. That would leave merge-time and rollout-time definitions free to drift. `DurableMigrationClaim`, collision grouping, and JSON report construction are shared by the runner, policy command, and train admission.

## One combined source+user train

Rejected. The parent contract explicitly makes source and user trains independent. Their schema targets and riders must be admitted separately. They coordinate only through the existing archive-root writer lease, which may be shared by matching reservation identity.

## Releasing after SQLite commit

Rejected. A successful transaction does not prove fresh-DDL parity, consumer behavior, or restart convergence. The writer lease is released before restart proof, but train contention remains owned until the full proof bundle is present.

## Automatically retrying any interrupted state

Rejected. Only exact current and target versions are unambiguous. Any other or unreadable version fails closed and retains stopped-daemon/single-writer authority pending exact authenticated restore.

## Hand-maintained canonical table lists

Rejected. Additive migrations make exact table sets stale. Inventory is derived from `sqlite_schema` and structural pragmas. This aligns with the canonical-inventory Bead and prevents unrelated valid additions from breaking legacy-absence tests.

## Blind whitespace normalization of stored DDL

Rejected during final audit. A regex over the whole SQL string collapsed whitespace inside trigger literals and could treat semantically different definitions as equal. The final normalizer protects literals and quoted identifiers before normalizing external layout.

## Manifest checksum as authorization

Rejected. A checksum is corruption detection, not a signature. Semantic validation, safe paths, a serialized revision lock, and the outer operator/lease trust boundary are all still required.

## Revision checking without serialization

Rejected during final audit. Reading revision N and then replacing the file is not a real compare-and-swap when two processes can race. The final write path holds a stable `flock` lock and requires exact N→N+1 advancement.

## A new lifecycle module

Deferred, not rejected architecturally. Project instructions require regenerating topology projections for a new `polylogue/` module. The focused pack did not contain that generated surface or full verification route. Keeping the kernel in `migration_runner.py` avoids an unverifiable generated-file delta and keeps the migration authority beside the engine it wraps. A later full-tree refactor may split the file only with topology regeneration and unchanged public behavior.

## Full-table content hashing as the generic row proof

Not selected for the kernel. Hashing every durable row can be expensive, representation-sensitive, and hard to define generically across migrations. The landed baseline uses row-count parity plus explicit allowances and mandatory behavior proof. High-risk data rewrites should add domain-specific fingerprints or copy-forward receipts rather than pretending count parity proves content identity.
