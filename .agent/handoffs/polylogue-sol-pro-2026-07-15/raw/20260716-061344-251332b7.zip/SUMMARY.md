# Executive result

The handoff lands a complete durable-change authority kernel and its focused tests. It converts the existing prose-coordinated migration window into a strict JSON manifest with typed lifecycle state, one-slot collision ownership, rider/runtime declarations, stopped-daemon and single-writer evidence, backup authorization, pre/post database evidence, row parity, fresh-DDL parity, runtime-consumer proof, restart convergence, failure classification, and final release.

The implementation reuses the existing additive migration runner and backup attestation. `apply_durable_change_train()` calls `migrate_archive_tier()` directly and verifies that exactly the train’s one contiguous numbered slot was applied. The existing transaction, WAL quiescence, backup receipt, and live-byte validation remain authoritative.

Six ordered patches modify five files: 3,447 insertions and 22 deletions. The focused verification collected and passed 21 tests. The policy command returned `ok: true`, the patch series replayed cleanly, and the replay tree matched the authored tree exactly.

## Main production changes

`polylogue/storage/sqlite/migration_runner.py` now owns the shared durable-migration contention claim and the lifecycle types/functions. The machine-readable state sequence is:

```text
DECLARED → ADMITTED → RESERVED → BACKUP_AUTHORIZED → APPLIED → PROVEN → RELEASED
                                                   ↘ FAILED → explicit recovery branch
```

Admission rejects stale current or target versions, duplicate ownership of `(tier, target_version, slot)`, unshipped or byte-mismatched migrations, backup-required trains without a backup plan, schema-only riders, test-only consumers, insufficient production-consumer diversity without a trust-floor exception, rider ordering cycles, and failed fresh-DDL parity.

Reservation binds the exact archive root and `{tier}.db` path to stopped-daemon and single-writer evidence. Source and user trains remain independent contention units, while both may share the same existing archive-root writer lease only when reservation ID and owner are identical.

Backup authorization reuses `validate_migration_backup_manifest()`, hashes the manifest and receipt, binds the live path and current version, and persists a pre-apply schema/row census before invoking the existing runner. This closes the crash window in which SQLite commits but the process dies before writing `APPLIED`.

Apply captures integrity, canonical schema inventory, versions, and per-table row counts before and after the existing migration transaction. It fails into a persisted machine-readable recovery branch. Interrupted current-version state can be retried after explicit release and reauthorization; target-version state is reconstructed as applied without re-running SQL; any other version fails closed and requires restoration of the exact authenticated backup.

Proof requires actual post-apply fresh-DDL parity, the exact admitted runtime-consumer result set, successful integrity and row parity, a released writer lease, and restart convergence to the same target schema hash and consumers. Only then can the train release its contention key.

Manifest persistence is canonical checksummed JSON with strict field decoding and cross-field validation. Writes use a safe single-linked lock file, `flock`, exact one-revision advancement, 0600 temporary files, fsync, atomic replacement, and parent-directory fsync. Symlinked parents, symlinked manifests/locks, hard-linked authority files, stale revisions, skipped revisions, unknown fields, and recomputed-checksum semantic forgeries are rejected.

`devtools/verify_schema_upgrade_lane.py` now emits and enforces the same contention-key model used by lifecycle admission. It names every duplicate path and owner and gives rebase/renumber guidance. `devtools/verify.py` schedules the schema-versioning policy once in every non-commit fast verification path rather than only in lab mode.

## Acceptance-criteria matrix

| Criterion | Result | Evidence | Remaining boundary |
|---|---|---|---|
| Typed machine-readable manifest covers tier/current/target/slot, riders, consumers, ordering, owner/reservation, backup, state, and proof refs. | Complete in kernel | `DurableChangeTrain` and typed nested dataclasses; strict JSON round-trip at every state in the source/user lifecycle test. | Active-manifest location, discovery, retention, and operator UI are conductor wiring. |
| Admission rejects stale versions, duplicate ownership, schema-only/unproven riders, absent fresh parity, missing backup authority, and a second writer. | Complete for kernel inputs | Focused mutation tests cover every listed rejection and shared-vs-second archive writer behavior. | Stopped-daemon and lease evidence are bound values supplied by the real actuator; the kernel does not stop the process itself. |
| Independent synthetic source and user trains complete declare→admit→reserve→authorize→apply→prove→release; late, failed, and interrupted cases recover exactly. | Complete in focused route | Parameterized source/user test persists and reloads every state and invokes the real existing migration transaction function; rollback, committed-interrupt, unknown-version, and late-rider tests pass. | Production train declaration/discovery and service actuation remain unwired. |
| Apply uses existing numbered migrations under stopped-daemon/single-writer authority and binds integrity, row parity, behavioral proof, and restart convergence. | Kernel complete; live actuator partial | Direct delegation to `migrate_archive_tier`; pre/post `quick_check`, inventory hash, row census, runtime results, and reopened convergence are enforced. | No live daemon was stopped/restarted. Consumer results are typed and checked, but probe dispatch is not implemented in this slice. |
| Source 008/009 replay and schema-without-runtime-consumer mutation fail. | Complete | Collision test uses the checked-in 008 bytes and a synthetic competing 008 owner; schema-only, one-consumer, and test-only consumer mutations fail. | None in the focused policy surface. |
| p155 and canonical inventory become lifecycle components; focused tests and quick gate pass. | Partially verified | Shared claim/report functions are consumed by both admission and policy; literal-safe canonical inventory test passes; direct policy command returns `ok: true`; 21 focused tests pass. | Full `devtools verify --quick`, Ruff, mypy, generated projections, and the full testmon route could not run because the pack omits the project root/configuration/dependencies. |

## Genuine residual risks

The production actuator is not yet switched from direct `migrate_archive_tier()` calls to manifest transitions. Until that wiring lands, the manifest is a proven authority kernel but not the only route through which the operator fast-forward command can mutate durable tiers.

The manifest records each rider’s schema object references, but this kernel does not yet derive a current→target per-rider schema delta and prove that every declared object reference maps to that delta. Whole-database migrated-vs-fresh parity is enforced; exact allocation of changed objects to individual riders remains a conductor/review check.

Generic row parity is intentionally count-based for pre-existing non-virtual tables. It detects missing tables and unauthorized count changes, but not in-place value rewrites that preserve counts. Such migrations need explicit behavior/data proofs; a future extension can add approved table-content fingerprints where warranted.

The manifest checksum detects corruption and accidental tampering; it is not a signature or privilege boundary. Correctness assumes the state directory and process account are trusted. The lock/CAS protects cooperating local writers, not a hostile user with equal filesystem privileges.
