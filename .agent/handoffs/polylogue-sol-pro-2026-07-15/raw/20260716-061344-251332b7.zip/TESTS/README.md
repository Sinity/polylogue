# Tests and captured verification

The two copied test modules are byte-for-byte copies of the final patched files. The compatibility conftest is not production code; it injects only modules omitted by the focused pack so the real patched modules can import and run.

## Focused result

`focused-test-run.txt` records 21 passing pytest items in the clean patch replay. `collected-tests.txt` lists every node. Coverage includes:

- full persisted source and user lifecycles, with every state written and reloaded;
- invocation of the existing `migrate_archive_tier()` transaction, not a fake SQL executor;
- fresh-DDL parity and trigger-literal canonicalization;
- stale current and target versions;
- source 008/009 collision replay with both owners and paths;
- duplicate train ownership and late riders;
- schema-only, one-consumer, test-only, and unproven rider rejection;
- missing backup authority and backup/evidence timestamp ordering;
- shared source/user lease and second-writer rejection;
- transaction rollback recovery;
- committed interruption recovery without SQL reapplication;
- unknown-version restore obligation and blocked unsafe writer release;
- exact consumer set and restart convergence before release;
- lifecycle timestamp ordering;
- checksum, semantic forgery, exact revision advancement, symlink/hardlink path rules, and unsafe lock path;
- checked-in collision policy output and exact-once fast-gate scheduling.

## Focused compatibility harness

`focused_snapshot_compatibility_conftest.py` supplies minimal definitions for imports that the pack omitted: `polylogue.paths.state_home`, archive tier/version definitions, index schema version, and the index delta declaration report. It does not replace the migration runner, SQLite transaction, lifecycle functions, tests, or policy implementation.

The no-harness transcript proves why it is needed: collection fails on missing `polylogue.paths` and `polylogue.storage.sqlite.archive_tiers`. In a full checkout, delete/ignore this harness and use the project-managed environment.

## Reproduction in the supplied focused tree

```bash
cp TESTS/focused_snapshot_compatibility_conftest.py /path/to/focused-tree/conftest.py
cd /path/to/focused-tree
PYTHONPATH=. pytest -q \
  tests/unit/storage/test_durable_change_train.py \
  tests/unit/devtools/test_durable_schema_policy_gate.py
```

## Required full-checkout verification

```bash
devtools test tests/unit/storage/test_durable_change_train.py
devtools test tests/unit/devtools/test_durable_schema_policy_gate.py
devtools lab policy schema-versioning --json
devtools verify --quick
devtools verify
```

Also run the existing durable migration/backup suites selected by testmon, because the lifecycle deliberately calls those production paths rather than duplicating them.

## Files

- `focused-test-run.txt`: passing focused execution.
- `collected-tests.txt`: all 21 collected nodes.
- `policy-gate-run.txt`: collision/schema policy JSON result.
- `static-check-run.txt`: compile, diff whitespace, AST, and changed-line length checks.
- `patch-apply-check.txt`: clean six-patch replay and exact tree comparison.
- `focused-snapshot-without-compatibility-harness.txt`: expected collection boundary caused by omitted pack modules.
- `test_durable_change_train.py`: final lifecycle tests.
- `test_durable_schema_policy_gate.py`: final policy/gate tests.
- `focused_snapshot_compatibility_conftest.py`: focused-pack-only import bridge.
