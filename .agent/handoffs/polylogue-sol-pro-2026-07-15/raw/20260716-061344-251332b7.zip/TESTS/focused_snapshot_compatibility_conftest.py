"""Disposable compatibility shims for the supplied focused snapshot only."""

from __future__ import annotations

import sys
import types
from enum import StrEnum
from pathlib import Path


paths = types.ModuleType("polylogue.paths")
paths.state_home = lambda: Path("/tmp/polylogue-focused-snapshot-state")
sys.modules["polylogue.paths"] = paths


class ArchiveTier(StrEnum):
    SOURCE = "source"
    USER = "user"
    INDEX = "index"
    EMBEDDINGS = "embeddings"


types_module = types.ModuleType("polylogue.storage.sqlite.archive_tiers.types")
types_module.ArchiveTier = ArchiveTier
sys.modules[types_module.__name__] = types_module

archive_tiers = types.ModuleType("polylogue.storage.sqlite.archive_tiers")
archive_tiers.__path__ = []
archive_tiers.ArchiveTier = ArchiveTier
archive_tiers.ARCHIVE_VERSION_BY_TIER = {
    ArchiveTier.SOURCE: 11,
    ArchiveTier.USER: 9,
    ArchiveTier.INDEX: 1,
    ArchiveTier.EMBEDDINGS: 1,
}
sys.modules[archive_tiers.__name__] = archive_tiers

index_module = types.ModuleType("polylogue.storage.sqlite.archive_tiers.index")
index_module.INDEX_SCHEMA_VERSION = 1
sys.modules[index_module.__name__] = index_module

lifecycle = types.ModuleType("polylogue.storage.sqlite.lifecycle")
lifecycle.IndexDeltaDeclarationReport = dict
lifecycle.index_delta_declaration_report = lambda version: {
    "ok": True,
    "compatibility_floor": version,
    "missing_versions": (),
    "duplicate_versions": (),
    "invalid_versions": (),
}
sys.modules[lifecycle.__name__] = lifecycle
