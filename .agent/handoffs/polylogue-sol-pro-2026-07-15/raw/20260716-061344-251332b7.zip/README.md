# Polylogue durable change-train handoff

This handoff implements the reviewable lifecycle kernel for `polylogue-60i5.1`, “Land the durable change-train manifest and lifecycle gate.” It adds one typed, persisted authority contract for additive durable migrations on `source.db` and `user.db`. The contract covers declare, admit, reserve, backup-authorize, apply, prove, and release; apply delegates to the existing numbered migration runner rather than introducing another migration engine.

The result is internally coherent and executable in the supplied focused snapshot. It is not represented as a completed live rollout conductor: `devtools/archive_schema_fast_forward.activate_prepared_forward` still calls `migrate_archive_tier` directly, and the real daemon stop/restart actuator plus production consumer-probe registry were outside the supplied slice. `DESIGN/03-remaining-actuator-wiring.md` names the exact remaining integration steps.

## Base and worktree assumptions

The immutable input was `polylogue-sol-pro-context-06a62c2cf0789e54.tar.gz`, SHA-256 `06a62c2cf0789e540ff0083cce7d4641d20f125990e5a3101801fd4962d138f7`, 563,901 bytes. Its Git metadata identifies source revision `76ee0d3842f12920ee71ad06f22b9cd8d2f88730` on `feature/browser/adopt-completion-monitors`. The captured status, staged patch, and working-tree patch were all clean.

The pack is intentionally focused: 171 selected source files, 184 entries excluding its own manifest, 2,431,376 uncompressed bytes, with `full_worktree_fallback=false`. For repeatable local patch construction, those selected files were committed as synthetic base `4c03fd6`; that synthetic hash is not a project revision. The production base remains `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`.

The final patch tree hash is `c2f37f63d863d8f34c2e2c18160e8e6d7da8fd53`. A clean replay of all six patches produced the same tree hash.

## Read order

1. Read `SUMMARY.md` for the executive result and acceptance-criteria matrix.
2. Read `DESIGN/01-architecture-and-lifecycle.md` for the state machine and invariants.
3. Read `DESIGN/03-remaining-actuator-wiring.md` before treating the kernel as an operator route.
4. Read `VERIFICATION-LIMITS.md` for the exact checks and environmental boundary.
5. Review `PATCHES/README.md`, then the six patches in numeric order.
6. Use `TESTS/README.md` and the captured transcripts to reproduce the focused verification.

## Applying the patch series

Start from the exact source revision or a descendant whose touched files have not diverged. Preserve any local dirty state explicitly; the supplied snapshot had none.

```bash
git status --short
git rev-parse HEAD
git switch -c feature/storage/durable-change-train 76ee0d3842f12920ee71ad06f22b9cd8d2f88730
git am /path/to/unpacked-handoff/PATCHES/*.patch
```

On an advanced branch, use a separate worktree and inspect every conflict rather than dropping hunks:

```bash
git am -3 /path/to/unpacked-handoff/PATCHES/*.patch
```

The patches touch only:

```text
polylogue/storage/sqlite/migration_runner.py
devtools/verify_schema_upgrade_lane.py
devtools/verify.py
tests/unit/storage/test_durable_change_train.py
tests/unit/devtools/test_durable_schema_policy_gate.py
```

No new `polylogue/` module was added. That is deliberate: the supplied project instructions require regenerating topology projections when adding a module, while the focused pack omitted the generated topology surface. The lifecycle therefore lives beside the existing durable migration engine.

## Verification after applying in a full checkout

Run the project-managed commands, not the focused compatibility harness:

```bash
devtools test tests/unit/storage/test_durable_change_train.py
devtools test tests/unit/devtools/test_durable_schema_policy_gate.py
devtools lab policy schema-versioning --json
devtools verify --quick
devtools verify
```

`TESTS/focused_snapshot_compatibility_conftest.py` exists only to replace imports omitted from the immutable focused pack. Do not commit or copy it into a complete Polylogue checkout.
