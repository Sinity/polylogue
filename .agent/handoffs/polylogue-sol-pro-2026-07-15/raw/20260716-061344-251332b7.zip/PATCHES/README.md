# Ordered patch series

Apply all patches in numeric order. The series was generated from the focused reconstruction base `4c03fd6`, whose file contents came from project revision `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`. A clean replay produced final tree `c2f37f63d863d8f34c2e2c18160e8e6d7da8fd53`, exactly matching the authored tree.

| Order | Subject | Purpose |
|---|---|---|
| 1 | `feat(storage): add durable change-train lifecycle` | Shared collision claims, typed state machine, schema/row evidence, backup/apply/proof/recovery APIs, strict manifest codec and persistence. |
| 2 | `chore(verify): gate durable migration collisions` | Use shared contention claims in schema policy and run it once in every non-commit fast gate. |
| 3 | `test(storage): cover durable change trains` | Synthetic source/user lifecycle, policy collisions, stale/late/rider/backup/writer/failure/restart/manifest cases. |
| 4 | `fix(storage): order backup authority evidence timestamps` | Remove same-millisecond dependence by timestamping authorization before its evidence capture. |
| 5 | `fix(storage): validate lifecycle evidence ordering` | Enforce post/apply/release/restart temporal order and repair committed-interrupt reconstruction order. |
| 6 | `fix(storage): harden manifest persistence and inventory` | Literal-safe DDL normalization, exact revision advancement, serialized lock, unsafe lock rejection, and final hardening tests. |

The three fix patches preserve review evidence from the final audit rather than hiding the defects in a squashed replacement. The complete applied state, not patch 1 in isolation, is the deliverable.
