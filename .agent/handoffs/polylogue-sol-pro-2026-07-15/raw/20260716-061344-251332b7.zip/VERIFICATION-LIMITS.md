# Verification performed and limits

## Checks completed

| Check | Result | Durable evidence |
|---|---|---|
| Apply all six patches from the focused synthetic base with `git am` | Passed | `TESTS/patch-apply-check.txt` |
| Compare replay tree to authored tree | Exact match: `c2f37f63d863d8f34c2e2c18160e8e6d7da8fd53` | `TESTS/patch-apply-check.txt` |
| Focused lifecycle and policy tests | 21 passed | `TESTS/focused-test-run.txt` |
| Test collection | 21 nodes | `TESTS/collected-tests.txt` |
| Direct schema-versioning policy JSON command | `ok: true`, no collisions/invalid resources/missing delta declarations | `TESTS/policy-gate-run.txt` |
| Python bytecode compilation of focused `polylogue`, `devtools`, and tests | Exit 0 | `TESTS/static-check-run.txt` |
| `git diff --check` | Exit 0 | `TESTS/static-check-run.txt` |
| AST parse of every changed Python file | Passed | `TESTS/static-check-run.txt` |
| Added-line length audit at 119 columns | No violations | `TESTS/static-check-run.txt` |
| Source worktree dirty-state inspection | Captured source clean; no staged or working-tree patch | Immutable `GIT/` metadata, summarized in `README.md` |
| Finished ZIP path/hash/size audit | Performed after archive creation | `MANIFEST.json` plus final operator report |

The lifecycle tests run Python 3.13.5 with pytest 9.0.2. They use real SQLite files and the actual existing migration transaction function. Synthetic migration resources/version maps are injected because those package modules were omitted from the focused archive.

## Not run

The following were not executable from the supplied pack and are not claimed:

- full `devtools verify --quick`;
- default `devtools verify` testmon route;
- Ruff format/check;
- mypy strict;
- generated topology, layering, closure matrix, manifests, documentation, and render checks;
- the existing complete durable migration and backup test suites, whose imports depend on omitted package modules;
- a full repository checkout at the exact revision. A clone was attempted, but the container had no outbound DNS;
- a live Polylogue daemon stop/start;
- a real operator archive, backup secrets/attestation keys, or production database;
- actual service-manager evidence, production consumer probe dispatch, NixOS deployment, browser capture, or operator credentials.

`focused-snapshot-without-compatibility-harness.txt` records the unmodified collection failure caused by the pack boundary. The compatibility harness is included so the focused result is reproducible and inspectable, not to imply the missing full-tree gates passed.

## Verification interpretation

The passing route proves the internal kernel: typed transitions, strict persistence, collision policy, delegation to the existing migration transaction, synthetic source/user independence, failure reconciliation, fresh parity, runtime result validation, reopened convergence, and release gating.

It does not prove the residual actuator wiring. In particular, stopped-daemon and single-writer evidence are validated and persisted but supplied by the caller; no service was actually stopped. Runtime consumer results are checked exactly but not dispatched by a registry. Restart convergence reopens SQLite but does not identify a restarted process. Those are explicit remaining tasks in `DESIGN/03-remaining-actuator-wiring.md`.

## Known proof boundaries

Row parity is count-based for pre-existing non-virtual tables. It is not a full row-content fingerprint.

Fresh-DDL parity binds the complete schema inventory, but rider `schema_objects` are declarations rather than a mechanically allocated current→target delta.

The manifest checksum is corruption detection, not a signature. The persistence lock and path checks assume a trusted local process account and state directory.

The six-patch replay is against the exact selected-file contents from the immutable snapshot. An advanced project branch may have contextual conflicts and must run the full project gates after resolution.
