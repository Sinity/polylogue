# Polylogue Sinex publication launch handoff

This archive is a reviewable patch handoff for Bead `polylogue-303r.2.1`, based on immutable snapshot revision `5abb30afc0b30348c4332ede1e592704e971f0a8` from branch `feature/browser/sol-pro-dispatch`.

## Read and apply order

1. Read `SUMMARY.md` for the result and acceptance-criteria matrix.
2. Read `DESIGN/architecture.md`, then `DESIGN/rejected-alternatives.md` and `DESIGN/research-sources.md`.
3. Confirm the target checkout is based on revision `5abb30afc0b30348c4332ede1e592704e971f0a8`. The supplied worktree already had `M .beads/issues.jsonl`; none of these patches touches `.beads/`, so preserve and reconcile that existing change independently.
4. Apply the files listed in `PATCHES/series`, in order:

   ```sh
   while IFS= read -r patch; do
       git apply --check "PATCHES/$patch"
       git apply "PATCHES/$patch"
   done < PATCHES/series
   ```

5. Review the additive durable migration `012_sinex_publication_payloads_receipts.sql`. Run it only through Polylogue's normal durable source-tier migration/backup machinery. There is intentionally no `index.db` migration.
6. In `mirror` or `primary` mode, deployment composition must register a concrete `SinexTransport` factory before the daemon builds default convergence stages. The patch deliberately fails backed-mode startup when no transport is registered. `LocalReferenceTransport` is only a deterministic contract double.
7. Follow `TESTS/verification-plan.md`. `TESTS/verify_handoff.py` can validate this archive and can apply-check the series against a supplied checkout.
8. Read `VERIFICATION-LIMITS.md` before interpreting the test evidence.

## Patch series

- `0001-source-tier-exact-publication-outbox.patch` adds source schema version 12, exact payload/segment storage, retry scheduling, receipt history, and transaction-owned sync/async outbox primitives.
- `0002-atomic-accepted-revision-publication.patch` maps accepted `ParsedSession` material through the real material-protocol v1 encoder/verifier and stages the exact bytes in the same `source.db` transaction as raw acceptance.
- `0003-supervised-publication-convergence.patch` adds explicit transport composition, bounded leases/retries, restart-safe receipt persistence, safe status, and per-subject primary barriers in the real daemon converger.
- `0004-publication-route-tests.patch` supplies production-route fixtures and tests for atomicity, duplicates, changed revisions, restart, retry/debt, gating, off mode, corrupt payload isolation, and observability.

## Base and scope assumptions

The input was a deliberately sparse selected-file snapshot rather than a complete checkout. Patches modify only selected snapshot files plus one required durable source migration and test files. No unrelated dirty state is embedded. The full repository has a pre-existing source migration 011 outside the snapshot, so the new migration and canonical source schema correctly advance from source schema version 11 to 12.
