# Executive result

The patch series wires the existing Sinex obligation substrate into the accepted normalized revision and daemon convergence paths without creating a second writer or claiming cross-database atomicity.

For `mirror` and `primary`, ingest now encodes each accepted `ParsedSession` with the existing material-protocol v1 implementation, runs protocol verification and decode closure, and retains the exact canonical manifest and segment bytes. The rebuildable `index.db` write remains replayable pre-work. The subsequent raw-state acceptance and exact publication outbox staging execute under the same `source.db` `BEGIN IMMEDIATE` transaction owned by the repository's existing bulk connection. A failure in either operation rolls back both. Duplicate exact revisions restage idempotently; changed revisions remain distinct history.

The source-tier outbox now stores exact payload bytes, ordered transport filenames, integrity metadata, publication leases, retry deadlines, and append-only attempt receipts. The daemon constructs no publication service in `off`; in `mirror`/`primary` it requires an explicitly composed transport, drains bounded due work, persists every result, recovers expired leases after restart, and redrives with a deterministic request ID. `primary` blocks only affected paths/sessions whose newest accepted revision lacks an allowed durable receipt. `mirror` reports lag and failures but never blocks local projections.

The archive contains four ordered unified patches changing 20 files (3,287 insertions, 1,131 deletions), including 22 repository test functions. It is not a deployment certification: no live Sinex network, credentials, operator daemon, production database, or NixOS environment was available.

## Acceptance-criteria matrix

| Criterion | Delivered evidence | Status |
|---|---|---|
| 1. Atomic accepted revision and obligation | `_persist_batch_raw_state_updates` reuses the source backend's active bulk connection; `stage_payload_async` has no transaction ownership; exact bytes are encoded before index writes; rollback/commit fixtures cover the same-boundary invariant. | Implemented; isolated transaction harness passed. |
| 2. Daemon construction, bounded retry/restart/status, off zero-work | Default stages read `sinex_mode`; backed modes resolve an explicit transport or fail; publication stage drains `max_batch`; leases and `next_attempt_at_ms` survive restart; status is bounded and secret-safe; off omits the stage/service and service methods do not open a database. | Implemented; service/runtime harness passed. Full daemon process not run. |
| 3. Primary receipt gate versus mirror continuation | Allowed durable states are `persisted_confirmed`, `durable_debt`, and `spool_accepted_lossless`; `raw_accepted` and `rejected` block the newest primary revision. Converger barriers are path/session-specific. Mirror reports exact lag with `blocking=0`. | Implemented; service gating executed, daemon barrier tests included and compiled. |
| 4. Complete material adapter and explicit gaps | Adapter maps sessions, messages, blocks, attachments, lineage, usage, and session events; unsupported normalized fields become fidelity gaps. Production encoding invokes the real v1 verifier and decoder, checks session identity, canonicalizes the manifest, and preserves protocol filenames including `head.ndjson`. | Implemented; exact-contract material tests passed. |
| 5. Duplicate/history/rejection/unavailable/restart/backpressure | Four-part durable key and deterministic request ID enforce idempotency; exact-byte collision checks reject mismatches; changed revisions remain rows; rejection and missing transport are explicit; staging has a 256 MiB batch budget; corrupt payloads become isolated retry debt. | Implemented; durability harness passed. |
| 6. Production-route tests, migration parity, quick gate, no false transport claim | Test patch covers ingest helper, daemon converger, source migration, adapter, transport, service, status, and off mode. Patch apply, syntax, schema, 18 reconstructed tests, and 13 scenario checks passed. | Partially verified: full repository quick gate and live transport were not run. |

## Review focus

The load-bearing review points are: transaction reuse in `_persist_batch_raw_state_updates`; canonical payload reconciliation in `material_adapter.py`; collision and lease semantics in `obligations.py`; receipt-state transitions and newest-revision gating in `service.py`; and barrier propagation in `daemon/convergence.py`.
