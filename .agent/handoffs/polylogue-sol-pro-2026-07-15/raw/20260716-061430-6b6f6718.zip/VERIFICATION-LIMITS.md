# Verification boundaries

## Executed in the container

- Reopened the supplied immutable snapshot and inspected repository instructions, Bead `polylogue-303r.2.1`, git metadata, selected architecture, exact-base async SQLite backend, raw repository contract, material-protocol implementation, and existing Sinex substrate.
- Applied all four patches in order to a fresh copy of the selected snapshot with `git apply --check` before each apply.
- Ran `git diff --check` over the complete series.
- Ran Python bytecode compilation over every modified/added production Python file and every Sinex test file.
- Ran 18 reconstructed exact-contract pytest tests: models, transport, real material-protocol adapter, source outbox/migration, publication service restart/retry/debt/gating, corruption isolation, status redaction, and off mode. Result: `18 passed`.
- Ran a standalone 13-scenario SQLite durability harness covering acceptance/outbox rollback and commit, duplicate and changed revisions, exact-byte collision/corruption, lost remote receipt and restart replay, expired lease recovery, raw-accepted retry, durable debt, rejection, mirror/primary gating, secret-safe status, bounded corrupt-row isolation, off zero-work, transport factory/idempotency, and migration structure. Result: all 13 passed.
- The production adapter invoked the exact material-protocol v1 encoder, verifier, decoder, canonical serializer, enums, and filename mapping from base revision `5abb30af...` in the reconstructed runtime.

Exact command transcripts are summarized in `TESTS/results.txt`.

## Not executed

- The full repository quick gate, because the delivered input is a sparse selected-file snapshot rather than a complete checkout with all project packages, generated topology files, Nix environment, and test fixtures.
- The new `test_ingest_atomicity.py` and daemon `test_convergence.py` under the full repository import graph. They were syntax-compiled and patch-apply checked; their lower-level invariants were executed by the standalone harness and service tests.
- A running `polylogued` process, operator browser, live filesystem watcher, daemon supervision lifecycle, or concurrent production writers.
- A real Sinex transport, JetStream/NATS connection, authentication, endpoint discovery, remote settlement, aggregate reconciliation, or external cancellation behavior.
- Any production secrets, databases, backups, source migration, archive rebuild, ops reset, or NixOS deployment.
- Migration 012 against production-scale or pre-existing version-11 data. It was structurally executed against a test database created from migration 010 followed by 012.
- The deployment composition change that registers a real `TransportFactory`; the patch intentionally leaves that to the actual adapter/composition owner and fails backed-mode startup until supplied.

## Residual verification implications

The handoff establishes internal transaction, persistence, idempotency, retry, and gate semantics. It does not establish interoperability or operational readiness of a future network adapter. Before merge/deployment, run the complete project quick gate in a full checkout, execute the production-route ingest and daemon tests, exercise migration backup/restore on a copy of version-11 source data, and perform a real adapter settlement test including lost-response replay and timeout cancellation behavior.
