# Verification plan

## Archive and patch integrity

```sh
python TESTS/verify_handoff.py --root .
python TESTS/verify_handoff.py --root . --repo /path/to/polylogue-at-5abb30af
```

The second command copies the target checkout to a temporary directory, applies every patch from `PATCHES/series` with `git apply --check`, runs `git diff --check`, and byte-compiles all modified Python files. It does not modify the supplied checkout.

## Full-checkout tests

After applying the series in a complete repository environment, run the project's normal environment/bootstrap command, then at minimum:

```sh
pytest -q tests/unit/sinex
```

Also run the repository's canonical quick gate from `CLAUDE.md`. Pay particular attention to:

- `test_ingest_atomicity.py`: source backend bulk transaction re-use, required payload failure rollback, and backed-mode refusal without source backend;
- `test_convergence.py`: path-specific primary barrier and mirror continuation;
- `test_material_adapter.py`: anti-removal coverage for every normalized unit and fidelity gaps;
- `test_service.py`: lost-receipt restart replay, retry/debt/rejection, corruption isolation, redaction, and off mode;
- `test_obligations.py`: source schema 12 and exact payload collision checks.

## Migration rehearsal

1. Create a verified backup of a copy of a source schema version-11 database using the normal Polylogue durable migration workflow.
2. Apply migration 012 through that workflow.
3. Confirm `PRAGMA user_version = 12`, all four publication tables, the retry index, foreign keys, and existing obligation backfill of `next_attempt_at_ms`.
4. Restart the daemon with `sinex_mode=off`; verify no Sinex stage/status/database activity.
5. Register a deterministic test transport and repeat in mirror and primary.

## Real adapter acceptance before deployment

A deployment-ready adapter must demonstrate request-ID idempotency with byte equality, durable receipt interpretation, lost-response replay, bounded timeout behavior, authentication redaction, and restart against a real Sinex service. Record that separately; `LocalReferenceTransport` cannot satisfy this step.
