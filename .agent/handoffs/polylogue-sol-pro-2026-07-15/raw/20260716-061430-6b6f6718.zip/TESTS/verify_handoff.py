#!/usr/bin/env python3
"""Validate an extracted handoff and optionally apply-check it against a checkout."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path, PurePosixPath

REQUIRED_FILES = {"MANIFEST.json", "README.md", "SUMMARY.md", "VERIFICATION-LIMITS.md"}
REQUIRED_DIRS = {"PATCHES", "DESIGN", "TESTS"}


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def safe_relative(path: str) -> bool:
    item = PurePosixPath(path)
    return bool(path) and not item.is_absolute() and ".." not in item.parts and "\\" not in path


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_root(root: Path) -> None:
    for name in REQUIRED_FILES:
        if not (root / name).is_file():
            fail(f"missing {name}")
    for name in REQUIRED_DIRS:
        directory = root / name
        if not directory.is_dir() or not any(path.is_file() for path in directory.rglob("*")):
            fail(f"missing or empty {name}/")

    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    if manifest.get("prompt_profile") != "polylogue-sol-pro-worker-v1":
        fail("unexpected prompt profile")
    records = manifest.get("files")
    if not isinstance(records, list):
        fail("manifest files is not an array")
    seen: set[str] = set()
    declared: set[str] = set()
    for record in records:
        path = record.get("path")
        if not isinstance(path, str) or not safe_relative(path):
            fail(f"unsafe manifest path: {path!r}")
        normalized = PurePosixPath(path).as_posix()
        if normalized in seen:
            fail(f"duplicate manifest path: {normalized}")
        seen.add(normalized)
        declared.add(normalized)
        target = root / normalized
        if not target.is_file():
            fail(f"declared file absent: {normalized}")
        data = target.read_bytes()
        if len(data) != record.get("size_bytes"):
            fail(f"size mismatch: {normalized}")
        if sha256(data) != record.get("sha256"):
            fail(f"sha256 mismatch: {normalized}")
        if "purpose" not in record or "apply_order" not in record:
            fail(f"incomplete manifest record: {normalized}")

    actual = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.name != "MANIFEST.json"
    }
    if actual != declared:
        fail(f"manifest coverage mismatch missing={sorted(actual-declared)} extra={sorted(declared-actual)}")
    print(f"PASS manifest: {len(records)} declared files")


def run(command: list[str], *, cwd: Path) -> None:
    subprocess.run(command, cwd=cwd, check=True)


def apply_check(root: Path, repo: Path) -> None:
    if not repo.is_dir():
        fail(f"repo not found: {repo}")
    with tempfile.TemporaryDirectory(prefix="polylogue-handoff-") as temp:
        checkout = Path(temp) / "repo"
        shutil.copytree(repo, checkout, symlinks=True)
        if not (checkout / ".git").exists():
            run(["git", "init", "-q"], cwd=checkout)
            run(["git", "add", "-A"], cwd=checkout)
            run(
                ["git", "-c", "user.name=handoff", "-c", "user.email=handoff@invalid", "commit", "-q", "-m", "base"],
                cwd=checkout,
            )
        series = [line.strip() for line in (root / "PATCHES/series").read_text().splitlines() if line.strip()]
        for name in series:
            patch = root / "PATCHES" / name
            run(["git", "apply", "--check", str(patch)], cwd=checkout)
            run(["git", "apply", str(patch)], cwd=checkout)
            print(f"PASS apply: {name}")
        run(["git", "diff", "--check"], cwd=checkout)
        py_files = [str(path) for path in checkout.rglob("*.py") if "/.git/" not in path.as_posix()]
        run([sys.executable, "-m", "py_compile", *py_files], cwd=checkout)
        print("PASS diff check and Python compilation")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--repo", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    validate_root(root)
    if args.repo is not None:
        apply_check(root, args.repo.resolve())


if __name__ == "__main__":
    main()
