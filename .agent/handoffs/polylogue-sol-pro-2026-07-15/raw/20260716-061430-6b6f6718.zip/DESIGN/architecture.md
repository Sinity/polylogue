# Architecture and invariants

## 1. Acceptance boundary

The repository has two different durability classes: `source.db` is durable, while `index.db` is a rebuildable projection. SQLite WAL mode does not provide a safe atomic-commit guarantee across multiple attached databases, so this change does not describe the index and source commits as one transaction.

Instead, material-protocol encoding and verification happen before the index write. The exact encoded manifest and segment bytes become the normalized evidence that must accompany acceptance. The index transaction is replayable pre-work. At the later accepted-raw-state boundary, the existing source backend enters `bulk_connection()`, which owns `BEGIN IMMEDIATE`; because that context intentionally yields `None`, the code separately enters `connection()`, which reuses the backend-local active connection. `repository.update_raw_state(...)` and `stage_payload_async(...)` therefore mutate the same `source.db` transaction. Any exception rolls back both the accepted marker and the outbox bytes.

This design closes both crash gaps:

- Encoding or bounded-staging failure happens before acceptance, so no accepted revision lacks publication evidence.
- Failure while updating acceptance or writing exact bytes rolls back both source-tier effects.

## 2. Durable exact outbox

Source schema version 12 adds:

- `next_attempt_at_ms` to the existing obligation row;
- `sinex_publication_payloads` for canonical manifest bytes and aggregate integrity metadata;
- `sinex_publication_segments` for ordered, transport-visible filenames and exact bytes;
- `sinex_publication_receipts` for append-only attempt outcomes and safe error codes.

The four-part key `(object_id, protocol_version, revision_id, manifest_digest)` remains the durable identity. The deterministic transport request ID is the same tuple joined in a stable representation. Re-presenting the same key compares all bytes, names, positions, digests, counts, and sizes. It is an idempotent no-op only when the exact evidence matches. A changed revision or manifest digest creates new history. Mode may monotonically elevate from mirror to primary but never silently downgrade.

Payload reads revalidate manifest digest/size, segment count, total size, and every segment digest/size before invoking a transport. A corrupt row does not abort the batch: it receives a durable retry attempt with a bounded error code, while later obligations continue.

## 3. Supervised convergence

A publication attempt has three durable phases:

1. Acquire a source-tier publishing lease by changing status to `publishing` and setting `next_attempt_at_ms` to the lease expiry.
2. Invoke the async transport with the deterministic request ID and exact staged bytes. No SQLite connection crosses into the transport thread/coroutine.
3. In a new source-tier transaction, append a receipt row and transition the obligation.

If the process dies after remote persistence but before phase 3, the publishing lease expires. Restart sends the same request ID and bytes. A conforming transport returns the prior durable result rather than creating another record. Exponential retry is bounded. `durable_debt` and lossless spool receipts remain observable and scheduled for redrive, while satisfying the declared primary progress rule.

## 4. Receipt and gate semantics

- `persisted_confirmed`: terminal clean success; unlocks primary.
- `durable_debt`: durable explicit debt; remains lag/retry work but unlocks primary.
- `spool_accepted_lossless`: durable lossless spool; unlocks primary.
- `raw_accepted`: non-durable acceptance only; retries and blocks primary.
- `rejected`: explicit terminal failure; remains observable and blocks primary until operator reset or a newer allowed revision.

Primary gating ranks obligations per object by `created_at_ms DESC, rowid DESC` and checks only the newest accepted revision. Historical unresolved rows remain in lag/status but cannot re-block a newer confirmed revision. The `DaemonConverger` carries barrier sets per path and per session, so one subject's publication debt does not stall unrelated projections. Mirror sets no barrier.

## 5. Off mode

Off mode returns before protocol encoding, does not retain publication payloads, does not construct the service or transport, does not create obligations, and service status/drain helpers return zero values without opening a database. This is stronger than a null transport no-op; `NullTransport` raises if accidentally invoked.

## 6. Transport composition and observability

Polylogue does not invent endpoint or secret environment variables in this patch. Deployment registers a process-local `TransportFactory` before default daemon stage construction. Backed mode with no factory fails explicitly. The in-process `LocalReferenceTransport` implements byte identity and deterministic replay only for tests.

Status exposes counts, due work, active lag, newest-revision blockers, oldest age, last receipt state, and a sanitized error code. It never includes payload bytes, transport endpoint data, raw exception messages, or receipt detail. Persisted receipt detail is NUL-stripped, redacted for common credential labels, and length-bounded.
