# Rejected alternatives

1. **Claim one atomic transaction across `index.db` and `source.db`.** Rejected because the active databases use WAL and SQLite does not guarantee atomic multi-file commit in that configuration. The design treats index work as replayable and places the irreducible acceptance/evidence invariant wholly in `source.db`.

2. **Put the outbox or payload only in `ops.db`.** Rejected because `ops.db` is disposable diagnostics. Crash recovery authority must remain in durable `source.db`.

3. **Add an `index.db` migration.** Rejected because derived tiers have canonical DDL plus rebuild, not numbered migration chains. This work needs only additive source-tier schema version 12.

4. **Publish while the acceptance transaction is open.** Rejected because a remote call cannot participate in SQLite commit, would hold the sole-writer lock across network latency, and creates ambiguous rollback after remote success. The outbox commits first; bounded convergence publishes afterward.

5. **Store only manifest digest and reconstruct payload after restart.** Rejected because parsers, source files, or encoder versions may change. Exact manifest and segment bytes are the only reliable replay evidence for the accepted revision.

6. **Treat `RAW_ACCEPTED` as success.** Rejected because in-memory/channel acceptance is not durable settlement. It remains retryable and blocks primary projection.

7. **Block all projections whenever any publication is behind.** Rejected because convergence is subject-scoped. Barrier sets block only affected paths or sessions.

8. **Silently continue backed mode without a transport.** Rejected because configured authority cannot degrade to warning-only local behavior. Startup fails explicitly until deployment registers an adapter.

9. **Infer transport credentials/endpoints in this selected-file patch.** Rejected because no existing deployment vocabulary or secret contract was supplied. A narrow factory seam preserves integration without inventing configuration.

10. **Use `LocalReferenceTransport` as proof of deployment success.** Rejected. It is a deterministic contract double, not a Sinex network implementation, authentication test, JetStream test, or settlement interoperability test.
