# Bead requirements trace

Source record: `polylogue-303r.2.1`, updated 2026-07-15T19:19:42Z.

| Requirement phrase | Patch locations |
|---|---|
| Same transaction as accepted normalized revision | `0002`: ingest `_core.py`; `0001`: `stage_payload_async` transaction ownership |
| Exact normalized evidence and idempotent obligation | `0001`: models/obligations/schema; `0002`: material adapter |
| Daemon constructs from `sinex_mode` | `0003`: `make_default_convergence_stages` |
| Bounded retry and restart/reset | `0001`: lease/retry columns; `0003`: service drain/reset |
| Lag/failure/status | `0003`: `PublicationStatus`, service status, converger stage status |
| Off starts no service and writes no obligation | `0002`: ingest mode branch; `0003`: default stage factory/service guards |
| Primary gates, mirror continues | `0003`: newest-revision blocker and path/session barrier propagation |
| Attachments/lineage/usage/events/gaps | `0002`: parsed-session adapter; `0004`: anti-removal assertions |
| Duplicate/history/rejection/unavailable/backpressure | `0001`/`0002`/`0003`; corresponding `0004` fixtures |
| Durable migration parity, no index migration | `0001`: source migration 012 and canonical schema version 12 |
