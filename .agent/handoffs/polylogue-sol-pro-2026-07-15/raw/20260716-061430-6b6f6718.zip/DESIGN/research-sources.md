# Research record

Access date for all sources: **2026-07-16**.

## Primary sources

- SQLite WAL documentation: https://sqlite.org/wal.html
  - Supports the decision not to claim atomic multi-database commits under WAL and the single-writer implications.
- SQLite `ATTACH DATABASE` documentation: https://sqlite.org/lang_attach.html
  - Documents the qualified atomicity limits for transactions spanning attached files.
- SQLite temporary files / super-journal documentation: https://sqlite.org/tempfiles.html
  - Clarifies when multi-database rollback-journal transactions use a super-journal and why that does not justify a WAL claim.
- Python `asyncio` task and timeout documentation: https://docs.python.org/3/library/asyncio-task.html
  - Supports bounded coroutine attempts and the fact that timeout cancellation does not by itself prove cancellation of an external side effect.
- Polylogue source at exact base revision: https://github.com/Sinity/polylogue/tree/5abb30afc0b30348c4332ede1e592704e971f0a8
- Exact async SQLite backend: https://github.com/Sinity/polylogue/blob/5abb30afc0b30348c4332ede1e592704e971f0a8/polylogue/storage/sqlite/async_sqlite.py
  - Source-supported fact: `bulk_connection()` owns the transaction, yields no connection object, and `connection()` reuses the active backend connection.
- Exact raw repository mixin: https://github.com/Sinity/polylogue/blob/5abb30afc0b30348c4332ede1e592704e971f0a8/polylogue/storage/repository/raw/repository_raw.py
  - Source-supported fact: raw-state updates select the source backend and acquire through its `connection()` context.

## Project evidence

The immutable snapshot's Bead record states that source-tier acceptance and the idempotent obligation must be atomic, source.db remains obligation authority, the daemon must consume `sinex_mode`, and `LocalReferenceTransport` is not deployment success. The later note, dated 2026-07-15, narrows this item to locally executable publication wiring while external settlement remains sequenced afterward.

## Inferences and proposals

- **Inference:** exact material-protocol bytes are the strongest normalized evidence available at the accepted-revision boundary, because they are independently verified and can be replayed without parser/source reconstruction.
- **Inference:** the safest sole-writer integration is a synchronous convergence stage whose SQLite phases stay on the daemon thread and whose async transport invocation receives no database handle.
- **Proposal for deployment:** register a concrete transport factory in the existing daemon composition root after the real Sinex adapter is available. This archive does not prescribe endpoint or credential names.
