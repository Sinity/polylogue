# Verification assets

`verify.sh` applies the ordered patch series to a temporary copy of a supplied clean snapshot and runs compilation plus focused mutation tests. `negative_contract_test.py` validates canonical parity hashes and performs a static strict-surface scan. The strict scan is intentionally conservative and returns a nonzero status for candidates that lack an observable kernel/permit reference; reviewers must disposition false positives rather than add a blanket waiver.

Focused tests cover preview non-mutation, mutation-sensitive plan hashing, authorization omission, replay, full-vector and per-target TOCTOU drift, direct actuator bypass, per-target idempotency, conservative reconciliation, and audit redaction. The fixture covers identity reset, storage reset, and excision with logical CLI, MCP, HTTP, and Python inputs.

Current static result: 52 public candidates, 0 with an observable kernel reference, 52 requiring disposition; 3 preview-write flags. Real route tests remain mandatory for true positives because AST evidence cannot prove runtime call graphs.
