#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/clean/snapshot-root" >&2
  exit 64
fi
SELF=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SRC=$(CDPATH= cd -- "$1" && pwd)
TMP=$(mktemp -d "${TMPDIR:-/tmp}/polylogue-mutation-verify.XXXXXX")
trap 'rm -rf "$TMP"' EXIT
cp -a "$SRC/." "$TMP/repo/"
cd "$TMP/repo"
if command -v git >/dev/null 2>&1; then git init -q; fi
while IFS= read -r patch; do
  [[ -n "$patch" ]] || continue
  git apply --check "$SELF/PATCHES/$patch"
  git apply "$SELF/PATCHES/$patch"
done < "$SELF/PATCHES/series"
export PYTHONPATH="${PYTHONPATH:-}:$TMP/repo:$TMP/repo/src"
python -m compileall -q .
TEST=$(find . -path '*/test_mutation_transaction_security.py' -print -quit)
[[ -n "$TEST" ]] || { echo 'focused mutation test was not added' >&2; exit 2; }
python -m pytest -q "$TEST"
python "$SELF/TESTS/negative_contract_test.py" "$TMP/repo" --fixture "$SELF/TESTS/cross-surface-parity.json"
set +e
python "$SELF/TESTS/negative_contract_test.py" "$TMP/repo" --fixture "$SELF/TESTS/cross-surface-parity.json" --strict-surfaces
STRICT=$?
set -e
if [[ $STRICT -ne 0 ]]; then
  echo "Strict surface gate found candidates requiring human disposition; see DESIGN/census.json." >&2
fi
echo "Focused mutation verification passed; strict_surface_exit=$STRICT"
