#!/usr/bin/env python3
from __future__ import annotations
import argparse, ast, hashlib, json, re, sys
from pathlib import Path

DESTRUCTIVE={'reset','delete','destroy','erase','excise','excision','purge','forget','wipe','clear','drop','remove','revoke','truncate','unlink','rmtree','shred'}
PREVIEW={'preview','plan','prepare','dry_run','dryrun'}
KERNEL=('MutationTransaction','PreparedMutation','AuthorizedMutation','TargetPermit','begin_apply','mutation_transaction','require_actuator_permit')

def canonical(v): return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()

def verify_fixture(path):
    data=json.loads(path.read_text())
    errors=[]
    for case in data['cases']:
        payload={'security_envelope':case['security_envelope'],'domain_payload':case['domain_payload']}
        scope={k:case['security_envelope'][k] for k in ('domain','operation','targets','affected_tiers','affected_replicas')}
        ph=hashlib.sha256(canonical(payload)).hexdigest()
        sh=hashlib.sha256(canonical(scope)).hexdigest()
        if ph!=case['expected_plan_hash']: errors.append(case['case_id']+': plan hash mismatch')
        if sh!=case['expected_target_scope_hash']: errors.append(case['case_id']+': target scope hash mismatch')
        if set(case['surface_inputs'])!={'CLI','MCP','HTTP','Python'}: errors.append(case['case_id']+': missing surface')
    return errors

def scan(root):
    findings=[]
    for path in root.rglob('*.py'):
        rel=path.relative_to(root)
        if any(p in {'.git','.venv','venv','node_modules','__pycache__'} for p in rel.parts): continue
        if any(p.lower() in {'tests','test','fixtures','examples'} for p in rel.parts): continue
        try: text=path.read_text(errors='replace'); tree=ast.parse(text)
        except Exception: continue
        surface=' '.join(rel.parts).lower()
        public=any(w in surface for w in ('cli','command','mcp','http','api','route','router'))
        if not public: continue
        lines=text.splitlines()
        for node in ast.walk(tree):
            if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)): continue
            seg='\n'.join(lines[node.lineno-1:getattr(node,'end_lineno',node.lineno)])
            toks=set(re.findall(r'[A-Za-z_]+',(node.name+' '+seg).lower()))
            if not (toks & DESTRUCTIVE): continue
            kernel=any(k in seg for k in KERNEL)
            preview=bool(toks & PREVIEW)
            calls=[]
            for ch in ast.walk(node):
                if isinstance(ch,ast.Call):
                    try: calls.append(ast.unparse(ch.func).lower())
                    except Exception: pass
            write=any(any(k in c.split('.')[-1] for k in DESTRUCTIVE) for c in calls)
            if preview and write:
                findings.append((str(rel),node.lineno,node.name,'preview-write-risk'))
            if not preview and write and not kernel:
                findings.append((str(rel),node.lineno,node.name,'destructive-surface-without-kernel-reference'))
    return findings

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('repo',type=Path)
    ap.add_argument('--fixture',type=Path,required=True)
    ap.add_argument('--strict-surfaces',action='store_true')
    args=ap.parse_args()
    errors=verify_fixture(args.fixture)
    findings=scan(args.repo)
    for e in errors: print('ERROR',e)
    for f in findings: print('%s:%s %s: %s'%f)
    print('fixture_errors=%d surface_findings=%d'%(len(errors),len(findings)))
    if errors or (args.strict_surfaces and findings): return 2
    return 0
if __name__=='__main__': raise SystemExit(main())
