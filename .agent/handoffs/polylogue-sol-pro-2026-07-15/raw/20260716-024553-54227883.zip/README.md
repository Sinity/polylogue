# Polylogue destructive-mutation launch handoff

This handoff targets **polylogue-kwsb.2**: every destructive CLI, MCP, HTTP, and Python operation must pass through a domain-preserving PREPARE → AUTHORIZE → APPLY → RECONCILE transaction and leave a redacted durable receipt.

## Read and apply order

1. Read `SUMMARY.md`, then `VERIFICATION-LIMITS.md`.
2. Review `DESIGN/repository-evidence.md` and `DESIGN/census.md`; the JSON census is the machine-readable companion.
3. Review `DESIGN/architecture.md`, `DESIGN/security-review.md`, and `DESIGN/rejected-alternatives.md`.
4. From a clean copy of the supplied snapshot root, apply the files listed in `PATCHES/series` in order. Run `git apply --check <patch>` before each `git apply <patch>`.
5. Run `TESTS/verify.sh /path/to/clean/snapshot`. It copies the base to a temporary directory, applies the series, compiles it, runs the focused mutation tests, validates parity fixture hashes, and emits a strict surface-gate report.

## Base and conflict assumptions

The immutable input is `polylogue-sol-pro-context-a62e54f83c114626.tar.gz` with SHA-256 `a62e54f83c1146264990ba756e00ecaa0de236d0705114653bf10737c6948b94`. Its patchable base tree contains 45 files and has content-tree SHA-256 `678ede424e6bc28285548e5239fcd525e7fe9953daaf814d1546a1d49f4395c6`. Git metadata present in the supplied patch root: `false`.

The patch series is scoped only to that tree. It must not be applied blindly over local edits. Compare each path in `DESIGN/base-assumptions.json` and the patch headers before applying; any existing mutation/security work on those paths is a semantic conflict even if `git apply` can merge it.

## Patch layers

`0001` introduces the shared fail-closed security kernel, canonical plan binding, scope-bound authorization, replay guard, per-target idempotency journal, redacted receipts, and permit validation. `0002` projects the already-shipped reset/excision envelopes into the security fields without merging their domain semantics. `0003` adds mutation-sensitive tests. The shared kernel never chooses targets, target order, or domain success semantics; domain code retains those responsibilities.

## Important integration status

The supplied snapshot yielded 52 destructive public-surface candidates in the static census: 0 already reference the kernel and 52 require reviewer disposition or adapter wiring. Static detection produces false positives and misses dynamic registration, so `DESIGN/census.json` is evidence for a human census rather than an automatic waiver. The patch is fail-closed at the kernel/permit boundary, but an unmodified public route remains a bypass until its real adapter and leaf actuator are wired and tested.
