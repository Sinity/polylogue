# Executive summary

## Result

The patch series implements the smallest shared destructive-mutation security kernel while keeping reset, storage-reset, and excision plans/actuators domain-owned. It freezes canonical plan bytes, binds exact target and replica state into a plan hash and scope hash, obtains a one-use actor/capability/scope authorization, consumes it only after TOCTOU validation, issues target-specific in-process permits, records idempotent per-target outcomes, and reconciles without converting uncertainty into success.

The durable journal is intentionally redacted: raw targets, actor identifiers, credentials, snapshot values, and evidence payloads are never written. Stable keyed fingerprints preserve correlation and evidence hashes preserve integrity. The implementation adds a signed-capability reference authorizer for self-contained tests; production adapters should bind the project’s existing authentication/capability service to the `MutationAuthorizer` protocol rather than ship a second identity system.

## Acceptance-criteria matrix

| Criterion | Status | Evidence / consequence |
|---|---|---|
| Census across CLI/MCP/HTTP/Python | PARTIAL | Generated AST/route census with excerpts and strict gate; dynamic registration still needs runtime confirmation. |
| Reuse reset and excision envelopes | MET IN PATCH | Domain projection hashes the shipped envelope as canonical domain payload; no merged executor. |
| Exact targets, tiers, replicas, snapshots, impact, hash, expiry | MET IN KERNEL | `MutationEnvelope` and `TargetBinding` validate exact set equality and canonical hash binding. |
| Actor/capability/scope-bound authorization | MET IN KERNEL | Authorizer decision echoes plan and target-scope hashes; capability and scopes are checked server-side. |
| TOCTOU revalidation | MET IN KERNEL | Full snapshot vector before authorization consumption plus per-target snapshot immediately before permit issuance. |
| Idempotent apply and per-target outcomes | MET IN KERNEL | Atomic target claims keyed by plan/target fingerprint; terminal outcomes are returned rather than re-applied. |
| Partial/held/unknown reconciliation | MET IN KERNEL | Only all APPLIED/NOOP becomes success; partial, held, and unknown remain non-terminal. |
| Redacted durable audit and receipts | MET IN KERNEL | SQLite FULL-synchronous journal stores HMAC fingerprints and evidence hashes, not raw target/actor/token/evidence. |
| Cross-surface reset/excision parity | FIXTURE PROVIDED | Three canonical fixtures cover identity reset, storage reset, and excision across CLI/MCP/HTTP/Python. |
| Real-route parity and direct-bypass closure | OPEN | Focused kernel bypass test exists; real public adapters require route-harness execution and strict-gate disposition. |

## Verification snapshot

| Check | Result |
|---|---|
| Safe patch application to a fresh base copy | PASS |
| Applied tree equals intended worktree | PASS |
| Python compilation on applied tree | PASS |
| Mutation security negative/positive tests | PASS |
| Reset/excision/mutation targeted tests | FAIL (exit 2) |
| Repository full pytest suite | FAIL (exit 2) |
| Ruff | NOT RUN / NOT AVAILABLE |
| Mypy | NOT RUN / NOT AVAILABLE |

## Highest-priority residual work

The static census contains **52** public-surface candidates without an observable kernel reference and **3** preview-write flags. Each must be manually classified against the full runtime registration graph. For true destructive routes, wire PREPARE and AUTHORIZE at the adapter, then require the kernel-issued target permit at the leaf actuator; add real CLI, MCP, HTTP, and Python route tests using the canonical fixtures. Do not weaken the permit boundary to preserve legacy `confirm=True` behavior.

The supplied context is a narrow snapshot, so live daemon state, secrets, external databases, replica behavior, NixOS deployment, and operator browser flows were not exercised. Those boundaries are explicit in `VERIFICATION-LIMITS.md`.
