# Verification limits

## Executed in the container

- **Safe patch application to a fresh base copy: PASS.** See `TESTS/raw-verification-logs.txt` for command output and exit code.
- **Applied tree equals intended worktree: PASS.** See `TESTS/raw-verification-logs.txt` for command output and exit code.
- **Python compilation on applied tree: PASS.** See `TESTS/raw-verification-logs.txt` for command output and exit code.
- **Mutation security negative/positive tests: PASS.** See `TESTS/raw-verification-logs.txt` for command output and exit code.
- **Reset/excision/mutation targeted tests: FAIL (exit 2).** See `TESTS/raw-verification-logs.txt` for command output and exit code.
- **Repository full pytest suite: FAIL (exit 2).** See `TESTS/raw-verification-logs.txt` for command output and exit code.
- **Ruff: NOT RUN / NOT AVAILABLE.** See `TESTS/raw-verification-logs.txt` for command output and exit code.
- **Mypy: NOT RUN / NOT AVAILABLE.** See `TESTS/raw-verification-logs.txt` for command output and exit code.

The input tar was enumerated before extraction; absolute paths, `..` traversal, duplicate member names, unsafe links, device nodes, and FIFOs were rejected. The finished ZIP is independently reopened, path-normalized, duplicate-checked, and every manifest size/hash is recomputed before release.

## Not executed or not claimable

- No operator browser, live CLI daemon, MCP client/server exchange, HTTP deployment, credential provider, secret store, production database, object store, replica, queue, or NixOS host was available.
- No production authorization secret was used. `SignedCapabilityAuthorizer` is a reference/test adapter; its protocol boundary must be connected to the project capability service.
- Static census results do not prove runtime registration coverage. Decorator aliases, generated routes, dependency injection, plugins, and subprocess/destructive calls outside the snapshot can evade it.
- The SQLite journal was exercised only on the container filesystem. Network filesystems, abrupt power loss, disk-full behavior, backup/restore, retention, key rotation, and multi-process contention need deployment tests.
- Cross-surface fixtures were hash-validated, but real CLI/MCP/HTTP/Python parity cannot be claimed unless the repository’s runnable route harness covers every candidate in `DESIGN/census.json`.
- No claim is made that legal/privacy policy labels, retention periods, or capability names are production-approved; those are domain policy inputs bound by the plan.

## Review boundary

The patches are reviewable implementation material scoped to the supplied snapshot. A release decision requires closing every true-positive uncovered surface in the census, proving leaf-actuator permit enforcement, and executing fault-injection against the actual stores and replicas.
