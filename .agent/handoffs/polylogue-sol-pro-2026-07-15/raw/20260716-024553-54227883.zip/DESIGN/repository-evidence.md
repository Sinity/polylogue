# Repository and Beads evidence

This file preserves the instruction/issue evidence used for the handoff. Later notes remain in source order; no issue description was treated as authoritative over a later note.

## Relevant Beads records

No literal `polylogue-kwsb` record was present in the patchable snapshot; this is an evidence gap.

## Instruction files consulted

### `.pytest_cache/README.md`
```text
# pytest cache directory #

This directory contains data from the pytest's cache plugin,
which provides the `--lf` and `--ff` options, as well as the `cache` fixture.

**Do not** commit this to version control.

See [the docs](https://docs.pytest.org/en/stable/how-to/cache.html) for more information.

```
