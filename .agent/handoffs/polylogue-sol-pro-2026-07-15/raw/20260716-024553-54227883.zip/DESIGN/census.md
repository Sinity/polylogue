# Destructive-operation census

Generated from the supplied immutable snapshot plus the patch worktree. It is a review aid, not a claim that keyword detection alone proves destructiveness. Every candidate below must be dispositioned as a public adapter, domain plan, guarded actuator, read-only preview, or false positive.

## Summary

| Surface | Candidate symbols |
|---|---:|
| CLI | 8 |
| MCP | 7 |
| HTTP | 38 |
| Python | 49 |

| Operation family | Candidate symbols |
|---|---:|
| excision | 30 |
| identity-reset | 4 |
| other-destructive | 54 |
| reset-other | 8 |
| storage-reset | 3 |
| unknown | 3 |

Preview-write risks flagged: **19**. Candidates already referencing the mutation kernel: **4**.

## Candidate inventory

| Surface | Family | Location | Symbol | Preview | Write/actuator evidence | Kernel ref |
|---|---|---|---|---:|---:|---:|
| CLI | excision | `polylogue/cli/commands/excise.py:30` | `_emit` | no | no | no |
| CLI | excision | `polylogue/cli/commands/excise.py:100` | `excise_command` | yes | yes | no |
| CLI | identity-reset | `polylogue/cli/commands/reset.py:225` | `_identity_reset_targets` | yes | no | no |
| CLI | identity-reset | `polylogue/cli/commands/reset.py:241` | `_emit_identity_reset_result` | no | no | no |
| CLI | identity-reset | `polylogue/cli/commands/reset.py:344` | `reset_command` | yes | yes | no |
| CLI | other-destructive | `polylogue/cli/commands/reset.py:144` | `_resolve_archive_session_ids` | no | yes | no |
| CLI | other-destructive | `polylogue/cli/commands/reset.py:189` | `_delete_archive_sessions` | no | yes | no |
| CLI | storage-reset | `polylogue/cli/commands/reset.py:65` | `_archive_database_targets` | no | no | no |
| HTTP | other-destructive | `polylogue/api/archive.py:1964` | `PolylogueArchiveMixin.postmortem_bundle` | no | no | no |
| HTTP | other-destructive | `polylogue/api/archive.py:2535` | `PolylogueArchiveMixin.compile_context` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:4325` | `PolylogueArchiveMixin.rebuild_insights` | no | no | no |
| HTTP | other-destructive | `polylogue/api/archive.py:4816` | `PolylogueArchiveMixin.delete_session` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:4827` | `PolylogueArchiveMixin.delete_session_safe` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:4881` | `PolylogueArchiveMixin.remove_tag` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:4955` | `PolylogueArchiveMixin.delete_metadata` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:5164` | `PolylogueArchiveMixin.remove_mark` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:5285` | `PolylogueArchiveMixin.delete_annotation` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:5324` | `PolylogueArchiveMixin.delete_view` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:5600` | `PolylogueArchiveMixin.delete_recall_pack` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:5689` | `PolylogueArchiveMixin.delete_workspace` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:5762` | `PolylogueArchiveMixin.delete_correction` | no | yes | no |
| HTTP | other-destructive | `polylogue/api/archive.py:5774` | `PolylogueArchiveMixin.clear_corrections` | yes | yes | no |
| HTTP | other-destructive | `polylogue/api/search_envelope_builder.py:42` | `build_search_envelope_for_spec` | yes | no | no |
| HTTP | other-destructive | `polylogue/daemon/http.py:199` | `_web_privacy_safe_projection` | no | no | no |
| HTTP | other-destructive | `polylogue/daemon/http.py:348` | `_normalize_session_route_id` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/http.py:410` | `implemented_daemon_route_patterns` | no | no | no |
| HTTP | other-destructive | `polylogue/daemon/http.py:1252` | `DaemonAPIHandler._check_host_admission` | no | no | no |
| HTTP | other-destructive | `polylogue/daemon/http.py:1752` | `DaemonAPIHandler.do_DELETE` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/http.py:1763` | `DaemonAPIHandler._do_delete_impl` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:175` | `dispatch_delete` | no | no | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:244` | `handle_delete_mark` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:254` | `_delete` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:359` | `handle_delete_annotation` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:360` | `_delete` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:428` | `handle_delete_saved_view` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:429` | `_delete` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:499` | `handle_delete_recall_pack` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:500` | `_delete` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:583` | `handle_delete_workspace` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:584` | `_delete` | no | yes | no |
| HTTP | other-destructive | `polylogue/daemon/user_state_http.py:600` | `_routes` | no | no | no |
| HTTP | reset-other | `polylogue/daemon/http.py:390` | `_authenticated_post_routes` | yes | no | no |
| HTTP | reset-other | `polylogue/daemon/http.py:1671` | `DaemonAPIHandler._do_post_impl` | no | no | no |
| HTTP | reset-other | `polylogue/daemon/http.py:4167` | `DaemonAPIHandler._handle_reset` | no | yes | no |
| HTTP | reset-other | `polylogue/daemon/http.py:4186` | `_do_reset` | no | yes | no |
| HTTP | unknown | `polylogue/daemon/http.py:1827` | `DaemonAPIHandler._handle_web_auth_revoke` | no | yes | no |
| MCP | other-destructive | `polylogue/mcp/server_mutation_tools.py:42` | `register_mutation_tools` | no | yes | no |
| MCP | other-destructive | `polylogue/mcp/server_mutation_tools.py:191` | `remove_tag` | no | yes | no |
| MCP | other-destructive | `polylogue/mcp/server_mutation_tools.py:192` | `run` | no | yes | no |
| MCP | other-destructive | `polylogue/mcp/server_mutation_tools.py:353` | `remove_mark` | no | yes | no |
| MCP | other-destructive | `polylogue/mcp/server_mutation_tools.py:360` | `run` | no | yes | no |
| MCP | other-destructive | `polylogue/mcp/server_mutation_tools.py:392` | `delete_session` | no | yes | no |
| MCP | other-destructive | `polylogue/mcp/server_mutation_tools.py:393` | `run` | no | yes | no |
| Python | excision | `polylogue/security/destructive_mutation_plans.py:40` | `ExcisionMutationPlan.mutation_envelope` | yes | no | no |
| Python | excision | `polylogue/security/excision.py:135` | `resolve_session_excision_target` | no | yes | no |
| Python | excision | `polylogue/security/excision.py:194` | `find_lineage_dependents` | no | yes | no |
| Python | excision | `polylogue/security/excision.py:253` | `LineageDependentsError.__init__` | no | no | no |
| Python | excision | `polylogue/security/excision.py:304` | `plan_session_excision` | yes | yes | no |
| Python | excision | `polylogue/security/excision.py:406` | `_receipt_assertion_id` | no | no | no |
| Python | excision | `polylogue/security/excision.py:414` | `_apply_single_session_excision` | no | yes | no |
| Python | excision | `polylogue/security/excision.py:577` | `apply_session_excision` | no | yes | no |
| Python | excision | `polylogue/security/lifecycle.py:149` | `_request_assertion_id` | no | no | no |
| Python | excision | `polylogue/security/lifecycle.py:157` | `submit_lifecycle_request` | no | no | no |
| Python | excision | `polylogue/security/lifecycle.py:346` | `apply_primary_invalidation_if_confirmed` | no | yes | no |
| Python | excision | `polylogue/security/secret_scan.py:238` | `scan_session_for_secret_candidates` | no | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:147` | `TestPlanSessionExcision.test_not_found_for_unknown_session` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:151` | `TestPlanSessionExcision.test_counts_every_tier` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:162` | `TestPlanSessionExcision.test_dry_run_does_not_mutate` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:171` | `TestApplySessionExcision.test_not_found_returns_found_false` | no | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:175` | `TestApplySessionExcision.test_apply_removes_rows_from_every_tier` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:226` | `TestApplySessionExcision.test_apply_writes_durable_audit_receipt` | no | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:243` | `TestApplySessionExcision.test_apply_removes_content_bearing_assertions_targeting_the_session` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:276` | `TestApplySessionExcision.test_apply_is_idempotent` | no | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:283` | `TestApplySessionExcision.test_reingest_does_not_resurrect_excised_content` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:308` | `TestApplySessionExcision.test_reingest_batch_skips_excised_file_without_aborting` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:362` | `TestApplySessionExcision.test_blob_ref_reingest_does_not_resurrect_excised_content` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:456` | `TestLineageSafety.test_plan_surfaces_lineage_dependents` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:461` | `TestLineageSafety.test_apply_without_cascade_refuses_and_does_not_mutate` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:476` | `TestLineageSafety.test_apply_with_cascade_removes_parent_and_dependents` | yes | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:501` | `TestLineageSafety.test_apply_with_no_dependents_behaves_as_before` | no | yes | no |
| Python | excision | `tests/unit/security/test_excision.py:524` | `TestAttachmentBlobHashesAreExcisedToo.test_attachment_blob_hash_recorded_in_excised_content` | yes | yes | no |
| Python | identity-reset | `tests/test_mutation_transaction_security.py:45` | `make_plan` | yes | yes | no |
| Python | other-destructive | `tests/test_mutation_transaction_security.py:40` | `CountingActuator.destroy` | no | no | no |
| Python | other-destructive | `tests/test_mutation_transaction_security.py:151` | `test_direct_actuator_bypass_and_forged_permit_are_rejected` | yes | yes | yes |
| Python | other-destructive | `tests/test_mutation_transaction_security.py:162` | `test_idempotent_target_claim_returns_prior_outcome_without_second_write` | yes | yes | yes |
| Python | other-destructive | `tests/unit/operations/test_mutations.py:105` | `TestDeleteMetadataValidated.test_deleted_then_not_found` | no | yes | no |
| Python | other-destructive | `tests/unit/operations/test_mutations.py:118` | `TestDeleteMetadataValidated.test_invalid_key_raises_validation_error` | no | yes | no |
| Python | other-destructive | `tests/unit/operations/test_mutations.py:124` | `TestDeleteMetadataValidated.test_missing_session_raises` | no | yes | no |
| Python | other-destructive | `tests/unit/operations/test_mutations.py:138` | `TestDeleteSessionSafe.test_delete_then_not_found` | no | yes | no |
| Python | other-destructive | `tests/unit/operations/test_mutations.py:150` | `TestDeleteSessionSafe.test_missing_session_returns_not_found` | no | yes | no |
| Python | other-destructive | `tests/unit/operations/test_mutations.py:157` | `TestDeleteSessionSafe.test_bool_wrapper_still_returns_bool` | no | yes | no |
| Python | other-destructive | `tests/unit/security/test_excision_lifecycle.py:123` | `TestFaultInjection.test_ops_db_deletion_does_not_erase_the_request` | no | yes | no |
| Python | other-destructive | `tests/unit/security/test_path_sanitization.py:152` | `TestFileTokenStoreSecurity.test_delete_removes_file` | no | yes | no |
| Python | other-destructive | `tests/unit/security/test_path_sanitization.py:160` | `TestFileTokenStoreSecurity.test_delete_nonexistent_no_error` | no | yes | no |
| Python | reset-other | `polylogue/security/destructive_mutation_plans.py:23` | `ResetMutationPlan.mutation_envelope` | yes | no | no |
| Python | reset-other | `tests/test_mutation_transaction_security.py:102` | `test_plan_hash_binds_mutation_sensitive_fields` | yes | no | no |
| Python | reset-other | `tests/test_mutation_transaction_security.py:134` | `test_full_vector_and_per_target_toctou_drift_fail` | yes | no | yes |
| Python | reset-other | `tests/test_mutation_transaction_security.py:185` | `test_partial_held_and_unknown_never_report_success` | yes | no | yes |
| Python | storage-reset | `polylogue/operations/archive_debt.py:114` | `_tier_rows` | no | no | no |
| Python | storage-reset | `tests/unit/security/test_excision_lifecycle.py:63` | `TestSubmitLifecycleRequest.test_idempotent_for_same_target_and_mode` | no | no | no |
| Python | unknown | `tests/unit/security/test_excision_lifecycle.py:194` | `TestModeGates.test_mirror_may_hide_before_confirmation` | no | yes | no |
| Python | unknown | `tests/unit/security/test_excision_lifecycle.py:208` | `TestModeGates.test_primary_never_hides_before_confirmed` | no | yes | no |

## Preview-write flags

- `polylogue/cli/commands/excise.py:100` `excise_command` calls: `plan_session_excision, plan_session_excision, apply_session_excision`
- `polylogue/cli/commands/reset.py:344` `reset_command` calls: `_identity_reset_targets, _delete_archive_sessions, _emit_identity_reset_result, _emit_identity_reset_result, _emit_identity_reset_result, _emit_identity_reset_result, path.unlink, shutil.rmtree`
- `polylogue/api/archive.py:5774` `PolylogueArchiveMixin.clear_corrections` calls: `archive.clear_corrections`
- `polylogue/security/excision.py:304` `plan_session_excision` calls: `resolve_session_excision_target, ExcisionPlan, ExcisionPlan, is_blob_hash_excised, conn.execute, conn.execute, conn.execute`
- `tests/unit/security/test_excision.py:147` `TestPlanSessionExcision.test_not_found_for_unknown_session` calls: `plan_session_excision`
- `tests/unit/security/test_excision.py:151` `TestPlanSessionExcision.test_counts_every_tier` calls: `plan_session_excision`
- `tests/unit/security/test_excision.py:162` `TestPlanSessionExcision.test_dry_run_does_not_mutate` calls: `plan_session_excision, resolve_session_excision_target`
- `tests/unit/security/test_excision.py:175` `TestApplySessionExcision.test_apply_removes_rows_from_every_tier` calls: `apply_session_excision, index_conn.execute, index_conn.execute, index_conn.execute, source_conn.execute, source_conn.execute, emb_conn.execute, emb_conn.execute`
- `tests/unit/security/test_excision.py:243` `TestApplySessionExcision.test_apply_removes_content_bearing_assertions_targeting_the_session` calls: `apply_session_excision, conn.execute`
- `tests/unit/security/test_excision.py:283` `TestApplySessionExcision.test_reingest_does_not_resurrect_excised_content` calls: `apply_session_excision, source_conn.execute, is_blob_hash_excised, source_conn.execute`
- `tests/unit/security/test_excision.py:308` `TestApplySessionExcision.test_reingest_batch_skips_excised_file_without_aborting` calls: `apply_session_excision, index_conn.execute, index_conn.execute`
- `tests/unit/security/test_excision.py:362` `TestApplySessionExcision.test_blob_ref_reingest_does_not_resurrect_excised_content` calls: `apply_session_excision, source_conn.execute, is_blob_hash_excised, source_conn.execute`
- `tests/unit/security/test_excision.py:456` `TestLineageSafety.test_plan_surfaces_lineage_dependents` calls: `plan_session_excision`
- `tests/unit/security/test_excision.py:461` `TestLineageSafety.test_apply_without_cascade_refuses_and_does_not_mutate` calls: `apply_session_excision, index_conn.execute`
- `tests/unit/security/test_excision.py:476` `TestLineageSafety.test_apply_with_cascade_removes_parent_and_dependents` calls: `apply_session_excision, index_conn.execute, user_conn.execute`
- `tests/unit/security/test_excision.py:524` `TestAttachmentBlobHashesAreExcisedToo.test_attachment_blob_hash_recorded_in_excised_content` calls: `resolve_session_excision_target, apply_session_excision, is_blob_hash_excised, is_blob_hash_excised, source_conn.execute`
- `tests/test_mutation_transaction_security.py:45` `make_plan` calls: `ResetMutationPlan`
- `tests/test_mutation_transaction_security.py:151` `test_direct_actuator_bypass_and_forged_permit_are_rejected` calls: `actuator.destroy`
- `tests/test_mutation_transaction_security.py:162` `test_idempotent_target_claim_returns_prior_outcome_without_second_write` calls: `actuator.destroy`

## Static-analysis limits

Dynamic registration, dependency injection, aliases, generated routes, reflection, and external actuators can evade this census. Conversely, collection `.clear()`/`.remove()` and test helpers can be false positives. The JSON companion retains excerpts and call evidence for reviewer disposition.
