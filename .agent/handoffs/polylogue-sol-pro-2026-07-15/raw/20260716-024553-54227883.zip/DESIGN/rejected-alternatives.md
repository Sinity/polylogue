# Rejected alternatives

## One universal mutation executor

Rejected because target resolution, ordering, legal holds, reversibility, and success semantics differ between identity reset, storage reset, and excision. A generic executor would either leak domain rules into security code or flatten meaningful outcomes. The kernel issues and validates permits; each domain applies and reconciles its own plan.

## Treating `--yes`, `confirm=True`, an MCP confirmation field, or an HTTP header as authorization

Rejected because a boolean is not actor-, capability-, scope-, target-, snapshot-, expiry-, or replay-bound. Surface confirmation may remain a UX step, but it cannot mint a mutation permit.

## Hashing only counts, a session ID, or a selector

Rejected because APPLY could re-resolve a different set. The plan hash covers exact targets, tiers, replicas, snapshot vector, reversibility/privacy impact, expiry, required authority, and the complete shipped domain envelope.

## Authorize once at login or at the route boundary

Rejected because session authentication can outlive target state and does not guard direct Python/actuator calls. Authorization is transaction-specific and the leaf actuator requires a target permit.

## Re-resolve at apply time and “best effort” compare

Rejected because it creates a TOCTOU substitution channel. APPLY compares the complete vector and then each target snapshot immediately before permit issuance. Drift requires a new plan and authorization.

## Replaying authorization as an idempotency mechanism

Rejected because replay resistance and idempotency solve different problems. Public authorization is consumed once. Durable per-target claims suppress duplicate effects; reconciliation uses evidence rather than reusing a public credential.

## Recording raw plans and payloads for audit convenience

Rejected because destructive operations often concern sensitive data. The durable record contains plan hashes, keyed fingerprints, reason codes, state, and evidence hashes. Exact plans remain domain data with their own retention/access policy.

## Optimistic success for missing outcomes

Rejected because a process crash after a write but before reporting cannot be distinguished from a pre-write crash. Missing/ambiguous outcomes are UNKNOWN and remain non-terminal until domain reconciliation proves a state.

## Repository-wide magic decorator inferred from function names

Rejected because static names cannot reliably identify targets or domain snapshots and would create a hidden universal executor. The census uses heuristics only to find review candidates; real adapters must project explicit domain plans.
