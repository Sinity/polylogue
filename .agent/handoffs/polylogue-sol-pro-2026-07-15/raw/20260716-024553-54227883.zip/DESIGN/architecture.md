# Destructive mutation security architecture

## Boundary and invariant

The kernel authorizes a *specific frozen domain plan*, not a verb such as “reset” and not a surface-level boolean. Reset and excision continue to decide what their targets mean, how targets are ordered, which legal holds apply, and how domain-specific failures are interpreted. The shared layer owns only security invariants that must be identical across surfaces.

A destructive write is valid only when all of these objects agree: the domain plan; its canonical security projection; the immutable plan hash; the target-scope hash; the actor/capability/scope authorization decision; the current full snapshot vector; the immediately observed target snapshot; the transaction/target permits; and the durable target claim. Any disagreement fails closed before the write.

## State protocol

### PREPARE

The existing reset/excision planner resolves exact target identifiers and emits its shipped domain envelope. It projects each target into `TargetBinding` with tier, replica, snapshot key/value, reversibility, and privacy impact. `MutationTransaction.prepare()` validates exact tier/replica set equality, expiry, uniqueness, snapshot consistency, capability, and scope. It hashes canonical JSON containing both the shared security envelope and the complete shipped domain envelope. PREPARE performs no actuator call.

### AUTHORIZE

The adapter obtains an opaque credential and calls the configured `MutationAuthorizer`. The request binds transaction ID, plan ID/hash, target-scope hash, domain/operation, required capability/scopes, and plan expiry. The returned decision must echo the exact plan and scope hashes and satisfy capability/scope policy. The journal atomically reserves a fingerprint of the authorization ID; a second reservation is replay.

### APPLY

Immediately before writes, domain code re-reads the complete snapshot vector and calls `begin_apply()`. A mismatch is plan drift and leaves the authorization unconsumed. Once the vector matches, the journal atomically consumes the one-use authorization. The domain retains the target loop. Immediately before each leaf write it re-reads that target’s snapshot and asks the session for a target permit. The atomic target claim either grants one attempt or returns a prior outcome, preventing duplicate writes. The leaf actuator must call `require_actuator_permit()` before destructive I/O.

### RECONCILE

The domain records a reason-coded target outcome plus optional evidence. Only a hash of canonical evidence is durable. Reconciliation materializes every planned target: absent evidence becomes UNKNOWN. All APPLIED/NOOP is SUCCEEDED. A mix of success and any other state is PARTIAL. All-held is HELD; uncertainty is UNKNOWN; all-confirmed failures are FAILED. PARTIAL, HELD, and UNKNOWN are never represented as terminal success.

## Durable evidence and redaction

The SQLite journal uses an append-oriented audit table plus atomic authorization and target-claim tables. `synchronous=FULL`, WAL mode, explicit immediate transactions, unique authorization fingerprints, and `(plan_hash,target_fingerprint)` keys protect the local protocol. Raw target IDs, actor IDs, authorization IDs/tokens, snapshots, and evidence are excluded. HMAC-SHA-256 fingerprints permit stable correlation without dictionary-free disclosure; evidence is SHA-256 hashed. The audit key therefore becomes a protected, rotatable deployment secret and must not be colocated with exported audit data.

## Domain integration pattern

Each real adapter should have four explicit calls rather than a convenience “execute mutation” helper:

```python
plan = reset_domain.preview_and_build_plan(request)       # read-only domain planner
prepared = mutation_kernel.prepare(plan)                  # PREPARE
authorized = mutation_kernel.authorize(prepared, token)   # AUTHORIZE
observed = reset_domain.read_snapshot_vector(plan)
session = mutation_kernel.begin_apply(prepared, authorized, observed)
for target in reset_domain.ordered_targets(plan):         # domain-owned APPLY
    current = reset_domain.read_target_snapshot(target)
    permit, prior = session.authorize_target(target.id, current)
    if prior is not None:
        reset_domain.accept_prior_outcome(target, prior)
        continue
    reset_actuator.apply_target(target, session=session, permit=permit)
    session.record_outcome(permit, reset_domain.outcome_for(target))
receipt = session.reconcile()                              # RECONCILE
```

Identity reset, storage reset, and excision should each retain separate orchestrators and actuator interfaces. The public CLI, MCP, HTTP, and Python adapters may share serialization fixtures, but they must not share a generic target resolver or generic mutation executor.

## Concurrency, replay, and recovery

Public authorization is one-use. A client retry after consumption must retrieve the receipt or enter an explicitly authorized reconciliation path; it must not replay the original token. Per-target idempotency is independent: a durable terminal target outcome suppresses a second write. A claim left as `UNKNOWN/claimed_not_reported` after a crash cannot be guessed successful. Domain reconciliation must inspect the store and replace uncertainty only with evidence.

## Security-sensitive deployment requirements

The production authorizer must validate credential authenticity and actor status, not trust caller-supplied actor text. Audit and authorization keys need independent rotation and access control. Receipt lookup needs its own authorization policy. Database permissions must prevent application code from rewriting history, and retention/backup behavior must match privacy policy. Metrics may count states but must not add raw target labels.
