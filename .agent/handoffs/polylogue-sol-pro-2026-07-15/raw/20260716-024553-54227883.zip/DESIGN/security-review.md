# Security review map

| Threat / failure | Control | Test or evidence |
|---|---|---|
| Preview triggers writes | PREPARE only canonicalizes and journals a plan; no actuator reference | `test_preview_prepare_has_no_actuator_write`; census preview-write flags |
| Authorization omitted | `begin_apply` requires sealed `AuthorizedMutation` | `test_authorization_omission_is_fail_closed` |
| Authorization replay | Unique authorization fingerprint reservation and atomic consumption | `test_authorization_replay_is_rejected` |
| Plan/target substitution | Canonical plan hash and target-scope hash echoed by authorizer | `test_plan_hash_binds_mutation_sensitive_fields`; parity fixture hashes |
| TOCTOU drift | Full vector before consumption and per-target snapshot before permit | `test_full_vector_and_per_target_toctou_drift_fail` |
| Direct actuator bypass | Leaf requires target-specific HMAC-sealed permit | `test_direct_actuator_bypass_and_forged_permit_are_rejected`; strict static gate |
| Duplicate target effect | Atomic `(plan_hash,target_fingerprint)` claim and stored outcome | `test_idempotent_target_claim_returns_prior_outcome_without_second_write` |
| False success after partial/crash/hold | Complete target materialization; conservative receipt lattice | `test_partial_held_and_unknown_never_report_success` |
| Audit leaks sensitive values | Keyed fingerprints/evidence hashes; no canonical plan or credential persistence | `test_durable_audit_is_redacted` |
| Surface semantic drift | Shared canonical fixtures; exact hashes across four adapters | `TESTS/cross-surface-parity.json`; fixture verifier |

## Manual review questions

1. Does each real public destructive route build the same domain plan as its peers before authorization?
2. Is every leaf destructive I/O reachable only through a target-permit check, including Python-internal calls and background jobs?
3. Are legal holds represented as HELD outcomes rather than exceptions converted to success?
4. Can receipt lookup, reconciliation, and audit export reveal target identity through authorization or metadata side channels?
5. Can any legacy `confirm` path call the actuator without the new transaction objects?
