# Primary-source research translated into project decisions

Accessed 2026-07-15.

| Source | URL | Concrete project decision |
|---|---|---|
| OWASP Transaction Authorization Cheat Sheet | https://cheatsheetseries.owasp.org/cheatsheets/Transaction_Authorization_Cheat_Sheet.html | Treat transaction authorization as distinct from login/session authentication; bind it to significant transaction data, validate server-side, make it short-lived and sequential, and reject any changed transaction. This maps to plan/scope hashes, expiry, one-use authorization, and TOCTOU checks. |
| OWASP Logging Cheat Sheet | https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html | Preserve who/what/when/outcome evidence while excluding credentials, tokens, secrets, and sensitive personal payloads. This maps to HMAC fingerprints, evidence hashes, allowlisted audit columns, and no raw plan persistence. |
| NIST SP 800-53 Rev. 5, AC-3 and AU family | https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final | Centralize access enforcement and retain protected, reviewable audit event content. This maps to one kernel permit boundary and an append-oriented durable journal rather than per-surface booleans. |
| RFC 9421, HTTP Message Signatures | https://www.rfc-editor.org/rfc/rfc9421.html | The created/expires/nonce and covered-component model supports explicit time and content binding. The patch applies the same design property to a local authorization envelope; it does not claim RFC 9421 wire compatibility. |
| SQLite PRAGMA documentation (`synchronous`) | https://www.sqlite.org/pragma.html#pragma_synchronous | Set FULL synchronization for the local journal and use explicit transactions. Deployment still needs filesystem/power-loss testing; a pragma is not a universal durability guarantee. |
| SQLite Write-Ahead Logging | https://www.sqlite.org/wal.html | WAL supports concurrent readers and atomic local commits but has operational constraints. The design keeps reconciliation explicit and lists network filesystem/multi-process validation as a release boundary. |
| Python `hmac` documentation | https://docs.python.org/3/library/hmac.html | Use HMAC for keyed redaction fingerprints and constant-time comparison; do not use plain hashes for predictable actor/target identifiers. |

No source is treated as a substitute for Polylogue domain policy. The sources justify security properties; reset/excision planners still define targets, legal holds, privacy labels, and reversibility.
