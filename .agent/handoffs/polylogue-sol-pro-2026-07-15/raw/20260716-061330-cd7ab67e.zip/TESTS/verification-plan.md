# Verification plan

## What the focused tests prove

`tests/unit/declarations/test_declaration_kernel.py` is self-contained and does
not import MCP or a service runtime. Its 15 collected cases prove:

- compatibility values are not coerced;
- every one of the five compatibility dimensions appears in a conflict;
- reversing incompatible registration order produces identical diagnostic
  bytes;
- all permutations of three declarations produce byte-identical derivation
  input;
- all six derivation categories include source provenance;
- removing each of seven completeness requirements yields exactly one
  diagnostic with declaration id, owner path/symbol, and the exact repair
  command;
- a missing actual callable yields `missing-handler`;
- a failed batch rolls back its compatible prefix;
- exact duplicates are idempotent and changed duplicates fail;
- the shared package has no imports from any Polylogue domain package;
- MCP contains no copied implementation of the shared model/registry/derivation
  classes.

`tests/unit/mcp/test_declaration_pilot.py` proves the real pilot rather than a
toy duplicate:

- the actual `MCP_READ_TOOL_SPECS` row wraps `DeclarationSpec`;
- MCP-only semantic fields are absent from `DeclarationSpec`;
- the actual MCP registry can derive the pilot's name, schema, example, and
  complete edge set;
- deleting the actual declaration row produces `missing-declaration` and the
  exact source repair command;
- passing a missing callable or deleting the handler binding fails before
  `FastMCP.tool()`;
- a valid callable retains the existing name/doc/decorator registration
  behavior.

The existing read-view and server-surface tests are included because they
exercise the route whose registration seam changed.

## Complete-checkout execution

Run the executable plan from the handoff root or pass an explicit repository:

```bash
./TESTS/verification.sh /path/to/polylogue
```

The script intentionally uses repository-standard `devtools` commands. It
first runs the isolated smoke, regenerates required topology surfaces, runs the
new focused tests and existing real-route tests, then runs the quick gate and
`git diff --check`.

Expected successful milestones:

```text
isolated MCP declaration pilot smoke: PASS
15 passed                         # kernel file; exact timing is irrelevant
MCP pilot tests passed
read-view route contracts passed
server-surface registration contracts passed
devtools verify --quick passed
```

The topology commands may leave intended changes in:

- `docs/plans/topology-target.yaml`
- `docs/topology-status.md`

Review and commit those generated changes; their absence from this patch series
is a limitation of the supplied partial snapshot, not an optional repository
rule.

## Additional review commands

These checks are useful when reviewing a conflict resolution or follow-up:

```bash
# Shared package must import no Polylogue domain package.
rg -n '^from polylogue\.|^import polylogue\.' polylogue/declarations

# MCP must consume, not reproduce, shared implementation classes.
rg -n '^class (DeclarationSpec|FamilySpec|DeclarationRegistry|DerivationInputs|Diagnostic)\b' polylogue/mcp

# Exactly one production pilot is expected in this slice.
rg -n 'mcp\.tool\.list_read_view_profiles|MCP_READ_TOOL_SPECS' \
  polylogue/mcp tests/unit/mcp

# Unified-diff and whitespace safety.
git diff --check
```

## Patch application proof already performed

The four patches were applied with `git am` to a fresh Git import of the
supplied `REPO/` tree. Every changed-file SHA-256 matched the implementation
worktree, the kernel suite passed again, and the isolated MCP smoke passed
again. See `patch-apply-results.txt` and `local-results.txt`.
