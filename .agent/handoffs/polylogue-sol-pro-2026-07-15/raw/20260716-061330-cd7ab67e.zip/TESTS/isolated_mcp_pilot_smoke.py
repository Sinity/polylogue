from __future__ import annotations

import ast
import sys
from pathlib import Path
from types import ModuleType
from typing import Any
from unittest.mock import MagicMock

from polylogue.declarations import (
    DeclarationValidationError,
    derive_inputs,
    validate_declaration,
)

# The supplied source slice omits most modules imported by server_support.  The
# MCP declaration model only needs its domain-owned MCPRole alias at runtime.
server_support = ModuleType("polylogue.mcp.server_support")
server_support.MCPRole = str
sys.modules[server_support.__name__] = server_support

from polylogue.mcp.declarations import (  # noqa: E402
    MCPReadToolSpec,
    MCP_READ_DECLARATION_REGISTRY,
    MCP_READ_TOOL_SPECS,
    require_mcp_read_tool_spec,
)

SOURCE = Path("polylogue/mcp/server_tools.py")
tree = ast.parse(SOURCE.read_text(encoding="utf-8"), filename=str(SOURCE))
selected = [
    node
    for node in tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "_register_mcp_read_tool"
]
assert len(selected) == 1
module = ast.Module(
    body=[
        ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0),
        selected[0],
    ],
    type_ignores=[],
)
ast.fix_missing_locations(module)
namespace: dict[str, object] = {
    "__name__": "isolated_mcp_declaration_pilot",
    "Any": Any,
    "FastMCP": object,
    "_MCPReadToolSpec": MCPReadToolSpec,
    "DeclarationValidationError": DeclarationValidationError,
    "validate_declaration": validate_declaration,
}
exec(compile(module, str(SOURCE), "exec"), namespace)
register_tool = namespace["_register_mcp_read_tool"]
assert callable(register_tool)

spec = require_mcp_read_tool_spec("list_read_view_profiles")
assert MCP_READ_DECLARATION_REGISTRY.require("mcp.tool.list_read_view_profiles") == spec.declaration
assert derive_inputs(MCP_READ_DECLARATION_REGISTRY.families()).names[0].name == "list_read_view_profiles"
assert spec.verb == "read"
assert spec.required_role == "read"
assert spec.result_semantics == "aggregate"

try:
    require_mcp_read_tool_spec("list_read_view_profiles", {})
except DeclarationValidationError as exc:
    assert [diagnostic.code for diagnostic in exc.diagnostics] == ["missing-declaration"]
else:
    raise AssertionError("missing pilot declaration did not fail")

mcp = MagicMock()
try:
    register_tool(mcp, None, spec)
except DeclarationValidationError as exc:
    assert [diagnostic.code for diagnostic in exc.diagnostics] == ["missing-handler"]
    mcp.tool.assert_not_called()
else:
    raise AssertionError("missing pilot handler did not fail")

mcp = MagicMock()
decorator = MagicMock()
mcp.tool.return_value = decorator

async def handler() -> str:
    return "{}"

register_tool(mcp, handler, spec)
assert handler.__name__ == "list_read_view_profiles"
assert handler.__doc__ == "List executable read-view profile metadata for agents."
mcp.tool.assert_called_once_with()
decorator.assert_called_once_with(handler)
print("isolated MCP declaration pilot smoke: PASS")
