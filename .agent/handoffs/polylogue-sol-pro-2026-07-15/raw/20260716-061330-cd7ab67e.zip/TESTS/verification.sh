#!/usr/bin/env bash
set -euo pipefail

HANDOFF_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO="${1:-.}"
REPO="$(cd "$REPO" && pwd)"
cd "$REPO"

required=(
  polylogue/declarations/models.py
  polylogue/declarations/registry.py
  polylogue/declarations/derive.py
  polylogue/declarations/validation.py
  polylogue/mcp/declarations/models.py
  polylogue/mcp/declarations/registry.py
  tests/unit/declarations/test_declaration_kernel.py
  tests/unit/mcp/test_declaration_pilot.py
)
for path in "${required[@]}"; do
  test -f "$path" || { echo "missing applied path: $path" >&2; exit 2; }
done

printf '\n== isolated pilot smoke (works even when optional services are absent) ==\n'
PYTHONPATH=. python "$HANDOFF_ROOT/TESTS/isolated_mcp_pilot_smoke.py"

printf '\n== generated topology surfaces ==\n'
devtools render topology-projection
devtools render topology-status
test -f docs/plans/topology-target.yaml
test -f docs/topology-status.md

printf '\n== focused declaration kernel ==\n'
devtools test tests/unit/declarations/test_declaration_kernel.py

printf '\n== real MCP declaration pilot ==\n'
devtools test tests/unit/mcp/test_declaration_pilot.py

printf '\n== existing MCP route contracts touched by the pilot ==\n'
devtools test tests/unit/mcp/test_tool_contracts.py::TestReadViewProfilesTool
devtools test tests/unit/mcp/test_server_surfaces.py::TestServerSurfaceRegistration

printf '\n== repository quick gate ==\n'
devtools verify --quick

printf '\n== patch hygiene ==\n'
git diff --check

printf '\nVerification completed. Review generated changes before committing:\n'
git status --short
