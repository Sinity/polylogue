# Test inventory and requirement trace

| Requirement | Test |
| --- | --- |
| No compatibility coercion | `test_models_reject_implicit_coercion` |
| All five mismatch dimensions named; reverse-order diagnostic determinism | `test_compatibility_diagnostic_names_every_differing_dimension_without_coercion` |
| Shuffled-order byte determinism | `test_shuffled_registration_has_byte_equivalent_normalized_derivation_inputs` |
| Six typed derivation categories and provenance | `test_derivation_inputs_cover_all_contract_categories_with_source_provenance` |
| Seven one-diagnostic completeness failures | `test_each_missing_completeness_part_emits_one_source_locatable_diagnostic` (seven parameters) |
| Actual callable missing | `test_declared_but_unbound_handler_fails_anti_vacuously` |
| Atomic deterministic batch behavior | `test_register_many_rolls_back_compatible_prefix_before_incompatible_member` |
| Duplicate semantics | `test_exact_duplicate_is_idempotent_but_changed_duplicate_is_rejected` |
| Shared dependency boundary | `test_kernel_has_no_domain_or_persistence_imports` |
| No copied MCP kernel | recursive MCP source scan inside `test_kernel_has_no_domain_or_persistence_imports` |
| MCP semantics remain MCP-owned | `test_mcp_pilot_consumes_shared_declaration_and_keeps_domain_semantics_local` |
| Real MCP registry derives shared projections | `test_mcp_pilot_registration_and_derivation_use_the_kernel` |
| Real declaration deletion is actionable | `test_removing_real_pilot_declaration_fails_with_exact_repair_command` |
| Real handler deletion fails before FastMCP | `test_removing_real_pilot_handler_fails_before_registration` |
| Declared binding deletion fails before FastMCP | `test_removing_declared_handler_binding_fails_before_registration` |
| Valid runtime semantics retained | `test_valid_pilot_handler_retains_mcp_registration_semantics` |
