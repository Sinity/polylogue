# Kernel contract

## Purpose and boundary

`polylogue/declarations` is a small authoring kernel for domain registries that
need to declare common structure once and derive several surfaces from it. It is
not a domain registry, runtime dispatcher, persistence layer, renderer, plugin
loader, migration mechanism, or global catalog.

The package imports only the Python standard library and itself. Domain packages
may wrap `DeclarationSpec`; the kernel never imports those wrappers.

## Typed model

| Type | Responsibility |
| --- | --- |
| `SourceLocation` | Repository-relative owner path plus optional line and symbol; used in every actionable diagnostic. |
| `AccessResultShape` | Opaque access and result identifiers forming one compatibility dimension. |
| `CompatibilityKey` | Exact identity, lifecycle, authority, access/result shape, and durability admission key. |
| `CompatibilityDifference` | One named mismatch, rendered in a fixed order. |
| `HandlerBinding` | Stable binding identifier and source location; deliberately not a callable. |
| `OutputSpec` | Schema or generated-output identity, path, media type, documentation fragment, and provenance. |
| `ExampleSpec` | Canonical request/response example and provenance. |
| `CompletenessEdge` | Source-locatable consumer contract. |
| `RepairCommandSet` | Exact repair instruction for each possible missing edge. |
| `DeclarationSpec` | One declaration's shared authoring structure. |
| `FamilySpec` | Immutable deterministic snapshot of compatible declarations. |

The shared fields are opaque strings and structured source records. Their
meaning belongs to the wrapping domain. For example, the kernel can compare the
MCP authority token `polylogue.mcp`; it does not know what MCP authority means.

## Exact compatibility law

A declaration may share `family_id` with an existing declaration only when all
five dimensions are exactly equal:

1. identity;
2. lifecycle;
3. authority;
4. access/result shape;
5. durability.

The implementation rejects implicit values at construction for the
compatibility fields and compares both exact runtime type and value. It does
not normalize case, aliases, enums, sequences, booleans, or numeric/string
representations. `CompatibilityKey.differences()` returns every mismatch in the
fixed order above, and the registration diagnostic includes each named
mismatch.

This is intentionally stricter than “compatible enough.” Coercion would allow
unrelated domain families to share generated artifacts, which is precisely the
drift this kernel exists to prevent.

## Registration law

`DeclarationRegistry` is a local process object owned by its caller. It has no
serialization, discovery, module scanning, singleton, or persistence behavior.

Registration is deterministic:

- input batches are sorted by family, declaration id, source location, and a
  deterministic full representation;
- an identical duplicate declaration is idempotent;
- a changed declaration with the same id is rejected;
- same-family registration requires an exact compatibility key;
- a failed batch rolls back its compatible prefix;
- `declarations()` and `families()` return sorted immutable tuples.

The rollback rule matters for shuffled-order proofs. A mixed batch cannot leave
an order-dependent partial registry after its first conflict.

## Derivation contract

`derive_inputs()` consumes family snapshots and returns `DerivationInputs` with
six typed projections:

- `NameDerivationInput`;
- `ContractDerivationInput`;
- `SchemaDocDerivationInput`;
- `ExampleDerivationInput`;
- `DiscoveryDerivationInput`;
- `CompletenessDerivationInput` and per-edge
  `CompletenessRequirementInput`.

Every item carries `SourceProvenance` containing family id, declaration id, and
owner source location. Nested schema, example, output, and consumer records also
retain their specific source locations.

The kernel exposes one protocol for each deriver class. It does not render or
write an artifact. Domain generators receive these typed inputs and remain free
to choose Markdown, JSON Schema, documentation, discovery text, or other output
formats.

`DerivationInputs.normalized_bytes()` emits canonical UTF-8 JSON with sorted
keys and compact separators. All declaration and nested collections are sorted
before projection. The tests register three declarations in every permutation
and require one unique byte sequence.

## Validation and diagnostics

`validate_declaration()` evaluates seven authored completeness requirements in
fixed order:

1. producer;
2. handler declaration and, when provided, actual callable;
3. role gate;
4. schema;
5. example;
6. generated output;
7. consumer edge.

Each missing requirement produces exactly one `Diagnostic` with:

- a stable code;
- declaration id;
- owner `SourceLocation`;
- human-readable message;
- exact repair command;
- deterministic details.

`missing_declaration_diagnostic()` covers an expected declaration that is
absent before validation can inspect it. `DeclarationValidationError` carries a
sorted diagnostic tuple and renders every repair command.

The callable check is opt-in through `bound_handler`. This preserves the
storage-free metadata model while letting a real runtime registration seam fail
before dispatch registration.
