# Evidence, alternatives, and residual work

## Sources read

The implementation was grounded in the supplied immutable snapshot and the
current public project record.

| Source | Use | Access |
| --- | --- | --- |
| Supplied `INSTRUCTIONS/AGENTS.md` / `CLAUDE.md` | Architecture, verification, generated-topology rule, no broad test runs | Snapshot, 2026-07-16 |
| Supplied `BEADS/selected.json` | Complete `polylogue-o21.1` description, design, notes, dependencies, and acceptance criteria | Snapshot, 2026-07-16 |
| Supplied `GIT/*` | Clean status, branch, base revisions, empty dirty-state patches | Snapshot, 2026-07-16 |
| Supplied MCP source/tests | Existing private pilot seam, role gating, real registration, discovery/contract tests | Snapshot, 2026-07-16 |
| `https://raw.githubusercontent.com/Sinity/polylogue/master/.beads/issues.jsonl` | Current `o21`, `o21.1`, `t46.8.1`, `1xc.14`, and `2qx.1.1` records; later notes and dependency context | 2026-07-16 |
| `https://github.com/Sinity/polylogue/commit/e0bc47279894ca0e2513b497388cbbf17e8d41bb` | Current-master identity and changed-path check | 2026-07-16 |

The selected Bead's later note is controlling: this slice is a derivation
protocol, not a universal registry or storage system, and MCP is the first real
pilot. The current `t46.8.1` record confirms the intended MCP package boundary
but its exhaustive tool inventory remains a separate body of work.

## Facts, inferences, and proposals

Source-supported facts:

- the supplied worktree was clean at
  `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`;
- the shared package must not import MCP, source, storage, insight, maintenance,
  or other domain registries;
- exact compatibility has five named dimensions;
- seven missing completeness categories require actionable diagnostics;
- MCP must retain verbs, roles, result semantics, and runtime registration;
- adding modules under `polylogue/` requires topology regeneration;
- the source pack omitted the checked-in topology files and full test runtime.

Implementation inference:

- `list_read_view_profiles` is the production pilot because it is the only
  supplied runtime tool already registered through a private typed spec/helper.
  This is a code-supported inference, not an explicit id-to-symbol mapping in
  the Bead text.

Proposal for follow-on work:

- migrate additional MCP declarations by semantic family only after the full
  `t46.8.1` model and existing inventory parity are agreed;
- make existing MCP generated surfaces consume `derive_inputs()` incrementally;
- use the same shared kernel for `OriginSpec` only after this pilot passes the
  complete repository gate.

## Rejected alternatives

### Universal runtime table

Rejected because the Bead explicitly forbids it and because domain runtimes
already have registration semantics. A global table would have to understand
MCP roles, source strictness, query behavior, and maintenance dispatch, turning
a small authoring kernel into a second application kernel.

### Persistence or plugin discovery

Rejected. Declarations are import-time source metadata. SQLite, file-backed
state, entry points, module scanning, or plugin loading would create lifecycle,
failure, and migration concerns outside this task.

### Callable fields in `DeclarationSpec`

Rejected. Callables are runtime/domain objects, are not canonically
serializable, and would make shuffled derivation depend on process identity.
The shared model stores `HandlerBinding`; the owning registration seam supplies
the actual callable to validation.

### Compatibility coercion

Rejected. Aliasing, lowercasing, enum conversion, bool/int equality, or
best-effort shape matching could merge incompatible families. The failure must
name all differences rather than silently choose one declaration's semantics.

### Rendering files from the kernel

Rejected. The contract is typed derivation inputs. Existing domain generators
own output formats and checked-in files. Keeping rendering out avoids a new
universal generator and makes derivation testable without filesystem state.

### Migrating all MCP tools in this series

Rejected as out of scope and high risk. The `t46.8.1` full inventory spans 103
tools, role matrices, examples, schemas, and generated docs. The selected Bead
asks for one production pilot, not a flag-day rewrite.

### Fabricating topology outputs from the partial tree

Rejected. Running the topology renderer over the selected source slice would
produce a false projection missing most of Polylogue. The full local checkout
must generate and review those files.

## Residual integration checklist

1. Apply the patch series to a clean current-master worktree.
2. Regenerate topology projection and status from the full tree.
3. Run the two new focused tests plus the existing read-view and server-surface
   contracts.
4. Run `devtools verify --quick` and inspect every generated-surface result.
5. Resolve only real current-master conflicts; do not alter compatibility or
   diagnostics merely to suppress a test.
6. Record Bead/PR state through the repository's normal `bd` workflow.
7. Before claiming `t46.8.1`, separately prove the exhaustive MCP inventory;
   this handoff does not make that claim.
