# MCP production pilot

## Why this seam

The supplied source already had one private declaration-like seam:
`_MCPReadToolSpec` for `list_read_view_profiles`, with a helper that assigned the
handler's public name and description before `FastMCP.tool()` registration. It
was the narrowest production route that could adopt the shared kernel without
rewriting the 103-tool MCP surface or changing runtime behavior.

The complete `polylogue-t46.8.1` Bead calls for an MCP-domain declaration
package and eventually a full tool inventory. `polylogue-o21.1` narrows that
work to a shared kernel and one real pilot. The patch therefore creates the
MCP package boundary now but migrates only the existing pilot.

## Ownership split

Shared fields live in `DeclarationSpec`:

- declaration and family identity;
- exact compatibility key;
- owner, producer, handler-binding, role-gate, schema, example, generated-output,
  and consumer provenance;
- name, contract, discovery text, and repair commands.

MCP-specific semantics live in `MCPReadToolSpec` under
`polylogue/mcp/declarations/models.py`:

- MCP verb;
- MCP object/ref kind;
- required MCP role;
- MCP result semantics;
- result model;
- MCP registration family;
- linked read view.

The concrete declaration lives in
`polylogue/mcp/declarations/registry.py`. The callable and FastMCP dispatch stay
in `polylogue/mcp/server_tools.py`.

No shared type contains `MCPRole`, MCP verbs, MCP result semantics, FastMCP
objects, or callables.

## Pilot data flow

```text
MCP_READ_TOOL_SPECS
        │
        ├── MCPReadToolSpec (MCP semantics)
        │       └── DeclarationSpec (shared structure)
        │
        ├── DeclarationRegistry (exact family admission)
        │       └── derive_inputs(...) for shared projections
        │
        └── require_mcp_read_tool_spec(...)
                └── server_tools._register_mcp_read_tool(...)
                        ├── validate_declaration(bound_handler=actual callable)
                        └── FastMCP.tool()(handler)
```

The server keeps compatibility aliases for the pre-existing private spec name
and dictionary because existing MCP tests import `_MCP_READ_TOOL_SPECS`. The
actual source registration call resolves the spec through
`require_mcp_read_tool_spec`, so deleting the registry row produces a
source-locatable `missing-declaration` diagnostic rather than a raw `KeyError`.

`_register_mcp_read_tool` passes the actual closure into shared validation. A
missing/non-callable value yields `missing-handler` before `__name__`,
`__doc__`, or FastMCP registration is touched.

## Declared pilot edges

`mcp.tool.list_read_view_profiles` declares:

- producer: the nested facade call in `register_read_tools`;
- handler: the nested `list_read_view_profiles` callable;
- role gate: `register_tools` read registration path;
- schema: `MCPRootPayload` with `read_views` and `total`;
- example: empty arguments with an empty catalog response;
- generated output: the exhaustive MCP tool index in `docs/mcp-reference.md`;
- consumer: `tests.infra.mcp.EXPECTED_TOOL_NAMES`.

Each edge has an exact command that points the local operator to the existing
focused test or renderer.

## Runtime invariance

The pilot does not change the tool's name, description, arguments, response,
role exposure, handler body, facade call, or registration order. The final
operation remains:

```python
handler.__name__ = spec.name
handler.__doc__ = spec.description
mcp.tool()(handler)
```

The only new runtime behavior is earlier failure with a typed diagnostic when
the declaration or callable is missing.

## Deliberately deferred MCP work

This patch does not inventory every MCP tool, derive the entire name set,
rewrite role matrices, consolidate result semantics across modules, or remove
all legacy MCP inventories. Those are the broader `t46.8.1` obligations and
should land by semantic family after parity tests. Expanding the pilot in this
kernel PR would make review anti-incremental and risk changing the runtime path.
