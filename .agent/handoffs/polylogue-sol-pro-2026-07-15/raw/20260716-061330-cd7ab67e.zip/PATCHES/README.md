# Patch series

Apply these patches in the exact order listed in `series`. They were generated
with `git format-patch` from an isolated Git import of the supplied snapshot.
The synthetic import commit is not part of the series.

Base content assumptions:

- supplied project revision: `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- supplied branch: `feature/browser/adopt-completion-monitors`
- supplied worktree: clean; staged and unstaged patch captures were empty
- captured `origin/master`: `934a12e69`
- GitHub `master` checked on 2026-07-16: `e0bc47279894ca0e2513b497388cbbf17e8d41bb`

The current-master transition was the squash of the supplied branch's browser
change and touched only browser modules. None of this series' declaration,
MCP, or test paths overlap that delta. Still use a clean worktree and `git am
-3` so Git can perform a three-way merge if master has moved again.

```bash
while IFS= read -r patch; do
  git am -3 "/path/to/handoff/PATCHES/$patch"
done < /path/to/handoff/PATCHES/series
```

Patch responsibilities:

1. `0001` creates the storage-free declaration models, deterministic registry,
   typed derivation inputs, and diagnostics.
2. `0002` adds compatibility, shuffled-order, derivation, completeness, and
   dependency-boundary tests.
3. `0003` makes multi-registration atomic and proves rollback on a mixed
   compatible/incompatible batch.
4. `0004` introduces the MCP-owned declaration wrapper and registry, pilots
   `list_read_view_profiles`, validates the actual callable before FastMCP
   registration, and adds anti-vacuous production-pilot tests.

Adding these Python packages requires regenerated topology artifacts on the
full checkout. Those generated files are intentionally not fabricated from the
partial source snapshot; run the commands in `TESTS/verification.sh` after
applying the series.
