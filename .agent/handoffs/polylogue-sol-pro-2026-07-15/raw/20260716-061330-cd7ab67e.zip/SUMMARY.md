# Executive result

The patch series implements a typed, storage-free `polylogue/declarations`
kernel and adopts it through one real MCP declaration. The implementation keeps
shared authoring structure centralized while preserving domain interpretation
and runtime behavior in the owning package.

The kernel provides:

- immutable typed declaration, family, output, handler, example, consumer-edge,
  source-location, repair-command, and compatibility models;
- exact five-dimensional family compatibility with no normalization or
  coercion;
- deterministic, atomic in-memory registration with stable family snapshots;
- typed derivation inputs for names, contracts, schema documentation, examples,
  discovery, and completeness, each carrying declaration/source provenance;
- canonical UTF-8 JSON bytes for shuffled-order determinism proofs;
- one actionable `Diagnostic` per missing producer, handler, role gate, schema,
  example, generated output, or consumer edge;
- a missing-declaration diagnostic and actual-callable validation at the MCP
  registration seam.

The production pilot moves the old private MCP spec shape into
`polylogue/mcp/declarations`, wraps a shared `DeclarationSpec`, and declares
`list_read_view_profiles`. MCP still owns the verb (`read`), object kind,
required role, result semantics, result model, registration family, handler,
and FastMCP dispatch. No other MCP tool is migrated in this slice.

## Acceptance-criteria matrix

| Criterion | Result | Evidence / remaining boundary |
| --- | --- | --- |
| 1. Typed storage-free APIs in `models.py`, `registry.py`, `derive.py`, and `validation.py`; no domain imports | Implemented | New package plus AST dependency test. Strict Pyright over the kernel and MCP declaration package reports 0 errors. Full repository mypy/ruff remain to run. |
| 2. Exact identity/lifecycle/authority/access-result/durability compatibility; all differences named; no coercion | Implemented | Runtime exact-type checks, fixed-order `CompatibilityKey.differences`, deterministic conflict diagnostic, reverse-order byte-equivalence test. |
| 3. Typed deterministic derivation for names/contracts/schema docs/examples/discovery/completeness plus provenance | Implemented | Six typed input families, deriver protocols, stable sorting, canonical normalized bytes, all-permutation test. |
| 4. One source-locatable diagnostic for every missing completeness edge; real missing declaration/handler fails | Implemented in code and focused proof | Seven parameterized missing-edge tests, missing-declaration helper, actual-callable validation, isolated production-pilot smoke. Full MCP pytest is blocked only by files omitted from the supplied slice. |
| 5. MCP pilot consumes kernel while MCP retains verbs/roles/results/dispatch/registration; no copied kernel | Implemented | Dedicated MCP wrapper/registry, server registration seam, semantic-field separation test, recursive AST no-copy test. Full 103-tool `t46.8.1` inventory is deliberately not attempted. |
| 6. Synthetic families, deterministic derivation, actionable diagnostics, pilot, and quick gate | Partially verified locally | 15 kernel tests pass; compile, strict Pyright, isolated MCP smoke, diff check, and clean four-patch `git am` all pass. `devtools verify --quick`, real MCP tests, and generated topology refresh require the complete checkout. |

## Concrete file changes

Shared kernel:

- `polylogue/declarations/__init__.py`
- `polylogue/declarations/models.py`
- `polylogue/declarations/registry.py`
- `polylogue/declarations/derive.py`
- `polylogue/declarations/validation.py`

MCP pilot:

- `polylogue/mcp/declarations/__init__.py`
- `polylogue/mcp/declarations/models.py`
- `polylogue/mcp/declarations/registry.py`
- `polylogue/mcp/server_tools.py`

Tests:

- `tests/unit/declarations/test_declaration_kernel.py`
- `tests/unit/mcp/test_declaration_pilot.py`

## Most important decisions

Compatibility is a hard admission law, not a merge heuristic. A declaration can
join a named family only when all five dimensions are exactly equal. The kernel
never lowercases, aliases, converts enums, casts values, or picks a “closest”
family. A failed batch rolls back completely.

The shared model contains handler metadata but never stores a callable. The
owning runtime passes the actual callable into validation immediately before
registration. This catches a declared-but-unbound handler without creating a
universal dispatch table.

Derivation returns typed, sorted inputs; it never writes files. Output rendering
and domain meaning stay with domain registries and existing generators.

## Genuine residual risks

The source pack is intentionally partial. It omits `tests/infra`, most Polylogue
packages, `pyproject.toml`, checked-in topology files, and the complete managed
environment. As a result, full MCP import/test execution, mypy, ruff, generated
surface refresh, and `devtools verify --quick` were not executable here.

The MCP pilot is one declaration, not the full `t46.8.1` inventory. That is the
correct scope for `o21.1`; subsequent MCP work should migrate tools in semantic
families and delete old parallel inventories only after parity proof.

Source locations use stable repository paths and symbols, with optional lines.
A future refactor that moves an owner must update the declaration and its exact
repair commands in the same change.
