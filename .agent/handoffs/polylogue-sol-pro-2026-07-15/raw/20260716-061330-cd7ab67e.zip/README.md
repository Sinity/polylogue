# Polylogue DeclarationSpec launch handoff

This handoff contains an ordered, reviewable implementation of
`polylogue-o21.1`, “Land the DeclarationSpec kernel and derivation contract.”
It builds one storage-free declaration kernel, proves deterministic derivation
and actionable completeness diagnostics, and uses the existing MCP read-tool
spec seam as the first production pilot without moving MCP semantics into the
shared package.

## Read and apply order

1. Read `SUMMARY.md` for the result and acceptance-criteria status.
2. Read `DESIGN/01-kernel-contract.md` and `DESIGN/02-mcp-pilot.md` for the
   architectural contract and domain boundary.
3. Read `DESIGN/03-evidence-alternatives-and-residuals.md` for source evidence,
   rejected alternatives, and unresolved integration work.
4. Read `PATCHES/README.md`, then apply the four patches in `PATCHES/series`.
5. Run `TESTS/verification.sh /path/to/polylogue` from a complete local checkout.
6. Review `VERIFICATION-LIMITS.md` before claiming the Bead complete.

## Clean application

The supplied archive represented a clean worktree at project revision
`76ee0d3842f12920ee71ad06f22b9cd8d2f88730`; both captured dirty-state patches
were empty. Do not apply over unrelated local edits. Create a branch or linked
worktree from current `master`, then apply with three-way fallback:

```bash
git switch master
git pull --ff-only
git switch -c feature/architecture/declaration-spec-kernel

HANDOFF=/absolute/path/to/polylogue-sol-pro-launch-handoff
while IFS= read -r patch; do
  git am -3 "$HANDOFF/PATCHES/$patch"
done < "$HANDOFF/PATCHES/series"
```

The series is based on the supplied content snapshot, not on a fabricated full
checkout. GitHub `master` was inspected on 2026-07-16 at
`e0bc47279894ca0e2513b497388cbbf17e8d41bb`; that commit changed only browser
files, so the declaration/MCP/test contexts did not overlap the master delta.
Re-check this assumption if master has advanced.

## Required post-apply integration

The repository instructions require topology regeneration whenever modules are
added below `polylogue/`. The context archive omitted the checked-in topology
inputs and most of the repository, so this handoff does not invent their
contents. On the full checkout run:

```bash
devtools render topology-projection
devtools render topology-status
git add docs/plans/topology-target.yaml docs/topology-status.md

TESTS=/absolute/path/to/polylogue-sol-pro-launch-handoff/TESTS
"$TESTS/verification.sh" "$PWD"
```

Inspect generated changes, then either fold them into the final feature commit
or add a conventional generated-surface commit according to the maintainer's
preferred review shape. Do not claim `devtools verify --quick` success until it
has run in the complete repository.

## Patch result at a glance

The shared package contains only typed metadata and pure deterministic logic:
no SQLite, persistence, plugin loading, callable dispatch, rendering, or domain
registry imports. The MCP package owns its verb, role, result semantics, object
kind, registration family, concrete handler, and FastMCP registration. The
shared declaration records only the cross-registry structure needed for exact
family compatibility, derivation, provenance, and completeness diagnostics.

The full handoff is self-contained: all source changes are in unified patches;
all reasoning, test evidence, commands, and verification boundaries are in this
archive.
