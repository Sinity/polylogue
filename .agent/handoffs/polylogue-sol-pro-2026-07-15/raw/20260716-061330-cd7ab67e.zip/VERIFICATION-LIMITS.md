# Verification limits

## Executed successfully

All successful commands were run against the isolated implementation tree and,
for patch application, against a fresh import of the supplied snapshot.

- `PYTHONPATH=. python -m pytest -q tests/unit/declarations/test_declaration_kernel.py`
  — 15 passed.
- `PYTHONPATH=. python TESTS/isolated_mcp_pilot_smoke.py` — passed using the
  actual MCP declaration package and AST-extracted production registration
  helper.
- `python -m compileall -q` over every changed Python source and test — passed.
- strict Pyright over `polylogue/declarations`,
  `polylogue/mcp/declarations`, and the kernel test — 0 errors, 0 warnings. A
  small `MCPRole` stub was used only because the supplied slice omits modules
  transitively imported by `server_support`; the production source was not
  replaced.
- `git diff --check` — passed.
- changed-file 120-column check — passed.
- four-patch `git am` against a fresh snapshot import — passed.
- changed-tree SHA-256 equivalence after patch application — passed.
- post-apply kernel test and isolated MCP smoke — passed.
- current-master history/path inspection through GitHub — performed on
  2026-07-16.

The implementation worktree was cleaned of generated `__pycache__` entries and
was clean at the final status check.

## Attempted but blocked by the supplied snapshot

`PYTHONPATH=. python -m pytest -q tests/unit/mcp/test_declaration_pilot.py`
failed during existing `tests/unit/mcp/conftest.py` import because
`tests.infra.mcp` is absent. The context archive contains a selected source
slice, not the full `tests/infra` package. The test body did not run in this
environment; its production path was exercised by the isolated smoke instead.

`PYTHONPATH=. python -m devtools verify --quick` failed while importing the
existing `devtools` command graph because source packages such as
`polylogue.bridges` are absent from the selected snapshot.

The topology render commands were not run. The required checked-in files
`docs/plans/topology-target.yaml` and `docs/topology-status.md`, the full source
graph, and the complete renderer context are absent. Running the renderer over
the partial tree would create misleading outputs.

## Not available in the container

- repository-managed mypy execution;
- repository-managed ruff execution;
- the full `pyproject.toml`/lockfile environment;
- NixOS deployment or service checks;
- live MCP daemon, browser, secrets, databases, or operator sessions;
- a full network clone of current master from the container shell.

Pyright is useful independent evidence but is not represented as a substitute
for the repository's strict mypy and ruff gates.

## Required before merge/Bead closure

A local agent with the complete checkout must:

1. apply the patches to a clean current-master branch;
2. regenerate topology projection and status;
3. run both new focused test files;
4. run the existing read-view tool and server-surface contract tests;
5. run `devtools verify --quick` in the managed environment;
6. inspect generated documentation/topology changes;
7. resolve any master drift and rerun all checks;
8. update Bead/PR state through normal project tooling.

No claim is made that a live browser, daemon, database, deployment, full MCP
surface, mypy, ruff, topology generation, or repository quick gate passed here.
