# Executive summary

This patch series repairs Polylogue's query curriculum at its executable source. The parser already distinguished session selection from terminal unit relations, but the product's own prompts taught two sessions-only `query_units` forms that the parser rejected. The change extends the existing `QueryUnitDescriptor` architecture into the smallest declaration kernel that can drive parser aliases, field semantics, operations, structured plans, generated prompt recipes, MCP descriptions and schemas, completions, a bounded searchable capability-and-coverage resource, compact result projections, exactness/continuation metadata, recovery guidance, docs, and parity checks.

The implementation contains 2,531 insertions and 125 deletions across 14 project files, packaged as three ordered commits. It does not add a parallel query engine. DSL strings and typed structured plans lower into the same Lark-owned terminal query pipeline. Shipped recipes render executable DSL from the same declarations, and tests compile every generated terminal example, every recipe expression, every structured-plan example, and the installed-skill expression census.

The production regression is corrected as follows:

```text
Invalid curriculum:
  sessions where repo:polylogue since:7d AND exists action(output:failed)
  sessions where repo:polylogue AND exists file(action:file_edit AND path:...)

Executable terminal forms:
  actions where session.repo:polylogue AND session.since:7d AND (is_error:true OR exit_code > 0)
  files where session.repo:polylogue AND action:file_edit AND path:"..."
```

For malformed sessions-only calls, generated recovery now offers both a session-search form and a parser-valid terminal relation. It also repairs the historical implicit conjunction spelling and maps the two stale `exists action(...)` / `exists file(...)` patterns to executable pipeline suggestions.

Result envelopes now state what a page means. `total` remains a compatibility alias for returned page rows, while `returned_count`, `match_count`, `match_count_is_exact`, `page_is_exhaustive`, `continuation_required`, `continuation_kind`, `next_offset`, `projection_fields`, and `omitted_fields` prevent an agent from mistaking a bounded page for the entire evidence relation.

The bounded catalog contains 420 unique declarations in this snapshot: 9 units, 396 field/projection entries, 6 operations, and 9 recipes. Search indexes declared public values rather than internal JSON key names, so a sparse query such as `model orchestration` returns the delegation-routing recipe instead of matching implementation metadata everywhere. Static declaration authority is kept separate from optional live coverage observations; telemetry is explicitly non-authoritative.

## Acceptance-criteria matrix

| # | Criterion | Result | Evidence and boundary |
|---|---|---|---|
| 1 | One registry generates schemas/descriptions, catalog, typed plans, completions/help/docs, projections, errors, and recipes. | **Implemented in the supplied slice; OpenAPI generator integration remains outside the snapshot.** | `metadata.py` owns units, fields, operations, recipes, result contracts, recovery, descriptions, catalog, and generated markdown. `query_contracts.py`, completions, MCP tools/resources/prompts, payloads, and docs project from it. No OpenAPI-generation module was supplied, so no direct OpenAPI emitter was patched. |
| 2 | Fields declare meaning, authority, origins/artifacts, coverage/freshness, projection, pushdown/cardinality/cost, order, examples, and closed live statuses. | **Implemented with a deliberate coverage limitation.** | Declarations carry the requested semantics and the catalog exposes six closed coverage states. Cheap live probes currently observe session/message counts only; other facts remain `unknown` rather than guessed. `applicable_origins` is registry data but is not yet joined to the absent OriginSpec implementation. |
| 3 | Six cookbook prompts are generated/tested; installed skill is derived or parity-checked. | **Implemented for prompts and census parity; direct installed-skill regeneration remains.** | All six MCP prompt recipes render from `QUERY_INTENT_RECIPES`; embedded expressions compile. The two installed-skill regressions are captured in a parity fixture. The actual installed shared-skill source was not present in the immutable snapshot, so direct regeneration of that external file was not possible. |
| 4 | Cold discovery supports continuity, evidence, orchestration, and paging flows without guessing. | **Contract implemented; live cold-model evaluation not run.** | Seed recipes cover resume, postmortem, decision, failure, file touch, cost, delegation/model/orchestration, material authorship, and paging. Catalog entries state authority, coverage, omissions, selective predicates, and next strategy. No live MCP client/model evaluation was available. |
| 5 | DSL, structured plan, and recipes lower to one plan and yield equivalent output semantics. | **AST parity implemented; database-row parity awaits full archive tests.** | Structured plans render canonical DSL and tests compare typed pipeline payloads. Every recipe expression uses the same parser. The partial snapshot had no runnable archive stack, so identical live refs/rows/totals across forms remain for full-repository verification. |
| 6 | Explain/catalog exposes estimates, narrowing, joins/cost/freshness, and non-rejecting large-query strategies. | **Implemented without duplicating the transaction worker.** | Catalog coverage reports observed/estimated rows, pushdown, cardinality, cost, plan shape, selective predicates, stable order, result semantics, and next strategy. Large valid relations advertise page/NDJSON/spool and queued execution when a runtime executor exists; cost never marks semantics unsupported. |
| 7 | Declaration mutations update surfaces; missing mappings fail actionable checks. | **Implemented with mutation-sensitive tests.** | Tests lock parser aliases/examples, prompt/skill expressions, plan schema, catalog bounds/search, coverage states, payload projections/omissions, executor registration, generated docs, resource registration, recovery, completions, and exactness. Full pytest collection was blocked by packages omitted from the snapshot. |
| 8 | Public descriptions avoid internal-only types; catalog is bounded/paged; telemetry is not authority. | **Implemented.** | Session tool descriptions no longer teach hidden request class names. Catalog pages clamp to 50, expose continuations, omit payload-class names, search public values, and declare `telemetry_is_authority: false`. |

## Patch series

1. `0001-feat-query-declare-executable-agent-discovery-regist.patch` establishes the registry kernel, structured-plan union, generated descriptions/schema, and recipe completions.
2. `0002-feat-mcp-project-query-discovery-and-exact-page-cont.patch` projects the registry through MCP prompts/resources/tools, docs, executors, and exact result envelopes.
3. `0003-test-query-enforce-agent-curriculum-and-discovery-pa.patch` adds the installed-skill census and mutation-sensitive parser/catalog/schema/prompt/projection checks.

## Verification result

The ordered patches were applied with `git am` to a fresh clone of the synthetic snapshot base. All three applied, the resulting tree hash exactly matched the implementation tree (`8f62c4fdeab87d4edd69ae8d06c68daa5b2e0725`), and `git diff --check` passed.

`TESTS/verify_snapshot.py` passed against both the implementation tree and the fresh patch-applied clone. It exercised 9 terminal units, 9 terminal examples, 9 structured examples, 9 recipes, 7 recipe expressions, 6 MCP prompt recipes, 4 embedded prompt query expressions, 6 executable recipe completions, 3 registered query resources, 420 catalog entries, 3 recovery incidents, both executor actions, compact projections, generated docs, and 3 exactness cases.

Eleven changed Python files compiled successfully. The implemented worktree was clean after verification. A direct pytest invocation reached collection but could not import `polylogue.operations`, which is absent from the supplied narrow snapshot; this is recorded as an environment boundary, not counted as a passing suite.

## Residual risks

The largest integration risk is full-checkout drift around modules omitted from the pack: OriginSpec, OpenAPI/schema generation, the installed shared skill source, full FastMCP registration, archive storage types, and current generated-reference gates. The patch series is designed around existing public seams, but those integrations require repository-native tests.

Live coverage probes are intentionally sparse. They report only cheap archive stats rather than scanning every relation. This prevents discovery from becoming an expensive hidden query, but a later integration should add authoritative low-cost observations as their owning registries expose them.

Offset pages are described as stable because current terminal executors use declared stable ordering. Concurrent archive mutation can still change membership between calls unless the separate transaction worker supplies a snapshot/cursor contract. This slice does not claim transaction-level snapshot isolation.
