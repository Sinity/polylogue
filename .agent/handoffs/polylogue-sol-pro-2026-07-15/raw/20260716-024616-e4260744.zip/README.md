# Polylogue agent-query discovery P0 handoff

This handoff contains a reviewable three-patch implementation for `polylogue-z9gh.3`: make the agent-facing query language derive its teaching, schemas, catalog, examples, projections, and recovery from executable declarations. It fixes the active contradiction where Polylogue prompts and installed-skill curriculum taught sessions-only `query_units` expressions even though the parser requires a terminal unit relation.

## Read order

1. Read `SUMMARY.md` for the result and acceptance-criteria matrix.
2. Read `DESIGN/registry-kernel.md` for the declaration and projection model.
3. Read `DESIGN/installed-skill-parity.md` for the exact regression and remaining skill-integration boundary.
4. Read `DESIGN/rejected-alternatives.md` and `DESIGN/research-notes.md` for decisions and protocol grounding.
5. Apply the patches in `PATCHES/series` order.
6. Run `TESTS/verify_snapshot.py`, then the full-repository test commands in `TESTS/verification-report.md`.
7. Read `VERIFICATION-LIMITS.md` before making a merge claim.

## Snapshot and base assumptions

The immutable context pack was captured from Polylogue revision:

```text
518ac33e318995539743e220c01b9883b7a688a0
branch: feature/browser/sol-pro-dispatch
```

The supplied worktree already had one staged operator change:

```text
M  .beads/issues.jsonl
```

This handoff does not modify `.beads/issues.jsonl`. Apply the series in a separate clean worktree so `git am` does not collide with that staged state.

The context pack did not include its original `.git` directory. A local synthetic baseline commit, `0f57214b0a6aa047456f800a737b7e5f15cec0c8`, was created solely to produce and verify the format-patch series. It represents the files supplied at real project revision `518ac33e...`; it is not a Polylogue history commit and must not be pushed.

## Apply order

From a full Polylogue clone with revision `518ac33e...` available:

```bash
git worktree add ../polylogue-z9gh3 518ac33e318995539743e220c01b9883b7a688a0
cd ../polylogue-z9gh3
git switch -c feat/query-agent-discovery

while IFS= read -r patch; do
  test -z "$patch" || git am "/path/to/handoff/PATCHES/$patch"
done < /path/to/handoff/PATCHES/series
```

The intended commits are:

```text
feat(query): declare executable agent discovery registry
feat(mcp): project query discovery and exact page contracts
test(query): enforce agent curriculum and discovery parity
```

The patches are scoped to the supplied snapshot. No new module was added under `polylogue/`, so this slice does not independently trigger the repository topology-projection regeneration rule.

## Verification order

The snapshot-level executable check is dependency-light and exercises the real changed parser and declarations with narrow shims for packages omitted from the context pack:

```bash
PYTHONDONTWRITEBYTECODE=1 \
  python TESTS/verify_snapshot.py /path/to/polylogue-z9gh3
```

A safe patch-application rehearsal that creates a disposable worktree is also included:

```bash
TESTS/apply-and-verify.sh /path/to/full/polylogue/clone
```

Then run the repository-native gates from the full development environment:

```bash
devtools test tests/unit/mcp/test_agent_query_discovery.py
devtools test tests/unit/mcp/test_query_tool_schema_derivation.py
devtools test tests/unit/archive -k 'query_unit or expression'
devtools verify
```

Because MCP descriptions and schemas changed, also run the full MCP contract/schema surfaces and any generated-reference checks required by the current branch. No database migration is involved.

## What the series deliberately does not do

It does not implement the generic bounded/resumable query transaction worker. It advertises present offset paging, CLI NDJSON/file spooling, and runtime-advertised queued execution without inventing a second transaction engine. It also does not claim that cost classification is permission to reject semantically valid large queries.
