# Declare-once query discovery kernel

## Problem statement

Polylogue had several partial sources of query truth: the Lark grammar, expression field registries, structural unit descriptors, terminal executors, MCP signatures, prompt prose, completions, result payloads, and docs. The production failure arose because those sources could disagree. Two product-owned recipes instructed a model to call `query_units` with `sessions where ...` as the terminal result even though `parse_unit_source_expression` only accepts sessions as an optional scope stage before a terminal unit.

The repair must make instructional text executable by construction, not merely correct two strings.

## Chosen integration seam

`QueryUnitDescriptor` was already consumed by parser/execution code and was therefore the correct declaration seam. The patch extends that model rather than creating a second registry package. The declaration layer remains stdlib-only so parser import cost and dependency direction do not worsen.

The declaration graph is:

```text
QueryUnitDescriptor
  ├─ source aliases and terminal support ───────────────> Lark parser
  ├─ fields / operators / closed values ───────────────> parser + schema + completions
  ├─ SQL/runtime lowerer and executor action ───────────> terminal executor parity
  ├─ fact authority / origin / artifact / freshness ───> capability catalog
  ├─ projection_fields / omitted_fields ────────────────> result envelopes
  ├─ pushdown / cardinality / cost / stable order ──────> explain/catalog strategy
  └─ examples / recovery guidance ──────────────────────> descriptions + docs + errors

QueryOperationDescriptor
  ├─ supported/unsupported semantics
  ├─ result contract
  └─ executor action / large-result strategy

QueryIntentRecipe
  ├─ bindings and intent tags
  ├─ generated MCP prompt text
  ├─ executable DSL examples
  └─ completion/catalog entries
```

## Canonical language path

`query_units.expression` remains one required input property. Its schema is a union of:

1. a canonical DSL string; or
2. a closed `MCPQueryUnitStructuredPlan` object.

The structured object validates its terminal source and pipeline shape, then renders canonical DSL. The real Lark parser parses that output. There is no separate plan evaluator and no semantics hidden in Pydantic-only code.

Example:

```json
{
  "source": "action",
  "where": "is_error:true OR exit_code > 0",
  "session_where": "repo:polylogue AND since:7d",
  "group_by": ["tool"],
  "aggregate": "count",
  "sort_by": "count",
  "sort_direction": "desc",
  "limit": 20,
  "offset": 40
}
```

lowers to:

```text
sessions where repo:polylogue AND since:7d | actions where is_error:true OR exit_code > 0 | group by tool | count | sort by count desc | limit 20 | offset 40
```

Tests compare the parsed pipeline payload of the rendered plan with the same DSL supplied directly.

## Sessions are scope, not a terminal unit

The registry explicitly declares a supported session-scope operation and an unsupported sessions-terminal-rows operation. This distinction is discoverable rather than implicit.

Valid forms are:

```text
<terminal-source> where <unit-predicate> [| stages]
sessions where <session-predicate> | <terminal-source> where <unit-predicate> [| stages]
```

Session rows remain available through `search` / `list_sessions`. `query_units` returns terminal unit rows or aggregates.

## Recovery contract

For a sessions-only expression, recovery returns structured data containing:

- why the expression is invalid;
- valid terminal sources and forms;
- a session-search alternative;
- a parser-valid terminal relation;
- the discovery resource URI.

The historical curriculum spellings receive targeted structural repair:

```text
sessions where repo:polylogue since:7d AND exists action(output:failed)
```

becomes a valid session search plus an action relation scoped to the same sessions. The unsupported lexical `output:failed` condition is replaced with structural action failure evidence: `is_error:true OR exit_code > 0`.

Likewise, `exists file(...)` is converted to a terminal files pipeline. Every generated `query_units` recovery suggestion is parser-compiled by tests.

## Capability and coverage catalog

The MCP resources are:

```text
polylogue://capabilities/query
polylogue://capabilities/query/{kind}/{offset}/{limit}
polylogue://capabilities/query/search/{term}/{offset}/{limit}
```

Kinds are `unit`, `field`, `operation`, and `recipe`. Pages clamp to 50 entries. The current declaration census is 420 unique entries.

The catalog separates static truth from live observation:

```text
static executable declaration = authority
live observation = availability/freshness signal
```

Coverage states are closed:

```text
supported-and-observed
supported-but-absent
supported-but-stale
degraded
unsupported
unknown
```

Absence is never inferred from a failed probe. In the current low-cost resource path, archive stats provide session/message observations; other facts stay unknown until a cheap authoritative probe exists.

Search indexes public declaration values, not internal dictionary key names. This prevents terms such as `model` or `cost` from matching every entry simply because each payload contains a `cost_class` key.

## Fact selection versus compact projection

A field can be:

- filterable and projected;
- filterable but explicitly omitted from compact rows;
- projection-only with an authoritative hydration route;
- unsupported.

These states must not be conflated. For example, `material_origin` is exposed as a meaningful compact/evidence dimension without falsely claiming a terminal predicate that the parser does not execute. Session-scoped `repo`, tags, cwd, and time constrain terminal rows but are explicitly omitted unless the row model actually carries them. Only session identity/origin/title map directly to existing row fields.

Tests require every declared field to have exactly one compact outcome: a projection mapping or an omission entry.

## Result semantics and continuation

Terminal row pages declare `exhaustive-relation-page`; grouped counts declare `aggregate-summary-page`. The envelope fields are:

```text
returned_count          exact rows in this page
total                   compatibility alias for returned_count
page_count_is_exact     always true
match_count             whole-relation count only when proven
match_count_is_exact    guards match_count
page_is_exhaustive      true only for a complete first page
continuation_required   whether another page must be fetched
continuation_kind       offset or none
next_offset             next request offset
projection_fields       fields carried by compact rows
omitted_fields          declared dimensions not carried by compact rows
```

A final nonempty page at offset `n` proves `match_count = n + returned_count`. An empty page after a nonzero offset does not prove the whole relation count and therefore leaves it unknown.

## Large valid queries

Cost classes are planner guidance, not semantic permissions. A declaration may identify a bounded scan, join, or derived relation and recommend selective predicates, but it does not mark a valid query unsupported merely for size.

The result contract teaches:

1. follow the returned offset continuation;
2. use CLI NDJSON streaming or file spooling for bulk export;
3. use queued execution when the runtime advertises the separate transaction executor.

This preserves the boundary with the other worker implementing generic resumable transactions.

## Surface projection

The registry now projects into:

- parser source aliases and field declarations;
- terminal operation/executor parity;
- `query_units` DSL-or-plan JSON Schema;
- generated `query_units`, `search`, `list_sessions`, and `facets` descriptions;
- six MCP prompt recipes;
- recipe completions;
- bounded MCP capability resources;
- compact result envelopes;
- generated MCP reference documentation;
- structured recovery errors;
- installed-skill expression census tests.

The implementation intentionally keeps legacy-compatible function signatures and the `total` field while making their semantics explicit.
