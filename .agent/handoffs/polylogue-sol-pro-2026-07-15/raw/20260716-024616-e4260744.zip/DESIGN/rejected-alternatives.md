# Rejected alternatives

## Fix only the two prompt strings

Rejected because the same contradiction could reappear in the installed skill, docs, completions, schemas, or a new prompt. The defect was multiple sources of truth. The repair makes prompt text and examples projections of executable declarations and compiles them in tests.

## Create a new discovery registry beside `QueryUnitDescriptor`

Rejected because it would require parity glue between two registries and recreate the exact drift class being repaired. The existing descriptor already participates in parsing and execution; extending it produces a smaller kernel and mutation-sensitive ownership boundary.

## Make `sessions` a terminal `query_units` source

Rejected for this slice because current execution and payload contracts return terminal unit rows, while session rows already have dedicated search/list surfaces. Silently changing `query_units` semantics would be broader and could break callers. Discovery instead states that sessions are a scope stage and gives the executable alternatives.

## Add a second structured-plan evaluator

Rejected because a Pydantic object and DSL could diverge. The structured plan validates shape, renders canonical DSL, and enters the same Lark parser and execution path.

## Put the entire query language in the tool description

Rejected because it would make every tool listing large, stale, and hard to search. Tool descriptions now contain a compact executable orientation and point to bounded URI resources. Detailed units, fields, operations, coverage, and recipes are paged/searchable.

## Treat cost or large cardinality as unsupported semantics

Rejected by the bead correction and product requirement. Cost is planning metadata. Valid large relations remain executable through paging, stream/NDJSON, spool, and a queued executor when the runtime supplies one.

## Implement the generic query transaction here

Rejected because another worker owns the bounded/resumable transaction design. This slice declares continuation and strategy contracts without adding a competing queue, cursor store, progress engine, or snapshot transaction abstraction.

## Infer support from telemetry

Rejected because an empty or failed probe does not change executable semantics. Static declarations are authority. Coverage observations report presence, age, degradation, or unknown status only, and the catalog explicitly states that telemetry is not authority.

## Probe every relation while listing capabilities

Rejected because discovery must itself stay bounded and cheap. The resource currently joins only low-cost archive statistics. Additional observations should arrive through owning registries or materialized counters, not hidden scans.

## Expose internal payload model names as public discovery

Rejected because class names are implementation details and produce noisy search matches. Catalog projection lists public fields and semantics instead. Tests reject `Payload` leakage and implementation-key search noise.

## Claim `material_origin` as a terminal filter before parser support exists

Rejected because it would make the catalog lie. The declaration exposes the fact, compact projection/hydration route, and authority while marking predicate support accurately. Future parser support can flip the executable declaration and automatically update projected surfaces.

## Assume every session-scope predicate appears in terminal rows

Rejected after projection audit. A terminal query may be scoped by repo, tag, cwd, or time without the compact child row carrying those dimensions. The registry now distinguishes queryability from projection and reports omissions explicitly.

## Make `total` silently mean the whole relation

Rejected because the executor fetches bounded pages and historically used `total` as page length. The additive exactness fields preserve compatibility while preventing agents from interpreting a page count as exhaustive evidence.
