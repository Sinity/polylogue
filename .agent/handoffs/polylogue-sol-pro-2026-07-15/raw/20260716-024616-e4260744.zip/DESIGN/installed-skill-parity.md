# Installed-skill curriculum parity

## Incident

The bead's later notes supersede the earlier interpretation that the model merely failed to discover hidden grammar. Polylogue itself taught invalid terminal forms in two places: MCP cookbook prompts and the installed shared skill. The parser correctly rejected those forms because `sessions` is not a terminal `query_units` source.

Exact regression fixtures:

```text
sessions where repo:polylogue since:7d AND exists action(output:failed)
sessions where repo:polylogue AND exists file(action:file_edit AND path:polylogue/mcp/server_prompts.py)
```

## Registry-owned replacements

Failure evidence:

```text
actions where session.repo:polylogue AND session.since:7d AND (is_error:true OR exit_code > 0)
```

File-touch evidence:

```text
files where session.repo:polylogue AND action:file_edit AND path:"polylogue/mcp/server_prompts.py"
files where session.repo:polylogue AND path:"polylogue/mcp/server_prompts.py"
```

These are recipe templates, not hand-maintained prompt fragments. MCP prompts render them from `QUERY_INTENT_RECIPES`, recipe completions use the same declarations, and parser tests compile the rendered expressions.

## What is verified in this snapshot

`tests/fixtures/query/installed_skill_query_expressions.json` is a source census for the two installed-skill intents. The parity test asserts that registry output exactly equals the census and compiles each expression. It also asserts that both stale forms remain rejected and do not occur in generated prompt/docs curriculum.

Generated recovery for each stale form includes a parser-valid `query_units` expression. That makes a cold call recoverable even when an old client or cached skill still submits the former syntax.

## Boundary

The immutable repository cut did not contain the actual installed shared Polylogue skill file or its installer/generator. Therefore this patch cannot rewrite or regenerate that external installed artifact directly. The census fixture prevents silent drift in this snapshot, but the integrating checkout must locate the owning skill source and replace its handwritten block with either:

1. direct generation from the same registry export; or
2. a repository test that extracts the installed skill expressions and compares them with `QUERY_INTENT_RECIPES`, eliminating the fixture as an intermediary.

Until that integration is completed, an already-installed stale skill may continue to emit the old form. Server-side recovery prevents a dead end, while the new MCP prompt source no longer teaches it.
