# MCP protocol research notes

Accessed 2026-07-15. Primary/official sources only.

## Sources

1. MCP tools specification, 2025-11-25:  
   https://modelcontextprotocol.io/specification/2025-11-25/server/tools

2. MCP resources specification, 2025-06-18:  
   https://modelcontextprotocol.io/specification/2025-06-18/server/resources

3. MCP pagination utility, 2025-06-18:  
   https://modelcontextprotocol.io/specification/2025-06-18/server/utilities/pagination

4. SEP-2106, JSON Schema 2020-12 support:  
   https://modelcontextprotocol.io/seps/2106-json-schema-2020-12

5. SEP-1613, JSON Schema 2020-12 default dialect:  
   https://modelcontextprotocol.io/seps/1613-establish-json-schema-2020-12-as-default-dialect-f

6. Official MCP Python SDK:  
   https://github.com/modelcontextprotocol/python-sdk

## Decisions translated into the patch

MCP tools expose descriptions and input schemas, so the `query_units` description and its DSL-or-structured-plan schema are generated from the executable declarations rather than maintained as prose beside the implementation.

MCP resources are URI-addressed application context. The detailed query catalog is therefore published as bounded resources and resource templates instead of expanding every tool description into a complete grammar manual.

MCP pagination establishes a continuation-oriented pattern. The catalog resource has explicit offset/limit pages and `next_offset`; query result contracts separately state whether pages are exhaustive, ranked, sampled, or aggregated.

JSON Schema 2020-12 supports composition keywords used for the string-or-structured-plan input. The schema is closed for the structured object (`additionalProperties: false`) and preserves terminal-source enums. This keeps backward-compatible DSL strings while making a discoverable typed form available.

The current MCP server serializes many tool results as JSON strings. This slice therefore puts result exactness and continuation semantics into the public payload models and catalog rather than claiming an MCP `outputSchema` migration that would require a wider server return-type change.
