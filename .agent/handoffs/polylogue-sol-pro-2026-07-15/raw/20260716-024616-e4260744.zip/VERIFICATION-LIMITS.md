# Verification limits

## What was run

- Read the supplied repository instructions and the complete selected `polylogue-z9gh.3` Beads record, including later notes that supersede the original description.
- Inspected the real Lark parser, query metadata, terminal execution, payload models, MCP tools/prompts/resources, docs, and existing schema tests in the immutable snapshot.
- Applied all three patches with `git am` to a fresh synthetic-base clone.
- Confirmed three commits applied in order and the resulting synthetic tree hash exactly matched the implementation tree.
- Ran `git diff --check` successfully.
- Compiled all 11 changed Python files successfully.
- Ran the standalone snapshot verifier on both the implementation tree and the patch-applied clone.
- Exercised the real Lark parser over all terminal examples, all recipe expressions, all structured-plan examples, and all generated terminal recovery suggestions.
- Validated DSL/structured-plan pipeline AST equality for an aggregate query.
- Validated the closed string-or-plan JSON Schema and terminal-source enums.
- Enumerated all 420 catalog entries and checked bounds, unique IDs, search relevance, internal-type leakage, and telemetry authority.
- Validated compact projection/omission coverage against actual Pydantic row models.
- Validated exactness/continuation behavior for a partial first page, final nonempty page, and empty nonzero-offset page.
- Verified the generated MCP reference block matches registry output.
- Attempted the focused project pytest file and recorded the collection boundary.

## What was not available or not run

- The operator's live daemon, browser, MCP client, archive databases, secrets, or NixOS deployment.
- A complete Polylogue checkout and its full package/dependency graph.
- `devtools test`, `devtools verify`, `nix flake check`, or full generated-reference/OpenAPI checks.
- Real FastMCP tool listing/schema serialization, because the `mcp` dependency and multiple project packages were absent from the source cut.
- Live archive execution comparing DSL and structured-plan rows/refs/totals.
- Multi-page behavior under concurrent archive mutation or a transaction snapshot.
- The actual installed shared Polylogue skill source/installer, which was not included in the snapshot.
- Direct OriginSpec integration, because its owning implementation was absent.
- Cold-model usability evaluation against the new discovery resources.
- Performance measurement of catalog resources or large query execution.

## Claims this handoff does not make

- It does not claim the full Polylogue test suite passes.
- It does not claim the patches have been exercised against the operator's live archive or daemon.
- It does not claim the external installed skill has already been rewritten.
- It does not claim transaction-level snapshot consistency for offset paging.
- It does not claim generic queued/resumable query execution was implemented; that work is intentionally left to the separate worker.
- It does not treat the pytest collection error as product test success.

## Integration risks to resolve before merge

1. Apply the series to a clean full checkout at or rebased from `518ac33e...`; resolve only genuine upstream drift, not by reintroducing duplicated metadata.
2. Run repository-native MCP schema/tool registry tests to confirm Pydantic/FastMCP emits the intended union schema through the installed SDK version.
3. Wire the real installed-skill source to registry generation or direct parity extraction.
4. Join OriginSpec coverage once the owning registry is available rather than preserving wildcard origin applicability indefinitely.
5. Run live archive parity for DSL and structured plan, including aggregate and multi-page results.
6. Confirm generated OpenAPI/reference surfaces consume the new schema and descriptions.
7. Coordinate any snapshot/cursor language changes with the separate bounded/resumable query transaction worker.
