# Verification report

## Environment

```text
Date: 2026-07-15
Python: 3.13.5
Pydantic: 2.13.4
Supplied real revision: 518ac33e318995539743e220c01b9883b7a688a0
Synthetic snapshot base: 0f57214b0a6aa047456f800a737b7e5f15cec0c8
Implementation commits: e53a1dd, fee7fec, cb7625e
Expected implementation tree: 8f62c4fdeab87d4edd69ae8d06c68daa5b2e0725
```

The context pack is a narrow source cut. It does not contain the original `.git`, complete Polylogue package graph, development shell, archive databases, daemon, browser, secrets, or Nix deployment.

## Patch application

Executed against a fresh clone of the synthetic baseline:

```bash
git checkout 0f57214
git switch -c verify-handoff
git config user.name 'Patch Verification'
git config user.email 'verify@example.invalid'
while IFS= read -r patch; do
  test -z "$patch" || git am "PATCHES/$patch"
done < PATCHES/series
git diff --check 0f57214..HEAD
```

Result:

```text
Applying: feat(query): declare executable agent discovery registry
Applying: feat(mcp): project query discovery and exact page contracts
Applying: test(query): enforce agent curriculum and discovery parity
PATCH_APPLY_PASS
expected_tree=8f62c4fdeab87d4edd69ae8d06c68daa5b2e0725
actual_tree=8f62c4fdeab87d4edd69ae8d06c68daa5b2e0725
commits=3
```

## Standalone snapshot verifier

Executed on both the implementation tree and the clean patch-applied clone:

```bash
PYTHONDONTWRITEBYTECODE=1 python TESTS/verify_snapshot.py /path/to/repo
```

Both runs returned:

```json
{
  "catalog_kinds": ["field", "operation", "recipe", "unit"],
  "catalog_total": 420,
  "embedded_prompt_expressions": 4,
  "executable_recipe_completions": 6,
  "executor_actions": ["count", "rows"],
  "mcp_prompts": 6,
  "recipe_expressions": 7,
  "recipes": 9,
  "recovery_cases": 3,
  "recovery_terminal_suggestions": 3,
  "registered_query_resources": 3,
  "registered_recipe_prompts": 6,
  "result_exactness_cases": 3,
  "status": "pass",
  "structured_examples": 9,
  "terminal_examples": 9,
  "terminal_units": 9
}
```

The verifier imports the real changed `expression.py`, `metadata.py`, `query_contracts.py`, `payloads.py`, and `completions.py`. It supplies narrow type shims only for dependencies omitted from the immutable pack. It verifies parser compilation, recipe/prompt/skill census parity, structured-plan AST parity, closed schema, coverage state classification, bounded catalog search, projection/omission completeness, executor registration, result exactness, recovery, completions, generated docs, and the actual registration/behavior of three query resources and six recipe prompt handlers under snapshot shims.

## Python syntax and whitespace

Executed:

```bash
python -m py_compile <all 11 changed Python files>
git diff --check 0f57214..cb7625e
git status --short
```

Result:

```text
PYTHON_FILES=11
DIFF_CHECK_PASS
WORKTREE_CLEAN
```

Generated `__pycache__` directories were removed before the clean-status check.

## Repository pytest attempt

Executed:

```bash
PYTHONPATH=. PYTHONDONTWRITEBYTECODE=1 \
  pytest -q tests/unit/mcp/test_agent_query_discovery.py
```

Result: pytest exited 2 during collection because the immutable source cut omits an existing project package:

```text
ModuleNotFoundError: No module named 'polylogue.operations'
```

The failure occurred while importing `polylogue.archive.query.completions`, before tests ran. It does not establish a passing or failing full suite. The standalone verifier covers the affected subset without pretending the omitted package exists.

## Required full-checkout verification

Run from the project devshell after applying to a complete checkout:

```bash
devtools test tests/unit/mcp/test_agent_query_discovery.py
devtools test tests/unit/mcp/test_query_tool_schema_derivation.py
devtools test tests/unit/archive -k 'query_unit or expression'
devtools verify
```

Also run the current generated MCP reference/schema/OpenAPI gates, MCP server surface registry checks, and a live archive smoke that calls:

```text
query_units with DSL
query_units with an equivalent structured plan
query capability root page
query capability kind page
query capability search page
one malformed sessions-only historical expression
multiple continuation pages over a relation larger than the physical page
```

Compare DSL and structured-plan rows, refs, totals, omissions, errors, and continuation behavior.
