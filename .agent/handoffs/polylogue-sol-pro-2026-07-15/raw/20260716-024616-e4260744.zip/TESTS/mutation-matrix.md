# Mutation-sensitive verification matrix

| Mutation | Expected failing check |
|---|---|
| Add/remove a terminal unit alias without parser projection. | Declared terminal sources differ from parser-owned sources; terminal examples fail compilation. |
| Add a unit without a valid terminal example. | Terminal example count/parsing check fails. |
| Change a field name/operator without updating executable grammar. | Generated examples or structured plan fail in `parse_unit_source_expression`. |
| Add a field without compact projection or explicit omission. | Projection/omission exclusivity check fails with unit and field identity. |
| Rename/remove a row payload field without updating the descriptor. | Descriptor `projection_fields` no longer equals the Pydantic model field order. |
| Add an operation executor action without wiring `TERMINAL_ACTION_EXECUTORS`. | Operation/executor action-set parity fails. |
| Add an executor without declaring its operation semantics. | The same action-set parity fails in the opposite direction. |
| Reintroduce a sessions-only `query_units` recipe. | Prompt/recipe/skill census expression compilation fails. |
| Hand-edit one of the six MCP prompt bodies away from its recipe. | Generated prompt recipe test and source-delegation checks fail. |
| Change the installed-skill census without changing the recipe. | Exact registry/census parity fails. |
| Remove a required recipe binding or sample. | Recipe render/expression validation fails. |
| Add arbitrary keys to the structured plan. | Closed JSON Schema/model validation rejects them. |
| Remove a terminal-source enum from schema projection. | Schema-enum parity fails. |
| Introduce a second plan rendering that changes AST shape. | DSL-versus-structured pipeline payload comparison fails. |
| Broaden catalog pages beyond the bound. | Page-size clamp check fails. |
| Duplicate a catalog capability ID. | Global catalog uniqueness check fails. |
| Index internal key names in catalog search. | `payload_model` / `cost_class` noise searches stop returning zero. |
| Leak a payload class name publicly. | Catalog serialization `Payload` leakage check fails. |
| Treat telemetry as declaration authority. | `telemetry_is_authority` contract check fails. |
| Remove a coverage state or speculate from absent observations. | Closed coverage-state parameterization fails. |
| Reinterpret `total` as whole-relation count on a partial page. | Exactness payload tests fail. |
| Claim an empty nonzero-offset page proves total count. | Empty-offset exactness test fails. |
| Remove continuation for a page with more rows. | `next_offset` / `continuation_required` test fails. |
| Remove the discovery resource or one resource template. | Resource registration/source contract check fails. |
| Remove generated recovery or emit another invalid suggestion. | Recovery suggestion parser compilation fails. |
| Delete paging/stream/spool/queue strategy from large-relation operation. | Catalog/operation strategy assertions in the project test fail. |
| Manually drift the generated MCP reference block. | Generated documentation parity fails. |
