#!/usr/bin/env bash
# Rehearse the handoff in a disposable worktree without touching operator state.
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/full/polylogue/clone" >&2
  exit 64
fi

repo=$(cd "$1" && pwd)
root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
base=${POLYLOGUE_HANDOFF_BASE:-518ac33e318995539743e220c01b9883b7a688a0}
tmp=$(mktemp -d "${TMPDIR:-/tmp}/polylogue-z9gh3-verify.XXXXXX")
worktree="$tmp/worktree"

cleanup() {
  git -C "$repo" worktree remove --force "$worktree" >/dev/null 2>&1 || true
  rm -rf "$tmp"
}
trap cleanup EXIT

git -C "$repo" cat-file -e "$base^{commit}"
git -C "$repo" worktree add --detach "$worktree" "$base" >/dev/null
git -C "$worktree" config user.name "Polylogue Handoff Verification"
git -C "$worktree" config user.email "verify@example.invalid"

while IFS= read -r patch; do
  [[ -z "$patch" ]] || git -C "$worktree" am "$root/PATCHES/$patch"
done < "$root/PATCHES/series"

git -C "$worktree" diff --check "$base..HEAD"
PYTHONDONTWRITEBYTECODE=1 python "$root/TESTS/verify_snapshot.py" "$worktree"

echo "patch application and snapshot verification passed in disposable worktree"
