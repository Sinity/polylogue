#!/usr/bin/env python3
"""Self-contained verification for the supplied narrow Polylogue snapshot.

The immutable context pack omits much of Polylogue's dependency graph.  This
script supplies only the minimum type/module shims needed to import the real
changed parser, declaration registry, structured-plan model, compact payloads,
and completions.  It does not replace full-repository pytest or live archive
verification; it makes the reviewable patch slice executable in isolation.
"""

from __future__ import annotations

import ast
import asyncio
import importlib
import json
import re
import sys
import types
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, RootModel


def _install_module(name: str) -> types.ModuleType:
    module = types.ModuleType(name)
    sys.modules[name] = module
    parent_name, _, child = name.rpartition(".")
    if parent_name:
        parent = sys.modules.get(parent_name)
        if parent is None:
            try:
                parent = importlib.import_module(parent_name)
            except ModuleNotFoundError:
                parent = _install_module(parent_name)
                parent.__path__ = []  # type: ignore[attr-defined]
        setattr(parent, child, module)
    return module


def _install_snapshot_shims() -> None:
    """Install shims only for dependencies omitted from the context pack."""

    errors = _install_module("polylogue.core.errors")

    class PolylogueError(Exception):
        pass

    errors.PolylogueError = PolylogueError

    enums = _install_module("polylogue.core.enums")

    class Origin(str, Enum):
        CLAUDE_CODE = "claude-code-session"
        CODEX = "codex-session"
        CHATGPT = "chatgpt-export"
        UNKNOWN = "unknown-export"

        @classmethod
        def from_string(cls, value: object) -> "Origin":
            raw = str(getattr(value, "value", value))
            try:
                return cls(raw)
            except ValueError:
                return cls.UNKNOWN

    class _StringEnum(str, Enum):
        @classmethod
        def from_string(cls, value: object) -> Any:
            raw = str(getattr(value, "value", value))
            try:
                return cls(raw)
            except ValueError:
                return next(iter(cls))

    class AssertionKind(_StringEnum):
        FINDING = "finding"
        DECISION = "decision"

    class AssertionStatus(_StringEnum):
        CANDIDATE = "candidate"
        ACCEPTED = "accepted"
        REJECTED = "rejected"
        DEFERRED = "deferred"
        SUPERSEDED = "superseded"
        ACTIVE = "active"

    class AssertionVisibility(_StringEnum):
        PRIVATE = "private"
        PUBLIC = "public"

    enums.Origin = Origin
    enums.AssertionKind = AssertionKind
    enums.AssertionStatus = AssertionStatus
    enums.AssertionVisibility = AssertionVisibility
    enums.enum_values = lambda cls: tuple(item.value for item in cls)

    refs = _install_module("polylogue.core.refs")

    @dataclass(frozen=True)
    class ObjectRef:
        kind: str
        object_id: str

        @classmethod
        def parse(cls, text: str) -> "ObjectRef":
            kind, object_id = text.split(":", 1)
            return cls(kind, object_id)

        def format(self) -> str:
            return f"{self.kind}:{self.object_id}"

    refs.ObjectRef = ObjectRef
    refs.delegation_edge_object_id = lambda source, target: f"{source}:{target}"
    refs.normalize_object_ref_text = lambda value: value
    refs.normalize_public_ref_text = lambda value: value

    query_identity = _install_module("polylogue.core.query_identity")
    query_identity.query_ref = lambda value: ObjectRef("query", value)
    query_identity.query_run_ref = lambda value: ObjectRef("query-run", value)
    query_identity.result_set_ref = lambda value: ObjectRef("result-set", value)

    spec = _install_module("polylogue.archive.query.spec")
    spec.QUERY_ACTION_TYPES = ("file_edit", "file_read", "shell", "none")

    class SessionQuerySpec:
        def __init__(self, **kwargs: object) -> None:
            self.__dict__.update(kwargs)

        @classmethod
        def from_params(cls, data: dict[str, object], strict: bool = False) -> "SessionQuerySpec":
            del strict
            return cls(**data)

    spec.SessionQuerySpec = SessionQuerySpec
    spec.normalize_retrieval_lane = lambda value: value
    spec.QuerySpecError = type("QuerySpecError", (PolylogueError,), {})
    spec.split_csv = lambda value: tuple(str(value).split(",")) if value else ()

    message_types = _install_module("polylogue.archive.message.types")

    class _MessageType:
        value = "text"

    message_types.validate_message_type_filter = lambda value: _MessageType()

    content_projection = _install_module("polylogue.archive.semantic.content_projection")

    class ContentProjectionSpec:
        def filters_content(self) -> bool:
            return False

    content_projection.ContentProjectionSpec = ContentProjectionSpec

    assertions = _install_module("polylogue.core.assertions")
    assertions.AssertionContextTrustClass = Literal["trusted", "untrusted", "unknown"]

    core_json = _install_module("polylogue.core.json")
    core_json.JSONDocument = dict[str, Any]
    core_json.JSONValue = Any
    core_json.require_json_document = lambda value, **kwargs: value

    affordances = _install_module("polylogue.surfaces.action_affordances")

    class ActionAffordancePayload(BaseModel):
        action: str = "test"

    affordances.ActionAffordancePayload = ActionAffordancePayload
    affordances.CandidateReviewDecision = Literal["accept", "reject", "defer"]
    affordances.InputUnit = str
    affordances.assertion_candidate_review_affordances = lambda **kwargs: ()

    action_contracts = _install_module("polylogue.operations.action_contracts")
    action_contracts.ACTION_CONTRACTS = ()
    action_contracts.CliActionContract = type("CliActionContract", (), {})


def _schema_enums(value: object) -> set[str]:
    if isinstance(value, dict):
        own = set(value.get("enum", ())) if isinstance(value.get("enum"), list) else set()
        children = (_schema_enums(child) for child in value.values())
        return own | set().union(*children, set())
    if isinstance(value, list):
        return set().union(*(_schema_enums(child) for child in value), set())
    return set()


def _generated_block(text: str, begin: str, end: str) -> str:
    start = text.index(begin) + len(begin)
    finish = text.index(end, start)
    return text[start:finish].strip()


def _executor_keys(path: Path) -> set[str]:
    module = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in module.body:
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if node.target.id != "TERMINAL_ACTION_EXECUTORS" or not isinstance(node.value, ast.Dict):
                continue
            keys = set()
            for key in node.value.keys:
                if isinstance(key, ast.Constant) and isinstance(key.value, str):
                    keys.add(key.value)
            return keys
    raise AssertionError("TERMINAL_ACTION_EXECUTORS literal was not found")


def verify(repo: Path) -> dict[str, object]:
    sys.path.insert(0, str(repo))
    _install_snapshot_shims()

    from polylogue.archive.query.completions import query_recipe_candidates
    from polylogue.archive.query.expression import ExpressionCompileError, parse_unit_source_expression
    from polylogue.archive.query.metadata import (
        QueryCoverageObservation,
        query_capability_catalog,
        query_coverage_status,
        query_intent_recipe,
        query_intent_recipes,
        query_operation_descriptors,
        query_unit_descriptors,
        query_unit_field_projection,
        query_unit_omitted_fields,
        query_unit_structured_plan_example,
        query_unit_terminal_recovery,
        render_query_discovery_markdown,
        render_query_recipe_prompt,
        terminal_query_examples,
        terminal_query_sources,
    )
    from polylogue.mcp.query_contracts import (
        MCPQueryUnitStructuredPlan,
        query_unit_input_expression,
        query_unit_input_schema,
    )
    from polylogue.surfaces import payloads as surface_payloads
    from polylogue.surfaces.payloads import MessageQueryRowPayload, build_query_unit_envelope

    terminal_units = {descriptor.unit for descriptor in query_unit_descriptors(terminal_supported=True)}

    def assert_terminal(expression: str) -> object:
        parsed = parse_unit_source_expression(expression)
        assert parsed is not None, f"sessions-only expression escaped into terminal curriculum: {expression!r}"
        assert parsed.unit in terminal_units
        return parsed

    terminal_examples = terminal_query_examples()
    assert len(terminal_examples) == len(terminal_units)
    for expression in terminal_examples:
        assert_terminal(expression)

    recipes = query_intent_recipes()
    mcp_prompt_names = {recipe.name for recipe in recipes if recipe.mcp_prompt}
    assert mcp_prompt_names == {
        "resume_context",
        "postmortem_last",
        "decisions_about",
        "unacknowledged_failures",
        "sessions_touching_file",
        "cost_of",
    }
    recipe_expression_count = 0
    for recipe in recipes:
        recipe.render(recipe.sample_binding_map)
        for expression in recipe.expressions(recipe.sample_binding_map):
            assert_terminal(expression)
            recipe_expression_count += 1
        if recipe.mcp_prompt:
            prompt = render_query_recipe_prompt(recipe.name, **recipe.sample_binding_map)
            for expression in recipe.expressions(recipe.sample_binding_map):
                assert expression in prompt

    fixture_path = repo / "tests/fixtures/query/installed_skill_query_expressions.json"
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    for intent, expected in fixture["intent_expressions"].items():
        actual = list(query_intent_recipe(intent).expressions(query_intent_recipe(intent).sample_binding_map))
        assert actual == expected
        for expression in expected:
            assert_terminal(expression)

    generated_corpus = "\n".join(
        [
            (repo / "polylogue/mcp/server_prompts.py").read_text(encoding="utf-8"),
            render_query_discovery_markdown(),
            *(render_query_recipe_prompt(recipe.name, **recipe.sample_binding_map) for recipe in recipes),
        ]
    )
    for expression in fixture["forbidden_regressions"]:
        assert expression not in generated_corpus
        try:
            parsed = parse_unit_source_expression(expression)
        except ExpressionCompileError:
            parsed = None
        assert parsed is None

    structured_count = 0
    for descriptor in query_unit_descriptors(terminal_supported=True):
        plan = MCPQueryUnitStructuredPlan.model_validate(
            query_unit_structured_plan_example(descriptor.plural_source)
        )
        assert_terminal(plan.to_expression())
        structured_count += 1

    plan = MCPQueryUnitStructuredPlan(
        source="action",
        where="is_error:true OR exit_code > 0",
        session_where="repo:polylogue AND since:7d",
        group_by=("tool",),
        aggregate="count",
        sort_by="count",
        sort_direction="desc",
        limit=20,
        offset=40,
    )
    rendered_plan = query_unit_input_expression(plan)
    expected_plan = (
        "sessions where repo:polylogue AND since:7d | "
        "actions where is_error:true OR exit_code > 0 | "
        "group by tool | count | sort by count desc | limit 20 | offset 40"
    )
    assert rendered_plan == expected_plan
    dsl_ast = assert_terminal(expected_plan)
    plan_ast = assert_terminal(rendered_plan)
    assert dsl_ast.pipeline.to_payload() == plan_ast.pipeline.to_payload()  # type: ignore[attr-defined]

    schema = query_unit_input_schema()
    variants = schema.get("anyOf") or schema.get("oneOf")
    assert isinstance(variants, list) and len(variants) == 2
    assert any(isinstance(variant, dict) and variant.get("type") == "string" for variant in variants)
    assert set(terminal_query_sources()) <= _schema_enums(schema)
    assert '"additionalProperties": false' in json.dumps(schema, sort_keys=True)

    coverage_cases = (
        (None, "unknown"),
        (QueryCoverageObservation(supported=None), "unknown"),
        (QueryCoverageObservation(supported=False), "unsupported"),
        (QueryCoverageObservation(degraded_reason="probe failed"), "degraded"),
        (QueryCoverageObservation(stale=True, observed_count=2), "supported-but-stale"),
        (QueryCoverageObservation(observed_count=0), "supported-but-absent"),
        (QueryCoverageObservation(observed_count=2), "supported-and-observed"),
    )
    for observation, expected in coverage_cases:
        assert query_coverage_status(observation) == expected

    catalog_entries: list[dict[str, object]] = []
    offset = 0
    while True:
        page = query_capability_catalog(limit=50, offset=offset)
        items = page["items"]
        assert isinstance(items, list) and len(items) <= 50
        catalog_entries.extend(items)
        next_offset = page["next_offset"]
        if next_offset is None:
            break
        assert isinstance(next_offset, int) and next_offset > offset
        offset = next_offset
    assert len(catalog_entries) == 420
    assert len(catalog_entries) == len({str(entry["id"]) for entry in catalog_entries})
    assert {entry["kind"] for entry in catalog_entries} == {"unit", "field", "operation", "recipe"}
    assert all("Payload" not in json.dumps(entry, sort_keys=True) for entry in catalog_entries)
    model_hits = query_capability_catalog(search="model orchestration", limit=50)["items"]
    assert [entry["id"] for entry in model_hits] == ["recipe:delegation_routing"]
    assert query_capability_catalog(search="payload_model", limit=50)["total"] == 0
    assert query_capability_catalog(search="cost_class", limit=50)["total"] == 0
    assert query_capability_catalog(limit=1)["coverage_contract"]["telemetry_is_authority"] is False

    for descriptor in query_unit_descriptors(terminal_supported=True):
        model = getattr(surface_payloads, descriptor.payload_model)
        assert tuple(model.model_fields) == descriptor.projection_fields
        omitted = set(query_unit_omitted_fields(descriptor))
        for field in descriptor.fields:
            projection = query_unit_field_projection(descriptor, field)
            assert bool(projection) != (field.name in omitted)

    declared_actions = {
        operation.executor_action
        for operation in query_operation_descriptors()
        if operation.executor_action is not None
    }
    executor_actions = _executor_keys(repo / "polylogue/archive/query/unit_results.py")
    assert declared_actions == executor_actions == {"rows", "count"}

    row = MessageQueryRowPayload(
        message_id="m",
        session_id="s",
        origin="codex-session",
        role="assistant",
        message_type="text",
        position=0,
        word_count=1,
        text="hi",
    )
    first = build_query_unit_envelope(
        (row,),
        unit="message",
        query="messages where role:assistant",
        limit=1,
        offset=0,
        has_next=True,
        projection_fields=("message_id", "text"),
        omitted_fields=("duration_ms",),
    )
    assert first.total == first.returned_count == 1
    assert first.match_count is None and first.match_count_is_exact is False
    assert first.next_offset == 1 and first.continuation_required is True
    assert first.page_count_is_exact is True and first.result_semantics == "exhaustive-relation-page"
    last = build_query_unit_envelope(
        (row,),
        unit="message",
        query="messages where role:assistant",
        limit=1,
        offset=1,
        effective_offset=1,
        has_next=False,
    )
    assert last.match_count == 2 and last.match_count_is_exact is True
    empty_after_offset = build_query_unit_envelope(
        (),
        unit="message",
        query="messages where role:assistant",
        limit=10,
        offset=10,
        has_next=False,
    )
    assert empty_after_offset.match_count is None and empty_after_offset.match_count_is_exact is False

    recovery_inputs = (
        "sessions where repo:polylogue since:7d",
        "sessions where repo:polylogue since:7d AND exists action(output:failed)",
        "sessions where repo:polylogue AND exists file(action:file_edit AND path:polylogue/archive)",
    )
    recovery_query_units = 0
    for expression in recovery_inputs:
        recovery = query_unit_terminal_recovery(expression)
        assert recovery["sessions_terminal_supported"] is False
        suggestions = recovery["suggestions"]
        assert isinstance(suggestions, list) and suggestions
        for suggestion in suggestions:
            if suggestion["tool"] == "query_units":
                assert_terminal(suggestion["expression"])
                recovery_query_units += 1

    completion_candidates = query_recipe_candidates("")
    assert len(completion_candidates) == 6
    for candidate in completion_candidates:
        assert_terminal(candidate.insert)
    assert [candidate.value for candidate in query_recipe_candidates("fail")] == [
        "unacknowledged_failures",
        "page_failures",
    ]

    reference = (repo / "docs/mcp-reference.md").read_text(encoding="utf-8")
    begin = "<!-- BEGIN GENERATED: agent-query-discovery -->"
    end = "<!-- END GENERATED: agent-query-discovery -->"
    assert _generated_block(reference, begin, end) == render_query_discovery_markdown().strip()

    resource_source = (repo / "polylogue/mcp/server_resources.py").read_text(encoding="utf-8")
    for uri in (
        "polylogue://capabilities/query",
        "polylogue://capabilities/query/{kind}/{offset}/{limit}",
        "polylogue://capabilities/query/search/{term}/{offset}/{limit}",
    ):
        assert resource_source.count(f'@mcp.resource("{uri}")') == 1
    assert "coverage_probe" in resource_source and "archive.stats" in resource_source

    tool_source = (repo / "polylogue/mcp/server_tools.py").read_text(encoding="utf-8")
    assert "query_units.__doc__ = query_units_tool_description()" in tool_source
    assert "canonical_expression = query_unit_input_expression(expression)" in tool_source
    assert "query_unit_terminal_recovery_text" in tool_source

    prompt_source = (repo / "polylogue/mcp/server_prompts.py").read_text(encoding="utf-8")
    assert "render_query_recipe_prompt" in prompt_source
    assert "query_intent_recipe" in prompt_source

    # Import the real resource and prompt registration modules with narrow
    # storage/surface shims, then exercise the generated handlers.
    archive_support = _install_module("polylogue.mcp.archive_support")
    archive_support.archive_messages_payload = lambda *args, **kwargs: {}
    archive_support.archive_session_list_payload = lambda *args, **kwargs: {}
    archive_support.archive_summary_payload = lambda *args, **kwargs: {}
    archive_support.archive_query_filters = lambda *args, **kwargs: {}
    archive_support.mcp_archive_root = lambda config: config

    mcp_payloads = _install_module("polylogue.mcp.payloads")

    class MCPRootPayload(RootModel[dict[str, object]]):
        pass

    class _UnusedPayload(BaseModel):
        pass

    mcp_payloads.MCPRootPayload = MCPRootPayload
    mcp_payloads.MCPArchiveStatsPayload = _UnusedPayload
    mcp_payloads.MCPErrorPayload = _UnusedPayload
    mcp_payloads.MCPReadinessReportPayload = _UnusedPayload
    mcp_payloads.MCPTagCountsPayload = _UnusedPayload
    mcp_payloads.MCPFencedCodeBlock = dict[str, str]
    mcp_payloads.session_tree_payload = lambda *args, **kwargs: {}

    archive_module = _install_module("polylogue.storage.sqlite.archive_tiers.archive")

    class ArchiveStore:
        @classmethod
        def open_existing(cls, path: object) -> object:
            raise RuntimeError("snapshot verifier has no archive")

    archive_module.ArchiveStore = ArchiveStore

    class _ResourceCapture:
        def __init__(self) -> None:
            self.handlers: dict[str, object] = {}

        def resource(self, uri: str) -> object:
            def register(handler: object) -> object:
                self.handlers[uri] = handler
                return handler

            return register

    class _StaticHooks:
        def get_config(self) -> object:
            raise RuntimeError("archive unavailable")

        def json_payload(self, payload: BaseModel, *, exclude_none: bool = False) -> str:
            return payload.model_dump_json(exclude_none=exclude_none)

        def error_json(self, message: str, **extra: object) -> str:
            return json.dumps({"message": message, **extra}, sort_keys=True)

    server_resources = importlib.import_module("polylogue.mcp.server_resources")
    resource_capture = _ResourceCapture()
    server_resources.register_resources(resource_capture, _StaticHooks())
    resource_uris = {
        "polylogue://capabilities/query",
        "polylogue://capabilities/query/{kind}/{offset}/{limit}",
        "polylogue://capabilities/query/search/{term}/{offset}/{limit}",
    }
    assert resource_uris <= set(resource_capture.handlers)
    root_handler = resource_capture.handlers["polylogue://capabilities/query"]
    root_payload = json.loads(root_handler())  # type: ignore[operator]
    live_catalog = root_payload["query_capability_catalog"]
    assert len(live_catalog["items"]) == 20 and live_catalog["next_offset"] == 20
    assert live_catalog["coverage_probe"]["status"] == "degraded"
    search_handler = resource_capture.handlers[
        "polylogue://capabilities/query/search/{term}/{offset}/{limit}"
    ]
    searched_payload = json.loads(search_handler("model%20orchestration", 0, 10))  # type: ignore[operator]
    searched_items = searched_payload["query_capability_catalog"]["items"]
    assert [item["id"] for item in searched_items] == ["recipe:delegation_routing"]

    class _PromptCapture:
        def __init__(self) -> None:
            self.handlers: dict[str, object] = {}

        def prompt(self) -> object:
            def register(handler: object) -> object:
                self.handlers[getattr(handler, "__name__")] = handler
                return handler

            return register

    server_prompts = importlib.import_module("polylogue.mcp.server_prompts")
    prompt_capture = _PromptCapture()
    server_prompts.register_prompts(prompt_capture, object())
    prompt_calls = {
        "resume_context": ("polylogue", 5),
        "postmortem_last": ("polylogue", "14d"),
        "decisions_about": ("query discovery", 20),
        "unacknowledged_failures": ("polylogue", "7d"),
        "sessions_touching_file": ("polylogue/mcp/server_prompts.py", "polylogue"),
        "cost_of": ("30d", 10),
    }
    embedded_expression_count = 0
    expression_pattern = re.compile(
        r"query_units\(expression=(?P<quote>['\"])(?P<expression>.*?)(?P=quote)",
        re.DOTALL,
    )
    for name, arguments in prompt_calls.items():
        handler = prompt_capture.handlers[name]
        rendered = asyncio.run(handler(*arguments))  # type: ignore[operator]
        for match in expression_pattern.finditer(rendered):
            assert_terminal(match.group("expression"))
            embedded_expression_count += 1
        for forbidden in fixture["forbidden_regressions"]:
            assert forbidden not in rendered
    assert embedded_expression_count == 4

    return {
        "status": "pass",
        "terminal_units": len(terminal_units),
        "terminal_examples": len(terminal_examples),
        "recipes": len(recipes),
        "recipe_expressions": recipe_expression_count,
        "mcp_prompts": len(mcp_prompt_names),
        "structured_examples": structured_count,
        "catalog_total": len(catalog_entries),
        "catalog_kinds": sorted({str(entry["kind"]) for entry in catalog_entries}),
        "executable_recipe_completions": len(completion_candidates),
        "recovery_cases": len(recovery_inputs),
        "recovery_terminal_suggestions": recovery_query_units,
        "executor_actions": sorted(executor_actions),
        "result_exactness_cases": 3,
        "registered_query_resources": len(resource_uris),
        "registered_recipe_prompts": len(prompt_calls),
        "embedded_prompt_expressions": embedded_expression_count,
    }


def main() -> int:
    repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    required = repo / "polylogue/archive/query/metadata.py"
    if not required.is_file():
        raise SystemExit(f"not a Polylogue snapshot root: {repo}")
    result = verify(repo)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
