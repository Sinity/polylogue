# Polylogue `polylogue-t8t` launch handoff

## Read order

1. `SUMMARY.md` — result and acceptance matrix.
2. `VERIFICATION-LIMITS.md` — exact local execution boundary.
3. `PATCHES/BASELINE.md` — base revision and dirty-state assumptions.
4. `DESIGN/ARCHITECTURE.md` and `DESIGN/ORACLE-INDEPENDENCE.md` — design and failure semantics.
5. `PATCHES/0001...`, `0002...`, `0003...` — ordered implementation series.
6. `TESTS/VERIFICATION-PLAN.md` and logs — reproduction commands and observed results.
7. Remaining design records — expansion plan, source evidence, research, and rejected alternatives.

## Apply order

Apply from the repository root, after restoring the exact supplied snapshot state described in `PATCHES/BASELINE.md`:

```bash
git apply --check PATCHES/0001-continuity-replay-kernel.patch
git apply PATCHES/0001-continuity-replay-kernel.patch
git apply --check PATCHES/0002-continuity-catalog-fixtures-and-generated-table.patch
git apply PATCHES/0002-continuity-catalog-fixtures-and-generated-table.patch
git apply --check PATCHES/0003-continuity-public-surface-and-oracle-tests.patch
git apply PATCHES/0003-continuity-public-surface-and-oracle-tests.patch
```

Then verify:

```bash
python -m polylogue.scenarios.continuity_replay.generate --check
python -m compileall -q polylogue/scenarios/continuity_replay tests/test_continuity_replay_oracle.py tests/test_continuity_replay_public_surfaces.py tests/continuity_public_surface_binding.py
uv run pytest -q tests/test_continuity_replay_oracle.py
uv run pytest -q tests/test_continuity_replay_public_surfaces.py
```

Use the repository's documented environment wrapper when `uv` is not the project entry point. The public-surface test deliberately fails rather than skips when it cannot construct an isolated real server or production ingestion path.
