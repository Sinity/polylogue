# Executable verification plan

Run from an exact supplied-state checkout after applying patches in order:

```bash
set -euo pipefail
python -m polylogue.scenarios.continuity_replay.generate --check
python -m compileall -q polylogue/scenarios/continuity_replay \
  tests/test_continuity_replay_oracle.py \
  tests/test_continuity_replay_public_surfaces.py \
  tests/continuity_public_surface_binding.py
uv run pytest -q tests/test_continuity_replay_oracle.py
uv run pytest -q tests/test_continuity_replay_public_surfaces.py
```

The first test module is self-contained and must pass without a daemon or network. The second must instantiate the real registered FastMCP server in an isolated temporary data root and import normalized blocks through a production ingestion surface. It must fail, not skip, if the binding or route is unavailable.

For deployment verification, run the same public-surface scenarios against a disposable instance configured exactly like the operator daemon, then retain the `OracleReport` JSON and source fixture digests. Do not point the fixture seeder at a private or production archive.
