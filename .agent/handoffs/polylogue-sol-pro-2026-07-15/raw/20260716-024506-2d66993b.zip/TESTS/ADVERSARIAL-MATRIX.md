# Adversarial test matrix

| Mutation | Expected verdict | Why |
| --- | --- | --- |
| Remove an anchored source record | `oracle_evidence_failure` | The judge can no longer establish a known answer; route output is irrelevant. |
| Change an anchored record outside the selected value | `oracle_evidence_failure` | Full-record provenance hash prevents laundering altered context. |
| Seed only a subset of required record IDs | `archive_failure` | Ingestion receipt proves archive incompleteness before query. |
| MCP tool errors or returns non-canonical payload | `surface_failure` | Registered public boundary failed. |
| Surface omits one fact but returns a fluent summary | `query_failure` | Model is not blamed for evidence it was not given. |
| Surface contains every fact; answer chooses plausible decoy | `unreasonable_model_behavior` | Complete evidence was available and payload digest was attested. |
| Candidate answer attests to a different surface digest | `unreasonable_model_behavior` | The answer cannot claim to have consumed the graded context. |
| Complete surface; no model run | `pass` | Evidence-only route verification is valid and does not invent model behavior. |
