# Public-surface binding

The integration test calls the exact catalog tool names through a FastMCP in-memory client. It isolates `HOME`, XDG roots, and common Polylogue data/database/archive variables beneath pytest's `tmp_path` before importing the server. It obtains the published JSON schema with `list_tools`, maps stable semantic fixture intent to that schema, and refuses unknown required fields.

For ingestion it first looks for a registered schema-compatible normalized-block tool, preferring bulk records/blocks/events/messages, then path import, then per-record mutation. If the project exposes ingestion only through its CLI, it tries isolated `ingest`/`import` command forms against JSON and JSONL normalized records. Every failed attempt becomes an archive failure; no query output is synthesized.

Observed container result: `FAIL (rc=2)`. The focused log follows in `TESTS/public-surface-tests.log`. This is intentionally a fail-closed integration seam: adapting the full operator checkout should change only this binding, not oracle facts, verdict logic, or fixtures.
