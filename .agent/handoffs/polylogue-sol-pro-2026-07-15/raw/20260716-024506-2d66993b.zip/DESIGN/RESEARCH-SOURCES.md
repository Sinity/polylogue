# Primary research sources

Accessed 2026-07-15.

1. RFC Editor, RFC 6901, “JavaScript Object Notation (JSON) Pointer”: https://www.rfc-editor.org/rfc/rfc6901.html  
   Decision: evidence extraction uses the RFC 6901 escaping rules (`~0`, `~1`) and fails closed when a pointer cannot resolve.
2. Model Context Protocol specification, Tools: https://modelcontextprotocol.io/specification/latest/server/tools  
   Decision: the public binding obtains each registered tool's published input schema and invokes it by tool name rather than importing a private query helper.
3. FastMCP official client documentation: https://gofastmcp.com/clients/client  
   Decision: the integration binding uses an in-memory client against the actual server object, avoiding a daemon/network dependency while preserving the registered MCP boundary.
4. Python standard library `json` documentation: https://docs.python.org/3/library/json.html  
   Decision: canonical fixture and payload digests use UTF-8 JSON with sorted keys, compact separators, `ensure_ascii=False`, and `allow_nan=False`.

Repository source and the complete Bead record remain the controlling sources for project-specific behavior. External sources were used only for the JSON-pointer and public-MCP transport conventions.
