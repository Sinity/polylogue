# Rejected alternatives

## Expected answers stored in fixture metadata

Rejected because the evaluator would merely validate its own declaration. The implemented catalog stores hashes and extraction locations; the answer value must still exist in raw source evidence.

## Production search as the oracle

Rejected because the same archive/query defect could affect both candidate and judge. The source oracle never imports production query code.

## Golden snapshots of MCP payloads

Rejected as the primary judge because harmless rendering changes create noise while plausible wrong evidence may still look structurally valid. The oracle resolves semantic facts and provenance independently, while preserving full payload digests for audit.

## Fuzzy semantic similarity alone

Rejected because decoys are intentionally plausible. Required facts are source-derived and matched with declared exact/contains/numeric semantics; forbidden decoys add a directional failure signal.

## Treat every wrong answer as a query failure

Rejected because it hides unreasonable model behavior. Model grading begins only after the public payload proves target evidence visibility.

## Mocked public handlers

Rejected for the end-to-end layer. Unit tests construct checkpoint values to exhaustively test classification, but the representative public-surface test uses an in-memory client for the repository's registered FastMCP server and production ingestion paths.

## Live private transcripts or operator databases

Rejected because replay must be deterministic, redistributable, and private-data-free. The fixtures use synthetic sessions and public project-relative evidence.

## Seven shallow transcripts immediately

Rejected in favor of two implementation-grade routes plus a completeness-checked expansion table. Planned entries cannot count as coverage until they gain source fixtures, anchors, route execution, and adversarial tests.
