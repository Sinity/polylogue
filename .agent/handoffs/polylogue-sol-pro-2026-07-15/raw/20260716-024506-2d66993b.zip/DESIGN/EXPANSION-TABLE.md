# Continuity replay catalog

Generated from `catalog.json`; do not edit by hand.

| Job | Scenario | State | Public surface | Expansion acceptance |
| --- | --- | --- | --- | --- |
| resume | `resume_context_image_public_v1` | implemented | `build_context_image` | Implemented fixture and oracle |
| failure_postmortem | `failure_postmortem_public_v1` | implemented | `get_postmortem_bundle` | Implemented fixture and oracle |
| forensic_file_session_lookup | `forensic_file_session_lookup_v1` | planned | `—` | Fixture includes same-basename decoys in two sessions.<br>Oracle anchors file path, operation, session ID, and record provenance.<br>Route test uses the registered forensic lookup surface and fails on the wrong session. |
| prior_art_retrieval | `prior_art_retrieval_v1` | planned | `—` | Fixture contains accepted and superseded implementation patterns.<br>Oracle anchors the accepted code fragment and source record.<br>Route test fails when only the superseded pattern is returned. |
| decision_lookup | `decision_lookup_v1` | planned | `—` | Fixture contains an older plausible decision and a later superseding note.<br>Oracle anchors both chronology and current decision.<br>Route test fails when the older decision is presented as current. |
| cost_usage_audit | `cost_usage_audit_v1` | planned | `—` | Fixture contains line-item usage records and an explicit public price table.<br>Oracle computes totals from source line items, never fixture totals.<br>Route test fails on duplicate charging, dropped usage, or wrong currency precision. |
| live_self_inspection | `live_self_inspection_v1` | planned | `—` | Fixture provides a deterministic health snapshot and stale decoy snapshot.<br>Oracle anchors tool registration, archive watermark, and freshness timestamp.<br>Route test distinguishes unavailable live state from unreasonable summary behavior. |

## Completeness invariant

Every `ContinuityJob` appears exactly once. Implemented rows require a source fixture, registered public surface, and independently anchored facts; planned rows require concrete expansion acceptance criteria and cannot carry placeholder evidence.


## Expansion fixture design

The five planned rows are deliberately non-executable: the catalog parser rejects planned entries that pretend to carry fixtures or facts. Promotion requires a public source fixture, exact provenance anchors, a registered route, a removal test, and a plausible-decoy test. This prevents completeness accounting from turning placeholders into false coverage.
