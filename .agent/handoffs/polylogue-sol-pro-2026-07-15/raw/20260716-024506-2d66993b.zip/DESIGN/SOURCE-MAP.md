# Source and integration map

- Continuity package: `polylogue/scenarios/continuity_replay`
- Import module: `polylogue.scenarios.continuity_replay`
- Native ScenarioSpec source: `polylogue/scenarios/specs.py`

## Existing route/corpus vocabulary occurrences

### `ScenarioSpec`
- `tests/unit/scenarios/test_scenario_specs.py:3` — `from polylogue.scenarios import CorpusSpec, ScenarioProjectionSourceKind, ScenarioSpec`
- `tests/unit/scenarios/test_scenario_specs.py:6` — `class _ScenarioFixture(ScenarioSpec):`
- `polylogue/scenarios/__init__.py:96` — `from .specs import ScenarioSpec`
- `polylogue/scenarios/__init__.py:162` — `"ScenarioSpec",`
- `polylogue/scenarios/corpus.py:25` — `from .specs import ScenarioSpec`
- `polylogue/scenarios/corpus.py:660` — `class CorpusScenario(ScenarioSpec):`
- `polylogue/scenarios/sources.py:7` — `from .specs import ScenarioSpec`
- `polylogue/scenarios/sources.py:11` — `class NamedScenarioSource(ScenarioSpec):`
- `polylogue/scenarios/specs.py:18` — `class ScenarioSpec(ScenarioProjectionSource, ScenarioMetadata):`
- `polylogue/scenarios/specs.py:47` — `__all__ = ["ScenarioSpec"]`

### `build_context_image`
- `tests/unit/mcp/test_context_image.py:1` — `"""Unit tests for the build_context_image MCP tool and context-image selection.`
- `tests/unit/mcp/test_context_image.py:3` — `build_context_image collapsed onto the shared ``compile_context`` engine: it is a`
- `tests/unit/mcp/test_context_image.py:64` — `"""Verify the build_context_image tool is registered and callable."""`
- `tests/unit/mcp/test_context_image.py:67` — `assert "build_context_image" in EXPECTED_TOOL_NAMES`
- `tests/unit/mcp/test_context_image.py:71` — `assert "build_context_image" in tools`
- `tests/unit/mcp/test_context_image.py:72` — `assert callable(tools["build_context_image"].fn)`
- `tests/unit/mcp/test_context_image.py:161` — `mcp_server._tool_manager._tools["build_context_image"].fn,`
- `tests/unit/mcp/test_context_image.py:185` — `mcp_server._tool_manager._tools["build_context_image"].fn,`
- `tests/unit/mcp/test_context_image.py:201` — `mcp_server._tool_manager._tools["build_context_image"].fn,`
- `tests/unit/mcp/test_envelope_contracts.py:109` — `"build_context_image": "single_object",`
- `tests/unit/mcp/test_tool_discovery.py:88` — `"build_context_image": {"project_repo": "test"},`
- `tests/unit/mcp/test_tool_discovery.py:166` — `"build_context_image",`
- `polylogue/mcp/server_context_tools.py:3` — `Registers ``build_context_image`` — the agent-facing context assembly tool. It is`
- `polylogue/mcp/server_context_tools.py:62` — `async def build_context_image(`
- `polylogue/mcp/server_context_tools.py:113` — `return await hooks.async_safe_call("build_context_image", run)`

### `get_postmortem_bundle`
- `tests/unit/mcp/test_distilled_bundle_tools.py:1` — `"""Tests for distilled-bundle MCP tools: get_postmortem_bundle (#2436)."""`
- `tests/unit/mcp/test_distilled_bundle_tools.py:15` — `async def test_get_postmortem_bundle_delegates_and_serializes(mcp_server: MCPServerUnderTest) -> None:`
- `tests/unit/mcp/test_distilled_bundle_tools.py:23` — `mcp_server._tool_manager._tools["get_postmortem_bundle"].fn,`
- `tests/unit/mcp/test_envelope_contracts.py:152` — `"get_postmortem_bundle": "single_object",`
- `tests/unit/mcp/test_server_surfaces.py:1298` — `("find_abandoned_sessions", "find_stuck_sessions", "get_postmortem_bundle", "get_pathologies"),`
- `tests/unit/mcp/test_tool_discovery.py:91` — `"get_postmortem_bundle": {},`
- `polylogue/mcp/server_insight_tools.py:715` — `async def get_postmortem_bundle(`
- `polylogue/mcp/server_insight_tools.py:756` — `return await hooks.async_safe_call("get_postmortem_bundle", run)`
- `polylogue/mcp/server_prompts.py:435` — `3. get_postmortem_bundle(repo="{repo_name}", since="{since}") — forensic bundle: timeline, decisions, tool errors.`

### `tool_result_is_error`
- `tests/unit/mcp/test_server_surfaces.py:699` — `"tool_result_is_error": 1,`

### `FastMCP`
- `tests/unit/mcp/test_contract_evidence.py:325` — `the failure cannot escape into the FastMCP stdio loop and kill the`
- `tests/unit/mcp/test_mcp_call_log.py:98` — `"""Exercise FastMCP registration, background HTTP, writer gate, and ops SQL."""`
- `tests/unit/mcp/test_mcp_call_log.py:130` — `"""Exercise real FastMCP wrappers for the previously uncorrelated tools."""`
- `tests/unit/mcp/test_mcp_edge_cases.py:63` — `stdio loop — the historical raise propagated through FastMCP and`
- `tests/unit/mcp/test_per_tool_contracts.py:19` — `Tool names are discovered from the admin-role FastMCP server (not a`
- `tests/unit/mcp/test_per_tool_contracts.py:477` — `for required parameters (FastMCP wraps the handler as a plain`
- `tests/unit/mcp/test_per_tool_contracts.py:559` — `# envelope OR a typed ``PolylogueError`` (FastMCP marshals the`
- `tests/unit/mcp/test_query_tool_schema_derivation.py:19` — `from mcp.server.fastmcp import FastMCP`
- `tests/unit/mcp/test_query_tool_schema_derivation.py:40` — `server = FastMCP("schema-derivation-test")`
- `tests/unit/mcp/test_server_runtime.py:16` — `patch("mcp.server.fastmcp.FastMCP", fake_fast_mcp),`
- `polylogue/mcp/server.py:27` — `from mcp.server.fastmcp import FastMCP`
- `polylogue/mcp/server.py:30` — `def build_server(*, role: MCPRole = "read") -> FastMCP:`
- `polylogue/mcp/server.py:31` — `"""Construct the FastMCP server with all tools, resources, and prompts."""`
- `polylogue/mcp/server.py:32` — `from mcp.server.fastmcp import FastMCP`
- `polylogue/mcp/server.py:34` — `mcp = FastMCP(`
- `polylogue/mcp/server.py:71` — `_server_instance: FastMCP | None = None`
- `polylogue/mcp/server.py:75` — `def _get_server(services: RuntimeServices | None = None, *, role: MCPRole = "read") -> FastMCP:`
- `polylogue/mcp/server_context_tools.py:15` — `from mcp.server.fastmcp import FastMCP`
- `polylogue/mcp/server_context_tools.py:33` — `def register_context_tools(mcp: FastMCP, hooks: ServerCallbacks) -> None:`
- `polylogue/mcp/server_insight_tools.py:29` — `from mcp.server.fastmcp import FastMCP`

### `completeness`
- `tests/unit/mcp/test_lineage_completeness_payload.py:1` — `"""4ts.6: the lineage-completeness signal must reach the MCP payloads that`
- `tests/unit/mcp/test_lineage_completeness_payload.py:28` — `def test_archive_messages_payload_carries_lineage_completeness() -> None:`
- `tests/unit/mcp/test_lineage_completeness_payload.py:40` — `def test_mcp_archive_session_payload_carries_lineage_completeness() -> None:`

## New paths

- `polylogue/scenarios/continuity_replay/EXPANSION.md`
- `polylogue/scenarios/continuity_replay/__init__.py`
- `polylogue/scenarios/continuity_replay/catalog.json`
- `polylogue/scenarios/continuity_replay/catalog.py`
- `polylogue/scenarios/continuity_replay/fixtures/failure_postmortem.json`
- `polylogue/scenarios/continuity_replay/fixtures/resume_context_image.json`
- `polylogue/scenarios/continuity_replay/generate.py`
- `polylogue/scenarios/continuity_replay/models.py`
- `polylogue/scenarios/continuity_replay/native.py`
- `polylogue/scenarios/continuity_replay/oracle.py`
- `polylogue/scenarios/continuity_replay/replay.py`
- `tests/test_continuity_replay_oracle.py`
- `tests/test_continuity_replay_public_surfaces.py`
- `tests/continuity_public_surface_binding.py`
