# Oracle independence and evidence provenance

The oracle is not allowed to call an archive, search index, context compiler, MCP handler, or model. Its only input is the catalog declaration and source fixture path. A fact declaration stores a source `record_id`, JSON pointer, full-record SHA-256, and extracted-value SHA-256; it deliberately has no expected-answer string. The known answer is computed from the fixture value at grading time.

This construction creates two independent channels:

- The route under test sees records only after production ingestion and query selection.
- The oracle sees records only by direct fixture read and pointer resolution.

Removing a target record, changing its pointer value, or changing its surrounding provenance invalidates the source oracle before route grading. Conversely, a route can return fluent but incorrect content and still fail because matching is against the source-derived value, not fixture labels or the route's own citations.

Every resolved fact carries `fixture_path`, `fixture_sha256`, `record_id`, `record_sha256`, `pointer`, and `value_sha256`. Reports attach this provenance to query/model findings so a reviewer can reproduce the decision without a database.

Determinism is enforced by sorted-key, no-NaN JSON serialization and exact SHA-256. Privacy is enforced before oracle resolution with guards for home-directory paths, user-profile paths, email addresses, bearer/API-key forms, GitHub tokens, and AWS access keys. Fixtures use synthetic session identifiers and project-relative public paths only.

The evaluator distinguishes evidence visibility from answer reasonableness. It first proves that all facts are recursively visible in the normalized public payload. Only then does it grade an answer that attests to the exact surface digest. Therefore the adversarial "plausible but wrong" tests cannot be misclassified as retrieval failures.
