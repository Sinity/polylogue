# Supplied snapshot evidence

## Git records

- HEAD: `5abb30afc0b30348c4332ede1e592704e971f0a8`
- Branch: `feature/browser/sol-pro-dispatch`
- Context archive SHA-256: `576b97c6484bb240b90d6582617b0368bb7daca8f2f17214063ca0fcd89e97c0`
- Context archive member safety was checked before extraction: no absolute paths, parent traversal, backslashes, or NUL path bytes were accepted.

## Repository instructions (verbatim supplied file)

```markdown
# Polylogue

Polylogue is a **local, single-writer archive for AI coding/chat sessions** —
Claude (web + Code), ChatGPT, Codex, Gemini/Drive, Antigravity, Hermes — that
ingests heterogeneous exports into a split SQLite file set, derives rich read
models, and serves them through a query-first CLI, an MCP server, a Python API,
and an HTTP daemon. Pure Python, no native deps beyond pre-built wheels.

This file is **standalone**: it carries the working understanding you need to
be effective here. For depth, read the referenced docs on demand (see
[Reference docs](#reference-docs)) — they are not auto-loaded.

---

## Orientation

The system has four rings; substrate owns meaning, surfaces are leaf adapters:

```
sources/ ─detect→ pipeline/ ─hash+write→ storage/{5 tiers} ─materialize→ insights/
                                              │                              │
                            surfaces: cli/  mcp/  api/  daemon/  ─read-through─┘
                            verification:   devtools/  tests/  schemas/
```

Package sizes (rough): `storage/` (largest), `daemon/`, `cli/`, `archive/`,
`sources/`, `schemas/`, `insights/`. Entry points:

| File | Role |
| --- | --- |
| `polylogue/api/__init__.py` | Async library facade (`Polylogue`) — deliberately thin |
| `polylogue/config.py` | 5-layer config resolution + inventory-driven diagnostics |
| `polylogue/cli/click_app.py` | Root query-first CLI dispatch |
| `polylogue/operations/specs.py` | High-level archive operations (`operations/archive.py` is just `ArchiveStats`; the real operation logic lives here + `import_operations.py` + contracts) |
| `polylogue/daemon/cli.py` | Daemon runner (`polylogued run`) |

**Working rule:** new semantics go into the substrate (`storage`/`insights`) or
product layer first, then surfaces adapt. Surfaces may not import substrate
internals directly (`docs/plans/layering.yaml` enforces this).

---

## Architecture

### The data model (know this cold)

Identity is **computed, never stored redundantly** — every id is a SQLite
generated column:

- `sessions.session_id = origin || ':' || native_id`
- `messages.message_id = session_id || ':' || COALESCE(native_id, position||'.'||variant_index)`
- `blocks.block_id = message_id || ':' || position`

Three-level content tree **sessions → messages → blocks**, all `STRICT` tables.
Load-bearing columns:

- **`messages.material_origin`** (`core/enums.py`) — the authoredness axis
  `Role` can't express (`human_authored`, `assistant_authored`,
  `operator_command`, `runtime_protocol`, `runtime_context`, `tool_result`,
  `generated_context_pack`, …). This is what makes honest cost/user-word
  accounting possible: Claude Code `role=user` protocol rows are excluded from
  authored-user counts.
- **`blocks.tool_result_is_error` / `tool_result_exit_code`** (index v16
  keystone) — provider-reported outcomes read from structure; `NULL` = unknown,
  never regex-guessed from prose.
- **`actions` is a VIEW**, not a table — it left-joins `tool_use ↔ tool_result`
  blocks by `tool_id`. The queryable "action" relation is derived on read.
- FTS5 is **contentless** (`content=''`, `contentless_delete=1`) over
  `blocks.search_text`, kept in sync by three triggers. `tokenize=unicode61`
  (no porter stemmer in this build — don't change it).
- CHECK constraints are **generated from Python types** —
  `literal_check("status", *get_args(RunStatus))` embeds `typing.Literal` args
  into SQL, so Python type ↔ SQL constraint stay in lockstep.

**Lineage normalization** (`session_links`, index v12+) is the sharpest design
point. Forks/resumes/subagents/auto-compaction physically replay the parent's
prefix, so the writer stores only the child's **divergent tail** plus
`branch_point_message_id` + `inheritance` (`prefix-sharing` | `spawned-fresh`);
reads recompose parent-up-to-branch + child-tail. `branch_point_message_id` is
**deliberately not a FK** — an `ON DELETE SET NULL` would null it during a
parent full-replace's DELETE step (cascade fires before re-INSERT) and
permanently break composition. `session_links` is also the topology-edge table
(the docs' older `topology_edges` name): it persists every parent reference a
parser asserts, even when the parent isn't ingested yet, keyed
`(src_session_id, dst_origin, dst_native_id, link_type)`, resolved on each save
by `resolve_session_links_for_session`. `TopologyEdgeStatus` =
unresolved/resolved/repaired/**quarantined** (cycle-break).

### The five tiers (durability is the axis)

| Tier | ver | durability | holds |
| --- | --- | --- | --- |
| `source.db` | 3 | durable | raw acquired bytes (`raw_sessions`), artifact taxonomy, blob/GC substrate (`blob_refs`, `gc_generations`), hook events, sidecars |
| `index.db` | 24 | **rebuildable** | the whole parsed tree, FTS, `session_links`, cost tables, and all materialized insights |
| `embeddings.db` | 1 | rebuildable | `vec0` virtual table (Voyage 1024-dim), meta, status |
| `user.db` | 6 | **durable, irreplaceable** | unified `assertions`, settings/context receipts, immutable annotation schemas + batch provenance |
| `ops.db` | 1 | disposable | ingest cursors, attempts, `convergence_debt`, cursor-lag samples, daemon events, embed catch-up runs, otlp |

`user.db` is a **single unified `assertions` table** keyed by a closed
`AssertionKind` (mark / tag / correction / annotation / suppression / metadata /
saved_query / recall_pack / workspace_note / note / decision / caveat / lesson /
blocker / handoff / judgment / pathology / …). It collapsed the old separate
overlay tables; `context_policy_json` (default `{"inject":false}`) gates whether
an assertion is injected into agent context. The column is plain `TEXT` so the
vocabulary can grow without a user-tier schema bump. User corrections are
`AssertionKind.CORRECTION` rows here (a legacy `user_corrections` table survives
only as a compat read path for pre-split single-file archives). Versioned
annotation construct definitions live in `annotation_schemas`; independent
label-run provenance lives in `annotation_batches`, while the labels remain
ordinary assertion rows scoped by `annotation-batch:<id>` ObjectRefs.

### Content-hash idempotency

Archive writes are idempotent by content hash (`pipeline/ids.py`,
`core/hashing.py`): SHA-256 over an **NFC-normalized** payload with
None/empty/missing sentinels, hashing title + timestamps + messages + blocks +
attachments (sorted) + session events. It **excludes** user metadata by
construction — tagging/annotating never triggers re-import. Re-ingest with a
matching hash is skipped; a differing hash updates the session and rebuilds
dependent insights.

### Provider detection & parsing

`sources/dispatch.py:detect_provider()` is shape-based, in **tightness order**
(not filename order): structural/document detectors first (browser-capture,
gemini-cli, hermes, antigravity), then Pydantic-validated record checks (Codex,
Claude Code), then loose dict-key checks (ChatGPT, Claude web, Gemini). Insert a
new detector at the tightness level it deserves or an earlier parser claims its
records. `_lower_payload_specs` then recursively lowers a payload into typed
`LoweredPayloadSpec`s (handling bundles, grouped JSONL split by `sessionId`,
drive-like nesting, single-document providers), and `_parse_lowered_spec` routes
each to a concrete parser. A memory-bounded streaming path exists for multi-GiB
Claude Code JSONL. `grok-export` is a reserved origin token with no wired parser
yet.

---

## Runtime

The **daemon owns all writes** (`polylogued run`). Ingest stages:
**acquire → parse → materialize → index** (`reprocess` = parse+materialize+index
without re-acquire; `all` = full). Raw acquire/parse/materialize lives in
`pipeline/services/ingest_batch/`.

The **`DaemonConverger`** (`daemon/convergence.py`) drives *derived-model*
convergence (FTS repair, embedding catch-up, insights) after ingest. Each
`ConvergenceStage` has check/execute, plus optional batch (`check_many`/
`execute_many`) and session-scoped (`check_sessions`/`execute_sessions`, for
retrying `convergence_debt` without re-resolving source paths) variants. Two
deliberate tricks:

- `false_means_pending` — a stage does bounded work and returns `False` to push
  the *remaining* backlog into `convergence_debt` as retry-able, not a failure
  ("insights deferred until quiet").
- Hot-file quiet deferral (`convergence_stages.py`) batches still-appending
  Codex/Claude sessions until a quiet window; embed runs in bounded windows.

CPU-bound stages go to a `ProcessPoolExecutor`; the main process stays the
**sole SQLite writer**. Blob GC uses two independent safety invariants (leases +
snapshot reference check) to bridge the acquire-blob → commit-row window.

### Schema regimes (durability-keyed)

Two evolution regimes, enforced by `devtools lab policy schema-versioning`:

- **Durable tiers** (`source.db`, `user.db`): explicit **additive** numbered SQL
  migrations under `storage/sqlite/migrations/{source,user}/NNN_*.sql`, one
  `PRAGMA user_version` step at a time, behind a **verified backup manifest**.
  Destructive durable changes need a copy-forward design + explicit consent.
- **Derived tiers** (`index.db`, `embeddings.db`): **no migration chain**. A
  schema mismatch rebuilds/blue-green-replaces the tier from source
  (`polylogue ops reset --index && polylogued run`). Bumping their schema edits
  the canonical DDL + a rebuild plan, never an upgrade helper.

Before editing schema, classify the change: metadata-only, index-only,
additive-derived, additive-durable, or semantic-reparse-required. Batch
same-tier bumps from ready Beads before triggering a live rebuild; don't
repeatedly reset+reingest the active archive for isolated index additions.

**If you add any module/file under `polylogue/`**: regenerate the topology
projection or `render all --check` fails — run
`devtools render topology-projection && devtools render topology-status` and
commit the updated `docs/plans/topology-target.yaml` + `docs/topology-status.md`.

---

## Surfaces

- **CLI is query-first** (`cli/click_app.py`): `find QUERY then ACTION`. Verbs:
  `find` / `read` / `analyze` / `mark` / `select` / `delete` / `continue`
  (+ `read --view transcript|messages|…`). Root filters go **before** `find`,
  verb options **after** the action. Use `--origin` (not `-p`/`--provider`),
  `read --all` (there is no `list`/`show`/`stats` verb).
  - **Strict command floor (#1842):** query mode needs *signalled intent* — the
    `find` keyword, a **quoted** expression (single argv token with internal
    whitespace), or **field syntax** (`repo:x`, `since:7d`). A bare *unquoted*
    plain word (`polylogue foo`) raises a `UsageError` with a did-you-mean/`find`
    hint; it does **not** silently search.
  - The query grammar (`archive/query/expression.py`) is a real Lark DSL:
    fielded predicates, booleans, `near:"…"`, count/date ranges, `with <units>`
    projection, and pipeline stages (`sessions where … | group by … | count`)
    over unit sources sessions/actions/messages/observed-events, lowered to SQL.
- **Python API** (`api/__init__.py`): the `Polylogue` facade is deliberately
  thin — it holds config/services and exposes `repository`/`backend`. The rich
  verbs live on the **10-mixin** `SessionRepository`
  (`storage/repository/__init__.py`: archive reads, archive writes, raw,
  vectors, + six insight readers — profile, run-projection, timeline, thread,
  summary, topology) and on `services.py`.
- **MCP** (`mcp/`): the large agent-facing surface (103 tools across
  `server_*.py`, pinned by `tests/unit/mcp/test_server_surfaces.py` against
  `EXPECTED_TOOL_NAMES`) — search/list/get, insights, corrections,
  context/recall, postmortem bundles. This, not the API, is the continuity
  surface. Adding a tool requires updating `EXPECTED_TOOL_NAMES` + a tool
  contract.
- **Insights** (`insights/registry.py`): descriptor-driven — one
  `INSIGHT_REGISTRY` where each `InsightType` declares field accessors + a
  Pydantic query model + operations method + CLI/MCP metadata, driving
  plaintext, JSON, and MCP from one place. `project_origin_payload` renames
  provider-token keys → origin at the output boundary (see Vocabulary).
- **`SessionFilter`** (`archive/filter/filters.py`) is a fluent shell over an
  immutable `SessionQueryPlan` that separates SQL-pushdown from post-filters and
  summaries-from-full loading, plus the `with_units` projection.

---

## Vocabulary: Provider vs Origin vs Source

Three origin-related vocabularies with different scopes (`core/enums.py`,
`core/sources.py`; full table in `docs/provider-origin-identity.md`):

- **`Origin`** — the public source-origin token on query surfaces and read
  payloads: `claude-code-session`, `claude-ai-export`, `chatgpt-export`,
  `codex-session`, `gemini-cli-session`, `hermes-session`,
  `antigravity-session`, `aistudio-drive`, `grok-export`, `unknown-export`.
  **Public filters use `origin`.**
- **`Provider`** — the older provider-wire token (mixes lab/product/source-family
  identity). Still legitimate at wire boundaries (raw export parsing,
  `schemas/providers/`, provider/embedding-provider metadata) but a **leak** on
  public surfaces.
- **`Source`** — richer identity (`family`, `runtime_root`, `originating_lab`).

The provider→origin retirement is **in progress**, not a done rename.
`project_origin_payload` is a transitional shim: internal storage columns
(`session_profiles.source_name`, cost keys) and insight models still speak
provider vocabulary, so public surfaces project to `origin` at the boundary. A
naive rename is unsafe because `GEMINI` **and** `DRIVE` both collapse to
`AISTUDIO_DRIVE` (non-injective). Tracked in Beads **polylogue-9e5.8**
(retirement plan), **polylogue-jnj.7** (CLI help leakage), **polylogue-2qx**
(OriginSpec). Anti-goal: provider wording on source-origin public filters/payloads.

---

## Working Rules (agent workflow)

These override default agent behavior.

### Beads issue tracking

This repo uses `bd` (Beads) for durable task state AND as the devloop: `bd
prime` -> `bd ready` -> claim -> work -> PR -> close with reasons. The former
bespoke conductor packet is archived at `.agent/archive/devloop-2026-07/`
(evidence, never scaffold — do not resurrect it or `devloop-*` scripts). Repo
agent conventions: `.agent/CONVENTIONS.md`; run `.agent/scripts/bd-graph-lint`
before shipping bead-state deltas. Run `bd prime` when task
context, ready work, blockers, or project memory matter. Use `bd ready --json`,
`bd show <id> --json`, `bd update <id> --claim --json`,
`bd close <id> --reason "…" --json`. Create linked Beads issues for discovered
follow-up work rather than leaving markdown TODOs as the source of truth.
`bd dolt push` follows the same policy as `git push` (feature branches / PR
updates after verification; no direct push to protected default).

**Branch-switching resets bd's live query state — this is bd's correct,
documented behavior, not a bug, but it actively fights a workflow that spins
up many short-lived branches.** `post-checkout`/`post-merge` hooks
(`.beads-hooks/`, `bd hooks run ...`) re-import whichever `.beads/issues.jsonl`
is committed on the branch you just checked out into the live database. If
branch A has a bead closed and branch B (checked out later, created earlier
from an older `master`) doesn't have that commit yet, `bd show`/`bd ready` on
branch B will report the bead as still open — nothing is lost (the close is
safe in branch A's git history), but the live query layer is stale until a
commit carrying that state lands on whatever branch you're now on. Concretely
seen this session: a bead closed, then re-opened by a later unrelated
checkout, three separate times, before being caught.

To avoid this:
- **Don't spin up a new dedicated `chore(beads): ...` branch while one is
  already open and unmerged.** Merge (or rebase onto) it first, or add commits
  to the same branch, rather than creating a sibling branch from a
  possibly-stale `master`.
- **Merge bd-only bookkeeping branches immediately** — they are small and
  fast to verify; don't let one sit open while starting unrelated work on
  other branches, since every branch created off `master` in the meantime
  will diverge from it and need its own conflict resolution later.
- **Prefer folding a `bd claim`/`bd close` into the same commit/branch as the
  actual code change** it accompanies, rather than a separate tiny branch per
  mutation — this was the single biggest source of divergent branches this
  session. Reserve a dedicated bookkeeping branch for bd-only changes that
  don't accompany code (e.g. batching several investigation closes together).
- **After any `git checkout`/`git merge`/`git worktree add`, re-verify with
  `bd show <id> --json` before trusting `bd ready`/`bd show` output for a bead
  you just mutated** — treat it as possibly stale relative to your last
  action, the same as any other memory-recalled fact.
- **When resolving a `.beads/*.jsonl` merge conflict, do not run `bd export`
  to "fix" it.** `bd export` (and the pre-commit hook that calls it) writes to
  a FIXED path resolved from bd's own database location, independent of the
  invoking shell's cwd — inside a temporary conflict-resolution worktree this
  silently no-ops on that worktree's own file, leaving literal `<<<<<<<`
  conflict markers in place. Extract both sides directly (`git show
  :2:.beads/issues.jsonl` / `:3:...`), hand-merge bead-by-id preferring
  whichever side has the later `updated_at`, write the result back, then
  `git add`. Verify every line parses as JSON before committing.

### Issue-first for non-trivial work

Open an issue before work that is non-trivial, spans multiple PRs, or introduces
architectural decisions — it defines scope and acceptance criteria. Reference it
from the PR with neutral wording (`Ref #NNN`). Skip issues for self-contained
fixes where the PR body suffices.

**Do not use GitHub resolver keywords** (the close/fix/resolve family) next to
issue numbers in agent-authored PR bodies/comments/commits unless the operator
explicitly asks for that exact PR to change that exact issue's state. Use
`Ref #N` + explicit `Remaining #N scope:` instead.

### Verification — testmon inner loop, never blanket-run

The default path is `devtools verify`: static/generated gates +
**pytest-testmon affected-selection** (only tests whose dependency graph touches
your change; seconds-to-minutes). For a single target: `devtools test <file>` or
`devtools test -k <expr>`.

**Anti-pattern (do NOT):** `devtools test tests/unit/<dir>` over whole
directories, or blanket `pytest tests/unit`. Running broad directories is
effectively the full suite (>1h) and re-confirms tests your change never
touched. A mypy-green, behavior-preserving refactor needs only its
testmon-affected set.

- `mypy --strict` (via `devtools verify`) is the primary net for type/identifier
  refactors — trust it. Config in `pyproject.toml`, no exclude list.
- Seed testmon on a fresh checkout / after harness or dependency changes:
  `devtools verify --seed-testmon --skip-slow`.
- Reserve `devtools verify --all` (full non-integration run) for
  harness/dependency changes or a final pre-PR diagnostic.
- `devtools verify --quick` = format + lint + mypy + `render all --check`
  (no tests); it runs on `git push` via the pre-push hook. It is a fast gate,
  not a substitute for the default baseline before a PR.
- If failures land in files your change didn't touch and testmon didn't select,
  classify as pre-existing/flaky (re-run the exact node) before assuming yours.

Don't treat CI as the first verification pass — anticipate failures locally.

### Schema-touching changes

See [Schema regimes](#schema-regimes-durability-keyed). Durable tiers → numbered
additive migration + backup manifest; derived tiers → edit canonical DDL +
rebuild plan (`polylogue ops reset --index && polylogued run`), never an upgrade
helper (`devtools lab policy schema-versioning` rejects them).

### Commit / PR discipline

All product code lands via **feature branches + squash-merged PRs** to `master`
(protected; no direct pushes). Branch names: `feature/<category>/<desc>`.

- Conventional commit subjects (`feat:`/`fix:`/`refactor:`/`perf:`/`test:`/
  `docs:`/`chore:`). The **PR title is the squash-merge subject** on `master` —
  ≤72 chars, imperative, describes what changed. Ends up as permanent history.
- PR body sections (all required): **Summary**, **Problem** (evidence, not "user
  asked"), **Solution** (modules touched, non-obvious decisions), **Verification**
  (exact commands + the output line that matters, not "tests pass").
- Routine PRs do **not** edit `pyproject.toml` `version` or `CHANGELOG.md` —
  release-please owns those from conventional subjects on `master`.
- **Claim verification:** before writing that something is "unified"/"aligned"/
  "converged"/"complete", grep the diff and check both paths. A claim the code
  doesn't support is worse than no claim. State partial work honestly.
- **Acceptance-criteria honesty:** address each AC as satisfied / deferred (to a
  named follow-up issue) / misframed. Tests are not a substitute for missing
  runtime wiring.
- Stage by path (`git add <file>`), never `git add -A` / `-a` on significant
  changes. Never `--no-verify` unless the operator asked; a hook failure means
  fix the root cause in a **new** commit (don't `--amend` a successful one).

Issues and PR bodies are durable artifacts — write them to stand alone for a
reader with no conversation context (file paths, AC, design references).

---

## Testing essentials

Full detail in `TESTING.md`. Layout: `tests/unit` (~95%), `tests/property`
(Hypothesis), `tests/integration` (slow, protected), `tests/benchmarks`,
`tests/fuzz`. Shared infra in `tests/infra/` (`SessionBuilder`, `make_message`,
`corpus_seeded_db`, schema-driven strategies). `workspace_env` fixture gives
isolated XDG paths + archive root.

- **Prefer `devtools test`** over raw pytest — it runs through the managed
  harness (repo env, single-process by default, live output, stall/runtime
  timeouts, serialized overlapping runs). `POLYLOGUE_PYTEST_WORKERS=N` overrides.
- **Clock hygiene:** timestamp-sensitive tests use the `frozen_clock` fixture
  (`tests/infra/frozen_clock.py`), not the host wall clock. The
  `verify-test-clock-hygiene` lint rejects new direct `datetime.now`/`time.time`
  in tests outside `docs/plans/test-clock-allowlist.yaml`.
- Pytest temp DBs default to `/realm/tmp/polylogue-pytest` (not `/dev/shm`).
  `seeded_db`/`corpus_seeded_db` build a shared DB once under a `.build.done`
  guard — a SIGKILL mid-build leaves a partial DB + set guard →
  `no such table: sessions`; fix with
  `rm -rf /realm/tmp/polylogue-pytest/pytest-polylogue-seeded-*` (and legacy
  `/dev/shm/pytest-polylogue-seeded-*`). Never `pkill` polylogue pytest without
  clearing this.
- Verify-run artifacts land under `.cache/verify/`
  (`current-pytest-{progress,selection,summary}.json`, `-output.log`).

Demo path (private-data-free) for read/search/reader checks:
`polylogue demo seed … && polylogue demo verify …`, or
`polylogue import --demo --wait`.

---

## devtools (the control plane)

`devtools` owns repo readiness: generated-surface rendering, verification,
validation-lane dispatch, packaging, PR-readiness. Domain semantics live in
lab/schema/scenario/insight modules; `devtools` commands are thin entrypoints.

Core loop:

- `devtools status` — repo state, generated-surface drift, next steps.
- `devtools render all [--check]` — refresh/verify every generated surface after
  changing docs, CLI help, or schema. **Gotcha:** `render all --check` can print
  per-surface `sync OK` yet still exit 1 — grep the output for `out of sync`,
  don't trust the tail line.
- `devtools verify [--quick|--all|--lab|--seed-testmon]` — see
  [Verification](#verification--testmon-inner-loop-never-blanket-run).
- `devtools test <sel>` — focused pytest through the managed harness.
- `devtools lab …` — executable schema/provider/pipeline/lane checks.
- `devtools workspace …` — task history, frontier, worktree-gc, evidence.

Adding a devtools command: add a `CommandSpec` to `devtools/command_catalog.py`,
implement in `devtools/<name>.py`, run `devtools render devtools-reference`.

Local state: `.cache/` (disposable) and `.local/` (untracked outputs). Keep new
outputs there, not new top-level roots.

---

## Cloud lane (Claude Code Web / Codex Cloud)

Well-suited to cloud sandboxes: pure Python, all paths overridable via
`POLYLOGUE_ARCHIVE_ROOT`. Bootstrap: `.claude/setup.sh`; env from
`.claude/settings.json` (`POLYLOGUE_ARCHIVE_ROOT=/tmp/polylogue-archive`,
`POLYLOGUE_FORCE_PLAIN=1`, `HYPOTHESIS_PROFILE=ci`).

- **Safe:** `uv run pytest tests/unit -q` / `tests/property -q`;
  `ruff check`/`format --check`; `mypy polylogue`; `devtools verify` (slow);
  `render all --check`; `polylogued run --no-api --no-watch --no-browser-capture`
  against synthetic fixtures only.
- **Never in cloud:** uploading a real `~/.claude/projects/` or
  `~/.codex/sessions/` corpus (fixtures only); browser-capture flows; any
  `/realm/data/...` path (not mounted). Privacy tier follows the running
  account — confirm before enabling cloud lanes on sensitive repos
  (`docs/cloud-agents.md`).

---

## Gotchas (hard-won)

- `render all --check` exits 1 even while printing `sync OK` per surface — grep
  for `out of sync`.
- Adding a `polylogue/` module without regenerating the topology projection
  breaks `render all --check` (see [Schema regimes](#schema-regimes-durability-keyed)).
- New Click params on query verbs must go **last** — a positional shift silently
  reroutes args.
- New MCP tool → update `EXPECTED_TOOL_NAMES` (lives in `tests/infra/mcp.py`,
  103 tools currently) + tool contract, or discovery tests fail.
- New `AssertionKind` is schema-free (`TEXT`, no CHECK) but its enum is embedded
  in `render openapi` + `render cli-output-schemas` — regenerate them.
- Per-PR CI **skips the heavy `test` suite** (runs post-merge on master). A green
  `gh pr checks` does **not** mean tests ran — verify locally with
  `devtools test <files>`. Required merge checks are `lint` + `test`; an
  `UNSTABLE`/neutral `mergeStateStatus` is usually the test-skip, not a failure —
  inspect `statusCheckRollup`.
- Committing from a linked worktree: a hook aborts if you `cd`'d into the main
  checkout from inside a worktree (worktree-escape detector, #1211); set
  `POLYLOGUE_ALLOW_WORKTREE_ESCAPE=1` for legitimate cross-worktree flows.
- `AGENTS.md` is a **symlink to this file** (`CLAUDE.md`) — edit CLAUDE.md, never
  AGENTS.md; there is no render step.

---

## Reference docs

Read on demand (paths relative to repo root):

| Topic | Doc |
| --- | --- |
| System rings, data flow, provider table | `docs/architecture.md` |
| Invariants, hot files, schema-version history, extension points | `docs/internals.md` |
| Target shape + architectural decision log | `docs/architecture-spine.md` |
| Execution control center hotspot map + decomposition sequence | `docs/architecture-hotspots.md` |
| Contributor workflow (branches, PRs, hooks, releases) | `CONTRIBUTING.md` |
| Full testing reference | `TESTING.md` |
| devtools command catalog | `docs/devtools.md` |
| Cloud-agent setup + privacy | `docs/cloud-agents.md` |
| Provider/Origin/Source vocabulary table | `docs/provider-origin-identity.md` |
| Retrieval lanes + search semantics | `docs/search.md` |
| Public Python domain models | `docs/data-model.md` |
| Daemon convergence + threat model | `docs/daemon.md`, `docs/daemon-threat-model.md` |
| Cost/usage model | `docs/cost-model.md` |
| CLI reference (generated) | `docs/cli-reference.md` |
| MCP reference | `docs/mcp-reference.md` |
| Normalized-session material protocol v1 (Sinex-independent wire format) | `docs/material-protocol-v1.md` |

```

## Complete selected Bead record for `polylogue-t8t`

```json
[
  {
    "_type": "issue",
    "acceptance_criteria": "1. Seven executable scenario declarations cover resume, forensic debug, prior art, decision lookup, postmortem, cost, and self-inspection, plus the parallel-Claude incident variant. 2. Every scenario contains sparse original wording, required fact/coverage inventory, independently computed target population or answer, allowed discovery state, expected evidence refs, plan equivalence rules, paging/cancellation/resource bounds, and stop conditions. 3. Baseline real-agent transcripts and server receipts prove the harness can classify source/coverage, discovery/formulation, plan/pushdown, execution/cancellation, projection/rendering, and reasoning failures without confusing them. 4. The incident oracle grades the original calls using exposed curriculum: candidate list reasonable but physically oversized; operator phrase a wrong-corpus assumption; Sonnet a weak lexical proxy induced by missing structure; sessions-only query product-induced because shipped instructions advertised it; later correct topology/delegation calls are execution failures. 5. Mutation fixtures cover lost request-state continuation, capped pseudo-total search, identical-call topology replay, hidden fact/grammar discovery, missing source coverage, and unreasonable-query classification. 6. z9gh.7 consumes this catalog as the sole terminal pass/fail gate; this bead does not duplicate the final all-green walk.",
    "comment_count": 0,
    "created_at": "2026-07-03T15:15:57Z",
    "created_by": "Sinity",
    "dependencies": [
      {
        "created_at": "2026-07-15T20:43:43Z",
        "created_by": "Sinity",
        "depends_on_id": "polylogue-s7ae",
        "issue_id": "polylogue-t8t",
        "metadata": "{}",
        "type": "relates-to"
      },
      {
        "created_at": "2026-07-15T19:22:09Z",
        "created_by": "Sinity",
        "depends_on_id": "polylogue-z9gh",
        "issue_id": "polylogue-t8t",
        "metadata": "{}",
        "type": "parent-child"
      }
    ],
    "dependency_count": 0,
    "dependent_count": 1,
    "description": "Polylogue needs a durable black-box specification for seven operator/model continuity jobs: resume work, forensic file/session lookup, prior-art retrieval, decision lookup, failure postmortem, cost/usage audit, and live self-inspection. Individual function tests cannot state what evidence a cold model should discover or distinguish product failure from unreasonable model behavior. This bead owns reusable scenarios, independent target answers, and a failure-classification harness. z9gh.7 owns the terminal run after mandate mechanisms land; a Claude Code Workflow is only one source artifact inside one scenario.",
    "design": "Add polylogue/product/continuity_scenarios.py as the canonical declaration registry, using the existing polylogue.scenarios ScenarioSpec/ScenarioMetadata protocols and referencing, rather than duplicating, product/workflows.py query-action recipes. Each ContinuityScenarioSpec declares sparse prompt, required fact/coverage inventory, independent oracle builder, allowed discovery state, canonical and equivalent plan families, result semantics, page/cancel/resource budgets, stop conditions, and failure taxonomy. Add devtools/continuity_replay.py as the black-box runner: it launches an isolated MCP server/client against a deterministic demo or privacy-safe incident fixture, records discovery/tool calls/server receipts, compares answer refs with an oracle built directly from fixture/source and repository evidence, and emits one machine JSON artifact. Store deterministic fixture manifests/oracle inputs under tests/data/continuity; never build the expected answer by calling the production query route under test. The parallel-Claude scenario models provider Workflow artifacts only as source records, then grades normalized run/task/call/attempt/session/claim/effect facts. tests/unit/product/test_continuity_scenarios.py validates declarations and mutation classification; tests/integration/test_continuity_replay.py exercises the real MCP walk. z9gh.7 owns the live terminal run, not this bead.",
    "id": "polylogue-t8t",
    "issue_type": "task",
    "labels": [
      "area:context",
      "area:legibility",
      "area:mcp",
      "area:query",
      "delivery:C-read-evidence-contract",
      "delivery:D-agent-context-coordination",
      "horizon:frontier",
      "lane:agent-coordination",
      "lane:read-contracts",
      "spine",
      "wave:2"
    ],
    "metadata": {
      "frontier": "active",
      "frontier_program_ref": "polylogue-z9gh"
    },
    "notes": "[Delivery upgrade 2026-07-07T00:05:00Z] Release=D-agent-context-coordination; lane=agent-coordination; readiness=A-implementation-ready; proof=two-agent separate-worktree proof with before/after coordination envelopes. Original readiness=A-implementation-ready.\n[Prework packet 2026-07-07] Static execution packet (anchors, mechanism, plan, tests, verification): .agent/scratch/corpus-gpt-pro-2026-07-07/prework-v2/task_packets/task_packets/070_polylogue_t8t.md (depth: bead-localized-from-export; urgency: T2-foundation-before-feature-proof). Generated from master @ 8a975a40 2026-07-06 — verify source anchors before coding; line numbers are snapshot-relative.\n[2026-07-15 mandate audit] Elevated from P2 to P0. This bead is not optional cookbook polish: the missing end-to-end walk allowed individually tested MCP tools to ship while the actual continuity job was unusable. polylogue-z9gh is the incident/recovery program; this bead owns the durable black-box acceptance evidence.\nDogfood correction 2026-07-15: black-box walks must audit whether the model query was reasonable given discovery, which information was absent, and where that absence should have been exposed. The independent target answer separates product failure from agent reasoning failure.\n[2026-07-15 incident classification oracle] Grade the original calls explicitly rather than treating all model behavior as product failure: candidate list=reasonable but oversized physical request; exact operator phrase=wrong-corpus assumption; Sonnet text=weak lexical proxy induced by absent structured model/material discovery; nonterminal query_units expression=malformed under hidden grammar. Then prove the cold-model replay recovers: discover model/material/orchestration dimensions, formulate a terminal canonical plan, receive a useful first page plus complete continuation, and reach the exact coordinator/run population. The oracle must also include later correct-ID topology and delegation calls, which failed despite correct formulation, so agent reasoning cannot mask transport/executor defects.\n[2026-07-15 query-grade correction] Treat the original nonterminal query_units call as product-induced and reasonable under available instructions. The installed Polylogue skill advertised the same sessions-where-only shape for failure and file-touch recipes, while the parser only accepts sessions as a scope before a terminal unit. The replay must record both the exposed skill text and executable catalog state; mutation/parity tests fail if any shipped skill/prompt/example teaches a plan rejected by its live tool. This supersedes the earlier shorthand that classified the call only as model-malformed.\n[2026-07-15 transport oracle detail] Add mutation cases for each non-progressing recovery class: a filter-rich list whose wrapper loses all request state; a search with no offset/cursor and a capped pseudo-total; and a recursive topology whose continuation repeats the identical oversized call. A replay is successful only if every logical row/node/edge can be enumerated exactly once; a metadata envelope plus a same-call retry is not recovery.\nTerra-readiness correction 2026-07-15: bound the abstract scenario registry to product/continuity_scenarios.py, the existing scenario and workflow registries, a concrete devtools black-box runner, independent fixture-derived oracles, and named tests.",
    "owner": "ezo.dev@gmail.com",
    "priority": 0,
    "status": "open",
    "title": "Declare continuity replay scenarios and independent known-answer oracles",
    "updated_at": "2026-07-15T20:45:32Z"
  },
  {
    "created_at": "2026-07-15T20:43:43Z",
    "created_by": "Sinity",
    "depends_on_id": "polylogue-s7ae",
    "issue_id": "polylogue-t8t",
    "metadata": "{}",
    "type": "relates-to"
  },
  {
    "created_at": "2026-07-15T19:22:09Z",
    "created_by": "Sinity",
    "depends_on_id": "polylogue-z9gh",
    "issue_id": "polylogue-t8t",
    "metadata": "{}",
    "type": "parent-child"
  }
]
```

## Supplied task packet

```markdown
# 070. polylogue-t8t — Agent workflow catalog: walk the seven core flows end-to-end, fix what breaks

Priority/type/status: **P2 / task / open**. Lane: **06-agent-context-coordination**. Release: **D-agent-context-coordination**. Readiness: **implementation-ready-after-local-inspection**.

## What the bead says

Affordances exist in pieces; nobody has walked the actual workflows end-to-end: (1) RESUME — arrive in repo, recover context, continue; (2) FORENSIC DEBUG — did a past session touch this; (3) PRIOR ART — has anything explored this approach; (4) DECISION LOOKUP — what did we decide and why; (5) POSTMORTEM WRITE — close the loop after failure (37t.7); (6) COST CHECK — what has this repo/task cost; (7) SELF-INSPECTION — agent reads its own live session mid-flight (raw-log 05-28; needs hook-fresh ingest + get_session on self). Walk each as a real agent over MCP against the live archive, time it, file every gap — the empirical complement to the cookbook (pj8).

## Existing design note

(1) Each flow = a workflow registry entry (product/workflows.py REQUIRED_WORKFLOW_IDS) with intent, tool sequence, envelope shapes, round-trip token cost, latency budget (20d.14). (2) Execute from a real Claude Code session via polylogue MCP on this machine; archive the walk transcript as evidence. (3) Verify-or-refute known suspects: self-inspection freshness (searchable within seconds?), search-within-session ergonomics, resume-brief token cost vs preamble budget, cost-check cold latency. (4) Output: per flow PASS+timing or a filed bead; catalog doc renders from the registry (drift-checked) and becomes the reference the cookbook prompts point at.

## Acceptance criteria

Seven registry entries; seven archived walk transcripts; every gap filed as a linked bead; rendered catalog lists measured tokens+latency per flow; self-inspection demonstrates an agent reading its own in-progress session.

## Static mechanism / likely defect

Issue description localizes the mechanism: Affordances exist in pieces; nobody has walked the actual workflows end-to-end: (1) RESUME — arrive in repo, recover context, continue; (2) FORENSIC DEBUG — did a past session touch this; (3) PRIOR ART — has anything explored this approach; (4) DECISION LOOKUP — what did we decide and why; (5) POSTMORTEM WRITE — close the loop after failure (37t.7); (6) COST CHECK — what has this repo/task cost; (7) SELF-INSPECTION — agent reads its own live session mid-flight (raw-log 05-28; needs hook-fresh ingest + get_session … Design direction: (1) Each flow = a workflow registry entry (product/workflows.py REQUIRED_WORKFLOW_IDS) with intent, tool sequence, envelope shapes, round-trip token cost, latency budget (20d.14). (2) Execute from a real Claude Code session via polylogue MCP on this machine; archive the walk transcript as evidence. (3) Verify-or-refute known suspects: self-inspection freshness (searchable within seconds?), search-within-session ergo…

## Source anchors to inspect first

- `polylogue/coordination/envelope.py` — Coordination envelope model exists; harden it as the shared payload.
- `polylogue/coordination/payloads.py` — Coordination payload types should stay small and evidence-ref oriented.
- `polylogue/coordination/rendering.py` — Rendered advisories should be scheduler-mediated, not chat spam.
- `tests/unit/coordination/test_envelope.py` — Existing envelope tests are the starting verification lane.
- `polylogue/mcp/server_prompts.py:219` — MCP prompt registration exists and can surface cookbook/roles.
- `polylogue/cli/commands/agents.py` — CLI agent commands are the operator-facing entry point.
- `polylogue/storage/sqlite/archive_tiers/user_write.py:31` — ASSERTION_DEFAULT_STATUS is ACTIVE, so missing status currently means trusted active.
- `polylogue/storage/sqlite/archive_tiers/user_write.py:641` — upsert_blackboard_note passes author_kind and no explicit status into upsert_assertion.
- `polylogue/storage/sqlite/archive_tiers/user_write.py:901` — upsert_assertion is the single write chokepoint to patch.
- `polylogue/api/contracts/assertions.py` — Check public assertion request/response contract after changing default status behavior.

## Implementation plan

1. (1) Each flow = a workflow registry entry (product/workflows.py REQUIRED_WORKFLOW_IDS) with intent, tool sequence, envelope shapes, round-trip token cost, latency budget (20d.14).
2. (2) Execute from a real Claude Code session via polylogue MCP on this machine
3. archive the walk transcript as evidence.
4. (3) Verify-or-refute known suspects: self-inspection freshness (searchable within seconds?), search-within-session ergonomics, resume-brief token cost vs preamble budget, cost-check cold latency.
5. (4) Output: per flow PASS+timing or a filed bead
6. catalog doc renders from the registry (drift-checked) and becomes the reference the cookbook prompts point at.

## Tests to add

- Acceptance proof: Seven registry entries
- Acceptance proof: seven archived walk transcripts
- Acceptance proof: every gap filed as a linked bead
- Acceptance proof: rendered catalog lists measured tokens+latency per flow
- Acceptance proof: self-inspection demonstrates an agent reading its own in-progress session.

## Verification commands

- `devtools test <focused tests added for this bead>`
- `devtools test tests/unit/coordination tests/unit/mcp -q`

## Pitfalls

- Do not add direct context injection or trusted memory writes outside the scheduler/candidate policy.

## Expected end state

A coding agent can point to a focused failing test, a small patch at the shared seam, and a verification artifact proving the bead's acceptance criteria without inventing a new product direction.

```

## Interpretation applied

Later Bead notes were treated as authoritative over older packet language. The implementation therefore delivers a deterministic black-box replay/oracle catalog with two deep public-route scenarios and a strict five-row expansion plan, rather than fabricating seven live operator transcripts.
