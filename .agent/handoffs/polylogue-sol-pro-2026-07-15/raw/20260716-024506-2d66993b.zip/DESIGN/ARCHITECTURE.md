# Continuity replay architecture

## Product seam

The implementation is added at `polylogue/scenarios/continuity_replay` and colocated with the repository's native scenario/verification vocabulary. The canonical `ContinuityScenario` declaration sits above the existing `ScenarioSpec` vocabulary; when a native `ScenarioSpec` definition is present, `native.py` provides a strict constructor bridge and requires explicit overrides for runner-specific required fields instead of inventing doubles.

The execution flow is intentionally one-way:

1. A source fixture contains deterministic, public, normalized records using the repository's block vocabulary (`tool_name`, `tool_input`, `tool_result`, and `tool_result_is_error`).
2. An archive seeder imports those records and emits an `ArchiveCheckpoint` receipt with fixture digest and record IDs.
3. A registered MCP client calls the declared public tool. The two implemented routes are `build_context_image` and `get_postmortem_bundle`.
4. The source oracle independently reopens the immutable fixture, resolves facts by record ID plus RFC 6901 pointer, verifies record and value SHA-256 anchors, and only then grades the public payload.
5. An optional model answer is graded only after the surface payload is proven to contain the target evidence. This makes a plausible wrong answer a model-behavior failure rather than a query failure.

## Typed kernel

`models.py` defines the seven operator/model jobs, scenario maturity, source selectors, immutable provenance, archive/surface/model checkpoints, findings, and verdicts. `oracle.py` owns canonical serialization, privacy guards, source resolution, visibility matching, and classification. `replay.py` owns dependency protocols, FastMCP-compatible result normalization, schema-aware semantic request adaptation, and the archive → public tool → optional model sequence. `catalog.py` enforces one row per job and at least the two required implemented routes.

## Failure partition

| Verdict | Earliest failed boundary | Meaning |
| --- | --- | --- |
| `oracle_evidence_failure` | immutable fixture | Target record/pointer/hash is missing or fixture violates deterministic/private-data-free rules. |
| `archive_failure` | ingestion checkpoint | Fixture was not indexed intact or source receipt does not match the oracle fixture. |
| `surface_failure` | registered MCP boundary | Tool is absent, errors, changes schema incompatibly, or returns a non-canonicalizable payload. |
| `query_failure` | route evidence selection | Surface is healthy but omits at least one independently anchored fact. |
| `unreasonable_model_behavior` | answer synthesis | Complete target evidence was visible, but the answer omits it, contradicts it, selects a decoy, fails, or cannot attest to the consumed payload. |
| `pass` | all exercised boundaries | Every source-anchored fact is visible and, when supplied, reflected by the model answer. |

## Public-surface binding

`tests/continuity_public_surface_binding.py` isolates HOME/XDG/Polylogue paths, resolves the real registered FastMCP server after isolation, reads published tool schemas, and seeds normalized records through a registered ingestion/import/mutation tool. A guarded isolated-CLI fallback is provided when ingestion is exposed by the product CLI rather than MCP. It never substitutes a query result or reads oracle facts.
