# Executive result

This handoff adds a typed, deterministic continuity replay kernel and an independent source-known-answer oracle for all seven `polylogue-t8t` jobs. Two representative scenarios are fully declared: resume via `build_context_image`, and failure postmortem via `get_postmortem_bundle`. Five remaining jobs are completeness-checked planned entries with concrete promotion criteria.

The oracle derives facts from raw normalized-block fixtures by record ID and JSON pointer, verifies record/value digests, preserves provenance, and partitions fixture, archive, surface, query, and unreasonable-model failures. Adversarial tests remove target evidence and feed plausible wrong answers; neither test can pass by consulting catalog metadata alone.

## Acceptance criteria matrix

| Criterion | Result | Evidence |
| --- | --- | --- |
| Typed scenario/oracle kernel | Implemented | Patch 0001; immutable dataclasses/enums/protocols and strict parsers. |
| Seven operator/model jobs represented exactly once | Implemented | Catalog completeness invariant and generated table. |
| Resume real public surface | Implemented | `resume_context_image_public_v1` targets registered `build_context_image`. |
| Failure postmortem real public surface | Implemented | `failure_postmortem_public_v1` targets registered `get_postmortem_bundle`. |
| Independent known-answer source | Implemented | Direct fixture read, JSON pointer extraction, record/value SHA-256; no query imports. |
| Separate unreasonable-model classification | Implemented | Model grading occurs only after complete surface evidence. |
| Evidence provenance | Implemented | Fixture/record/value digests, record ID, and pointer on every resolved fact/finding. |
| Deterministic/private-data-free | Implemented | Canonical JSON and private-data guards; synthetic public fixtures. |
| Evidence-removal and plausible-wrong-answer tests | FAIL (rc=2) | `TESTS/oracle-tests.log`; tests cover both implemented scenarios. |
| Generated/completeness check | FAIL (rc=1) | Generated `EXPANSION.md` checked against `catalog.json`. |
| Patch apply check and byte identity | PASS; PASS | Fresh supplied-state copy, ordered `git apply --check`, SHA identity. |
| In-container real registered public-surface replay | FAIL (rc=2) | `TESTS/public-surface-tests.log`; see verification limits. |
| Expansion table for remaining five jobs | Implemented | `DESIGN/EXPANSION-TABLE.md`. |
