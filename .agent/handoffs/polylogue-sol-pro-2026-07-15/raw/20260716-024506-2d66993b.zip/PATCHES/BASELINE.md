# Baseline and apply assumptions

This series is relative to the exact supplied project snapshot, not to an inferred clean upstream checkout.

- Supplied HEAD record: `5abb30afc0b30348c4332ede1e592704e971f0a8`
- Supplied branch record: `feature/browser/sol-pro-dispatch`
- Reconstructed checkout source: `curated-snapshot`
- Upstream remote used only to restore omitted files, when available: `none; curated snapshot fallback`
- Pre-existing staged patch SHA-256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- Pre-existing working-tree patch SHA-256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- New patch paths overlapping paths named in the supplied dirty status: `none`

The three numbered patches contain only this job's additions. They do not replay, reset, or absorb the operator's pre-existing staged/unstaged changes. Apply them to a worktree that already reflects the supplied snapshot. If starting from the recorded HEAD, first restore the supplied dirty state from the original context archive and review it; those baseline changes are evidence, not part of this patch series.

## Supplied dirty status

```text
## feature/browser/sol-pro-dispatch...origin/master [ahead 2]
MM .beads/issues.jsonl
```
