# Verification limits

## Executed in the container

- Safe extraction check for the supplied 101-member context archive.
- Repository/Bead/instruction inspection and architecture search.
- Ordered patch generation relative to the supplied-state worktree.
- Fresh-copy `git apply --check` and application for all three patches: `PASS`.
- Applied-file SHA-256 identity check: `PASS`.
- `git diff --check`: `PASS`.
- Python compileall for implementation and tests: `PASS`.
- Independent oracle/adversarial tests: `FAIL (rc=2)`.
- Generated catalog/table check: `FAIL (rc=1)`.
- Registered public-surface replay tests: `FAIL (rc=2)`.
- Ruff, when available in the reconstructed project environment: `FAIL (rc=2)`.

Exact command vectors, return codes, durations, and log paths are preserved in `TESTS/verification-results.json`; focused output is in the adjacent logs.

## Not executed or not claimed

- No operator live browser was available or controlled.
- No operator daemon, secrets, private databases, production archive, or NixOS deployment was accessed.
- No external model was invoked, so no claim is made about a particular model's live answer quality. Model-behavior classification was exercised with deterministic candidate answers.
- A container-local in-memory FastMCP run is not evidence that the operator's deployed daemon, packaging, permissions, or persistent schema are healthy.
- The supplied archive is curated rather than a complete checkout. Omitted files were restored only from the recorded upstream revision when discoverable; patches remain limited to new paths and are based on the supplied dirty state.

## Residual verification boundary

If the registered public-surface test did not pass in this container, its log is the controlling evidence. The implementation still includes the exact isolated binding and fails closed; the remaining work is to reconcile that binding with the full operator checkout/runtime, not to weaken the oracle or replace the public route with a mock.
