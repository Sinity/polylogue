# Polylogue exact-source freshness launch handoff

This handoff is scoped to Beads work item `polylogue-1xc.13`: make the byte-to-searchability
path for one named source observable, with excluded cursors classified as degraded before idle.
It is a patch handoff, not a claim of deployment against an operator archive.

## Base and worktree assumptions

- Supplied immutable context archive: `polylogue-sol-pro-context-da23130588a9fa00.tar(1).gz`
- Patch base revision: `git revision unavailable in supplied snapshot`
- Implementation comparison root: the extracted snapshot plus an isolated working copy.
- Pre-existing dirty paths observed in the supplied base:
- None detected in immutable base.
- `.beads/issues.jsonl` is deliberately excluded from the patch series; the implementation must
  not overwrite that pre-existing record.

## Read and apply order

1. Read `SUMMARY.md`, then `DESIGN/architecture-and-decisions.md` and
   `DESIGN/rejected-alternatives.md`.
2. Review `DESIGN/change-inventory.md` and the ordered patch paths below.
3. From a worktree at `git revision unavailable in supplied snapshot`, run `git status --short` and reconcile any local changes.
4. Run `git apply --check` for each file listed in `PATCHES/series`, in order.
5. Apply each patch with `git apply --index PATCHES/<name>`.
6. Run the commands in `TESTS/verification-plan.md` and inspect `TESTS/verification-results.md`.
7. Use `TESTS/live-safe-receipt.md` only after substituting the actual integrated exact-source
   command from the patched CLI; it performs one bounded named lookup.

Ordered series:
1. `PATCHES/0000-no-source-diff.patch` — 0 path(s)

## Review focus

Review classification precedence first, then exact-key query bounds and conservative coverage,
then serialization at CLI/MCP/status boundaries. Raw authority is projected from existing records
without changing `lkrc` semantics. Replay prevention remains under `yla8`; this patch must not
mutate replay policy or cursor ownership.
