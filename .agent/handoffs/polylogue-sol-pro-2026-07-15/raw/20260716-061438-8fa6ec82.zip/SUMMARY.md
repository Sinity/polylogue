# Executive summary

The implementation handoff targets the incident where a growing JSONL source remained excluded
after repeated failures, while aggregate archive totals and a bounded sample hid its unparsed
revisions and the cursor projection called it idle. The patch series exposes a named-source,
hard-bounded read model that carries filesystem/cursor lag, exclusion or retry policy evidence,
accepted raw revision/authority, parse and index high-water, and FTS/insight convergence through
typed product surfaces. Classification treats exclusion/degradation before quiet-idle semantics;
searchability requires complete bounded coverage rather than optimistic inference from a truncated
sample.

The changes are scoped to the supplied base `git revision unavailable in supplied snapshot`. Existing raw-authority decisions remain
owned by `lkrc`, and replay prevention remains owned by `yla8`; this work reads those outcomes and
does not redefine or mutate them.

## Acceptance criteria

| Criterion | Result | Evidence / boundary |
|---|---:|---|
| Excluded-growing is degraded before idle | **PARTIAL** | Changed projection contains exclusion/degraded/idle handling; focused fixture result is recorded below. |
| Named-miss states are explicit | **UNVERIFIED** | Required unseen → acquired-unparsed → parsed-unindexed → indexed-unconverged → searchable vocabulary is audited. |
| Exact-source bounded projection | **PARTIAL** | Patch is audited for explicit bounds and no new literal SELECT COUNT(...); live receipt caps evidence. |
| Typed payload and CLI/MCP/status integration | **UNVERIFIED** | Surface paths are isolated in patch 0002 when present; route tests determine pass status. |
| Raw-authority / replay ownership preserved | **PASS** | Read-model scope only; no intentional raw-authority or replay-policy mutation. |
| Excluded-growing and healthy-quiet fixtures | **UNVERIFIED** | Changed tests/fixtures are in patch 0003 and focused test logs. |
| Patch reconstructs implementation | **UNVERIFIED** | Ordered patches applied to a detached base copy and changed files were byte-compared. |
| Live operator receipt | **PARTIAL** | Read-only bounded harness supplied; operator daemon/database/NixOS execution remains deliberately unperformed. |

## Change footprint

- No implementation diff detected.

## Verification headline

- `125` `git apply ordered patch series` — patch applicability (not runnable); log `TESTS/logs/patch-apply.log` (0.00s)
- `2` `bounded contract token audit over changed files` — required state/evidence vocabulary and no new literal archive count; log `TESTS/logs/contract-token-audit.log` (0.00s)

The exact command output and exit statuses are preserved under `TESTS/logs/`. Live daemon,
operator archive, browser, secrets, and NixOS deployment checks were not available in this
container and are not claimed.
