# Live-safe named-source receipt

This procedure probes one operator-selected source. It does not enumerate sources,
count archive tables, or request an unbounded sample. Run the integrated CLI/MCP
exact-source projection through the harness and substitute its actual command syntax:

```sh
python TESTS/live-safe-receipt.py \
  --source /absolute/path/to/source.jsonl \
  --limit 8 \
  --output excluded-growing.receipt.json \
  -- polylogue <exact-source-command> --source-path '{source}' --sample-limit '{limit}' --json
```

Before using it live, replace `<exact-source-command>` with the command documented by
the applied implementation. The harness rejects globs, caps evidence at 32, invokes the
projection once, and records the exact filesystem stat plus returned typed payload.

For an excluded source whose file has grown beyond the cursor offset/observed size,
the receipt must show degraded health before any idle classification, a positive byte
lag, exclusion policy reason/failure count, and a non-searchable pipeline state until
downstream convergence is evidenced. For a healthy quiet source, filesystem size and
cursor high-water should agree, exclusion/retry evidence should be absent, and idle may
be reported only without degradation. `searchable` is valid only when bounded coverage
is complete and parse, index, FTS, and insight evidence all converge.
