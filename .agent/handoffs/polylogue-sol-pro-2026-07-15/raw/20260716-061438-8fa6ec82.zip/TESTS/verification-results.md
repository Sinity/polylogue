# Verification results

- `125` `git apply ordered patch series` — patch applicability (not runnable); log `TESTS/logs/patch-apply.log` (0.00s)
- `2` `bounded contract token audit over changed files` — required state/evidence vocabulary and no new literal archive count; log `TESTS/logs/contract-token-audit.log` (0.00s)

Exit code 0 means the command passed in this container. Exit code 125 means the check was structurally unavailable; 124 means timeout. Full output is under `TESTS/logs/`.
