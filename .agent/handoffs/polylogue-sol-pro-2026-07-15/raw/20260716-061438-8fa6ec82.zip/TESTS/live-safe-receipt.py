\
        #!/usr/bin/env python3
        """Bounded, read-only receipt harness for one exact Polylogue source.

        The harness never enumerates archive rows. It stats one explicit filesystem path,
        runs the operator-supplied exact-source projection command once, validates the
        JSON envelope, and saves a receipt. Use {source} and {limit} placeholders in the
        command after `--`.
        """
        from __future__ import annotations
        import argparse, json, os, pathlib, subprocess, sys, time

        ALLOWED_STATES = {
            "unseen", "acquired-unparsed", "acquired_unparsed",
            "parsed-unindexed", "parsed_unindexed",
            "indexed-unconverged", "indexed_unconverged", "searchable",
        }

        def main() -> int:
            parser = argparse.ArgumentParser()
            parser.add_argument("--source", required=True, help="Exact named source path; no globs")
            parser.add_argument("--limit", type=int, default=8, help="Evidence cap, 1..32")
            parser.add_argument("--output", default="named-source-receipt.json")
            parser.add_argument("command", nargs=argparse.REMAINDER,
                                help="After --, exact-source CLI command containing {source} and {limit}")
            args = parser.parse_args()
            if not (1 <= args.limit <= 32):
                parser.error("--limit must be between 1 and 32")
            if any(ch in args.source for ch in "*?[]"):
                parser.error("globs are forbidden; provide one exact source path")
            source = pathlib.Path(args.source).expanduser().resolve(strict=False)
            if not args.command:
                parser.error("provide the integrated Polylogue exact-source command after --")
            command = args.command[1:] if args.command and args.command[0] == "--" else args.command
            rendered = [part.replace("{source}", str(source)).replace("{limit}", str(args.limit)) for part in command]
            if not any(str(source) in part for part in rendered):
                parser.error("command must include a {source} placeholder")
            before = None
            try:
                st = source.stat()
                before = {"size_bytes": st.st_size, "mtime_ns": st.st_mtime_ns, "is_file": source.is_file()}
            except FileNotFoundError:
                before = {"missing": True}
            started = time.time_ns()
            proc = subprocess.run(rendered, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  timeout=60, check=False)
            finished = time.time_ns()
            if proc.returncode != 0:
                sys.stderr.write(proc.stderr)
                return proc.returncode
            try:
                payload = json.loads(proc.stdout)
            except json.JSONDecodeError as exc:
                sys.stderr.write(f"projection did not emit JSON: {exc}\n")
                return 65
            state = payload.get("state") or payload.get("freshness_state") or payload.get("pipeline_state")
            if state is not None and str(state).lower() not in ALLOWED_STATES:
                sys.stderr.write(f"unexpected named-source state: {state!r}\n")
                return 66
            samples = payload.get("samples") or payload.get("evidence") or []
            if isinstance(samples, list) and len(samples) > args.limit:
                sys.stderr.write(f"projection exceeded evidence limit: {len(samples)} > {args.limit}\n")
                return 67
            receipt = {
                "source_path": str(source), "stat_before": before,
                "command": rendered, "sample_limit": args.limit,
                "started_ns": started, "finished_ns": finished,
                "projection": payload,
            }
            pathlib.Path(args.output).write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
            print(args.output)
            return 0

        if __name__ == "__main__":
            raise SystemExit(main())
