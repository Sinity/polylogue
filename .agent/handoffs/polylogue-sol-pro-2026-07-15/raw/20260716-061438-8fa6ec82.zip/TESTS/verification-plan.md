# Verification plan

Run from a clean checkout of `git revision unavailable in supplied snapshot` after applying `PATCHES/series` in order.

1. `git diff --check` on the applied change.
2. Compile every changed Python file when applicable.
3. Run each changed Python test/fixture module with pytest (or the repository-native test runner
   captured in the results).
4. Confirm the excluded-growing fixture reports degraded before idle and remains non-searchable
   until all convergence evidence is complete.
5. Confirm the healthy-quiet fixture may be idle without degraded/excluded evidence.
6. Exercise the actual CLI/MCP/status routes and compare their typed JSON payloads.
7. On an operator host, use `live-safe-receipt.py` for exactly one source with a small sample cap;
   do not replace it with an archive-wide count.

Container checks actually executed are listed in `verification-results.md`; live checks are left as
an explicit operator boundary.
