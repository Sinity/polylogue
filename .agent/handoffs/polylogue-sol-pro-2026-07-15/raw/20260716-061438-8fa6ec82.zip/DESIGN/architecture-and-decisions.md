# Architecture and decisions

## Read-model shape

The feature is implemented as an exact-source projection rather than another aggregate archive
summary. One requested `source_path` is the root key. Evidence is joined through existing durable
identifiers—logical source key, accepted raw revision/raw identifier, and session identifier—then
returned with explicit coverage/bounds. Filesystem stat, cursor offset and observed size, failure
and retry/exclusion policy state, accepted revision authority, parse state, index high-water, FTS,
and insight convergence are evidence fields, not independent guesses.

The pipeline state vocabulary is ordered: `unseen`, `acquired_unparsed`, `parsed_unindexed`,
`indexed_unconverged`, and `searchable`. Cursor health is a separate concern. Exclusion and positive
byte lag are evaluated before idle/quiet classification, so an excluded growing source cannot be
hidden by a quiet timestamp. A truncated or ambiguous bounded sample cannot establish complete
coverage and therefore cannot yield `searchable`.

## Query and receipt bounds

The projection must use equality predicates on the named source and derived exact identifiers.
Samples are hard-capped. The implementation patch is statically audited for a new literal
`SELECT COUNT(...)`; the live receipt harness itself performs no archive enumeration or count and
caps evidence to 32 (default 8). These constraints keep the receipt safe on a live archive while
making a single incident source directly observable.

## Policy ownership

`lkrc` continues to own raw-authority semantics. This projection reports the accepted revision and
its existing authority evidence; it does not choose a new winner. `yla8` continues to own replay
prevention. No cursor replay or ingestion mutation belongs in a freshness query. The cursor schema
has no durable originating exception text, so the payload reports stable policy facts such as
excluded-after-threshold/retry state, failure count, next retry time, and byte lag without inventing
an exception message or adding a schema migration.

## Changed declarations

- No declaration symbols could be extracted; inspect the patches directly.

## Product integration

Typed serialization is carried through existing CLI, MCP, and status/product layers where those
paths appear in `PATCHES/0001-exact-source-freshness.patch`. Product surfaces should all call
the same projection and serialize the same state rather than reimplementing classification.
