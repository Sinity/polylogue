# Change inventory

Base revision: `git revision unavailable in supplied snapshot`

## Pre-existing dirty state

- None detected in immutable base.

## Patch-owned paths

- No implementation diff detected.

## Patch grouping

1. `PATCHES/0000-no-source-diff.patch` — 0 path(s)

The ordered series excludes `.beads/issues.jsonl`; apply it only after reconciling local operator
changes against the recorded base.
