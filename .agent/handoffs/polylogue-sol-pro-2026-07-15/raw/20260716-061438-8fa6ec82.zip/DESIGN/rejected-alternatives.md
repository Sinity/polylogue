# Rejected alternatives

1. **Fix only the aggregate cursor counter.** Rejected because aggregate totals and bounded archive
   samples caused the incident to remain invisible. The operator needs an exact named-source path.
2. **Treat excluded as idle when timestamps are quiet.** Rejected because exclusion can freeze the
   cursor while the filesystem continues growing; degradation has higher precedence.
3. **Scan or count the archive for certainty.** Rejected for live safety and latency. Exact indexed
   joins plus bounded samples expose evidence without an archive-wide receipt query.
4. **Declare searchable from the newest sampled session.** Rejected because a capped multi-session
   sample can omit unconverged revisions. Incomplete coverage is conservative, never searchable.
5. **Persist or synthesize the original cursor exception.** Rejected because the current schema does
   not own that text. Stable exclusion/retry policy evidence is truthful and migration-free.
6. **Move raw revision choice or replay prevention into freshness.** Rejected because that would
   violate `lkrc` and `yla8` ownership and turn an observability read model into ingestion policy.
7. **Create a parallel diagnostic database or subsystem.** Rejected because it would drift from the
   canonical cursor/archive/index state. The projection is integrated into existing repositories and
   product routes.
