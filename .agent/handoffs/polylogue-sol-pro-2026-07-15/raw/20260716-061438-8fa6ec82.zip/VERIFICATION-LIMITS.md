# Verification limits

## Executed in the container

- `125` `git apply ordered patch series` — patch applicability (not runnable); log `TESTS/logs/patch-apply.log` (0.00s)
- `2` `bounded contract token audit over changed files` — required state/evidence vocabulary and no new literal archive count; log `TESTS/logs/contract-token-audit.log` (0.00s)

The immutable extraction and isolated implementation tree were compared at `git revision unavailable in supplied snapshot`. Where
Git metadata was available, the ordered patch series was applied to a detached clean copy and each
changed path was byte-compared with the implementation worktree. Logs are preserved verbatim.

## Not executed

- No operator live browser, long-running Polylogue daemon, MCP client session, secrets, production
  archive/index databases, or NixOS deployment was available.
- No claim is made about production data cardinality, index plans, lock behavior, or filesystem
  permissions beyond the self-contained fixtures and static query review.
- The live-safe receipt was prepared but not run against an operator path or database.
- The cursor schema does not retain the originating ingestion exception; no exception text was
  reconstructed, and no migration was attempted.

## Residual verification risk

A production receipt still needs to confirm that the exact-source query plan uses the expected
indexes on the deployed schema and that CLI/MCP/status wrappers resolve the same configured archive
locations as the daemon. Any nonzero command above remains an explicit blocker or environment gap,
not a hidden pass.
