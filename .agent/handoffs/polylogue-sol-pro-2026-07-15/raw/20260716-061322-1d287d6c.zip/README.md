# Polylogue workload-envelope and resource-receipt handoff

This archive is the reviewable implementation handoff for `polylogue-1xc.14`. It targets the supplied operator revision `5abb30afc0b30348c4332ede1e592704e971f0a8` on `feature/browser/sol-pro-dispatch` and preserves the snapshot's pre-existing staged and unstaged changes to `.beads/issues.jsonl` by never touching that path.

## Read order

1. Read `SUMMARY.md` for the executive result and acceptance-criteria matrix.
2. Read `DESIGN/bead-traceability.md` and `DESIGN/contract-and-collector.md` for scope, semantics, and integration decisions.
3. Read `DESIGN/research-sources.md` and `DESIGN/rejected-alternatives.md` for source-backed Linux choices and rejected approaches.
4. Read `VERIFICATION-LIMITS.md`, then `TESTS/verification-report.md`, before treating the patch as production-ready.
5. Inspect `PATCHES/base-blobs.json` and `PATCHES/README.md` before applying the three patches in lexical order.

## Apply order

Use a clean worktree at the recorded operator base. Do not apply directly over the dirty snapshot worktree.

```bash
git worktree add -b feature/ops/workload-receipts \
  ../polylogue-workload-receipts \
  5abb30afc0b30348c4332ede1e592704e971f0a8
cd ../polylogue-workload-receipts
```

Preflight the two explicitly recovered base files against `PATCHES/base-blobs.json`:

```bash
git hash-object devtools/query_memory_budget.py
git hash-object polylogue/scenarios/__init__.py
```

Expected Git blob IDs are `15674fe888684b5b26daa0583bff0dd56551074c` and `2b3340414b4f4b450becc799608f0f8ed7646c41`. Stop and review rather than forcing the series if either differs.

Apply the ordered unified patch series:

```bash
git am --3way \
  /absolute/path/to/PATCHES/0001-*.patch \
  /absolute/path/to/PATCHES/0002-*.patch \
  /absolute/path/to/PATCHES/0003-*.patch
```

Then run the operator-side verification plan:

```bash
POLYLOGUE_BASE_REVISION=5abb30afc0b30348c4332ede1e592704e971f0a8 \
  bash /absolute/path/to/TESTS/run-focused.sh
```

`MANIFEST.json` is authoritative for the archive inventory, hashes, byte sizes, purposes, and apply order.
