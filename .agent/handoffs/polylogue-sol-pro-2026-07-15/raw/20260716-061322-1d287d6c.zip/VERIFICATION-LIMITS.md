# Verification limits

## What was run

The supplied 57,284-byte context archive was inspected before use. All 33 members were relative regular paths; no parent traversal, absolute path, symbolic link, or hard link was accepted. The complete repository instruction file and complete selected Beads record for `polylogue-1xc.14`, including its later active-set note, were read before implementation.

A reconstructed full-source harness was assembled from the Polylogue 0.2.0 source distribution. Every context-packed source or test file used as a base was verified byte-for-byte against the immutable pack manifest before candidate files were overlaid. Two modified files absent from the context pack have explicit base Git blob and SHA-256 assumptions in `PATCHES/base-blobs.json`.

The following self-contained checks were run against the final candidate source:

- Focused pytest over the envelope, collector, query-memory, and pipeline-probe tests: 45 passed, 1 deliberately deselected, 2 configuration warnings.
- The deselected archive-subset test was run separately against both candidate and untouched source-distribution baseline. Both failed with the same `raw_sessions_count` assertion (`3` observed, `2` expected).
- Ruff check over all 12 changed Python files: passed.
- Ruff format check over all 12 changed Python files: passed.
- Targeted mypy over all 8 changed source modules: passed with no issues.
- `python -m compileall -q` over all 12 changed Python files: passed.
- Both named canary JSON documents parsed and satisfied inventory, schema, peak/quiescent, anonymous/cache, and logical-validity assertions.
- `git diff --check` over the three-commit series: passed.
- All three generated mail patches were applied in order with `git am` to a clean detached synthetic base. The replay worktree was clean, and all 14 touched paths were byte-identical to the candidate.
- The finished ZIP was reopened and independently checked for unsafe, duplicate, case-fold-colliding, directory, and symlink entries; required roots; exact manifest coverage; and recomputed SHA-256/size matches.

Raw outputs and exact command shapes are retained in `TESTS/`.

## Checks attempted but not completed

`python -m devtools verify --quick` was attempted in the reconstructed harness. Its Ruff format and Ruff check stages passed, but the broad repository mypy stage did not finish before the 360-second command limit. This is not reported as a passing quick gate. The targeted eight-module mypy result is the only clean type-check result claimed.

A normal project pytest startup using the repository's top-level conftest did not complete in this container because its managed scratch/basetemp initialization hung while traversing unavailable or stale environment state. The focused run therefore disabled automatic third-party plugins and cut conftest discovery at `tests/unit`; it still imported and exercised the real reconstructed Polylogue modules and real pipeline-probe routes.

## What was not run

The operator's live MCP/browser, daemon or watcher, secrets, private databases, actual incident inputs, production archive, systemd units, NixOS deployment, or production-scale memory pressure were unavailable and were not run. No claim in this handoff implies otherwise.

A live cgroup-v2 end-to-end run was not possible in this container. Cgroup parsing, scope, missing-file, charge/cache/anonymous/swap, CPU, and I/O semantics were exercised with deterministic filesystem fixtures. Live process-tree collection was exercised against child processes and pipeline routes.

The patch does not complete production persistence in modules outside the supplied footprint for the daemon observer, generic scenario runner, verify supervisor, or SLO catalog. It provides the typed declaration/adapters and explicit ownership entries needed for those owners to wire without inventing another receipt.

The patches were not applied to the operator's actual Git checkout. They were generated and replayed against a synthetic Git base assembled from the immutable context members plus two explicitly identified recovered base files. Operator-side `git am --3way`, base-blob preflight, and focused verification remain mandatory.

## Measurement caveats retained by design

Procfs status and task-child interfaces are sampled and racy. The collector records truncation and unavailable dimensions rather than fabricating completeness. Sampling may miss a transient peak between intervals; kernel containment is still required where a hard upper bound is mandatory.

Process-tree RSS/PSS components are not cgroup memory charge. Cgroup `memory.stat` file charge can include tmpfs/shmem, so file cache and shared memory remain separately labeled. `memory.peak` is read-only and is not reset; it may predate a run, which is why the run-local sampled peak is distinct from the observed kernel peak.

Temporary-space evidence uses a constant-time `statvfs` available-space delta for the declared filesystem. It can include unrelated writers and is labeled mount-shared. PSS uses lower-cadence `smaps_rollup` reads to avoid perturbing short phases and may remain unavailable on unsupported or restricted kernels.
