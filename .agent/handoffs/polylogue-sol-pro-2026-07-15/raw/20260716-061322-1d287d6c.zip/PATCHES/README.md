# Ordered patch series

Apply these unified mail patches in lexical order with `git am --3way`:

| Order | Patch | Purpose |
|---:|---|---|
| 10 | `0001-feat-scenarios-declare-common-workload-envelopes-and.patch` | Adds the typed envelope, budget, receipt, phase, scope, and scenario declaration contract. |
| 20 | `0002-feat-devtools-collect-bounded-Linux-workload-receipt.patch` | Adds the bounded Linux collector; live query-memory and pipeline-probe integrations; verify/SLO adapters; and physical budget evaluation. |
| 30 | `0003-test-workloads-cover-scope-canaries-and-logical-vali.patch` | Adds unit, process-scope, anti-vacuity, logical-validity tests and both named incident canary fixtures. |

## Base and worktree assumptions

The supplied snapshot records operator revision `5abb30afc0b30348c4332ede1e592704e971f0a8` on `feature/browser/sol-pro-dispatch`. It also records staged and unstaged edits to `.beads/issues.jsonl`. No patch in this series touches that path; apply from a separate clean worktree rather than overwriting the dirty one.

A synthetic local base, `2f77147788165da06b8389b8fd70f47561100bfa`, was created solely to generate and replay the series. It is not an operator revision. Seven modified base files are byte-identical to members of the immutable context pack. Two modified files were not packed and have explicit assumptions:

- `devtools/query_memory_budget.py`: expected base Git blob `15674fe888684b5b26daa0583bff0dd56551074c`.
- `polylogue/scenarios/__init__.py`: expected base Git blob `2b3340414b4f4b450becc799608f0f8ed7646c41`.

`base-blobs.json` records full base and candidate SHA-256 values, byte sizes, Git blobs, status, and provenance for every touched path. Check those two Git blobs in the operator checkout before applying. Review any mismatch; do not force it.

## Candidate commits

- `0414805bd636eead9fe5e0bbde8a07c653737566` — typed scenario contract.
- `23476e186dda847345811c514d1fe6c8ef09e5f9` — bounded collector and real-path integrations.
- `c6bc05d9e4f47fbb0cd185008625ed60dd84148b` — tests and canaries.

## Replay evidence

The generated patches were applied with `git am` to a clean detached worktree at the synthetic base. Replay commits were `bbc602b67167f13e8b80cd43ab251c6d354306be`, `5e26d8aee16d62ed55a25f3ce00a57a403660e77`, and `5c9f20d6cbee0b24e6acd7fbf566791b1cb5270c`. The replay worktree was clean; `git diff --check` passed; and all 14 touched paths were byte-identical to the candidate. See `TESTS/patch-replay.log`.
