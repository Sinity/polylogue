# Rejected alternatives

## Global `/proc` scan on every sample

Rejected because it scales with all host processes, introduces a second heavyweight workload, and still races. The implemented traversal is rooted, thread-aware, and hard-bounded.

## Full `/proc/<pid>/smaps` or forced `smaps_rollup` on every poll

Rejected because proportional-memory reads can materially perturb short phases and quiescence. The collector uses `smaps_rollup` at a separate lower frequency and preserves unavailable PSS when it cannot be read.

## Resetting cgroup `memory.peak`

Rejected because a reset writes kernel state and changes the observed environment. The receipt separates the read-only observed kernel lifetime/FD peak from its own sampled run peak.

## Killing or declaring a query unsupported at budget breach

Rejected because the work item explicitly separates physical containment from semantic validity. The query-memory adapter lets the command complete, then reports the physical verdict. Product owners may schedule, page, stream, spool, pause, or resume without changing the logical answer contract.

## Treating missing measurements as zero or falling back silently

Rejected because it creates vacuous passes. Missing dimensions yield `unavailable`; if a shared receipt exists, pipeline budget reporting does not silently substitute a legacy self-only RSS number.

## One more domain-specific receipt

Rejected because the existing fragmentation caused incomparable evidence. Domain phase instrumentation remains, but each surface declares/emits/adapts the common contract.

## Recursive cgroup directory walk for process counting

Rejected in this patch because cgroup memory/CPU/I/O files are already hierarchical while recursively counting arbitrary sub-cgroups would need another explicit bound and ownership policy. The receipt treats controller totals as authoritative and does not infer a complete hierarchical process count from a local `cgroup.procs` file.

## Serializing the input corpus to calculate evidence identity or response size

Rejected because it duplicates heavy work. Adapters bind existing input/build/archive identifiers, and pipeline response byte binding serializes only the already-materialized summary document.
