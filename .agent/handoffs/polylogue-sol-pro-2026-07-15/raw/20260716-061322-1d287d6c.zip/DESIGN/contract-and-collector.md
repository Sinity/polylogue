# Contract and collector design

## Contract boundary

`WorkloadEnvelopeSpec` declares the logical operation and the observation policy without changing result validity. It binds a stable workload ID/family, logical operation, input/build/archive/frame scope, phase model, process-tree or cgroup-v2 scope, concurrency/admission shape, bounded sampling parameters, quiescence window/timeout, permitted physical controls, and physical budgets.

`WorkloadReceipt` binds one run to that declaration and records build/input/archive/frame/runtime identity; wall and CPU time; memory peak/end/quiescent/retained points; I/O and temporary allocation; response bytes; cancellation, progress, backpressure, cleanup, phase receipts, unavailable dimensions, budget verdicts, logical outcome, and collector provenance.

Budget dimensions are physical measurements. Constructor and payload validation reject known semantic-cap names and result-limit token combinations. A budget verdict can be `within`, `exceeded`, or `unavailable`; unavailable is never converted to a pass.

## Memory semantics

The receipt does not equate all memory concepts:

- `rss_bytes` is sampled resident memory for the declared scope.
- `pss_bytes` and PSS anonymous/file/shared/swap components come from lower-frequency `smaps_rollup` reads where available.
- Process-tree anonymous/file/shared/swap values come from per-process status fields and are reported as sampled sums.
- Cgroup `total_charge_bytes` is separate from process RSS and comes from `memory.current`.
- Cgroup anonymous charge and file cache come from keyed `memory.stat` values. Shared memory is reported separately, even though the kernel's `file` counter includes tmpfs/shmem.
- `memory.peak` is a sampled component-wise peak. `kernel_peak_total_charge_bytes` is separately exposed because `memory.peak` may predate this run and is deliberately not reset.
- `end`, `quiescent`, and `retained_after_quiescence` are distinct from peak. A quiescence timeout produces explicit unavailability instead of fabricating stability.

## Bounded process-tree collector

The process-tree path starts at one declared root PID and follows `/proc/<pid>/task/<tid>/children` for all enumerated threads. A single hard `max_processes` budget covers processes and task-directory reads. It never scans the global `/proc` namespace. PID plus process start ticks keys retained CPU and I/O counters to avoid joining recycled PIDs.

Fast samples read status, stat, and I/O counters. PSS uses `smaps_rollup` only at the declared detailed interval. Quiescence polling follows the normal cadence rather than forcing a heavy PSS read on every poll. Processes may exit during enumeration; vanished task directories and entries are skipped, and a regression test covers the `ProcessLookupError` race found during real-route verification.

## Cgroup-v2 collector

The cgroup path reads a fixed set of files under an explicitly declared or discovered safe relative path: `memory.current`, `memory.peak`, `memory.swap.current`, keyed `memory.stat`, `cpu.stat`, `io.stat`, and `cgroup.procs`. It does not reset `memory.peak`, migrate processes, or write controller state. Missing files/keys are recorded per dimension.

## I/O and temporary storage

Process I/O reports syscall-character counters and storage-layer read/write/cancelled-write counters from `/proc/<pid>/io`. Cgroup I/O sums keyed per-device byte counters. Temporary allocation uses a constant-time `statvfs` available-space delta for the declared temp filesystem; the receipt labels this as mount-shared and therefore susceptible to unrelated activity.

## Phase and control observations

Adapters bracket real domain phases rather than replacing existing timing instrumentation. Phase receipts include wall, CPU delta, memory start/peak/end, I/O delta, response bytes, and phase-local unavailable data. Progress, queue/backpressure, cancellation request/acknowledgement latency, cleanup outcome, and response bytes are adapter-reported because only domain owners know their semantics.

## Surface integration

- **Query memory:** `run_memory_budget` measures the real child process tree, command execution, cleanup, and quiescence. Exceeding the physical budget does not terminate a logically valid command; it changes the post-run verdict.
- **Pipeline probe:** synthetic, source-subset, and archive-subset routes emit receipts around prepare, ingest, optional materialize/index, cleanup, evidence, and quiescence. CLI arguments expose resource scope and bounded sampling controls.
- **Scenario execution:** `ExecutionSpec.workload_envelope` carries declarations through authored execution payloads.
- **Ingest/source observation:** pipeline source-subset phases adapt the existing `ParsingService.ingest_sources` path; production daemon observation remains with its owner.
- **Verify runs:** `adapt_verify_resource_samples` translates existing sampler rows without rereading the process tree and marks uncaptured dimensions unavailable.
- **SLO evidence:** `workload_comparison_scope` and `compare_workload_receipts` require matching workload/input/build/archive/frame/runtime scopes before regression comparison.

## Canary intent

The canary JSON files are workload declarations plus evidence expectations, not fabricated production receipts. They preserve incident names, known lower-bound evidence, phase models, required dimensions, and the invariant that no semantic result cap is allowed. Actual comparable receipts must be captured on the incident inputs/builds in the operator environment.
