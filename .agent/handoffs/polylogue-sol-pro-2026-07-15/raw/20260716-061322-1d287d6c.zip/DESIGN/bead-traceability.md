# Beads scope and traceability

## Source record

Primary issue: `polylogue-1xc.14`, “Declare workload envelopes and resource receipts once.” The complete selected record was read from the immutable context pack. Its later note, “Active-set expansion 2026-07-15,” changes scheduling priority but does not supersede the description, design, or six acceptance criteria.

The record describes two motivating observations: an MCP query process at approximately 8.5 GiB RSS plus swap, and a watcher catch-up process retaining more than 4 GiB anonymous memory. The context contains the Beads statements, not private incident traces. The named fixtures therefore encode canary declarations and evidence requirements without pretending to be production measurements.

## Architecture placement

The existing scenario execution vocabulary is the declaration boundary, so the typed contract lives in `polylogue/scenarios/execution.py` and is re-exported by `polylogue/scenarios/__init__.py`. The Linux collector and cross-owner adapters live in `devtools/workload_receipts.py`, next to the existing operational measurement tools rather than creating a second package or daemon.

Two supplied real routes own live collectors:

- `devtools/query_memory_budget.py` observes the spawned command's process tree, lets it complete, waits for cleanup/quiescence, and reports physical verdicts.
- `devtools/pipeline_probe` observes synthetic, source-subset, and archive-subset runs around their real prepare/ingest/materialize/index/cleanup/evidence phases and binds response bytes to the emitted JSON document.

The remaining required surfaces use existing ownership boundaries:

- scenario execution carries a `WorkloadEnvelopeSpec` in `ExecutionSpec`;
- ingest/source observation is represented by the source-subset adapter and catalog entry while production daemon emission remains with its owner;
- verify resource rows are adapted without rereading `/proc`;
- SLO evidence uses a strict comparison scope before evaluating receipt regressions.

## Acceptance trace

1. Typed declaration and receipt: patch 0001 and the contract tests.
2. Six-surface integration/adaptation plus unit and scope semantics: patches 0001–0003 and `WORKLOAD_ADAPTER_CATALOG`.
3. Named incident canaries: patch 0003 and copied fixtures under `TESTS/fixtures/`.
4. Logical validity independent of physical budget: semantic-cap validation and query-memory completion test.
5. Like-scope, unavailable-not-pass, and anti-vacuity behavior: comparison/budget helpers and mutation tests.
6. Bounded, non-perturbing collection: rooted process traversal, fixed cgroup files, lower-cadence PSS, no corpus scan, and no parallel heavyweight reader.

## Explicit assumptions

The operator base and dirty state come from the context pack: revision `5abb30afc0b30348c4332ede1e592704e971f0a8`, branch `feature/browser/sol-pro-dispatch`, with staged and unstaged `.beads/issues.jsonl` changes. The patch series excludes that file.

Seven modified base paths were present in the context pack and matched its manifest exactly. Two modified base paths were absent and were recovered from prior worker source state; their full Git blob and SHA-256 assumptions are recorded in `PATCHES/base-blobs.json`. Five paths are new. No operator checkout or private runtime was available to remove that final apply-time uncertainty.
