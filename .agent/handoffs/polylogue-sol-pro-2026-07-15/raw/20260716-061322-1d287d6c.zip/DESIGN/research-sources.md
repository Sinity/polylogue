# Primary research sources

Accessed 2026-07-16. These are implementation sources, not evidence that the operator's deployed kernel exposes every interface.

## Linux kernel cgroup v2 documentation

URL: https://docs.kernel.org/admin-guide/cgroup-v2.html

Decisions derived:

- `memory.current` is the current memory used by a cgroup and descendants, so it maps to hierarchical total charge rather than process RSS.
- `memory.peak` covers the cgroup and descendants since cgroup creation or a per-file-descriptor reset. The collector does not reset it because that mutates the measurement environment; the value is labeled separately from the run's sampled peak.
- `memory.stat` is keyed, byte-valued, and extensible; the collector parses by key rather than line position. `anon`, `file`, and `shmem` remain distinct receipt fields.
- `memory.swap.current` is hierarchical current swap usage.
- `cpu.stat` exposes usage/user/system microseconds for cgroup processes.
- `io.stat` is per-device and unordered; the collector sums `rbytes` and `wbytes` by key.

## Linux kernel procfs documentation

URL: https://docs.kernel.org/filesystems/proc.html

Decisions derived:

- `smaps_rollup` supplies aggregate PSS plus `Pss_Anon`, `Pss_File`, and `Pss_Shmem` at lower cost than walking all mappings.
- Proc memory-map reads are inherently racy, so PSS remains sampled evidence rather than an exact invariant.
- The collector schedules `smaps_rollup` at a lower detailed cadence and does not force it during every quiescence poll.

## Linux manual pages

URLs:

- https://man7.org/linux/man-pages/man5/proc_pid_status.5.html
- https://man7.org/linux/man-pages/man5/proc_pid_io.5.html
- https://man7.org/linux/man-pages/man5/proc_tid_children.5.html
- https://man7.org/linux/man-pages/man5/proc_pid_stat.5.html

Decisions derived:

- `VmRSS` is the sum of `RssAnon`, `RssFile`, and `RssShmem`, but proc status values are approximate. The receipt therefore names source semantics and never treats them as cgroup charge.
- `/proc/<pid>/io` separates characters submitted through syscalls from bytes actually sent to or fetched from storage and exposes cancelled writes; both concepts are retained.
- task `children` enumeration is unreliable under concurrent process changes. The collector uses it only as a bounded best-effort scope, reads every thread's child list, tolerates exit races, and exposes truncation/unavailable evidence rather than launching a global process scan.
- `/proc/<pid>/stat` start time is in clock ticks. PID plus start ticks identifies retained counters across samples and prevents PID-reuse conflation.
