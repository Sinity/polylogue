#!/usr/bin/env python3
"""Validate a Polylogue Sol Pro handoff directory or ZIP."""
from __future__ import annotations

import argparse
import hashlib
import json
import stat
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

PROFILE = "polylogue-sol-pro-worker-v1"
REQUIRED_ROOT_FILES = {
    "MANIFEST.json",
    "README.md",
    "SUMMARY.md",
    "VERIFICATION-LIMITS.md",
}
REQUIRED_DIRS = {"PATCHES", "DESIGN", "TESTS"}
REQUIRED_RECORD_FIELDS = {"path", "sha256", "size_bytes", "purpose", "apply_order"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_file_path(name: str) -> bool:
    path = PurePosixPath(name)
    return (
        bool(name)
        and not name.endswith("/")
        and not path.is_absolute()
        and ".." not in path.parts
        and "." not in path.parts
        and "\\" not in name
        and "\x00" not in name
    )


def validate_manifest(manifest: dict[str, Any], actual: dict[str, bytes]) -> None:
    assert manifest.get("prompt_profile") == PROFILE, manifest.get("prompt_profile")
    records = manifest.get("files")
    assert isinstance(records, list), "manifest files must be an array"
    paths: list[str] = []
    for record in records:
        assert isinstance(record, dict), "manifest record must be an object"
        assert REQUIRED_RECORD_FIELDS <= set(record), record
        path = record["path"]
        assert isinstance(path, str) and safe_file_path(path), path
        assert isinstance(record["sha256"], str) and len(record["sha256"]) == 64, path
        int(record["sha256"], 16)
        assert isinstance(record["size_bytes"], int) and record["size_bytes"] >= 0, path
        assert isinstance(record["purpose"], str) and record["purpose"].strip(), path
        assert isinstance(record["apply_order"], int) and record["apply_order"] >= 0, path
        paths.append(path)
    assert len(paths) == len(set(paths)), "duplicate manifest paths"
    assert len(paths) == len({path.casefold() for path in paths}), "case-fold duplicate manifest paths"
    assert set(paths) == set(actual), (set(paths) - set(actual), set(actual) - set(paths))
    indexed = {record["path"]: record for record in records}
    for path, data in actual.items():
        record = indexed[path]
        assert len(data) == record["size_bytes"], path
        assert sha256(data) == record["sha256"], path


def validate_required_paths(names: set[str]) -> None:
    assert REQUIRED_ROOT_FILES <= names, REQUIRED_ROOT_FILES - names
    for directory in REQUIRED_DIRS:
        assert any(name.startswith(directory + "/") for name in names), directory
    patch_names = sorted(
        name for name in names if name.startswith("PATCHES/") and name.endswith(".patch")
    )
    assert len(patch_names) == 3, patch_names
    assert [Path(name).name[:4] for name in patch_names] == ["0001", "0002", "0003"]


def validate_directory(root: Path) -> tuple[int, int]:
    assert root.is_dir(), root
    files: dict[str, bytes] = {}
    names_seen: set[str] = set()
    folded_seen: set[str] = set()
    for path in sorted(root.rglob("*")):
        assert not path.is_symlink(), f"symlink: {path}"
        if path.is_dir():
            continue
        assert path.is_file(), f"unsupported filesystem entry: {path}"
        rel = path.relative_to(root).as_posix()
        assert safe_file_path(rel), rel
        assert rel not in names_seen, rel
        assert rel.casefold() not in folded_seen, rel
        names_seen.add(rel)
        folded_seen.add(rel.casefold())
        files[rel] = path.read_bytes()
    validate_required_paths(set(files))
    manifest = json.loads(files.pop("MANIFEST.json"))
    validate_manifest(manifest, files)
    return len(files) + 1, sum(len(data) for data in files.values()) + len(
        (root / "MANIFEST.json").read_bytes()
    )


def validate_zip(path: Path) -> tuple[int, int]:
    assert path.is_file(), path
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        assert infos, "empty ZIP"
        names = [info.filename for info in infos]
        assert len(names) == len(set(names)), "duplicate ZIP paths"
        assert len(names) == len({name.casefold() for name in names}), "case-fold duplicate ZIP paths"
        files: dict[str, bytes] = {}
        for info in infos:
            assert safe_file_path(info.filename), info.filename
            mode = (info.external_attr >> 16) & 0o170000
            assert mode != stat.S_IFLNK, f"symlink ZIP entry: {info.filename}"
            assert not info.is_dir(), f"directory ZIP entry: {info.filename}"
            files[info.filename] = archive.read(info)
        assert archive.testzip() is None, "ZIP CRC failure"
        validate_required_paths(set(files))
        manifest = json.loads(files.pop("MANIFEST.json"))
        validate_manifest(manifest, files)
        return len(files) + 1, path.stat().st_size


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact", type=Path)
    args = parser.parse_args()
    if args.artifact.is_dir():
        count, size = validate_directory(args.artifact)
    else:
        count, size = validate_zip(args.artifact)
    print(json.dumps({"valid": True, "file_count": count, "size_bytes": size}, sort_keys=True))


if __name__ == "__main__":
    main()
