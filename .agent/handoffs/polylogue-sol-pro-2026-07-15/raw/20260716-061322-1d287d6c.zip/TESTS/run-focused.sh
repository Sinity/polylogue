#!/usr/bin/env bash
set -euo pipefail

# Run from a clean operator Polylogue checkout after applying PATCHES/*.patch.
root=$(git rev-parse --show-toplevel)
cd "$root"
base=${POLYLOGUE_BASE_REVISION:-HEAD~3}

uv run devtools test tests/unit/scenarios/test_workload_envelope.py
uv run devtools test tests/unit/devtools/test_workload_receipts.py
uv run devtools test tests/unit/devtools/test_query_memory_budget.py
uv run devtools test tests/unit/devtools/test_pipeline_probe.py

changed_python=(
  polylogue/scenarios/execution.py
  polylogue/scenarios/__init__.py
  devtools/workload_receipts.py
  devtools/query_memory_budget.py
  devtools/pipeline_probe/__init__.py
  devtools/pipeline_probe/engine.py
  devtools/pipeline_probe/request.py
  devtools/pipeline_probe/result.py
  tests/unit/scenarios/test_workload_envelope.py
  tests/unit/devtools/test_workload_receipts.py
  tests/unit/devtools/test_query_memory_budget.py
  tests/unit/devtools/test_pipeline_probe.py
)

uv run ruff check "${changed_python[@]}"
uv run ruff format --check "${changed_python[@]}"

uv run mypy \
  polylogue/scenarios/execution.py \
  polylogue/scenarios/__init__.py \
  devtools/workload_receipts.py \
  devtools/query_memory_budget.py \
  devtools/pipeline_probe/__init__.py \
  devtools/pipeline_probe/engine.py \
  devtools/pipeline_probe/request.py \
  devtools/pipeline_probe/result.py

python -m compileall -q "${changed_python[@]}"

python - <<'PY'
import json
from pathlib import Path

expected = {
    "2026-07-13-watcher-append-cohort.json",
    "2026-07-15-mcp-query.json",
}
seen: set[str] = set()
for path in sorted(Path("tests/fixtures/workload-receipts").glob("*.json")):
    if path.name not in expected:
        continue
    payload = json.loads(path.read_text(encoding="utf-8"))
    seen.add(path.name)
    assert payload["schema"] == "polylogue.workload-canary.v1", path
    assert payload["name"] == path.stem, path
    assert payload["envelope"]["schema"] == "polylogue.workload-envelope.v1", path
    assert payload["envelope"]["logical_result_contract"] == "preserve-logical-validity", path
    dimensions = set(payload["required_comparison_dimensions"])
    assert "memory.peak.anonymous_bytes" in dimensions, path
    assert "memory.peak.file_cache_bytes" in dimensions, path
    assert any(item.startswith("memory.quiescent.") for item in dimensions), path
    assert payload["logical_validity"]["oversized_operation_remains_valid"] is True, path
assert seen == expected, (seen, expected)
PY

git diff --check "$base"..HEAD --
