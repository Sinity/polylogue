# Verification report

Date: 2026-07-16 UTC. Environment details are in `environment.txt`.

## Focused behavioral run

Executed in the reconstructed full-source harness with the final candidate files overlaid:

```bash
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=. \
python -m pytest -q -o addopts='' --confcutdir=tests/unit \
  -p pytest_asyncio.plugin \
  tests/unit/devtools/test_workload_receipts.py \
  tests/unit/devtools/test_query_memory_budget.py \
  tests/unit/scenarios/test_workload_envelope.py \
  tests/unit/devtools/test_pipeline_probe.py \
  -k 'not test_run_probe_can_sample_archive_subset_and_persist_manifest'
```

Observed result: `45 passed, 1 deselected, 2 warnings in 19.87s`. The warnings report unavailable pytest timeout configuration because automatic plugins were intentionally disabled. See `focused-pytest.log`.

This run covers contract payloads and invalid semantic caps; byte/MiB and clock-tick conversion; bounded, thread-aware process-tree traversal; child/root scope; PID identity and exit races; RSS/PSS/anonymous/file/shared/swap dimensions; deterministic cgroup-v2 parsing; CPU and I/O deltas; temp allocation; phase receipts; progress/backpressure/cancellation/cleanup; quiescence; unavailable measurements; like-scope comparison; verify adapters; both canaries; query-memory logical completion after budget breach; and real pipeline-probe paths.

## Known baseline-reproduced assertion

The deliberately deselected test was run separately against the candidate and an untouched Polylogue 0.2.0 source-distribution baseline using the same isolated lane:

```bash
python -m pytest -q -o addopts='' --confcutdir=tests/unit \
  -p pytest_asyncio.plugin \
  tests/unit/devtools/test_pipeline_probe.py::test_run_probe_can_sample_archive_subset_and_persist_manifest
```

Both executions failed at the pre-existing expectation that `db_stats.raw_sessions_count` is 2; both observed 3. Candidate and pristine outputs are in `known-baseline-candidate.log` and `known-baseline-pristine.log`. This is not counted as passing and must be rerun under the operator repository's normal workspace-isolation fixture.

## Static and serialization checks

```bash
python -m ruff check --no-cache <all 12 changed Python files>
python -m ruff format --check --no-cache <all 12 changed Python files>
python -m mypy --no-incremental \
  devtools/workload_receipts.py \
  devtools/query_memory_budget.py \
  devtools/pipeline_probe/__init__.py \
  devtools/pipeline_probe/engine.py \
  devtools/pipeline_probe/request.py \
  devtools/pipeline_probe/result.py \
  polylogue/scenarios/execution.py \
  polylogue/scenarios/__init__.py
python -m compileall -q <all 12 changed Python files>
```

Results:

- Ruff check: `All checks passed!`
- Ruff format check: `12 files already formatted`
- Mypy: `Success: no issues found in 8 source files`
- Compileall: exit status 0 with no diagnostics

The named canary fixtures were parsed and checked for schema, inventory, required peak/quiescent and anonymous/cache dimensions, and logical-validity invariants. All checks passed. Corresponding raw files are `ruff-check.log`, `ruff-format.log`, `mypy.log`, `compileall.log`, and `fixture-validation.log`.

## Source and patch integrity

The context tar audit passed with 33 members, no unsafe paths, and no links. Seven modified base files matched context-pack SHA-256 and size exactly. Two absent base files are explicit assumptions, and five paths are new; see `source-integrity.log` and `PATCHES/base-blobs.json`.

The three current patches were regenerated from the final candidate, applied with `git am` to a clean synthetic base, and checked with `git diff --check`. All 14 replayed paths were byte-identical to the candidate. See `patch-replay.log`.

## Broad-gate boundary

`python -m devtools verify --quick` passed its Ruff format and Ruff check stages, then remained in broad repository mypy until the 360-second external command limit. It is an incomplete run, not a pass. See `quick-gate-partial.log` and `VERIFICATION-LIMITS.md`.
