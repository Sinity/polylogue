# Focused verification plan and recorded results

Run from the full Polylogue repository root after applying the patch.

## Required selectors

```bash
devtools test tests/unit/sources/test_live_batch_support.py -k live_multi_session_divergence_reopens_raw_authority
devtools test -k raw_authority
```

Recorded in the supplied-scope reconstructed harness:

```text
# exact file selector
collected 64 items / 63 deselected / 1 selected
1 passed, 63 deselected in 1.48s

# repository selector over the included test corpus
collected 64 items / 63 deselected / 1 selected
1 passed, 63 deselected in 1.43s
```

## Static checks

```bash
ruff check polylogue/sources/live/batch.py tests/unit/sources/test_live_batch_support.py
ruff format --check polylogue/sources/live/batch.py tests/unit/sources/test_live_batch_support.py
python -m py_compile \
  polylogue/sources/live/batch.py \
  tests/unit/sources/test_live_batch_support.py
```

Recorded results:

```text
All checks passed!
2 files already formatted
py_compile OK
```

## Patch integrity

```bash
git apply --check PATCHES/0001-fix-live-multi-session-authority.patch
git apply PATCHES/0001-fix-live-multi-session-authority.patch
git apply --reverse --check PATCHES/0001-fix-live-multi-session-authority.patch
```

Recorded result: all three checks succeeded, and both applied files compared byte-for-byte with the prepared patched copies.

## Behavioral assertions in the regression node

The node now proves all of the following through SQLite state and indexed content:

- real ChatGPT bundle taxonomy acceptance;
- provider detection retained as `chatgpt`;
- first raw accepted and made the shared authority head;
- second divergent raw returned for retry;
- two shared memberships marked `ambiguous`/`quarantined`;
- no terminal `parse_error` rows;
- `safe-1`, `safe-2`, and `shared` remain queryable;
- shared indexed text stays `base`, `left`;
- retrying the matching first raw restores it to `applied`/`byte_proven`;
- the divergent second raw remains nonterminal debt;
- accepted head remains unchanged throughout.
