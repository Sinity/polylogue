# Anti-vacuity checks

Both mutations were performed against the passing candidate and then reverted.

## Production-condition mutation

Mutation: remove the multi-session call argument:

```python
allow_current_complete_raw=True
```

Exact node result: exit 1 at the first acceptance assertion.

```text
assert first_result.succeeded == [first]
E assert [] == [first.json]
```

This proves the test depends on the repaired production route before it can reach divergence assertions.

## Fixture-shape mutation

Mutation: replace the ChatGPT conversation key `mapping` with `not_mapping`, leaving all authority assertions unchanged.

Exact node result: exit 1 at the explicit taxonomy assertion.

```text
assert _parse_path_as_session_artifact(first, provider=Provider.CHATGPT) is True
E assert False is True
```

This proves the replacement fixture cannot silently stop representing a valid session-document bundle.

## Why these checks are complementary

The first mutation guards the authority repair. The second guards the acquisition shape. Together they prevent the old failure mode where mocks authorized arbitrary bytes while the production authority gate was never reached in a meaningful state.
