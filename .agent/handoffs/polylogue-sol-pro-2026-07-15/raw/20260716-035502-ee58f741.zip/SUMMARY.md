# Executive result

The clean-master failure was reproduced before changing the supplied source. It was not a parser exception, validation exception, or SQLite write failure. `_ingest_full_records_archive` returned normally, but its `_ArchiveFullWriteResult.raw_ids` remained empty. The source tier contained a complete two-member census, yet both memberships were still `quarantined` with no decision and the raw remained unparsed without a `parse_error`.

Instrumentation showed the decisive condition: for both logical members, `raw_membership_raw_ids(..., include_complete_raw_id=None)` returned an empty tuple. The authority filter correctly excludes quarantined evidence unless it is the caller-owned raw with a complete, undecided census. The single-session browser-snapshot route supplied that exception; the multi-session route did not. Therefore no revision entered classification, `raw_membership_authority_complete` remained false, and `_ingest_full_paths_sync` mapped the first path into `failed`.

A second reproduction used a genuine ChatGPT export JSON bundle through production detection, taxonomy, and parsing. It was detected as `chatgpt`, classified as a `session_document` with reason `bundle of session documents`, and still failed in the same authority gate. This proves the production path rejected a valid bundle. The old test fixture was independently stale because it used arbitrary Codex JSONL objects and monkeypatched `_jsonl_provider_and_session_artifact` plus `parse_stream_payload`, bypassing the source-shape contract.

The patch makes the smallest production repair: after a multi-session raw has passed artifact taxonomy and produced a complete census, the caller passes `allow_current_complete_raw=True` to `_apply_membership_sessions`. The existing storage query then admits only that exact raw, only while its census is complete and its membership decision is unset. It does not reopen unrelated quarantined or ambiguous evidence.

The test now uses two real ChatGPT export bundles and the production parser. It verifies first acceptance, explicit divergent debt, safe-member visibility, accepted-head and transcript preservation, absence of terminal parse errors, and successful authority resumption by retrying the matching first bundle.

## Acceptance-criteria matrix

| Criterion | Result | Evidence |
| --- | --- | --- |
| Reproduce the clean-master failure and record the internal reason | Satisfied | `TESTS/baseline-valid-bundle.json` records the empty candidate calls, complete census, pending memberships, empty archive raw-ID mapping, and failed first path. |
| Reach multi-session membership authority through a production-valid fixture | Satisfied | The replacement fixture is a real ChatGPT export array with native `mapping` trees; no classifier or parser monkeypatch remains. The test also asserts taxonomy acceptance and detected source name. |
| First ingest succeeds | Satisfied | Patched exact node asserts `succeeded == [first]`, `failed == []`, and captures the accepted raw head. |
| Divergent second ingest becomes explicit nonterminal debt | Satisfied | The second path is failed for retry, both shared memberships are `ambiguous`/`quarantined`, and both raw rows have `parse_error IS NULL`. |
| Safe members remain queryable | Satisfied | `safe-1`, `safe-2`, and `shared` remain in the index after divergence. |
| No accepted branch is deleted | Satisfied | The `chatgpt:shared` head remains the first raw and the indexed transcript remains `base`, `left`. |
| Matching retry can resume authority | Satisfied | Retrying `first.json` succeeds; its shared membership returns to `applied`/`byte_proven`, while the divergent second membership remains ambiguous debt. |
| Anti-vacuity | Satisfied | Removing the production admission line fails at the first-success assertion; breaking the ChatGPT `mapping` shape fails the taxonomy assertion. See `TESTS/anti-vacuity.md`. |
| Required focused selectors | Satisfied in the supplied-scope reconstructed harness | Both exact `devtools test` commands selected one node and reported `1 passed, 63 deselected`. Full-checkout limitations are in `VERIFICATION-LIMITS.md`. |

## Files changed by the patch

- `polylogue/sources/live/batch.py`: three added lines, including the caller-owned complete-raw admission and its safety comment.
- `tests/unit/sources/test_live_batch_support.py`: replaces the impossible mocked JSONL fixture with parser-backed ChatGPT bundles and extends assertions through retry.

No expected-failure list is changed.
