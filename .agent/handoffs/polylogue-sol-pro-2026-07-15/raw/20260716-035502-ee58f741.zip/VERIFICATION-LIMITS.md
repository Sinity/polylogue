# Verification limits

## What was run

- The exact unchanged failing node was executed before modifying the supplied source files.
- `_ArchiveFullWriteResult` and source/index tier state were captured for the failure.
- A second unpatched reproduction used a genuine ChatGPT export bundle with production provider detection, artifact taxonomy, and parsing.
- Candidate membership calls were instrumented to record the exact empty candidate sets and missing `include_complete_raw_id`.
- Both anti-vacuity mutations were executed and failed at their intended assertions.
- Both required `devtools test` selectors were executed successfully in the reconstructed focused harness.
- Ruff lint, Ruff format check, Python compilation, patch apply check, patch application, byte comparison, and reverse apply check were run.

## Snapshot boundary

The supplied context pack is a selected immutable source footprint, not a complete Git checkout. It does not contain `.git`, the complete test corpus, the current `devtools` source, lockfiles, or every target-commit storage module. The patch itself is based only on the supplied source files.

For executable reproduction, the harness used:

1. the public `polylogue==0.2.0` wheel for omitted package files and dependencies;
2. the exact supplied source and test files overlaid on that package;
3. target-commit versions of the small post-release modules needed by the selected route;
4. the target `pyproject.toml` and the packaged `devtools` runner for the two required focused commands.

The exact patch files and selected route were exercised, but this hybrid harness is not equivalent to a full checkout of `41cb11f8739afd303b77eafacdc92d3e88183469`.

## Exploratory adjacent selection

A non-required adjacent selection of ten membership/revision tests was attempted in the hybrid harness. Seven passed and three failed in single-session/storage interactions outside the supplied patch footprint:

- `test_single_session_full_terminally_supersedes_older_membership_prefix`
- `test_single_session_full_cannot_overwrite_divergent_membership_head`
- `test_single_session_full_advances_authorized_metadata_only_head`

Because the public wheel substrate differs substantially from the target commit and those nodes depend on omitted storage implementation, these failures were not treated as evidence for or against the two-file patch. They remain a full-checkout verification boundary and are reported rather than hidden.

## What was not run

- A complete `devtools verify` or full testmon-affected run in the operator's actual repository.
- The complete `devtools test -k raw_authority` selection from the full repository corpus; only the included 64-node test file was available.
- NixOS/devenv checks, deployment, daemon convergence against a live archive, browser capture, secrets, operator databases, or private source corpora.
- Any schema migration or generated-surface check, because the patch changes no schema, generated file, command surface, or package module.
- Beads mutation or closure, because `.beads/issues.jsonl` was already dirty in the supplied worktree and was outside the selected source patch.

## Source retrieval record

Accessed on 2026-07-15:

- Clean-master tree: `https://github.com/Sinity/polylogue/tree/41cb11f8739afd303b77eafacdc92d3e88183469`
- Clean-master live batch source: `https://raw.githubusercontent.com/Sinity/polylogue/41cb11f8739afd303b77eafacdc92d3e88183469/polylogue/sources/live/batch.py`
- Public package used only as omitted-file harness substrate: `https://pypi.org/project/polylogue/0.2.0/`

The downloaded clean-master `batch.py` was byte-identical to the context-pack copy. Public retrieval was used for harness restoration and cross-checking, not to broaden the patch beyond the supplied snapshot.
