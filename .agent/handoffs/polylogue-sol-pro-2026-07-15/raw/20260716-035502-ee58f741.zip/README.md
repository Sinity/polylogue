# Polylogue live multi-session raw-authority repair handoff

This handoff addresses `polylogue-lkrc.4`, “Restore live multi-session divergence authority coverage.” It is scoped to the immutable context pack supplied for this job.

## Read and apply order

1. Read `SUMMARY.md` for the result and acceptance matrix.
2. Read `DESIGN/raw-authority-diagnosis.md` for the reproduced failure, root cause, safety argument, and rejected alternatives.
3. Review `PATCHES/0001-fix-live-multi-session-authority.patch`.
4. From the repository root, verify and apply the patch:

   ```bash
   git apply --check /path/to/PATCHES/0001-fix-live-multi-session-authority.patch
   git am --3way /path/to/PATCHES/0001-fix-live-multi-session-authority.patch
   ```

   To apply without creating the patch commit, use `git apply` instead of `git am`.

5. Run the focused commands in `TESTS/verification-plan.md`.
6. Read `VERIFICATION-LIMITS.md` before treating the scoped verification as a full-checkout or live-daemon result.

## Base and worktree assumptions

- Clean-master reproduction revision recorded by the Bead: `41cb11f8739afd303b77eafacdc92d3e88183469`.
- Supplied snapshot HEAD: `518ac33e318995539743e220c01b9883b7a688a0` on `feature/browser/sol-pro-dispatch`.
- The selected source footprint had no staged or unstaged changes.
- The supplied worktree already had `M  .beads/issues.jsonl`; this handoff deliberately does not alter or overwrite that file.
- The patch changes only:
  - `polylogue/sources/live/batch.py`
  - `tests/unit/sources/test_live_batch_support.py`
- No schema, migration, generated surface, dependency, or new package module is introduced.

The original `batch.py` in the context pack is byte-identical to the public clean-master file at `41cb11f8739afd303b77eafacdc92d3e88183469` (SHA-256 `90481393f94213ddb9757a00437f8eb370c6dcd40f942aa22f43dabe08e33866`).

## Patch intent

The storage filter is intentionally strict: established byte-proven evidence is admitted, while unrelated quarantined raws remain excluded. The live multi-session caller had stopped passing its own newly completed census as the one permitted candidate, so the first valid bundle could never enter classification. The patch passes that caller-owned raw ID after production artifact validation and a complete membership census. The regression test replaces an impossible monkeypatched Codex JSONL shape with real ChatGPT export bundles parsed through the production route.
