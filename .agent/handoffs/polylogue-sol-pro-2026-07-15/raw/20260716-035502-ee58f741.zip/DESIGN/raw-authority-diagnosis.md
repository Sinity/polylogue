# Raw-authority diagnosis and design decision

## Scope

Work item: `polylogue-lkrc.4`, “Restore live multi-session divergence authority coverage.”

Required invariant:

1. The first branch is accepted.
2. A divergent second branch becomes explicit, nonterminal authority debt.
3. Safe members remain queryable.
4. No accepted branch is deleted or replaced by ambiguous evidence.
5. A matching retry can resume authority.

## Reproduction before source changes

The exact unchanged node failed at its first assertion:

```text
assert processor._ingest_full_paths_sync([first], source_name="codex").failed == []
E assert [first.jsonl] == []
```

Capturing the internal `_ArchiveFullWriteResult` showed:

```json
{
  "raw_ids": {},
  "session_ids": [],
  "session_count": 0,
  "message_count": 0
}
```

The source tier simultaneously showed a complete census with two members. Both membership rows had:

- `decision = NULL`
- `revision_authority = 'quarantined'`
- `parsed_at_ms = NULL`
- `parse_error = NULL`

That combination rules out a parser exception, source validation exception, or terminal archive error. The path failed because authority did not complete.

## Fixture diagnosis

The old fixture wrote:

```json
{"first": true}
```

and forced `_jsonl_provider_and_session_artifact` to return `(codex, True)`. It then forced `parse_stream_payload` to return two sessions unrelated to the bytes. That no longer expressed a valid live multi-session source artifact. The later payload-shape and authority gates remained real, so the test mixed impossible acquisition evidence with production authority behavior.

The replacement fixture is a JSON array of real ChatGPT conversation documents. Each document has a native `mapping` tree with deterministic message IDs and content. The production route:

- detects `Provider.CHATGPT`,
- classifies the payload as `ArtifactKind.SESSION_DOCUMENT`,
- records the reason `bundle of session documents`,
- parses both sessions through the real ChatGPT parser.

No acquisition or parser authorization mock remains.

## Production-path diagnosis

A valid ChatGPT bundle still failed on the unpatched route. Instrumentation recorded these calls:

```json
[
  {
    "logical_source_key": "chatgpt:shared",
    "include_complete_raw_id": null,
    "returned_raw_ids": []
  },
  {
    "logical_source_key": "chatgpt:safe-1",
    "include_complete_raw_id": null,
    "returned_raw_ids": []
  }
]
```

The relevant storage rule is deliberate. `raw_membership_raw_ids` admits:

- established membership rows with `revision_authority = 'byte_proven'`; or
- the exact `include_complete_raw_id`, but only when its census is `complete` and its membership decision is still `NULL`.

A newly censused raw starts quarantined. The multi-session caller invoked `_apply_membership_sessions` without supplying its current raw ID, so the first valid bundle produced an empty classification cohort for every member. The raw stayed incomplete and the path was returned as failed.

This is a caller regression, not a reason to weaken the storage filter.

## Chosen repair

In the `len(sessions) > 1` branch, immediately after `replace_raw_membership_census` completes, call:

```python
self._apply_membership_sessions(
    archive,
    source_raw_id,
    sessions,
    acquired_at_ms=acquired_at_ms,
    allow_current_complete_raw=True,
)
```

This mirrors the typed exception already used by complete browser snapshots, but at the correct multi-session production boundary. The current raw has already passed artifact taxonomy and produced a complete census. The callee translates the boolean into `include_complete_raw_id=source_raw_id`; storage still enforces exact ID, complete census, and undecided membership.

## Why the repair preserves source-shape validation

The change occurs after all of these gates:

1. Path/payload artifact classification accepted the source as session material.
2. Provider detection selected a concrete provider.
3. Production parsing returned more than one session.
4. `replace_raw_membership_census` persisted a complete census.

The patch does not alter `_jsonl_provider_and_session_artifact`, `_parse_path_as_session_artifact`, `_parse_payload_as_session_artifact`, provider detection, parser dispatch, or storage SQL. Invalid source shapes remain rejected before authority classification.

## Divergence behavior after the repair

First bundle:

- `chatgpt:shared` and `chatgpt:safe-1` are applied and byte-proven.
- Both sessions are indexed.
- `raw_revision_heads` points to the first raw.

Divergent second bundle:

- `chatgpt:safe-2` is safely applied and indexed.
- The two `chatgpt:shared` revisions are classified ambiguous.
- The accepted head remains the first raw.
- The indexed shared transcript remains `base`, `left`; the divergent `right` branch has no deletion or replacement authority.
- Both raws remain retryable with `parse_error = NULL`.

Matching retry of the first bundle:

- the first shared membership returns to `applied`/`byte_proven`;
- its raw becomes authority-complete again;
- the second shared membership remains `ambiguous`/`quarantined` debt;
- the accepted head is unchanged.

## Rejected alternatives

### Update the expected failed list

Rejected. It would encode the regression and make the test vacuous without restoring first-ingest authority.

### Remove or broaden the quarantine filter

Rejected. Allowing every quarantined membership into classification would reopen unrelated failed or ambiguous raws and weaken the source-evidence boundary. The existing exact-ID exception is the safer mechanism.

### Mark the whole raw byte-proven before classification

Rejected. Membership authority is per logical session. A bundle may contain both safe and divergent members; pre-authorizing the entire raw would collapse that distinction.

### Keep the arbitrary Codex JSONL fixture and add another monkeypatch

Rejected. It would authorize an impossible source shape and test a private arrangement rather than the production acquisition route.

### Route the fixture through browser capture

Rejected. Browser capture is a complete mutable snapshot of one visible session. It is not the natural representation of a multi-session export bundle.

### Add schema state or a test-only flag

Rejected. The required state already exists: provider/artifact validation plus a complete membership census. The missing operation was passing the caller-owned raw into the existing typed gate.

## Beads/worktree decision

The supplied worktree already contained a modification to `.beads/issues.jsonl` outside the selected source footprint. No Beads file is included in the patch, avoiding accidental overwrite or merge of pre-existing operator state. The diagnosis and acceptance evidence are preserved in this handoff instead.
