# Polylogue Sol Pro durable incorporation kernel

This handoff is the smallest coherent first phase for turning a receiver-validated GPT-5.6 Sol Pro result into durable incorporation work. It extends the existing LaunchJob receiver, the local `devtools` command surface, normal Git worktrees, and Beads review. It does not add an extension-owned Git engine, a second result outbox, or a parallel persistence system.

The patch series is scoped to the supplied immutable Polylogue snapshot. The recorded project revision is `9c1bbbbbf73e2e7008099fc0e2b0e0c7cedec559`. The supplied status record showed only `.beads/issues.jsonl` as dirty; both supplied Git patch captures were empty. None of these patches touches `.beads/issues.jsonl`.

## Read and apply order

1. Read `SUMMARY.md` for the outcome and acceptance matrix.
2. Read `DESIGN/architecture-state-machine.md` for authority and lifecycle decisions.
3. Read `DESIGN/handoff-contract.md` and `DESIGN/migration-v1-v2.md` for the deterministic v3 contract and legacy behavior.
4. Review the three patches in numeric order. `PATCHES/README.md` maps each patch to its responsibility.
5. Apply patches in order from a clean checkout of the recorded revision or a descendant on which all three patches pass preflight.
6. Run the checks in `TESTS/verification-plan.md` in the full repository environment.
7. Use `DESIGN/example-agent-receipt.md` as the exact downstream handoff shape, not as evidence that a live production workspace was created.
8. Read `VERIFICATION-LIMITS.md` before interpreting the test result.

## Apply without overwriting operator state

First preserve and inspect the existing worktree:

```bash
git status --short
git rev-parse HEAD
git diff -- .beads/issues.jsonl
```

Then preflight and apply:

```bash
git apply --check PATCHES/0001-feat-capture-plan-durable-Sol-Pro-handoff-intake.patch
git apply --check PATCHES/0002-feat-devtools-seed-Sol-Pro-cluster-workspaces.patch
git apply --check PATCHES/0003-test-capture-cover-Sol-Pro-incorporation-intake.patch

git am --3way \
  PATCHES/0001-feat-capture-plan-durable-Sol-Pro-handoff-intake.patch \
  PATCHES/0002-feat-devtools-seed-Sol-Pro-cluster-workspaces.patch \
  PATCHES/0003-test-capture-cover-Sol-Pro-incorporation-intake.patch
```

`git apply --check` evaluates each patch independently against the same tree, so the authoritative sequence check is either `git am --3way` in a disposable branch/worktree or the fresh-repository procedure in `TESTS/verification-plan.md`. Do not reset or replace a pre-existing `.beads/issues.jsonl` modification to make this series apply.

## Operator flow after merge

The receiver accepts the acquired ZIP, verifies its manifest and v3 intake contract, derives patch paths, records a validation receipt, and creates an initial immutable intake plan. Browser code may show that plan and submit an explicit disposition through the safe receiver route. It cannot perform Git or Beads mutations.

An operator then runs the local surface explicitly:

```bash
devtools workspace sol-pro-intake show \
  --spool .local/browser-capture \
  --job-id JOB

devtools workspace sol-pro-intake plan \
  --repo . \
  --spool .local/browser-capture \
  --job-id JOB

devtools workspace sol-pro-intake dispose \
  --spool .local/browser-capture \
  --job-id JOB \
  --actor operator \
  --action accept \
  --reason-code reviewed-for-import \
  --reason 'Reviewed receiver evidence and repository applicability receipt'

devtools workspace sol-pro-intake seed \
  --repo . \
  --spool .local/browser-capture \
  --job-id JOB \
  --worktree-root ../polylogue-worktrees
```

Research-only results stop at a reviewable Beads append-note proposal and reject repository planning. Code results require a current repository applicability plan and explicit acceptance. A seeded commit is always labeled `UNVERIFIED WAYPOINT`; clean application is not behavioral verification.

## Package map

`PATCHES/` contains the ordered mergeable series. `DESIGN/` preserves decisions, invariants, rejected alternatives, migration phases, and a later-agent receipt. `TESTS/` contains the immutable input index, exact verification transcript, a full-repository verification plan, and a v3 contract example. `MANIFEST.json` covers every other file by exact size and SHA-256.
