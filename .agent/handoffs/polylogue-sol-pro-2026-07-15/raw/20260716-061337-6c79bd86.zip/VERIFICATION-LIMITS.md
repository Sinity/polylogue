# Verification limits

## What was run

- Safety inspection and SHA-256 indexing of the supplied 109,440-byte tar archive and all 29 members.
- Review of repository instructions, complete selected Beads records, recorded Git revision/branch/status, relevant architecture, receiver helpers, command catalog, and focused tests.
- Ordered patch application in a fresh synthetic Git repository made from the supplied `REPO/` files.
- Isolated-index application of the complete patch sequence and comparison of the resulting tree.
- Twelve focused real-Git/intake/work-package tests.
- Five selected receiver/server route tests.
- Ruff over every changed source and test path.
- Mypy over the primary intake modules with missing imports skipped.
- Python compile checks and `git diff --check`.
- Canonical recomputation of the illustrative plan/receipt hashes and creation of a real deterministic example commit object.
- Final ZIP reopen, path/member safety checks, exact manifest coverage, per-file size/SHA-256 recomputation, v3 contract validation through the patched receiver validator, and independent archive byte/file counting.

## What was not run

- A live authenticated ChatGPT browser, Sol Pro conversation, extension runtime, provider download endpoint, or expiring asset acquisition.
- The operator's production receiver, daemon, secrets, CAS/blob store, databases, shared CaptureJob registry, or restart/adoption path.
- A network fetch or observation of the real current remote `origin/master`; repository drift tests used isolated local repositories and controlled remote-tracking refs.
- A live Beads append, mutation, export refresh, or issue-status transition. No `.beads/issues.jsonl` file was changed by the patch.
- A Nix build, NixOS deployment, production browser bundle, or live daemon route.
- The complete repository test suite, `devtools render all --check`, topology projection, route-schema generation, layering checks, or `devtools verify --quick`, because the supplied snapshot contains only scoped source files and omits several imported modules, generated targets, configuration, and test plugins.
- A production branch/worktree/import commit. All workspace tests and the documented example used disposable local Git repositories.
- Independent semantic review of every changed behavior by a second agent, a rebase onto a later project master, pull-request creation, publication, or merge.

## Interpretation boundary

The passing checks establish that the patch series applies to the supplied file snapshot, that the focused state transitions and safety fixtures behave as tested, and that the example provenance is internally consistent. They do not establish compatibility with changes outside the snapshot, full-system correctness, authenticated browser behavior, deployment readiness, or merge readiness.

A patch applying cleanly to current or declared base is never verification. A seeded workspace receipt explicitly records an unverified waypoint. Behavioral verification, fixes, any required rebase, generated repository artifacts, Beads updates, and normal publication remain residual work.

Temporary stubs were used only to satisfy imports omitted from the scoped snapshot. They are not packaged and did not replace the patched intake algorithms or Git operations. The repository's custom pytest marker plugin was absent, producing one non-failing unknown-marker warning in the selected route test run.

The secret-path policy rejects known secret/credential directories, filenames, key/certificate containers, Git control paths, and mutable Beads exports. It is a path and operation safety boundary, not a general content secret scanner. The explicit operator review and normal repository verification gate remain required before publication.
