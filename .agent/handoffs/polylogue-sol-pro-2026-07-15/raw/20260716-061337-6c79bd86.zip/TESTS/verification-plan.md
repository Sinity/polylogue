# Full-repository and production verification plan

This plan is executable after applying the patches in a complete Polylogue checkout. It separates merge-gating checks from live evidence that requires operator-controlled browser, receiver, repository, Beads, and deployment state.

## 1. Preserve the operator worktree

```bash
git status --short
git rev-parse HEAD
git diff -- .beads/issues.jsonl
```

Do not reset the existing `.beads/issues.jsonl` change. Create a clean review worktree/branch if the current checkout contains unrelated changes.

## 2. Apply and inspect the series

```bash
git switch -c review/sol-pro-durable-intake <recorded-or-reviewed-base>
git am --3way \
  PATCHES/0001-feat-capture-plan-durable-Sol-Pro-handoff-intake.patch \
  PATCHES/0002-feat-devtools-seed-Sol-Pro-cluster-workspaces.patch \
  PATCHES/0003-test-capture-cover-Sol-Pro-incorporation-intake.patch

git diff --check HEAD~3..HEAD
git show --stat --oneline HEAD~2..HEAD
```

If the complete repository has moved beyond the scoped snapshot, resolve conflicts semantically. Do not replace newer LaunchJob, receiver-registry, or Beads behavior with the scoped versions.

## 3. Regenerate required project projections

The repository instructions require generated topology updates when a module is added under `polylogue/`. This series adds a module only under `devtools/`, but it changes command catalog and browser-capture surfaces. Run the normal generators/checkers in the full checkout:

```bash
devtools render all
devtools render all --check
```

Review generated diffs and include only required projections. The scoped source pack did not contain the generated targets, so this could not be completed here.

## 4. Run focused tests without stubs

```bash
pytest -q \
  tests/unit/devtools/test_sol_pro_intake.py \
  tests/unit/browser_capture/test_work_package.py

pytest -q tests/unit/browser_capture/test_launch_jobs.py
```

Then run the project's ordinary gate:

```bash
devtools verify --quick
```

Any full-repository type, layering, route-schema, generated-doc, or browser bundle failure must be fixed before merge.

## 5. Receiver-route safety fixture

In an isolated spool, create/claim a LaunchJob and POST a valid deterministic handoff through the real receiver HTTP route. Assert:

1. exact bytes exist under the receiver-owned job storage before validation outcome;
2. validation receipt binds artifact reference, size, SHA-256, profile, reason, and receipt digest;
3. `.beads/issues.jsonl`, `.git`, traversal, duplicate-portable paths, secret paths, replacement payloads, inventory mismatch, symlink modes, and path-claim mismatch all reject with stable reasons;
4. invalid artifacts never produce an accepted plan or worktree;
5. browser disposition requests alter only receiver receipts/projection.

Repeat with an identical archive under another job, and with identical ordered patch bytes renamed, to prove artifact and patchset duplicate paths independently.

## 6. Repository applicability matrix

Use disposable repositories with locally controlled refs:

- patch applies to current `refs/remotes/origin/master`;
- current fails and declared base is present/applies;
- current ref absent;
- current fails and declared base absent;
- both present and both fail;
- origin/master advances after accepted plan;
- existing cluster worktree is dirty;
- next overlapping patch applies to cluster HEAD;
- bridge touches two existing cluster IDs;
- commit hook mutates the message or worktree.

For each case, compare plan/receipt digests, reason codes, selected base, result tree, and branch/worktree side effects. Confirm rollback leaves no unreceipted branch, worktree, or import commit reachable from the cluster branch.

## 7. Exact import review

For a seeded sample:

```bash
JOB=<job-id>
devtools workspace sol-pro-intake show --spool <spool> --job-id "$JOB" > /tmp/intake.json

BRANCH=$(jq -r '.intake_workspace_receipts[-1].branch' /tmp/intake.json)
WORKTREE=$(jq -r '.intake_workspace_receipts[-1].worktree_path' /tmp/intake.json)
COMMIT=$(jq -r '.intake_workspace_receipts[-1].import_commit' /tmp/intake.json)
TREE=$(jq -r '.intake_workspace_receipts[-1].expected_import_tree' /tmp/intake.json)

test "$(git -C "$WORKTREE" rev-parse "$COMMIT^{tree}")" = "$TREE"
git -C "$WORKTREE" show --no-ext-diff --format=fuller --stat "$COMMIT"
git -C "$WORKTREE" status --porcelain=v1 --untracked-files=all
```

Confirm the commit says `UNVERIFIED WAYPOINT`, includes all provenance lines, and is followed by separate verification/fix commits rather than amendment.

## 8. Research-only Beads route

Submit a v3 research result with no patches or paths. Assert `research_notes_proposed`, one exact proposal per target Bead, and refusal by `plan`/`seed`. Review the proposal text, then append it through the normal Beads operation in a disposable Beads fixture. Assert the receiver and browser never directly edit `.beads/issues.jsonl`.

## 9. Browser projection smoke test

After a later UI patch, reload the unpacked extension against a controlled receiver. Confirm it can display validation, classification, proposal, applicability, disposition, and workspace state and can submit only explicit dispositions. Inspect extension permissions/messages to prove no Git/worktree/Beads mutation primitive was added.

This phase's patch does not include that popup projection; the HTTP disposition route is the kernel contract for it.

## 10. Shared registry and recovery integration

When `polylogue-06zm.1` lands, migrate plan/receipt storage into the shared receiver registry and test:

- restart and profile-loss recovery;
- lease/adoption and CAS conflicts;
- exact receipt-chain continuity;
- stale browser caches rehydrating from receiver state;
- no acknowledged result replay;
- no parallel JSON and SQLite authorities after cutover.

## 11. Independent verification and publication

A separate agent reviews the imported patch, runs relevant project tests, fixes defects in later commits, rebases when the receipt requires it, updates Beads through normal commands, and opens/publishes/merges through the existing project route. Record those verification and publication outcomes separately; never mutate the original intake receipt into a verification claim.
