# Verification results

All checks below were run on 2026-07-16 inside the supplied container. Exact command output is preserved under `TESTS/logs/`.

## Immutable input inspection

Input: `polylogue-sol-pro-context-8cf244526fff6a1a.tar.gz`

- Archive size: 109,440 bytes.
- Archive SHA-256: `8cf244526fff6a1a9a7461f802c43a8c83e494fae06247fcdc0713d90c63e57c`.
- Members: 29.
- All members were regular files with unique normalized relative paths.
- No absolute path, `..` traversal, duplicate member, symlink, hard link, device, FIFO, or socket was accepted.
- Every member's size and SHA-256 is recorded in `TESTS/context-member-index.json`.

The recorded repository revision was `9c1bbbbbf73e2e7008099fc0e2b0e0c7cedec559` on branch `feature/browser/sol-pro-dispatch`. `GIT/status.txt` identified `.beads/issues.jsonl` as the only dirty path. The staged and working-tree patch captures were both zero-byte files with SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. A canonical empty untracked inventory (`[]\n`) has SHA-256 `37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570`.

## Fresh patch application

The files under `context/REPO/` were copied into a fresh Git repository and committed as an immutable synthetic baseline representing the recorded source revision. The three email-format patches were then applied in order with `git am` without conflict:

```text
Applying: feat(capture): plan durable Sol Pro handoff intake
Applying: feat(devtools): seed Sol Pro cluster workspaces
Applying: test(capture): cover Sol Pro incorporation intake
```

The synthetic verification baseline commit is `29624e07ddc2172f20ae7156604667bf588c59b4`; it is not the project's recorded object ID. The final patch-applied tree is `ca9c6caefec03ec5ea6301752a83424560427e18`. The scoped source snapshot does not include the original `.git` object database, so the recorded revision's object identity could not be reconstructed or used as a parent locally.

The ordered patches were also applied as raw patch bytes to an isolated Git index initialized from the synthetic baseline; the resulting tree matched `ca9c6caefec03ec5ea6301752a83424560427e18`.

## Focused executable tests

Environment:

- Python 3.13.5
- Git 2.47.3
- pytest 9.0.2
- Ruff 0.15.21
- mypy 2.3.0

The scoped snapshot omits several imported modules and the repository pytest plugin. Temporary import stubs under `/tmp/solpro-stubs` supplied only those omitted interfaces; they are not part of this ZIP or patch series. The patched production LaunchJob/server/devtools code and real temporary Git repositories were exercised.

Command:

```bash
PYTHONPATH=/tmp/solpro-stubs:. pytest -q \
  tests/unit/devtools/test_sol_pro_intake.py \
  tests/unit/browser_capture/test_work_package.py
```

Result:

```text
............                                                             [100%]
12 passed in 3.37s
```

These tests cover current-master exact import, declared-base fallback and rebase flag, renamed duplicate patchset suppression, overlap-cluster worktree reuse, research-only note behavior, missing current remote-tracking ref, post-plan origin drift/defer/replan, and deterministic dirty-state packaging.

Receiver/server route subset:

```bash
PYTHONPATH=/tmp/solpro-stubs:. pytest -q \
  tests/unit/browser_capture/test_launch_jobs.py \
  -k 'existing_v2_launch_job or handoff_completion_requires or receiver_routes_enqueue or unsafe_patch_is_acquired or research_disposition_route'
```

Result:

```text
.....                                                                    [100%]
5 passed, 13 deselected, 1 warning in 1.22s
```

The warning is `PytestUnknownMarkWarning` for the repository's `frozen_clock_modules` marker because the scoped snapshot omits its plugin/registration. The selected tests passed. They cover acquired-and-validated cohesive ZIP completion, safe receiver routes, acquired-then-rejected `.beads/issues.jsonl` patch evidence, research disposition/no-worktree state, and legacy v2 `legacy_metadata_required` migration.

## Static and structural checks

Ruff was run over every changed source/test path:

```text
All checks passed!
```

Mypy was run over the principal new/changed intake modules with omitted imports skipped:

```text
Success: no issues found in 4 source files
```

`git diff --check HEAD~3..HEAD` and Python `compileall` both exited zero. Exact invocations and exit-code aggregation are under `TESTS/logs/`.

## Example receipt reproducibility

`TESTS/example-receipts.json` contains canonical applicability, plan, disposition, research-proposal, commit, and workspace examples. Their digest fields were recomputed from sorted-key compact JSON excluding each digest field itself. The illustrative import commit `a05022e5550916e22dde2bbf981df9c5c5f472bc` is a real deterministic commit object created in the isolated verification repository with:

- parent `29624e07ddc2172f20ae7156604667bf588c59b4`;
- tree `ca9c6caefec03ec5ea6301752a83424560427e18`;
- exact message SHA-256 `378c7c53b8ab3c772a70872cafd6e3232d0b694b6a0d30632a4982368c91fa5a`.

It is an example object, not a production workspace or merged project commit.
