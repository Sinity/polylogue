# Phased migration for existing v1/v2 handoffs

## Principle

Existing ZIPs are immutable evidence. Migration adds reviewed metadata and receipts; it never edits or silently reissues the original artifact. Missing deterministic fields are not inferred from prose, branch names, patch filenames, or provider assertions.

## Phase 1 — implemented compatibility classification

When a LaunchJob with profile `polylogue-sol-pro-worker-v1` or `polylogue-sol-pro-worker-v2` submits a package without an `intake` object, the receiver still validates the package's required root structure and exact manifest coverage, sizes, and SHA-256 values. It then creates an intake plan with:

- `handoff_schema = legacy:<prompt-profile>`;
- `contract = null`;
- `classification = legacy_metadata_required`;
- `recommended_action = supply_reviewed_v3_sidecar`;
- `reason_codes = [legacy_handoff_lacks_deterministic_intake]`;
- acquired artifact and LaunchJob/conversation provenance preserved.

No repository applicability check, branch, worktree, patch application, or research-note generation is allowed from that state. Duplicate artifact SHA evidence can still be retained in receiver history, but incomplete metadata is not upgraded by guessing.

A v1/v2 package that already contains a valid v3 `intake` object receives full deterministic validation. This allows additive compatibility without changing its original profile label.

## Phase 2 — reviewed sidecar binding

A later patch should add a local, explicit sidecar command. The sidecar should contain only the missing v3 contract and reviewer evidence, including:

- exact original artifact SHA-256 and LaunchJob ID;
- reviewer identity and timestamp;
- source used to establish target Beads and revisions;
- patch inventory and locally recomputed per-patch SHA-256 values;
- locally derived touched paths and reviewed owned-path envelope;
- dirty-state digests, residual work, and verification limits;
- sidecar SHA-256 and append-only receiver receipt.

The receiver should validate the sidecar against the immutable original ZIP without repackaging it. A successful binding should create a new plan revision referencing the legacy plan digest and the sidecar receipt. Conflicts or ambiguity remain `legacy_metadata_required` with a durable reason.

This phase is designed but not implemented in the patch series.

## Phase 3 — projection-only browser workflow

The extension may later render:

- artifact and validation state;
- legacy missing-field checklist;
- duplicate/overlap classification;
- proposed Beads notes;
- applicability and rebase status;
- disposition history and workspace outcome.

It may submit a reviewed disposition or request that an operator perform local planning. It must not create sidecars without explicit field review, run Git, write Beads, or seed worktrees.

## Phase 4 — shared receiver registry adoption

When `polylogue-06zm.1` lands the receiver-authoritative CaptureJob/LaunchJob registry, migrate the current atomic-JSON plan and receipt structures into that shared durable boundary:

- stable job identity and scope remain owned by the shared registry;
- intake plans become revisioned/CAS records associated with the job;
- validation, disposition, and workspace receipts remain append-only and hash-linked;
- client extension state remains a cache/projection;
- explicit discovery/adoption handles profile loss without duplicating an intake-specific database.

The migration must preserve exact receipt bytes or canonical payloads and prove digest continuity. It must not create a Sol-Pro-only SQLite store beside the shared registry.

## Mapping guidance

| Legacy evidence | v3 field / action | Rule |
|---|---|---|
| Worker profile in manifest | Existing `prompt_profile` | Preserve exactly. It identifies prompt contract, not verification. |
| Patch files present under `PATCHES/` | `patches[]` | Recompute byte SHA-256 and review order explicitly; do not sort filenames as an authority. |
| Bead IDs mentioned in prose | `target_beads[]` | Human review required. Prose mention alone is insufficient. |
| Git HEAD in bundled context | `source_revision` | Use only when the context provenance is explicit and reviewed. |
| Claimed base in summary/patch headers | `declared_base_revision` | Human review and local object resolution required. |
| Supplied staged/working patches | `input_dirty_state` | Hash exact supplied bytes, including an empty file. |
| Supplied untracked list | `untracked_inventory_sha256` | Canonicalize through a defined sidecar tool; absence is not automatically an empty list. |
| Patch diff headers | `touched_paths[]` | Derive with the same safe parser used by receiver validation. |
| Repository directories affected | `owned_paths[]` | Reviewer chooses the narrow scope envelope; every touched path must fit. |
| “TODO”, caveat, test prose | `residual_work[]`, `verification_limits[]` | Review and preserve, but never upgrade claims to verification evidence. |
| Research report | `result_kind=research` | Requires no patch payload or path ownership; creates note proposals only. |

## Existing artifact disposition

Rejected, obsolete, and duplicate legacy artifacts still need an explicit durable disposition reason. The correct endpoint is not deletion: keep the acquired artifact, validation/legacy plan, and append-only receipt so future operators can explain why no workspace exists.
