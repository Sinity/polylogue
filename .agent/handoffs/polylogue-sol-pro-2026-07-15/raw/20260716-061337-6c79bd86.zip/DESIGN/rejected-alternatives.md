# Rejected alternatives

## A second Sol Pro outbox or result store

Rejected because the existing LaunchJob receiver already links an authenticated conversation, acquired result bytes, local validation, and completion. A second outbox would split authority and duplicate adoption/recovery semantics. The future transactional receiver registry belongs to `polylogue-06zm.1` and should absorb these plan/receipt records rather than coexist with a Sol-Pro-only database.

## Browser-extension Git or Beads mutation

Rejected because an extension has ambient authenticated page authority, not repository or issue-tracker authority. It may project receiver state and submit a deliberate disposition, but it receives no Git, filesystem-worktree, or Beads-write primitive.

## One branch/worktree per chat

Rejected because conversations are transport units, not integration boundaries. Related patches commonly overlap paths and Beads. The cluster algorithm groups connected work into one subsystem worktree while preserving one imported commit and receipt per handoff.

## Automatically applying every validated code handoff

Rejected because validation proves package consistency, not intent, freshness, overlap safety, or code correctness. Code seeding requires repository observation and an explicit acceptance receipt for the current plan.

## Treating a clean patch application as verification

Rejected explicitly. Applicability is only a Git tree-transition observation. Ready plans, commit messages, receipts, and docs all preserve `unverified`; independent tests, review, fixes, and normal merge remain mandatory.

## Applying directly to the operator's current checkout

Rejected because it risks staged/unstaged state and makes provenance ambiguous. Applicability uses an isolated index; accepted code uses a dedicated or reused cluster worktree.

## Fetching `origin/master` during planning

Rejected because an intake tool must not silently mutate repository refs or depend on network/authentication. It observes the exact local remote-tracking ref, blocks if absent, and records drift if it changes between plan and seed.

## Always falling back to the declared base

Rejected because current-master incorporation is the desired path. Declared-base fallback is allowed only after current-master failure and only when the exact commit is locally present. It always carries `rebase_required=true`.

## Directly applying `.beads/issues.jsonl`

Rejected because it is a mutable export and the supplied worktree already reported it dirty. Research produces an append-note proposal; Beads remains authoritative and is changed only through its normal reviewed operation.

## Inferring missing v1/v2 metadata from prose or filenames

Rejected because target Beads, patch order, revisions, dirty inputs, ownership, and residual work cannot be reconstructed deterministically. Legacy artifacts are preserved and classified `legacy_metadata_required` until a separately reviewed v3 sidecar is bound to their artifact SHA-256.

## Full replacement archives and provider-declared verification

Rejected because replacements obscure review boundaries and may overwrite local work. Only ordered unified patches in `PATCHES/` are seedable in phase one. Statements such as “tests passed,” “based on master,” or “verified” remain claims in the artifact; they never elevate receiver verification state.

## Broad popup UI before a durable kernel

Rejected for the first phase. UI built before stable plan and receipt semantics would either be cosmetic or gain unsafe implicit authority. The receiver route and command surface provide the contract for a later projection-only UI.

## Automatic rebase, fix, publish, or merge

Rejected because those actions require semantic conflict resolution, independent verification, credentials, and project policy. The workspace receipt makes remaining work machine-readable without claiming completion.
