# Delivery and follow-on phase map

## Phase 1 — this patch series

Receiver kernel:

- acquire exact result bytes before validation outcome;
- validate full manifest and deterministic v3 intake contract;
- reject unsafe/protected/replacement content with durable reasons;
- classify legacy, research, duplicate artifact, duplicate patchset, overlap, and cluster bridge cases;
- generate research Beads note proposals;
- seal immutable plan revisions and append-only disposition/workspace receipts;
- expose a safe receiver disposition route.

Local incorporation kernel:

- explicitly plan against local current `origin/master`, then a present declared base;
- record applicability without claiming verification;
- explicitly accept/defer/reject/duplicate/obsolete;
- create/reuse one cluster worktree for code only;
- commit exact imported GPT tree and provenance as an unverified waypoint;
- record drift, conflict, dirty-state, rollback, and seed outcomes.

Tests:

- focused real-Git and receiver-route coverage in the supplied snapshot;
- exact package/provenance examples and full-repository verification plan.

## Phase 2 — projection and reviewed legacy sidecars

- Render plan, duplicate/overlap, note, applicability, disposition, and workspace status in browser UI.
- Permit only deliberate receiver disposition requests.
- Add a local reviewed-sidecar workflow for v1/v2 artifacts, bound to immutable artifact SHA-256 and a sidecar receipt.
- Add operator tooling to copy an accepted research proposal into the normal Beads append-notes command without browser-side mutation.

## Phase 3 — verification orchestration

- Create a verification task/Bead linkage from a seeded workspace receipt.
- Run project-specific verification in the cluster worktree and record test commands/results as separate evidence.
- Preserve the original import commit; add fixes, generated projections, and rebase commits afterward.
- Surface rebase-required and verification-blocked state without conflating it with intake.

## Phase 4 — shared receiver durability

- Move LaunchJob/intake plans and receipts into the receiver-authoritative registry delivered by `polylogue-06zm.1`.
- Add lease/adoption, CAS, restart, profile-loss, and cache-rehydration tests.
- Retire atomic JSON only after a single-authority migration; do not leave a Sol-Pro-specific store in parallel.

## Phase 5 — publication integration

- Hand verified cluster work to the existing Polylogue/devtools/Git/Beads publication route.
- Record branch/PR/merge and Beads outcomes as new receipts or assertions.
- Never convert the original provider artifact or applicability receipt into a verified claim.
