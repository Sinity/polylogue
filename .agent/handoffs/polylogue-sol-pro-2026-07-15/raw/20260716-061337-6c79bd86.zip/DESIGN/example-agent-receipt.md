# Precise later-agent outputs

These are two mutually exclusive route examples. A research-only handoff yields the Beads proposal and no worktree. A code-bearing handoff yields the branch/worktree/import receipt and no automatic Beads mutation. The code example was generated against the isolated verification clone so its commit object and all displayed canonical receipt hashes are internally reproducible; it is not evidence of a production workspace, browser session, or merge.

## Research-only Beads append-note proposal

Proposal SHA-256: `6df4dc98f820102bb91d8e7b7dbf95a05855652018626d31f09b8b1e088f301e`

```text
[UNVERIFIED SOL PRO RESEARCH HANDOFF — review before Beads append]
Target Bead: polylogue-yyvg.5
LaunchJob: sol-pro-polylogue-yyvg-5-research-example
Conversation: https://chatgpt.com/c/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee
Artifact SHA-256: b423cccf12969662cdab332654f7cf1104f9af345f9a9753d6061b45533b0948
Prompt profile: polylogue-sol-pro-worker-v3
Declared source/base: 29624e07ddc2172f20ae7156604667bf588c59b4 / 29624e07ddc2172f20ae7156604667bf588c59b4

Research summary from the immutable handoff:
Receiver adoption should own stable identity and immutable evidence. Browser code should remain a projection and explicit-disposition surface; local devtools should own repository observation.

Residual work declared by the worker:
- Reconcile the proposal with the shared CaptureJob registry owned by polylogue-06zm.1.
- Record the reviewed conclusion through the normal Beads append-notes operation.

Verification limits declared by the worker:
- Source review only; no live receiver or browser execution was performed.
- Provider statements were not treated as implementation evidence.

This proposal records research only. No Git worktree was created and no Beads record was mutated.
```

Receiver proposal object:

```json
{
  "bead_id": "polylogue-yyvg.5",
  "note_markdown": "[UNVERIFIED SOL PRO RESEARCH HANDOFF — review before Beads append]\nTarget Bead: polylogue-yyvg.5\nLaunchJob: sol-pro-polylogue-yyvg-5-research-example\nConversation: https://chatgpt.com/c/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee\nArtifact SHA-256: b423cccf12969662cdab332654f7cf1104f9af345f9a9753d6061b45533b0948\nPrompt profile: polylogue-sol-pro-worker-v3\nDeclared source/base: 29624e07ddc2172f20ae7156604667bf588c59b4 / 29624e07ddc2172f20ae7156604667bf588c59b4\n\nResearch summary from the immutable handoff:\nReceiver adoption should own stable identity and immutable evidence. Browser code should remain a projection and explicit-disposition surface; local devtools should own repository observation.\n\nResidual work declared by the worker:\n- Reconcile the proposal with the shared CaptureJob registry owned by polylogue-06zm.1.\n- Record the reviewed conclusion through the normal Beads append-notes operation.\n\nVerification limits declared by the worker:\n- Source review only; no live receiver or browser execution was performed.\n- Provider statements were not treated as implementation evidence.\n\nThis proposal records research only. No Git worktree was created and no Beads record was mutated.",
  "proposal_sha256": "6df4dc98f820102bb91d8e7b7dbf95a05855652018626d31f09b8b1e088f301e"
}
```

A later agent receives this text for review and uses the normal Beads append-notes mechanism. The receiver and extension do not write `.beads/issues.jsonl`.

## Code-bearing cluster identity

- Cluster: `sol-pro-167337beaebc1ca3`
- Branch: `feature/sol-pro/polylogue-06zm.1-167337beaebc1ca3`
- Worktree: `/realm/polylogue-worktrees/polylogue-06zm.1-167337beaebc1ca3`
- Selected base: `29624e07ddc2172f20ae7156604667bf588c59b4`
- Expected/import tree: `ca9c6caefec03ec5ea6301752a83424560427e18`
- Import commit: `a05022e5550916e22dde2bbf981df9c5c5f472bc`
- Rebase required: `false`
- Plan SHA-256: `f0f9db48b5214e40d489b36b8598ab4a72559440c5a32770e5359250a45b7a18`
- Applicability receipt SHA-256: `505fe76290d5b69176f3940c7f89e9169f45dfd2069f35a737ae133dd788cb96`
- Accepting disposition SHA-256: `77a72a9ece2f725b414aa4d7623f45fefaddb2f16b1d09e9229512c2b282bdc6`
- Commit-message SHA-256: `378c7c53b8ab3c772a70872cafd6e3232d0b694b6a0d30632a4982368c91fa5a`
- Workspace receipt SHA-256: `423bf09aefe5932a6225410561baa52684b198a0d3bbb86b9d6ff26a203e6331`

## Exact unverified import commit message

```text
chore(sol-pro): import unverified GPT draft for polylogue-06zm.1

UNVERIFIED WAYPOINT: exact receiver-validated ordered GPT patch inventory.
Patch applicability is not behavioral verification. Corrections belong in later commits.

LaunchJob-ID: sol-pro-polylogue-yyvg-5-example
Conversation-ID: 11111111-2222-3333-4444-555555555555
Conversation-URL: https://chatgpt.com/c/11111111-2222-3333-4444-555555555555
Artifact-SHA256: 28bcfa47a0b539968c343fdcecaf673f31b69d7c0714a7a4c7aa5d0d831e5f3b
Prompt-Profile: polylogue-sol-pro-worker-v2
Handoff-Schema: polylogue-sol-pro-handoff-v3
Source-Revision: 29624e07ddc2172f20ae7156604667bf588c59b4
Declared-Base-Revision: 29624e07ddc2172f20ae7156604667bf588c59b4
Current-Origin-Master-Revision: 29624e07ddc2172f20ae7156604667bf588c59b4
Selected-Base-Ref: refs/remotes/origin/master
Selected-Base-Revision: 29624e07ddc2172f20ae7156604667bf588c59b4
Input-Staged-Patch-SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
Input-Working-Tree-Patch-SHA256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
Input-Untracked-Inventory-SHA256: 37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570
Target-Beads: ["polylogue-06zm.1","polylogue-5k5l","polylogue-yyvg.5"]
Owned-Paths: ["devtools","polylogue/browser_capture","tests/unit/browser_capture","tests/unit/devtools"]
Touched-Paths: ["devtools/command_catalog.py","devtools/sol_pro_intake.py","polylogue/browser_capture/launch_jobs.py","polylogue/browser_capture/models.py","polylogue/browser_capture/route_contracts.py","polylogue/browser_capture/server.py","polylogue/browser_capture/sol_pro_prompt.py","polylogue/browser_capture/work_package.py","tests/unit/browser_capture/test_launch_jobs.py","tests/unit/browser_capture/test_work_package.py","tests/unit/devtools/test_sol_pro_intake.py"]
Patch-Inventory: [{"order":1,"path":"PATCHES/0001-feat-capture-plan-durable-Sol-Pro-handoff-intake.patch","sha256":"fb72e4fefb60169ea353ac8e54e6469416b1018d275ecc1143073d64d3a99133"},{"order":2,"path":"PATCHES/0002-feat-devtools-seed-Sol-Pro-cluster-workspaces.patch","sha256":"1012a63dfa7f7a85741c67c102ae6c4fae30e0fc0310bcdb869b1968d5b56602"},{"order":3,"path":"PATCHES/0003-test-capture-cover-Sol-Pro-incorporation-intake.patch","sha256":"03c0ccdab98ec30393061c44bf8861b689e123660a8704b16fe989e45905959d"}]
Patchset-SHA256: 8cf9d944f0b5c5d1409e11630c3261c2ea8ae810b5dc14f1573a3752991caab5
Applicability-Receipt-SHA256: 505fe76290d5b69176f3940c7f89e9169f45dfd2069f35a737ae133dd788cb96
Rebase-Required: false
Residual-Work: ["Run the complete repository quick gate and generated topology/document checks.","Independently review and test receiver concurrency behavior in the full dependency graph.","Project intake state in the browser without granting browser Git or Beads authority."]
Verification-Limits: ["The scoped snapshot omitted several imported production dependencies; focused tests used temporary stubs for those imports only.","No live authenticated ChatGPT browser, production daemon, remote fetch, Beads write, NixOS deployment, publish, or merge was exercised.","Git applicability and exact import provenance do not establish behavioral correctness."]
Verification-State: unverified
```

## Accepting disposition receipt

```json
{
  "receipt_schema": "polylogue-sol-pro-disposition-v1",
  "sequence": 1,
  "receipt_id": "disp-example-0001",
  "at": "2026-07-16T01:16:00+00:00",
  "job_id": "sol-pro-polylogue-yyvg-5-example",
  "artifact_sha256": "28bcfa47a0b539968c343fdcecaf673f31b69d7c0714a7a4c7aa5d0d831e5f3b",
  "plan_sha256": "f0f9db48b5214e40d489b36b8598ab4a72559440c5a32770e5359250a45b7a18",
  "previous_receipt_sha256": null,
  "actor": "operator",
  "action": "accept",
  "reason_code": "reviewed-for-import",
  "reason": "Reviewed receiver evidence, overlap classification, and current-origin/master applicability receipt.",
  "receipt_sha256": "77a72a9ece2f725b414aa4d7623f45fefaddb2f16b1d09e9229512c2b282bdc6"
}
```

## Workspace receipt

```json
{
  "receipt_schema": "polylogue-sol-pro-workspace-v1",
  "sequence": 1,
  "receipt_id": "workspace-example-0001",
  "at": "2026-07-16T01:17:01+00:00",
  "job_id": "sol-pro-polylogue-yyvg-5-example",
  "artifact_sha256": "28bcfa47a0b539968c343fdcecaf673f31b69d7c0714a7a4c7aa5d0d831e5f3b",
  "plan_sha256": "f0f9db48b5214e40d489b36b8598ab4a72559440c5a32770e5359250a45b7a18",
  "disposition_receipt_sha256": "77a72a9ece2f725b414aa4d7623f45fefaddb2f16b1d09e9229512c2b282bdc6",
  "workspace_status": "seeded",
  "cluster_id": "sol-pro-167337beaebc1ca3",
  "branch": "feature/sol-pro/polylogue-06zm.1-167337beaebc1ca3",
  "worktree_path": "/realm/polylogue-worktrees/polylogue-06zm.1-167337beaebc1ca3",
  "current_origin_master_revision": "29624e07ddc2172f20ae7156604667bf588c59b4",
  "declared_base_revision": "29624e07ddc2172f20ae7156604667bf588c59b4",
  "selected_base_revision": "29624e07ddc2172f20ae7156604667bf588c59b4",
  "cluster_head_before": "29624e07ddc2172f20ae7156604667bf588c59b4",
  "import_commit": "a05022e5550916e22dde2bbf981df9c5c5f472bc",
  "expected_import_tree": "ca9c6caefec03ec5ea6301752a83424560427e18",
  "import_tree": "ca9c6caefec03ec5ea6301752a83424560427e18",
  "patch_applicability_receipt_sha256": "505fe76290d5b69176f3940c7f89e9169f45dfd2069f35a737ae133dd788cb96",
  "commit_message_sha256": "378c7c53b8ab3c772a70872cafd6e3232d0b694b6a0d30632a4982368c91fa5a",
  "rebase_required": false,
  "reason_code": "unverified_import_seeded",
  "detail": "exact ordered patch inventory committed as an unverified waypoint; independent verification/fixes and normal publication remain required",
  "receipt_sha256": "423bf09aefe5932a6225410561baa52684b198a0d3bbb86b9d6ff26a203e6331"
}
```

The later verification agent starts from `feature/sol-pro/polylogue-06zm.1-167337beaebc1ca3` at `/realm/polylogue-worktrees/polylogue-06zm.1-167337beaebc1ca3`, verifies that `git rev-parse a05022e5550916e22dde2bbf981df9c5c5f472bc^{tree}` equals `ca9c6caefec03ec5ea6301752a83424560427e18`, treats that commit as the immutable GPT draft, and adds review/fix/rebase commits afterward. It does not amend the waypoint or claim verification from applicability.
