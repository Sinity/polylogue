# Architecture and state-machine decision

## Decision

Validated Sol Pro handoffs become receiver-authoritative intake records, then enter ordinary local development through an explicit `devtools` operation. The browser extension remains a projection and operator-control surface. Git remains authoritative for repositories, branches, commits, indexes, and worktrees. Beads remains authoritative for issue notes and status. Publication remains the existing Polylogue/developer merge path.

This is a kernel-first phase: durable evidence, classification, disposition, repository planning, and exact import seeding are implemented before broad popup UI or verification orchestration.

## Authority map

| Concern | Authority | Implemented behavior |
|---|---|---|
| LaunchJob identity, lease, conversation binding | Existing receiver | Existing receiver-captured values are copied into intake evidence; provider claims cannot replace them. |
| Acquired result bytes | Existing receiver LaunchJob spool | Exact bytes are written before validation, then size/SHA-256 checked on every read. Invalid results retain rejection receipts and artifact references. |
| Handoff validation | Receiver | Validates ZIP structure, manifest coverage/hashes/sizes, prompt profile, v3 intake schema, patch inventory, derived paths, protected paths, and bounded quotas. |
| Initial duplicate/overlap/research triage | Receiver | Produces an immutable hash-sealed intake plan from receiver-visible jobs and deterministic contract fields. |
| Operator disposition | Receiver route / explicit local command | Appends a CAS-bound, hash-chained receipt. No Git or Beads mutation occurs at this boundary. |
| Repository observation | Local `devtools workspace sol-pro-intake plan` | Reads local Git refs and applies patch bytes to an isolated index. It CAS-replaces only repository-observation fields in the receiver plan. It never fetches implicitly. |
| Branch, worktree, import commit | Git, invoked by explicit local devtools command | Seeds only accepted, code-bearing, non-duplicate, repository-ready plans. One cluster maps to one branch/worktree. |
| Research incorporation | Beads, after human review | Receiver emits exact append-note proposals. No worktree is created and no `.beads/issues.jsonl` write is attempted. |
| Independent verification and fixes | Later development agent/operator | Subsequent commits; the imported GPT commit is never rewritten into a falsely verified state. |
| Publish/merge | Existing Polylogue/devtools/Git/Beads workflow | Out of scope for automatic action. Receipts expose the evidence later automation needs. |

## State machine

The receiver's existing LaunchJob execution states remain intact. Intake begins only after the exact provider result has been acquired.

```text
provider result bytes
    |
    v
ACQUIRED (artifact_ref + size + SHA-256 persisted)
    |
    +-- validation failure ------------------------------+
    |                                                    |
    |                                         REJECTED EVIDENCE
    |                                         validation receipt has
    |                                         accepted=false + reason
    |
    v
VALIDATED (validation receipt accepted=true)
    |
    v
INITIAL INTAKE PLAN
    |
    +-- legacy v1/v2 ----------> legacy_metadata_required
    |                            reviewed v3 sidecar required later
    |
    +-- duplicate -------------> duplicate_artifact / duplicate_patchset
    |                            explicit duplicate receipt; no worktree
    |
    +-- research --------------> research_notes_proposed
    |                            exact note proposals; no worktree
    |
    +-- overlap bridge --------> blocked_cluster_bridge
    |                            explicit cluster decision required
    |
    +-- code ------------------> code_pending_repository_plan or
                                 overlap_pending_repository_plan
                                      |
                                      v
                         EXPLICIT LOCAL REPOSITORY PLAN
                                      |
                 +--------------------+-------------------+
                 |                    |                   |
                 v                    v                   v
       code_ready_current_master  code_ready_declared_   blocked_*
                                 base_rebase_required
                 |                    |
                 +---------+----------+
                           |
                           v
                    EXPLICIT DISPOSITION
                    accept/reject/duplicate/
                    obsolete/defer
                           |
                  accept current plan only
                           |
                           v
                    EXPLICIT LOCAL SEED
                           |
              +------------+-------------+
              |                          |
              v                          v
       workspace_seeded              blocked receipt
       exact unverified commit       drift/dirty/conflict/hook/
       + durable receipt             tree/receipt failure
              |
              v
       INDEPENDENT VERIFY/FIX
       later commits, rebase if flagged
              |
              v
       NORMAL PUBLISH/MERGE
```

`intake_status` is a current projection (`unplanned`, `legacy_metadata_required`, `planned`, `dispositioned`, `notes_proposed`, `workspace_seeded`, or `blocked`). The evidence is the append-only receipt collections plus the current plan's link to `previous_plan_sha256`.

## Receiver plan invariants

Each plan contains the receiver's LaunchJob/conversation identity, acquired artifact digest and size, deterministic contract, patchset digest, duplicates, overlap jobs, cluster identity, optional applicability receipt, optional research proposals, and `verification_state=unverified`.

A plan SHA-256 is calculated from canonical sorted-key JSON excluding the digest field itself. Repository replanning uses compare-and-swap against the current plan digest and increments `plan_revision`. The new plan names `previous_plan_sha256`; it does not rewrite history.

Repository replanning cannot alter artifact provenance, contract, patchset identity, duplicate evidence, overlap evidence, cluster identity, note proposals, or verification state. It can only replace the applicability observation and its resulting repository classification. Once a workspace has been seeded, that plan cannot be replaced. After an operator disposition, replanning requires the latest action to be `defer`.

Disposition receipts are also canonical-hash sealed and form an append-only chain through `previous_receipt_sha256`. A request must match both the current plan digest and the current receipt-chain head. `accept` is legal only for research proposals or a repository-ready code plan. `duplicate` is legal only when receiver duplicate evidence exists.

Workspace receipts bind the current plan, latest accepting disposition, artifact, cluster, selected base, applicability receipt, branch/worktree, current observed `origin/master`, exact expected/import trees, import commit, commit-message digest, rebase flag, and durable reason.

## Intake and overlap classification

Artifact duplication is exact equality of receiver-acquired artifact SHA-256. Patch duplication uses canonical SHA-256 over the ordered sequence of `{order, sha256}` entries. Patch filenames are intentionally excluded from patch identity so a renamed identical patchset cannot evade duplicate classification.

Code overlap is true when either handoff targets any common Bead or any owned/touched path is equal to or contains another handoff's owned/touched path. Existing overlapping jobs contribute cluster identities:

- no existing cluster: derive `sol-pro-<16 hex>` from canonical `{target_beads, owned_paths}`;
- exactly one existing cluster: reuse it;
- more than one existing cluster: classify `blocked_cluster_bridge` rather than silently joining independently seeded work.

This creates one subsystem/bead-cluster worktree rather than one worktree per conversation. Each accepted handoff still receives its own exact unverified import commit and workspace receipt on the shared cluster branch.

## Repository planning and drift

Planning resolves local `refs/remotes/origin/master`. Absence is a durable block; the tool does not fetch or guess. When present, the entire ordered patch inventory is applied to an isolated index initialized from that exact commit. The caller's worktree and index are untouched.

If the patchset applies, current `origin/master` is selected. If it fails, the declared base is considered only when its commit object resolves locally. A clean declared-base application is seedable but marks `rebase_required=true`. Failure at both bases, or a missing declared base after current-master failure, is durable and explicit.

Before seeding, the command resolves `origin/master` again. Any change or disappearance records `origin_master_changed_after_plan`; no branch or import is silently created. The operator must record `defer`, replan, review the new plan, and accept it.

Applicability means only that Git can perform the tree transition. Every ready plan records `applicability_is_not_verification`, and every imported commit states the same limit.

## Exact unverified import

For a new cluster, the seed command rejects an unaccounted-for pre-existing branch or worktree path, then uses `git worktree add -b` at the selected base. For an existing cluster, it requires the recorded worktree to remain registered on the recorded branch.

The cluster worktree must be clean. The patch inventory is preflighted against the cluster's current HEAD in an isolated index. The same bytes are then applied with `git apply --index`; the staged tree must equal the preflight tree. The commit is created with GPG signing disabled and an exact generated message. The committed tree and message are re-read and compared, and the worktree must be clean after commit. Hook changes, tree drift, extra files, or commit-message mutation cause rollback to the prior cluster HEAD and a durable blocked receipt.

The exact GPT draft is therefore a waypoint with stable provenance. Verification/fix agents add later commits; they do not amend away the imported state.

## Research behavior

A v3 research result cannot declare patches or code ownership. For every target Bead, the receiver generates a markdown proposal containing the unverified label, Bead ID, LaunchJob and conversation identity, artifact SHA-256, prompt profile, declared source/base, handoff summary, residual work, verification limits, and the statement that no Git worktree or Beads mutation occurred.

Accepting a research plan changes only the receiver projection to `notes_proposed`. A human or later Beads-aware local operation must review and append the proposal through the normal Beads mechanism.

## Security and trust boundary

The handoff is treated as hostile provider output. Validation rejects unsafe, non-NFC, absolute, parent-traversing, control-character, backslash, duplicate, portable-colliding, encrypted, linked, device, and over-quota ZIP members. It rejects protected payload paths, replacement roots, undeclared PATCHES payloads, malformed inventories, unsupported patch encodings and operations, symlink/gitlink modes, path-claim mismatch, out-of-ownership paths, secret-bearing paths, Git control paths, and mutable `.beads/*.jsonl` exports.

Receiver-captured LaunchJob, conversation, artifact, and receipt identities are authoritative. Handoff-declared revisions, dirty-state digests, target Beads, ownership, residual work, and verification limits are provider claims retained for audit and local review. Local Git resolves revision presence and derives touched paths from the patch bytes. No provider claim is treated as evidence of correctness.

## Phase boundary

This phase intentionally omits broad browser UI, automatic Beads writes, verification runners, automated rebases, pull-request creation, publication, and the future shared receiver SQLite/CAS registry. It creates the durable kernel and explicit local route those later phases can safely project or orchestrate.
