# Deterministic handoff contract

## Compatibility decision

The existing `prompt_profile` remains the receiver's expected worker profile. Future generated LaunchJobs move to `polylogue-sol-pro-worker-v3`, whose prompt requires deterministic intake metadata. A v1/v2 artifact with no `intake` object remains readable but is classified `legacy_metadata_required`. A v1/v2 artifact may also carry a structurally valid v3 `intake` object; the receiver validates and plans it deterministically. This package uses the required `polylogue-sol-pro-worker-v2` profile and includes the v3 intake object, demonstrating that compatible strengthening path.

The contract lives in `MANIFEST.json` under `intake`:

```json
{
  "handoff_schema": "polylogue-sol-pro-handoff-v3",
  "result_kind": "code",
  "target_beads": ["polylogue-06zm.1", "polylogue-5k5l", "polylogue-yyvg.5"],
  "source_revision": "9c1bbbbbf73e2e7008099fc0e2b0e0c7cedec559",
  "declared_base_revision": "9c1bbbbbf73e2e7008099fc0e2b0e0c7cedec559",
  "input_dirty_state": {
    "staged_patch_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "working_tree_patch_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "untracked_inventory_sha256": "37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570"
  },
  "patches": [
    {
      "order": 1,
      "path": "PATCHES/0001-feat-capture-plan-durable-Sol-Pro-handoff-intake.patch",
      "sha256": "fb72e4fefb60169ea353ac8e54e6469416b1018d275ecc1143073d64d3a99133"
    }
  ],
  "owned_paths": ["devtools", "polylogue/browser_capture", "tests/unit/browser_capture", "tests/unit/devtools"],
  "touched_paths": ["devtools/command_catalog.py"],
  "residual_work": ["Run complete-repository generated-document and quick gates."],
  "verification_limits": ["No live authenticated browser or production daemon was available."]
}
```

The complete current example is `TESTS/v3-handoff-manifest-example.json`; the final authoritative values are in the root `MANIFEST.json`.

## Field semantics

| Field | Constraint | Intake meaning |
|---|---|---|
| `handoff_schema` | Exact `polylogue-sol-pro-handoff-v3` | Selects deterministic validation behavior. |
| `result_kind` | `code` or `research` | Controls whether Git planning is legal. |
| `target_beads` | Nonempty, sorted, unique, whitespace-free identifiers | Machine-readable issue scope and one overlap dimension. |
| `source_revision` | 40–64 lowercase hex | Worker-declared source snapshot revision; audit evidence, not local proof. |
| `declared_base_revision` | 40–64 lowercase hex | Exact base the patch inventory declares. Used only after current-master failure and local object resolution. |
| `input_dirty_state.staged_patch_sha256` | SHA-256 | Digest of supplied staged patch capture. |
| `input_dirty_state.working_tree_patch_sha256` | SHA-256 | Digest of supplied unstaged patch capture. |
| `input_dirty_state.untracked_inventory_sha256` | SHA-256 | Digest of canonical supplied untracked-file inventory. |
| `patches` | Contiguous order starting at one; unique safe `PATCHES/*.patch` or `.diff` paths; SHA-256 per file | Exact application sequence. For code it is required and must cover every patch file exactly. For research it must be empty. |
| `owned_paths` | Sorted, unique, normalized relative POSIX paths | Declared scope envelope and overlap input. Required for code, forbidden for research. |
| `touched_paths` | Sorted, unique, normalized relative POSIX file paths | Must exactly equal paths derived from all unified diffs. Required for code, forbidden for research. |
| `residual_work` | Nonempty readable list | Work the next agent/operator must still perform. |
| `verification_limits` | Nonempty readable list | Exact boundaries on tests, environment, access, and claims. |

## Manifest requirements

The root ZIP must contain `MANIFEST.json`, `README.md`, `SUMMARY.md`, `VERIFICATION-LIMITS.md`, and at least one file under each of `PATCHES/`, `DESIGN/`, and `TESTS/`. The manifest `files` array must cover every non-manifest file exactly once. Each record requires a normalized relative path, SHA-256, exact byte size, nonempty purpose, and integer apply order.

The validator checks actual ZIP member bytes against every manifest record. `MANIFEST.json` cannot record itself, avoiding recursive checksum construction.

The archive is inspected in memory and not extracted during validation.

## Result-kind rules

A code result must provide one or more ordered patches, at least one owned path, and at least one touched path. Every derived touched path must fall within at least one owned path. Only a non-duplicate code result can proceed to repository planning, explicit acceptance, and workspace seeding.

A research result must have no patches, owned paths, or touched paths. It produces one exact note proposal per target Bead. Repository planning and worktree seeding reject it.

## Patch identity and applicability

Patch file SHA-256 values bind the exact bytes. A separate patchset digest is canonical SHA-256 over the ordered `{order, sha256}` sequence. Filenames are retained as provenance but excluded from patchset identity.

The receiver derives touched paths from Git unified-diff headers and requires exact equality with the declaration. Phase one intentionally supports text unified diffs with ordinary `100644` and `100755` modes. It rejects binary patches, rename/copy operations, symlink/gitlink modes, malformed or mode-only diffs, invalid UTF-8, and NUL bytes.

The local planner applies every patch, in order, to an isolated Git index. Its applicability receipt records both attempted bases, exact resolved commits, timestamps, failed patch order and detail, selected base, result tree, touched paths, patchset digest, rebase requirement, and canonical receipt digest. This is not a test result or correctness claim.

## Unsafe and non-seedable content

The validator rejects:

- absolute, parent-traversing, dot-segment, backslash, control-character, non-NFC, duplicate, and portable-case-colliding archive paths;
- encrypted members, symlinks, devices, and other non-regular archive members;
- archive entry count and uncompressed-size quota violations;
- `.git` control paths, secret/credential-bearing paths, `.env` variants, private-key/certificate containers, and mutable `.beads/*.jsonl` payloads;
- top-level replacement/replacements roots and undeclared payloads under `PATCHES/`;
- missing, extra, reordered, duplicated, or checksum-mismatched patch inventory entries;
- patch paths that differ from the declared touched-path list or escape declared ownership.

These failures occur after the receiver stores the acquired bytes and artifact digest. The validation receipt records `accepted=false`, a stable reason code, and detail. The artifact is evidence, not a candidate for application.

## Provenance and trust

### Receiver-authoritative

- LaunchJob ID and worker profile selected at enqueue time;
- current lease owner and completion state;
- conversation ID/URL reported through the authenticated execution path and bound to the LaunchJob;
- exact acquired artifact reference, size, and SHA-256;
- validation receipts, current plan, disposition chain, and workspace receipts;
- repository observations returned by the explicit local tool and accepted through plan CAS.

### Provider-declared and retained as claims

- source and declared base revisions;
- dirty-state input digests;
- target Beads and path ownership;
- result kind, residual work, and verification limits;
- any prose in `SUMMARY.md`, README, patches, or commit messages.

The receiver verifies structural consistency but does not convert provider claims into facts. Local Git establishes only object presence and applicability. Independent verification establishes behavior.

## Exact imported commit contract

The generated import commit contains:

- an `UNVERIFIED WAYPOINT` warning;
- LaunchJob, conversation, artifact, prompt-profile, and handoff-schema identity;
- source, declared base, current `origin/master`, selected base ref/revision;
- all three dirty-state digests;
- target Beads, owned/touched paths, ordered patch inventory, and patchset digest;
- applicability receipt digest and rebase flag;
- residual work, verification limits, and `Verification-State: unverified`.

The seed command verifies that the staged tree equals the isolated-index plan, that the committed tree equals the same tree, that the stored commit message equals the generated message, and that no hook-created state remains. A workspace receipt binds all of these values.
