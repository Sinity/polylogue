# Executive result

This handoff delivers a mergeable first-phase kernel that converts a validated GPT-5.6 Sol Pro handoff into durable incorporation state and, when explicitly accepted, a normal Git worktree containing an exact unverified import commit. It keeps the existing LaunchJob receiver authoritative for identity, acquisition, validation, classification, plans, and receipts. The browser remains a projection/disposition surface; only an explicit local `devtools workspace sol-pro-intake` command may observe Git or seed work. Beads and publication remain their existing authorities.

The implementation is an ordered three-patch series:

1. receiver validation, deterministic v3 contract, intake plans, research proposals, durable dispositions/workspace receipts, and safe disposition route;
2. explicit repository planning and cluster worktree/import seeding;
3. focused receiver-route and real-Git tests.

The patch changes eleven paths. It does not touch the pre-existing dirty `.beads/issues.jsonl`, does not add browser-extension Git/Beads authority, does not create a second outbox or database, and does not claim that applicable GPT patches are verified.

## Core decisions

- Exact provider bytes are acquired and hashed before validation outcome. Rejected results retain an artifact reference and hash-sealed rejection reason.
- The v3 contract adds only deterministic intake data: result kind, target Beads, source/base revisions, dirty-input digests, ordered patch inventory, owned/touched paths, residual work, and verification limits.
- Receiver-captured LaunchJob/conversation/artifact identity is authoritative. Provider metadata remains a claim.
- Duplicate artifacts use artifact SHA-256. Duplicate code uses a canonical ordered-patch digest that ignores filenames. Overlap uses target Beads and path containment.
- Overlapping code handoffs share one subsystem cluster branch/worktree. A handoff bridging multiple existing clusters blocks for an explicit decision.
- Research-only results produce exact Beads append-note proposals and can never enter Git planning or create a worktree.
- Repository planning tests local current `refs/remotes/origin/master` first in an isolated index. Declared-base fallback is allowed only after current failure and local commit resolution, and always records `rebase_required=true`.
- Plan-to-seed origin drift blocks durably. Seeding verifies exact staged and committed trees, exact commit message, and a clean worktree; failures roll back.
- The imported GPT patch is a clearly labeled `UNVERIFIED WAYPOINT`. Verification, fixes, rebase, Beads updates, and publication happen later through normal project workflow.

## Acceptance-criteria matrix

| Requirement | Result | Evidence / boundary |
|---|---|---|
| Extend existing LaunchJob receiver authority | Implemented | Patch 0001 adds plan and receipt evidence to `BrowserLaunchJob`; no parallel result store. |
| Acquire and validate before intake | Implemented | Exact bytes are atomically stored, hashed, validated, and accepted/rejected with sealed receipts. |
| Browser may project/dispose but not mutate Git/Beads | Kernel implemented | Safe HTTP disposition route is implemented. Broad popup projection is Phase 2; no browser Git/Beads primitive was added. |
| Explicit local plan and seed surface | Implemented | `devtools workspace sol-pro-intake` provides `show`, `plan`, `dispose`, and `seed`. |
| Only code-bearing non-duplicates create worktrees | Implemented | Research, legacy, duplicate, bridge, and blocked classifications refuse repository seed. |
| Group overlapping patches into cluster worktrees | Implemented | Receiver overlap/cluster algorithm plus seed-time branch/worktree reuse; real-Git test proves two overlapping jobs produce one worktree and two import commits. |
| Preserve exact imported GPT draft and provenance | Implemented | Generated unverified commit message, isolated-index tree, staged/commit tree comparison, message digest, clean-status check, rollback, and workspace receipt. |
| Research-only Beads proposal, no worktree | Implemented | One hashed proposal per target Bead; route and devtools tests prove no workspace. Actual Beads append remains explicit. |
| Durable reasons for reject/obsolete/duplicate | Implemented | Validation, disposition, and workspace receipts retain stable reason codes/details and hash provenance. |
| Never seed unsafe paths, mutable Beads export, secrets, replacements | Implemented for declared safety boundary | Archive and patch validators reject these path/member/operation classes. General content secret scanning remains a normal review gate. |
| Current-master-first drift handling | Implemented | Isolated-index current check, present declared-base fallback, rebase flag, missing-base blocks, and plan-to-seed origin drift receipt. |
| Do not equate applicability with verification | Implemented | Plan reason, receipt detail, commit warning, verification state, tests, and docs all retain `unverified`. |
| Production-route tests for unsafe/stale/duplicate/overlap/research/provenance | Implemented in scoped snapshot | 12 focused intake/work-package tests plus 5 receiver-route tests pass; exact commands/results are under `TESTS/`. |
| Phased migration for v1/v2 handoffs | Implemented classification; sidecar deferred | Legacy packages remain immutable and become `legacy_metadata_required`; reviewed sidecar and browser checklist are mapped in `DESIGN/migration-v1-v2.md`. |
| Exact later-agent note and workspace receipt example | Delivered | `DESIGN/example-agent-receipt.md` plus machine-readable `TESTS/example-receipts.json`. |
| Independently verified/fixed and published/merged | Deliberately not automated | Receipt/schema boundary is ready. Full-repo verification, fixes, Beads append, rebase, PR, and merge remain later-agent work. |
| Shared receiver CAS/adoption registry | Not duplicated | Remains owned by `polylogue-06zm.1`; Phase 4 maps these records into that registry. |

## Verification result

The input archive was safety-inspected and every member hashed. The patch series was applied in order to a fresh synthetic repository built from the supplied snapshot. The resulting tree was reproduced through isolated-index patch application. Twelve focused real-Git/intake tests and five selected receiver-route tests passed. Ruff, mypy, compile checks, and `git diff --check` passed.

The complete repository, live authenticated browser, production receiver/daemon, real remote refs, Beads writer, Nix/NixOS deployment, publication, and merge were unavailable and were not claimed. Exact limits and follow-on commands are in `VERIFICATION-LIMITS.md` and `TESTS/verification-plan.md`.

## Genuine residual risks

The supplied source pack is scoped, so full-repository imports, generated projections, layering and route-schema checks, browser bundling, and broader tests may reveal integration conflicts. The current receiver is still atomic JSON rather than the shared CAS/adoption registry planned by `polylogue-06zm.1`. Broad browser status projection and reviewed v1/v2 sidecar tooling are not implemented. The protected-path rules are not a general secret-content scanner. Repository commit hooks and local Git configuration can have side effects beyond the exact tree checks and must be reviewed in the complete environment. No live provider, asset-expiry, production recovery, Beads append, or merge path was exercised.
