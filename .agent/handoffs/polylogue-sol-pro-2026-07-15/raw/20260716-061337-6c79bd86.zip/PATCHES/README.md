# Ordered patch series

Apply these patches in numeric order.

## 0001 — receiver intake contract and durable receipts

`0001-feat-capture-plan-durable-Sol-Pro-handoff-intake.patch`

Adds the v3 deterministic intake contract, archive and patch safety validation, artifact and patchset duplicate classification, overlap clustering, research-note proposals, immutable/hash-sealed intake plans, append-only disposition/workspace receipts, a safe disposition HTTP route, and prompt/work-package contract updates. The receiver acquires and stores exact provider bytes before validation so rejected artifacts retain durable evidence.

This patch deliberately keeps the existing LaunchJob atomic-JSON receiver boundary. It does not create the SQLite/CAS CaptureJob registry owned by `polylogue-06zm.1` and does not create a second outbox.

## 0002 — explicit local planning and workspace seed

`0002-feat-devtools-seed-Sol-Pro-cluster-workspaces.patch`

Adds `devtools workspace sol-pro-intake` with `show`, `plan`, `dispose`, and `seed` subcommands. Planning tests the ordered patch series against local `refs/remotes/origin/master` first using an isolated Git index, then against the declared base only when its commit object is present. Seeding creates or reuses one subsystem cluster worktree and commits the exact imported tree as an unverified waypoint. It rolls back or records a durable block on drift, dirty worktrees, cluster conflicts, hooks, tree mismatches, or receipt failures.

## 0003 — production-route and real-Git tests

`0003-test-capture-cover-Sol-Pro-incorporation-intake.patch`

Adds receiver-route tests and real temporary-Git-repository tests for unsafe paths, acquired-then-rejected evidence, legacy v2 classification, duplicate patchsets, overlapping cluster reuse, current-master and declared-base decisions, origin/master drift, research-only no-worktree behavior, exact import provenance, and deterministic source dirty-state digests.

## Scope and conflict expectations

The series changes eleven paths under `polylogue/browser_capture/`, `devtools/`, and focused unit tests. It does not modify `.beads/issues.jsonl`, browser-extension code, storage schemas, daemon deployment, or generated topology files. Because the supplied snapshot is intentionally scoped rather than a full checkout, generated documentation/topology checks must be run after applying in the complete repository.
