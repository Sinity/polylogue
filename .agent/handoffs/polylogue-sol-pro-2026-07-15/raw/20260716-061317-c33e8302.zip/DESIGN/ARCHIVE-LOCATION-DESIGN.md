# ArchiveLocation identity and resolver design

## Decision

Polylogue now has one immutable `ArchiveLocation` value for every SQLite location that may cross the archive boundary. Durable/archive semantics are assigned by typed construction and one resolver, not recovered later from an arbitrary `Path` or an opened database’s parent directory.

The design extends—not replaces—the existing `ArchiveIdentity`. Existing status/conflict consumers retain the `TierFileIdentity` projection and old fields. New routing code consumes the richer configured/resolved location plan.

## Failure being removed

The previous sync factory followed this sequence:

1. call `sqlite3.connect(index_path)`;
2. query `PRAGMA database_list` to recover the main path;
3. if the main filename was `index.db`, take `main.parent` as an archive root;
4. attach `source.db`, `user.db`, `embeddings.db`, and `ops.db` from that parent.

That assumption is correct only for the legacy same-directory layout. It is false when the configured durable root is separate from an index-generation directory. A generated index may be reached through `/generations/index.db -> index.g7.db`, while the authoritative source remains `/archive/source.db`. A plausible `/generations/source.db` is not a peer merely because its name fits.

The new flow computes the complete location plan before any SQLite open. The opened index path contributes no authority over peer locations.

## Type states

`ArchiveLocation.kind` has six runtime-validated states:

| Kind | Meaning | SQLite-open eligible |
|---|---|---|
| `configured-root` | Configuration-owned durable archive root. | No |
| `configured-tier` | One configured tier path derived from the root or an explicit per-tier override. | No |
| `resolved-tier` | A resolved fixed tier (`source`, `embeddings`, `user`, or `ops`). | Yes, through its matching identity |
| `resolved-generation` | The resolved active index generation plus its configured and active pointer identities. | Yes, through its matching identity |
| `owned-campaign` | A non-archive campaign database guarded by an opaque ownership capability. | Yes, with the exact capability |
| `owned-external` | A non-archive external database guarded by an opaque ownership capability. | Yes, with the exact capability |

The constructors enforce non-interchangeability. Configured roots/tiers cannot be opened. Fixed tiers cannot pretend to be index generations. Index generations cannot claim a fixed tier. Owned locations cannot claim an archive root/tier/pointer and cannot open with a newly minted capability that merely repeats the same owner text.

## Identity carried by each location

The value records:

- configured path;
- resolved target path;
- archive root, where applicable;
- tier and durability (`durable`, `rebuildable`, `disposable`);
- access intent (`read`, `write`, `migration`);
- active pointer path;
- pointer `lstat` device/inode identity;
- target `stat` device/inode identity;
- index generation label (`legacy` or parsed `gN` suffix);
- generation stable identity;
- optional exact `ArchiveOwnership` capability.

`Path.resolve(strict=False)` is used to resolve symlinks while retaining missing-path bootstrap behavior. Python documents that `resolve()` makes a path absolute, resolves symlinks, removes `..`, and with `strict=False` appends a missing remainder without raising. Source: Python `pathlib.Path.resolve`, accessed 2026-07-16: https://docs.python.org/3/library/pathlib.html#pathlib.Path.resolve

The configured/pointer path is retained separately rather than discarded after resolution. The resolver can therefore report both “what configuration pointed at” and “what generation is active,” and the pre-open check can detect pointer replacement even when a replacement points to the same target.

## Single resolver

`resolve_archive_locations(root, configured_tier_paths=None, active_index_path=None, ...)` is the sole archive-plan builder.

Inputs are typed and explicit:

1. one `configured-root` location;
2. optional explicit per-tier configured paths;
3. optional active index pointer/generation path;
4. generation owner/state metadata.

Resolution rules:

- source/user/embeddings/ops come from the configured root unless explicitly overridden;
- the configured index remains `<configured-root>/index.db` for reporting;
- the active index pointer may live elsewhere;
- the active pointer resolves to a target generation and records both identities;
- no tier path is derived from the active index target or pointer parent.

The resolver emits one `ArchiveIdentity` containing:

- all configured locations;
- all resolved locations;
- the compatibility `TierFileIdentity` tuple;
- generation label, target stable ID, and pointer stable ID;
- the original configured root and access plan.

`ArchiveIdentity.resolve(root)` remains as a compatibility constructor but delegates to the same resolver.

## Pre-open authorization

Every typed sync SQLite route passes through `_prepare_open_target` before `sqlite3.connect`.

For archive tiers, `ArchiveIdentity.assert_openable` checks:

1. the value is a resolved tier/generation, not a configured descriptor;
2. tier and root are present;
3. the location root resolves to the identity’s configured root;
4. identity-plan, location, and requested access intents are equal;
5. kind and durability match the resolver’s expected location;
6. configured tier paths match;
7. pointer paths and pointer stable identities match;
8. resolved paths and target stable identities match;
9. generation labels and generation stable identities match;
10. both the plan-owned expected location and supplied location still point to their recorded current target.

For owned campaign/external locations, the exact `ArchiveOwnership` object must be supplied. `ArchiveOwnership.issue("x")` called twice produces two intentionally non-equivalent capabilities even though the diagnostic owner IDs match.

Only after this validation does the factory call SQLite. Attachments are prepared from `identity.location(tier)` and prevalidated through the same identity. SQLite’s `ATTACH DATABASE` creates a separate named schema within the connection; the design therefore treats selecting each attachment filename as an authorization decision rather than a filename convenience. Source: SQLite `ATTACH DATABASE`, accessed 2026-07-16: https://www.sqlite.org/lang_attach.html

Read-only opens continue to use SQLite URI `mode=ro` and deliberately attach no peers, preserving the previous one-file behavior. SQLite documents URI filename parameters including `mode=ro`. Source: SQLite URI filenames, accessed 2026-07-16: https://www.sqlite.org/uri.html

Migration uses the write profile but requires an identity/location resolved with `access_intent="migration"` and an explicit matching factory argument. A read or write plan cannot be reused accidentally for migration.

## Legacy compatibility boundary

`resolve_legacy_archive_location` is the only path-to-tier adapter in the SQLite factory layer.

It recognizes ordinary canonical tier filenames for the same-directory layout. A plain regular `index.db` therefore still attaches canonical siblings through the resolver and preserves existing unqualified source/index reads.

Two ambiguous forms are intentionally not assigned archive semantics when passed untyped:

- a symlinked `index.db`, because it is generation-pointer shaped and its parent need not be the durable root;
- an `index.g*.db` generation file, because its directory is generation storage, not archive configuration.

Those paths remain valid standalone SQLite inputs, but attach no tiers. Split-layout callers must use `Config.archive_identity()` / `resolve_archive_locations()` and pass the resulting resolved location plus its identity. This is the compatibility/safety trade: legacy layouts remain available; new layouts cannot silently fall back to invented siblings.

## Config and path integration

`Config.archive_identity(access_intent=...)` resolves `archive_root` and the active `db_path` as one plan. `Config.archive_location(tier, ...)` returns a member of that same plan.

The path compatibility helpers also delegate to the resolver:

- `resolve_active_index_db_path` recognizes canonical and generated index paths while retaining the explicit configured root;
- `archive_file_set_root_for_paths` always returns the configured durable root, never the active index parent;
- `sibling_index_db` remains explicitly documented as a legacy same-directory helper and is implemented through the resolver.

## Why this remains compact

The patch does not introduce a second archive registry, path subclass, process-global side table, schema, pointer-manifest protocol, or new product module. It adds one value type to the existing identity module, one plan builder, and one pre-open target builder at the existing sync SQLite choke point. Existing path APIs continue to work through compatibility adapters.

## Rejected alternatives

### Continue inspecting the opened main database

Rejected because the opened index path proves only index identity. Its parent cannot prove durable tier ownership. Validation after opening also violates the Bead’s pre-open failure requirement.

### Attach `main.parent/<tier>.db` only when files exist

Rejected because existence and plausible schema/name are not identity. The canary’s wrong `source.db` exists and contains valid queryable data; existence would select semantically incorrect bytes.

### Treat every `index.db` path as a generation pointer

Rejected because it would break plain legacy archives. The adapter instead distinguishes ordinary non-symlink legacy `index.db` from ambiguous untyped symlink/generation paths.

### Eliminate all `Path` overloads immediately

Rejected as an unnecessary compatibility break. Arbitrary standalone SQLite paths remain supported without archive semantics; canonical legacy paths pass through the resolver. New split-aware call sites use typed locations.

### Use owner strings as authorization

Rejected because text equality is forgeable and conflates diagnostics with capability. Owned locations require object identity.

### Add a JSON pointer manifest / blue-green generation manager now

Rejected as speculative scope. This Bead needs generation/pointer identity and split-root safety, not a full activation protocol. The model can carry a future resolver-selected active path without committing to a pointer-file format.

### Change schema or migration DDL

Rejected because the bug is location identity/routing, not data shape. No tier schema version changes.

### Attach peers to the read-only one-file factory

Rejected because it would alter established read behavior. Cross-tier reads continue through the resolver-aware archive/write profile or higher archive facade; `open_readonly_connection` stays one-file and `mode=ro`.

## Residual race boundary

The resolver rechecks pointer and target identity immediately before opening and opens the resolved target rather than the symlink pointer. This removes pointer-swap ambiguity. Python’s SQLite API still accepts a pathname, not an already validated file descriptor, so replacing the resolved target pathname between the final check and `sqlite3.connect` remains theoretically possible. Closing that interval requires a separate OS/SQLite handle design and is outside this Bead.
