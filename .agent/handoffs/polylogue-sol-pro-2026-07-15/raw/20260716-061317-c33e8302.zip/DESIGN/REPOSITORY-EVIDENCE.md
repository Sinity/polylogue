# Repository and Bead evidence

## Immutable inputs

The work used the supplied archive `polylogue-sol-pro-context-7b7cf87e47b11837.tar.gz`:

- size: `53,129` bytes
- SHA-256: `7b7cf87e47b118371fa316a7675eca0bd09066e022cd0f855702daf62a628454`
- recorded upstream revision: `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- recorded branch: `feature/browser/adopt-completion-monitors`
- staged and working patches: empty

The repository slice was treated as immutable. Implementation occurred in a separate copy.

## Selected Bead

`polylogue-ovme.1` — **Land ArchiveLocation identity, resolution, and split-tier canaries**

The record was created 2026-07-15, updated 2026-07-15, priority 1, status open, with no later comments. There were therefore no comment-level supersessions to reconcile.

Its design requires:

- extension of the existing `ArchiveIdentity`/plan substrate;
- configured per-tier paths;
- symlinked active index generations;
- generation/pointer identity;
- durability and access intent;
- optional ownership capability;
- kind/generation/root consistency before SQLite opens;
- legacy layout resolution only behind the resolver;
- a split durable-root plus index-only-generation fixture.

Its acceptance criteria explicitly require mutation-sensitive canaries: removing kind validation or restoring sibling inference must fail.

## Repository invariants applied

The supplied repository instructions define the five tiers by durability:

| Tier | Durability |
|---|---|
| `source.db` | durable |
| `index.db` | rebuildable |
| `embeddings.db` | rebuildable |
| `user.db` | durable/irreplaceable |
| `ops.db` | disposable |

That inventory became `TIER_DURABILITY` and is checked at runtime. The implementation does not infer durability from a `Path` after construction.

The instructions also require substrate ownership of semantics, strict MyPy, focused test selection, no speculative schema migration, and topology regeneration only when adding a new product module. The patch stays in existing config/path/storage modules and adds no schema or product module.

## Existing substrate retained

The original `polylogue/storage/archive_identity.py` already provided:

- `ArchiveTierName` and canonical tier filenames;
- `TierFileIdentity` with configured/resolved path and device/inode identity;
- `ArchiveIdentity` with durable conflict detection;
- pre-bootstrap split-root conflict rejection.

The patch preserves these APIs and projections. `ArchiveLocation` becomes the richer pre-SQLite identity; `TierFileIdentity` remains the compatibility/status view.

## Located failure seam

The original `polylogue/storage/sqlite/connection_profile.py` function `_attach_sibling_tiers` opened SQLite first, read `PRAGMA database_list`, required `main.name == "index.db"`, then constructed every peer from `main.parent / filename`.

This was the precise invented-sibling seam. It conflated an active index location with the configured archive root and validated nothing before SQLite opened.

The replacement `_prepare_open_target` constructs and validates the main target plus all attachment paths before the connection call. `_attach_archive_tiers` receives prepared `(schema_name, peer_path)` values and does not inspect the main path.

## Path/config evidence

The original `archive_file_set_root_for_paths` returned `db_anchor.parent` whenever the anchor was named `index.db`. That promoted the active index parent into an archive root. The patch makes the configured root authoritative and resolves active index paths separately.

The original active index helper already treated `index.db` as a special anchor and ignored arbitrary custom SQLite anchors. The patch preserves that behavior while recognizing explicit `index.g*.db` paths at the config/path seam, where a durable root is also known.

## Compatibility decision grounded in tests

The existing sync factory attached source-tier tables for a plain same-directory `index.db`. That behavior is retained and locked with an exact BLOB read, not a text-only fixture.

The split fixture deliberately creates two valid `raw_sessions` tables:

- configured durable source payload: `00 01 02 FF`;
- invented sibling payload beside the generated index: `DE AD BE EF`.

The distinction is semantic and byte-visible. A resolver-selected attachment returns the configured bytes. Parent inference returns the decoy and fails.

## Evidence not present in the slice

The immutable package did not include the complete async SQLite implementation, real `ArchiveStore`, migration modules, daemon, CLI/MCP/API callers, shared test harness, `devtools`, or project configuration. No claim is made that those absent call sites were executed. The design and patch deliberately expose one typed resolver/factory contract for their follow-up integration in the complete checkout.
