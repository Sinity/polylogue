# Polylogue ArchiveLocation launch handoff

This handoff implements Bead `polylogue-ovme.1`, **“Land ArchiveLocation identity, resolution, and split-tier canaries.”** It is scoped to the immutable project slice supplied with the task and is intended to be reviewed and applied as a two-patch series.

## Base and worktree assumptions

The supplied snapshot recorded:

- upstream revision: `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- branch: `feature/browser/adopt-completion-monitors`
- staged patch: empty
- working-tree patch: empty
- status: clean apart from the branch/tracking header
- source archive SHA-256: `7b7cf87e47b118371fa316a7675eca0bd09066e022cd0f855702daf62a628454`

The implementation was developed in a local Git reconstruction because the supplied archive contains a project slice rather than its original `.git` directory. Local commit IDs in the patch headers (`d28583c…`, `55451bf…`) are handoff-only identities; the content baseline is the upstream revision above.

Do not silently apply these patches over unrelated dirty state. First inspect `git status --short` and preserve any local changes. No pre-existing dirty state from the supplied snapshot needs reconciliation.

## Read order

1. `SUMMARY.md` — executive result and acceptance-criteria matrix.
2. `DESIGN/ARCHIVE-LOCATION-DESIGN.md` — invariants, resolver/open flow, compatibility boundary, and rejected alternatives.
3. `DESIGN/REPOSITORY-EVIDENCE.md` and `DESIGN/polylogue-ovme.1.json` — the evidence summary and exact selected Bead record.
4. `PATCHES/series` — authoritative patch order.
5. `TESTS/RESULTS.md` and `TESTS/MUTATION-CANARIES.md` — exact local evidence.
6. `VERIFICATION-LIMITS.md` — what could not be exercised from the partial snapshot.

## Apply order

From a clean checkout at the recorded base revision, point `HANDOFF` at the unpacked ZIP root:

```bash
HANDOFF=/path/to/polylogue-sol-pro-launch-handoff

test "$(git rev-parse HEAD)" = "76ee0d3842f12920ee71ad06f22b9cd8d2f88730"
test -z "$(git status --porcelain)"

git apply --check "$HANDOFF/PATCHES/0001-feat-storage-resolve-archive-tiers-through-typed-loc.patch"
git apply --check "$HANDOFF/PATCHES/0002-test-storage-add-split-tier-identity-canaries.patch"

git am "$HANDOFF/PATCHES/0001-feat-storage-resolve-archive-tiers-through-typed-loc.patch" \
       "$HANDOFF/PATCHES/0002-test-storage-add-split-tier-identity-canaries.patch"
```

The series was independently applied to a fresh copy of the supplied base with `git apply --check`; every resulting touched file was byte-compared to the implementation tree.

If the target branch has advanced, inspect the changed files and rerun `git apply --check` before considering a three-way application. The highest-conflict files are `polylogue/storage/archive_identity.py` and `polylogue/storage/sqlite/connection_profile.py`; do not resolve conflicts by restoring parent-directory sibling inference.

## What the patches do

Patch 1 adds one typed `ArchiveLocation` model and a single resolver over the existing `ArchiveIdentity` substrate. It distinguishes configured roots, configured tier files, fixed resolved tiers, resolved active index generations, and explicitly owned campaign/external databases. The resolver carries durability, access intent, configured root, pointer identity, target identity, generation identity, and optional ownership capability.

The sync SQLite factories now validate every archive location and all resolver-selected peer attachments before calling `sqlite3.connect`. They no longer inspect `PRAGMA database_list` to discover the main database’s parent and invent `source.db`, `user.db`, `embeddings.db`, or `ops.db` beside it. Config and path helpers resolve through the same substrate. Plain same-directory legacy archives remain available through an explicit compatibility adapter; untyped symlinked `index.db` pointers and `index.g*.db` generation paths are treated as standalone SQLite files and attach no durable peers.

Patch 2 adds config/path/identity coverage and an executable split-root canary. Its generated index directory contains a deliberately wrong sibling `source.db` with bytes `DEADBEEF`, while the configured durable root contains `000102FF`. The typed route must return the durable-root bytes. The test suite also proves wrong kinds, roots, generations, access intents, stale symlink pointers, durability values, and ownership capabilities fail before SQLite opens.

## Verification after applying in the full repository

Run the handoff verifier against the patched checkout:

```bash
bash "$HANDOFF/TESTS/verify.sh" /path/to/polylogue-checkout
```

The script prefers the repository’s managed `devtools` gates when present and includes a raw `uv` fallback. In a complete checkout, the required final gate is `devtools verify --quick`; that command was unavailable in the supplied slice and remains an operator-side verification item.

## Scope boundaries

No schema, migration SQL, generated topology file, CLI grammar, daemon protocol, or public payload schema is changed. No new module under `polylogue/` is added. The supplied slice did not contain the async SQLite implementation or the complete `ArchiveStore`, so those full-repository call paths must be checked after application; the patch deliberately centralizes the sync pre-open choke point to make that follow-through mechanical rather than inventing a parallel subsystem.
