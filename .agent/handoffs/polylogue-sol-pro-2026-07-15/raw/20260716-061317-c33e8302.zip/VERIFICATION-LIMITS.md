# Verification limits

## Environment and supplied-material boundary

Verification was performed on 2026-07-16 with:

- Python `3.13.5`
- pytest `9.0.2`
- Ruff `0.15.21`
- MyPy `2.3.0`
- Git `2.47.3`

The supplied repository snapshot is intentionally partial. It contains 13 product files, selected tests, repository instructions, the Bead record, and Git metadata, but not the full package, dependency lock/configuration, `pyproject.toml`, `devtools`, shared pytest fixtures, or the original `.git` directory. Minimal temporary import stubs outside the patch tree were used only to load missing package surfaces for focused tests and type checking. They are not part of the handoff.

## What was run successfully

1. **Patch artifact application check**

   Both patches passed `git apply --check` and were applied in order to a fresh copy of the immutable `REPO/` directory. All eight resulting files were byte-identical to the implementation tree.

2. **Focused plus compatible existing tests**

   The exact node selection is embedded in `TESTS/verify.sh` and documented in `TESTS/RESULTS.md`.

   Result: `51 passed in 0.42s` on the independently patched tree (`0.45s` on the implementation tree).

3. **Ruff diagnostics**

   `uvx ruff check` ran over all eight touched files.

   Result: `All checks passed!`

4. **Strict type checking**

   MyPy ran with namespace-package/explicit-package-base handling over:

   - `polylogue.storage.archive_identity`
   - `polylogue.storage.sqlite.connection_profile`
   - `polylogue.paths._roots`
   - `polylogue.config`

   Result: `Success: no issues found in 4 source files`.

   `--ignore-missing-imports` was necessary only because the immutable slice omits most imported modules. The touched modules themselves were checked strictly.

5. **Compilation and diff hygiene**

   `python -m compileall -q` passed for all touched files. `git diff --check` passed.

6. **Mutation sensitivity**

   Two isolated copies were deliberately modified:

   - resolver-selected peers replaced with `main_location.resolved_path.parent / f"{tier}.db"`;
   - archive identity authorization replaced with direct `path.resolved_path` use.

   Both target tests failed as required. Details are in `TESTS/MUTATION-CANARIES.md`.

## Attempted but not executable as a meaningful full run

A broad raw pytest invocation over all four touched test files completed with:

```text
4 failed, 81 passed, 50 errors in 0.58s
```

Every failure/error was attributable to omitted snapshot infrastructure:

- `workspace_env` and other shared fixtures are absent;
- `polylogue.sources` is absent;
- `tomli_w` and the project dependency environment are absent;
- the temporary `ArchiveStore` stub intentionally raises `NotImplementedError`.

This broader result is recorded rather than treated as a product regression or omitted from the report.

## Not run

The following were not available and are not claimed:

- `devtools verify --quick`, the required complete-checkout quick gate;
- the default testmon-selected verification baseline or `devtools verify --all`;
- full unit/property/integration/benchmark/fuzz suites;
- generated-surface checks (`devtools render all --check`);
- the complete async SQLite backend and its attachment/open routes;
- the real `ArchiveStore` writer/read facade and full migration call graph;
- an installed wheel/package build;
- a live Polylogue daemon, operator browser, secrets, production archive, or NixOS deployment;
- destructive or write verification against any operator data.

The patch adds no new `polylogue/` module and no generated/schema surface, so no topology/schema regeneration is expected. That expectation still needs confirmation from the full repository’s managed gate.

## Formatter note

The partial snapshot omits the repository’s pinned Ruff configuration. `uvx ruff format --check` with current defaults reports that six pre-existing files would be reformatted because it falls back to default formatting settings. It reports the fully replaced identity module and the new test module as formatted. No broad formatter rewrite was applied, avoiding unrelated churn; the authoritative formatting result must come from the full checkout’s pinned quick gate.
