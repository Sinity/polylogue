# Verification results

## Patch-series reproducibility

The patches were generated from two local review commits and then tested against a fresh copy of the supplied immutable `REPO/` tree.

```text
patch_apply_check=PASS
byte_compare=PASS
```

Procedure:

1. initialize a temporary Git repository from the supplied base files;
2. run `git apply --check` for patch 1;
3. apply patch 1;
4. run `git apply --check` for patch 2;
5. apply patch 2;
6. compare all eight touched files byte-for-byte with the implementation tree.

## Focused and compatibility test selection

The independently patched tree ran:

```bash
pytest -q \
  tests/unit/storage/test_archive_location_connections.py \
  tests/unit/storage/test_archive_identity.py::test_path_aliases_resolve_to_equal_archive_identity \
  tests/unit/storage/test_archive_identity.py::test_split_roots_sharing_durable_tiers_reject_distinct_indexes_before_mutation \
  tests/unit/storage/test_archive_identity.py::test_distinct_archives_do_not_conflict \
  tests/unit/storage/test_archive_identity.py::test_sharing_any_irreplaceable_tier_rejects_divergent_index \
  tests/unit/storage/test_archive_identity.py::test_missing_index_cannot_bypass_split_root_preflight \
  tests/unit/storage/test_archive_identity.py::test_archive_location_constructors_are_non_interchangeable \
  tests/unit/storage/test_archive_identity.py::test_tier_durability_and_access_values_are_validated_at_construction \
  tests/unit/storage/test_archive_identity.py::test_resolver_reports_split_tiers_and_symlinked_generation_identity \
  tests/unit/storage/test_archive_identity.py::test_resolver_honors_explicit_per_tier_paths \
  tests/unit/core/test_paths.py \
  tests/unit/core/test_config.py::TestConfig::test_config_basic_construction \
  tests/unit/core/test_config.py::TestConfig::test_active_index_resolver_uses_index_db \
  tests/unit/core/test_config.py::TestConfig::test_active_index_resolver_ignores_sibling_index_for_overrides \
  tests/unit/core/test_config.py::TestConfig::test_active_index_resolver_does_not_fall_back_to_db_anchor \
  tests/unit/core/test_config.py::TestConfig::test_archive_file_set_index_availability_is_unconditional \
  tests/unit/core/test_config.py::TestConfig::test_config_resolves_split_index_without_moving_durable_root \
  tests/unit/core/test_config.py::TestConfig::test_config_archive_location_preserves_requested_access_intent
```

Result:

```text
...................................................                      [100%]
51 passed in 0.42s
```

The same selection passed in the implementation tree in `0.45s`.

## Static checks

Ruff command covered all eight touched files.

```text
All checks passed!
```

Strict MyPy command covered the four product modules with explicit namespace-package bases in the partial snapshot.

```text
Success: no issues found in 4 source files
```

`python -m compileall -q` passed for all eight touched files. `git diff --check` passed before the commits were emitted.

## Broad snapshot attempt

A raw run over all four touched test files was attempted rather than silently omitted:

```text
4 failed, 81 passed, 50 errors in 0.58s
```

The four failures were:

- the deliberately skeletal external `ArchiveStore` stub raising `NotImplementedError`;
- two missing `polylogue.sources` imports;
- missing `tomli_w`.

The 50 setup errors were missing shared fixtures such as `workspace_env`. These components are absent from the immutable slice. See `../VERIFICATION-LIMITS.md`.

## Behavioral observations locked by tests

- Split typed index open attaches `/durable/source.db`, not `/generation/source.db`.
- The selected source BLOB is exactly `00 01 02 FF`.
- The decoy sibling BLOB is `DE AD BE EF` and is never selected by the correct route.
- Plain same-directory legacy reads preserve exact bytes `00 FE 7F 80 FF`.
- Untyped symlinked `index.db` and `index.g7.db` paths attach no archive peers.
- Typed read-only opens pin the resolved index generation and preserve one-file behavior.
- Migration opens fail unless both the location and factory request `migration`.
- Wrong kind/root/generation/access/ownership and stale pointer swaps make zero `sqlite3.connect` calls.
