#!/usr/bin/env bash
set -euo pipefail

HANDOFF_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
REPO_ROOT=${1:-$PWD}
cd "$REPO_ROOT"

if [[ ! -f polylogue/storage/archive_identity.py ]]; then
  echo "usage: $0 /path/to/polylogue-checkout" >&2
  exit 2
fi

TEST_NODES=(
  tests/unit/storage/test_archive_location_connections.py
  tests/unit/storage/test_archive_identity.py::test_path_aliases_resolve_to_equal_archive_identity
  tests/unit/storage/test_archive_identity.py::test_split_roots_sharing_durable_tiers_reject_distinct_indexes_before_mutation
  tests/unit/storage/test_archive_identity.py::test_distinct_archives_do_not_conflict
  tests/unit/storage/test_archive_identity.py::test_sharing_any_irreplaceable_tier_rejects_divergent_index
  tests/unit/storage/test_archive_identity.py::test_missing_index_cannot_bypass_split_root_preflight
  tests/unit/storage/test_archive_identity.py::test_archive_location_constructors_are_non_interchangeable
  tests/unit/storage/test_archive_identity.py::test_tier_durability_and_access_values_are_validated_at_construction
  tests/unit/storage/test_archive_identity.py::test_resolver_reports_split_tiers_and_symlinked_generation_identity
  tests/unit/storage/test_archive_identity.py::test_resolver_honors_explicit_per_tier_paths
  tests/unit/core/test_paths.py
  tests/unit/core/test_config.py::TestConfig::test_config_basic_construction
  tests/unit/core/test_config.py::TestConfig::test_active_index_resolver_uses_index_db
  tests/unit/core/test_config.py::TestConfig::test_active_index_resolver_ignores_sibling_index_for_overrides
  tests/unit/core/test_config.py::TestConfig::test_active_index_resolver_does_not_fall_back_to_db_anchor
  tests/unit/core/test_config.py::TestConfig::test_archive_file_set_index_availability_is_unconditional
  tests/unit/core/test_config.py::TestConfig::test_config_resolves_split_index_without_moving_durable_root
  tests/unit/core/test_config.py::TestConfig::test_config_archive_location_preserves_requested_access_intent
)

TOUCHED=(
  polylogue/config.py
  polylogue/paths/_roots.py
  polylogue/storage/archive_identity.py
  polylogue/storage/sqlite/connection_profile.py
  tests/unit/core/test_config.py
  tests/unit/core/test_paths.py
  tests/unit/storage/test_archive_identity.py
  tests/unit/storage/test_archive_location_connections.py
)

run_uv() {
  if command -v uv >/dev/null 2>&1; then
    uv run "$@"
  else
    "$@"
  fi
}

echo "== focused ArchiveLocation tests =="
run_uv pytest -q "${TEST_NODES[@]}"

echo "== touched-file lint =="
run_uv ruff check "${TOUCHED[@]}"

echo "== touched product type check =="
run_uv mypy \
  polylogue/storage/archive_identity.py \
  polylogue/storage/sqlite/connection_profile.py \
  polylogue/paths/_roots.py \
  polylogue/config.py

echo "== bytecode compilation =="
run_uv python -m compileall -q "${TOUCHED[@]}"

echo "== repository quick gate =="
if [[ -x ./devtools ]]; then
  ./devtools verify --quick
else
  echo "SKIP: ./devtools is unavailable; run the full-checkout quick gate manually." >&2
fi

echo "Verification plan complete. Handoff: $HANDOFF_ROOT"
