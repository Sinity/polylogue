# Mutation canaries

The Bead requires evidence that the tests fail when the old behavior is restored or kind validation is removed. Two isolated copies of the final implementation were mutated and tested. Nonzero exits were required and observed.

## Canary 1: restore active-parent sibling inference

Mutation in `_resolved_attachment_paths`:

```python
# Correct
peer = identity.location(tier)
peer_path = identity.assert_openable(peer, access_intent=access_intent)

# Deliberate mutation
peer_path = main_location.resolved_path.parent / f"{tier}.db"
```

Target test:

```text
test_split_index_attaches_resolver_selected_durable_source
```

Observed failure:

```text
AssertionError: assert b'\xde\xad\xbe\xef' == b'\x00\x01\x02\xff'
1 failed
```

Interpretation: the mutation selected the valid-but-wrong `source.db` beside the generated index. The canary is semantic and byte-sensitive; it does not merely compare path strings.

## Canary 2: remove identity kind authorization

Mutation in `_prepare_open_target`:

```python
# Correct
open_path = archive_identity.assert_openable(path, access_intent=access_intent)

# Deliberate mutation
open_path = path.resolved_path
```

Target test:

```text
test_wrong_kind_fails_before_sqlite_connect
```

Observed failures for both parameter cases:

```text
AssertionError: sqlite3.connect must not run before identity validation
FAILED ...[root]
FAILED ...[configured-tier]
2 failed
```

Interpretation: without typed authorization, a configured root and a configured tier descriptor reach SQLite. The monkeypatched call counter proves the failure is pre-open, not merely a later SQL error.

## Reproduction guidance

Do not run mutation probes in a valuable checkout. Copy the patched tree or create disposable Git worktrees, apply one mutation at a time, run only the named target, require a nonzero exit, and delete the copy. The correct tree must pass the same targets before and after the mutation exercise is cleaned up.
