# Executive result

The handoff lands a typed archive-location identity and resolver that keeps durable tier meaning anchored to configuration instead of an active index path. The former failure mode was structural: after opening an index generation, the sync connection helper took the opened database’s parent and attached files named `source.db`, `user.db`, `embeddings.db`, and `ops.db` from that directory. In a split deployment, that directory is generation-owned, not the durable archive root, so a plausible sibling could be silently wrong.

The implementation removes that inference from the SQLite open path. `ArchiveIdentity` now owns an explicit tuple of configured and resolved `ArchiveLocation` values. The index may resolve through a symlink to `index.gN.db` anywhere, while source/user and other tiers continue to resolve from the configured root or explicit per-tier overrides. Every typed open checks kind, root, configured path, pointer path and inode identity, resolved target and inode identity, generation, durability, access intent, and—where applicable—the exact ownership capability before SQLite is invoked.

The result is supplied as two ordered patches touching eight files: four product files and four test files. The independently applied patch tree passes 51 focused and compatibility tests, Ruff checks, strict MyPy on all touched product modules, Python bytecode compilation, and two deliberate mutation probes.

## Concrete changes

| Area | Change |
|---|---|
| Identity | Adds `ArchiveLocation`, `ArchiveOwnership`, typed kind/durability/access aliases, runtime invariant checks, pointer/target stable identities, and exact pre-open authorization. |
| Resolver | Adds `resolve_archive_locations` for every tier, explicit per-tier overrides, and an independently located active index pointer/generation. |
| Compatibility | Keeps ordinary same-directory tier filenames behind `resolve_legacy_archive_location`; ambiguous untyped symlink/generation index paths attach nothing. |
| Config/path substrate | Adds `Config.archive_identity()` / `archive_location()` and routes active-index/root helpers through the resolver. The durable root never becomes the active index parent. |
| SQLite | Replaces post-open parent inspection with a precomputed `_OpenTarget`; resolver-selected attachments are validated before `sqlite3.connect`. Read-only behavior remains one-file/no-attachment. Migration opens require explicit `access_intent="migration"`. |
| Tests | Adds split durable/index roots, symlink generation identity, a wrong sibling canary, byte-preserving legacy reads, untyped-path non-inference, migration/read opens, stale pointer checks, and ownership/kind/root/generation/access failures. |

## Acceptance-criteria matrix

| Bead criterion | Result | Evidence and boundary |
|---|---|---|
| 1. Constructors are non-interchangeable; wrong kind/root/generation/ownership fails before SQLite opens. | **Implemented and locally verified.** | Constructor tests plus monkeypatched `sqlite3.connect` call-count assertions cover configured root/tier misuse, foreign roots, forged generations, read/write plan mixing, stale symlink generations, invalid durability/access values, and non-identical ownership capabilities. |
| 2. One resolver reports all configured/resolved tiers and generation/pointer identity for split and legacy layouts without deriving durable siblings from the active-index parent. | **Implemented and locally verified.** | `resolve_archive_locations` is the single plan builder. Config, path helpers, legacy adaptation, and SQLite routing delegate to it. The attachment implementation consumes `identity.location(tier)`, never `main.parent`. |
| 3. Existing production source+index reads remain byte/semantically compatible. | **Implemented for the supplied route; synthetic byte compatibility verified.** | Same-directory `index.db` still resolves unqualified source-tier tables, returning the exact non-text BLOB `00 FE 7F 80 FF`. Split typed reads return `00 01 02 FF`. A live operator archive was not available, so production data itself was not opened. |
| 4. Split-tier/symlink fixtures reproduce invented-sibling failure and pass only through `ArchiveLocation`; restoring inference or removing validation fails. | **Satisfied.** | The decoy source contains `DE AD BE EF`. The typed test reads the durable bytes; untyped pointer/generation paths attach no source. A deliberate sibling-inference mutation reads `DEADBEEF` and fails. A deliberate kind-validation bypass reaches the monkeypatched SQLite call and fails both cases. |
| 5. Focused config/path/storage tests, type checks, and quick gate pass. | **Focused tests and type/lint checks pass; full quick gate remains unverified.** | `51 passed`; Ruff clean; strict MyPy clean for four product modules; `git diff --check` and compileall clean. The immutable slice omits `devtools`, `pyproject.toml`, shared fixtures, and most package modules, so `devtools verify --quick` could not be run. |

## Review focus

The most important review invariant is that an index location does not authorize its parent directory. The configured archive root and explicit per-tier paths are the only source of peer locations. Any conflict resolution that reintroduces `opened_index.parent / "source.db"` defeats the change even if the happy-path tests still appear to work.

The second review focus is the legacy boundary. Plain, non-symlink same-directory `index.db` remains compatible. A symlinked `index.db` or generated `index.g*.db` presented as an untyped path is intentionally not treated as an archive file set; callers with split-generation knowledge must pass the resolver-produced `ArchiveLocation` and matching `ArchiveIdentity`.

## Residual risks

The supplied snapshot contains only a small subset of the full package. The async SQLite attachment path, complete `ArchiveStore`, migration modules, and all production surface call sites were unavailable. The patch establishes the type and sync factory seam they should consume, but a full-checkout grep and managed verification run remain necessary.

There is also an unavoidable filesystem time-of-check/time-of-use interval between identity validation and the Python SQLite open call. Opening the resolved generation path, rather than its symlink pointer, removes pointer-swap ambiguity; replacing the resolved target pathname in the tiny interval would still require a future OS/file-descriptor strategy beyond this Bead.
