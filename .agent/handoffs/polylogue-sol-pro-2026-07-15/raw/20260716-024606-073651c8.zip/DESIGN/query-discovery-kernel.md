# Declare-once query-discovery kernel

## Design objective

An agent-facing query vocabulary is safe only when the executable parser/runtime declarations generate the teaching surfaces. A separately maintained catalog or cookbook inevitably drifts. The implementation makes executable declarations the dependency root and treats prompts, resources, schemas, completions, errors, examples, projections, and tests as projections of those declarations.

## Registry shape

The existing `QueryUnitDescriptor` remains the central unit declaration. It now carries:

- executable identity: unit name, singular/plural sources, lowerer, runtime query method, terminal support;
- semantics: fact family, meaning, evidence authority, applicable origins and artifact kinds;
- shape: public fields, compact projection, row and aggregate result class;
- planning: pushdown shape, cardinality, cost class, selective predicates, joins, stable order;
- observability: coverage source and freshness source;
- agent teaching: description, terminal example, and recovery guidance.

Adjacent immutable registries declare operations, six result-semantics classes, recipes, and known gaps. They share one catalog record contract so agents can search across units, fields, operations, origins, recipes, result semantics, and unavailable dimensions without learning separate APIs.

## Generated flow

```text
QueryUnitDescriptor + field registries
        │
        ├── parser aliases / terminal source lookup
        ├── runtime payload model and executor parity
        ├── compact projections
        ├── completion candidates
        ├── MCP expression/plan descriptions and schema enums
        ├── invalid-expression recovery payload
        ├── capability/coverage catalog records
        └── terminal examples

QueryRecipeDescriptor
        ├── six shipped MCP prompts
        ├── catalog recipe records
        ├── recipe completions
        └── parser/installed-skill parity fixtures

QueryResultSemanticsDescriptor
        ├── exactness / total meaning / omitted fields
        ├── continuation requirements
        └── page / stream / queue / spool guidance
```

## Terminal grammar and structured plan

`query_units` accepts exactly one input form:

1. Executable DSL, for example:

   ```text
   sessions where repo:polylogue AND since:7d | actions where is_error:true | sort by time desc | limit 20
   ```

2. Typed structured plan:

   ```json
   {
     "source": "actions",
     "where": "is_error:true",
     "session_where": "repo:polylogue AND since:7d",
     "stages": [
       {"kind": "sort", "field": "time", "direction": "desc"},
       {"kind": "limit", "value": 20}
     ]
   }
   ```

The structured plan is not a second execution engine. It lowers to canonical DSL, validates through `parse_unit_source_expression`, and executes the existing AST/runtime path. The closed source/stage enums are generated from declarations and parity checked.

## Catalog protocol

The catalog is exposed as a read-only resource rather than another MCP tool:

- Base: `polylogue://capabilities/query`
- Search/continuation: `polylogue://capabilities/query/search/{search}/{offset}/{limit}`

Every response states exact matching record count, page count, result semantic, exactness, completeness, next offset, and a concrete continuation URI. Pages are capped at seven records. With a 15-origin stress enum, the first pretty-serialized page is 23,758 bytes, below the server’s 25,000-byte response budget.

Record ordering intentionally puts overview units, recipes, gaps, operations, and result semantics ahead of detailed fields. A cold agent receives useful terminal forms before deep field inventory, while search provides direct access to a specific capability or gap.

## Coverage contract

Coverage state is closed and semantically explicit:

- `supported-and-observed`
- `supported-but-absent`
- `supported-but-stale`
- `supported-but-degraded`
- `unsupported`
- `unknown`

`unknown` is not treated as absence. The MCP resource currently obtains bounded message/origin counts from `archive.stats`; other unit relations remain unknown unless a dedicated count provider is registered. This is intentionally less ambitious than inventing expensive relation counts or falsely claiming full coverage.

Known gaps are first-class catalog records. The initial records include unsupported `message.model`, degraded material-origin filtering, and unknown workflow artifact coverage, each with authority, applicability, recovery, and an executable navigation/example path.

## Result truth contract

The six classes are:

1. exhaustive relation page;
2. aggregate summary page;
3. ranked top-k;
4. sample;
5. bounded context;
6. recursive graph page.

For terminal rows and aggregate groups, `total` remains the returned page count for compatibility. New fields remove ambiguity:

- `page_count`
- `total_semantics`
- `result_semantics`
- `exactness`
- `complete`
- `continuation_required`
- `next_offset`
- continuation instructions and semantics-preserving strategies

`next_offset` advances by the number of rows actually returned, not the requested limit. This remains correct for a short page that still has continuation.

## Cost and large queries

Cost classes and cardinality are discovery/planner metadata. They never make a valid relation “unsupported.” Exhaustive and aggregate semantics declare page, stream, queue, and spool as preserving strategies. The current MCP route pages synchronously; the separate transaction worker can consume the same canonical plan and semantics metadata for queued/resumable execution.

## Compatibility choices

- No new MCP tool was added, avoiding further growth of the already large tool inventory.
- Existing `query_units(expression=...)` calls continue to work.
- `total` is retained as page count; callers can migrate to explicit fields.
- Unrelated MCP errors do not gain bulky recovery arrays because new recovery fields are optional and omitted when absent.
- No module was added under `polylogue/`; existing architecture and topology remain intact.

## Rejected alternatives

### Make `sessions` a terminal query unit

Rejected because it changes parser/runtime semantics and hides the distinction between session enumeration and normalized fact rows. The correct repair is to teach a terminal source.

### Keep a separate static capability catalog

Rejected because it would reproduce the prompt/parser drift. Catalog records must be rendered from executable declarations and parity checked against runtime models/executors.

### Put the entire inventory into the tool description

Rejected because the catalog already exceeds a safe single response and changes as fields/origins grow. Bounded searchable resources give a cold agent useful first-page orientation plus exact continuation.

### Reject expensive valid queries

Rejected by the Beads contract. Cost informs strategy and progress; it does not alter query meaning. Paging/streaming/queued/spooled execution preserves semantics.

### Claim zero when a live count is unavailable

Rejected because “not counted” and “absent” are different facts. The catalog uses `unknown` until an authoritative count provider exists.

### Execute structured plans independently

Rejected because two lowerers would drift. Structured input compiles to the same canonical DSL/AST.

### Add a discovery tool

Rejected because a resource is sufficient, read-only, searchable, and does not enlarge tool selection pressure.

## Extension points

Future work can add origins, unit count providers, operations, recipes, result classes, CLI/OpenAPI renderers, and generic transaction estimates by consuming the same declarations. The parity tests are intentionally exact so an incomplete declaration or stale renderer fails before shipping.
