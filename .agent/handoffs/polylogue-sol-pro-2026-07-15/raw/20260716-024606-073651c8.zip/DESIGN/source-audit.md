# Source audit and regression evidence

## Immutable snapshot boundary

The work was performed against the selected source snapshot supplied with the mission. Its recorded upstream state is:

- revision `518ac33e318995539743e220c01b9883b7a688a0`
- branch `feature/browser/sol-pro-dispatch`
- pre-existing staged change `.beads/issues.jsonl`

No patch touches Beads state. A synthetic local Git baseline was created only to produce reviewable mail patches; that baseline was byte-identical to the supplied selected files. The three patches were then applied to a separate fresh snapshot copy and reproduced the implementation tree exactly.

The snapshot is curated rather than a complete checkout. It includes the relevant query, MCP, surface payload, docs, and selected tests, but omits most `polylogue.core`, storage/archive substrate modules, package metadata, and the external installed shared-skill file.

## Concrete contradiction

The canonical parser in `polylogue/archive/query/expression.py` treats `sessions where …` as a session scope. `query_units` requires a terminal unit source such as `messages`, `actions`, `files`, `runs`, or `delegations`. A valid scoped expression therefore has the shape:

```text
sessions where <session predicate> | <terminal units> where <unit predicate>
```

or a direct terminal expression can place session fields in the unit predicate:

```text
<terminal units> where session.repo:<repo> AND <unit predicate>
```

The shipped `unacknowledged_failures` and `sessions_touching_file` prompts instead called `query_units` with a bare sessions selector containing `exists action(...)` or `exists file(...)`. The installed skill repeated those exact forms. The parser correctly returned no terminal unit source, and the old runtime emitted only a generic failure.

This was not a model mistake. The product’s own curriculum contradicted its executable grammar.

## Existing architecture reused

The audit found that `QueryUnitDescriptor` already drove parser aliases and row execution metadata. The repair therefore extends that declaration rather than introducing a new capability schema disconnected from execution.

The following existing seams were used:

- `archive/query/metadata.py`: unit and field declarations, now expanded into the discovery kernel.
- `archive/query/expression.py`: canonical DSL parser and terminal-source lowering.
- `archive/query/unit_results.py`: terminal action executor registry and row/aggregate execution.
- `surfaces/payloads.py`: compact row and envelope contracts.
- `mcp/query_contracts.py`: request models and schema derivation.
- `mcp/server_tools.py`: `query_units`, search/list/facet tool registration and preflight.
- `mcp/server_prompts.py`: six shipped cookbook prompts.
- `mcp/server_resources.py`: read-only resource registration.
- `archive/query/completions.py`: query completion registry.

## Beads requirements applied

Later Beads notes supersede any narrower interpretation of the title. The implementation follows these corrections:

- Cost classification is planner input, not permission to reject a semantically valid question.
- Discovery must include normalized facts, authority, coverage, freshness, cardinality, narrowing dimensions, and recovery.
- Static declarations/catalog/recipes can land before the separate shared transport executor.
- The exact two installed-skill expressions are immutable regression fixtures.
- Result semantics must distinguish exhaustive pages, aggregates, rankings, samples, bounded context, and recursive graph pages.
- Discovery must be paged/searchable rather than a huge static tool description.

## Scope deliberately not duplicated

A separate worker owns the generic bounded/resumable query transaction. This slice does not add a queue, spool manager, streaming transport, job store, progress protocol, or daemon transaction lifecycle. It declares which execution strategies preserve each result semantic and leaves the canonical expression/plan replayable for that worker.

## No external research dependency

The regression, grammar, runtime contracts, transport budget, and design vocabulary were all present in the supplied source and Beads record. No web-derived claim was required for this patch.
