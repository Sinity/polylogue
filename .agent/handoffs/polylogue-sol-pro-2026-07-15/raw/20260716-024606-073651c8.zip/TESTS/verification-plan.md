# Verification plan

## 1. Patch integrity and reproducibility

Apply all three mail patches in lexical order to a clean copy of revision `518ac33e318995539743e220c01b9883b7a688a0`. Require:

- all patches apply without rejects;
- `git diff --check` is empty;
- the patched selected source tree is byte-identical to the implementation tree;
- no patch modifies `.beads/issues.jsonl` or another path outside the 17-file change list.

## 2. Self-contained snapshot verifier

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 python TESTS/verify_snapshot.py /path/to/patched/repo
```

The verifier checks:

- syntax compilation of every changed Python file;
- nine unique terminal unit declarations and nine recipes;
- the exact six shipped recipe names;
- six result-semantics classes and six coverage states;
- all declared recipe expressions and terminal examples compile through the real `expression.py` parser;
- installed-skill fixture templates match the registry and compile;
- both historical sessions-only templates remain nonterminal/rejected;
- structured plans lower to canonical DSL, validate through the parser, expose closed source/stage enums, and enforce exactly one input form;
- every catalog record contains the common authority/coverage/plan contract;
- every coverage state is representable;
- catalog search, exact totals, continuation URI, page cap, and 25,000-byte response budget;
- compact projections exactly match runtime row payload class fields;
- declared terminal actions exactly match runtime executor-map keys;
- all six shipped prompt functions call the generated recipes;
- tool/resource/docs wiring and mutation-sensitive test assertions are present;
- row and aggregate envelopes expose explicit result truth fields.

The narrow stubs are only for modules absent from the curated snapshot. They do not replace the real metadata, parser, predicate AST, or structured-plan models under test.

## 3. Focused project tests in a complete checkout

Run:

```bash
PYTHONPATH=. pytest -q \
  tests/unit/core/test_query_discovery_registry.py \
  tests/unit/core/test_query_result_semantics.py \
  tests/unit/mcp/test_query_capability_resource.py \
  tests/unit/mcp/test_query_recipe_parity.py \
  tests/unit/mcp/test_query_tool_schema_derivation.py
```

These tests exercise real Pydantic payloads, MCP registration helpers, fake archive rows/stats, generated prompts, DSL/plan envelope parity, and error payloads. Then run the project’s complete test, type, formatting, architecture/topology, and documentation gates.

## 4. Live-route checks in an operator environment

With a real archive and MCP server:

1. Read `polylogue://capabilities/query`; confirm a bounded first page and concrete continuation URI.
2. Search the resource for `message.model`, `material_origin`, `workflow`, and a terminal source.
3. Call `query_units` with a valid direct terminal expression and page through `next_offset` without changing filters/order.
4. Call the equivalent structured plan and compare canonical expression, rows, references, exactness, and continuation.
5. Call the exact historical sessions-only expression; confirm the response gives valid forms, every terminal source, examples, plan example, completion call, and catalog URI.
6. Render all six cookbook prompts and execute each embedded expression.
7. Exercise an archive whose page contains fewer rows than the requested limit but still has a continuation; verify `next_offset = offset + returned row count`.
8. Confirm an unavailable live stats path yields `unknown`, not `supported-but-absent`.

## 5. Mutation checks

The new suite should fail if a maintainer performs any of these mutations:

- changes either corrected recipe back to a bare `sessions where …` expression;
- adds/removes a row payload field without updating `compact_projection`;
- adds a terminal executor or stage without declaring it;
- adds a result-semantics Literal without a registry record;
- raises the catalog page cap beyond the transport budget;
- removes exactness/continuation fields or advances `next_offset` by requested limit;
- hand-writes a shipped prompt instead of rendering its recipe;
- changes the installed-skill template without updating executable declarations and fixture parity.
