#!/usr/bin/env python3
"""Self-contained verification for the Polylogue query-discovery patch series.

The supplied review snapshot intentionally omits most substrate modules and the
MCP package. This verifier imports the real metadata, expression parser, and
Pydantic query-plan models while installing narrow in-memory stubs only for the
omitted dependencies. It also performs AST parity checks that do not require a
live archive, daemon, or storage implementation.
"""

from __future__ import annotations

import argparse
import ast
import dataclasses
import enum
import importlib
import json
import os
import sys
import types
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

EXPECTED_CHANGED_PATHS = (
    "docs/mcp-reference.md",
    "docs/search.md",
    "polylogue/archive/query/completions.py",
    "polylogue/archive/query/metadata.py",
    "polylogue/archive/query/unit_results.py",
    "polylogue/mcp/payloads.py",
    "polylogue/mcp/query_contracts.py",
    "polylogue/mcp/server_prompts.py",
    "polylogue/mcp/server_resources.py",
    "polylogue/mcp/server_tools.py",
    "polylogue/surfaces/payloads.py",
    "tests/fixtures/query_discovery/installed_skill_expressions.json",
    "tests/unit/core/test_query_discovery_registry.py",
    "tests/unit/core/test_query_result_semantics.py",
    "tests/unit/mcp/test_query_capability_resource.py",
    "tests/unit/mcp/test_query_recipe_parity.py",
    "tests/unit/mcp/test_query_tool_schema_derivation.py",
)

COMMON_CATALOG_KEYS = {
    "id",
    "kind",
    "name",
    "fact_family",
    "meaning",
    "authority",
    "applicable_origins",
    "artifact_kinds",
    "coverage_source",
    "freshness_source",
    "coverage",
    "projection",
    "pushdown_plan",
    "cardinality",
    "cost_class",
    "stable_order",
    "examples",
    "recovery",
}

EXPECTED_SEMANTICS = {
    "exhaustive-relation-page",
    "aggregate-summary-page",
    "ranked-top-k",
    "sample",
    "bounded-context",
    "recursive-graph-page",
}

EXPECTED_SHIPPED_RECIPES = {
    "resume_context",
    "postmortem_last",
    "decisions_about",
    "unacknowledged_failures",
    "sessions_touching_file",
    "cost_of",
}

EXPECTED_COVERAGE_STATES = {
    "supported-and-observed",
    "supported-but-absent",
    "supported-but-stale",
    "supported-but-degraded",
    "unsupported",
    "unknown",
}


def fail(message: str) -> None:
    raise AssertionError(message)


def read_text(repo: Path, relative: str) -> str:
    return (repo / relative).read_text(encoding="utf-8")


def class_fields(tree: ast.Module, class_name: str) -> tuple[str, ...]:
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            return tuple(
                stmt.target.id
                for stmt in node.body
                if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name)
            )
    fail(f"class not found: {class_name}")


def assignment_dict_keys(tree: ast.Module, assignment_name: str) -> tuple[str, ...]:
    for node in tree.body:
        target: ast.expr | None = None
        value: ast.expr | None = None
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target, value = node.targets[0], node.value
        elif isinstance(node, ast.AnnAssign):
            target, value = node.target, node.value
        if isinstance(target, ast.Name) and target.id == assignment_name and isinstance(value, ast.Dict):
            keys: list[str] = []
            for key in value.keys:
                if not isinstance(key, ast.Constant) or not isinstance(key.value, str):
                    fail(f"{assignment_name} has a non-literal key")
                keys.append(key.value)
            return tuple(keys)
    fail(f"dict assignment not found: {assignment_name}")


def literal_call_arguments(tree: ast.Module, function_name: str) -> tuple[str, ...]:
    values: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Name) or node.func.id != function_name:
            continue
        if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
            values.append(node.args[0].value)
    return tuple(values)


def install_snapshot_stubs(repo: Path) -> None:
    """Install only dependencies omitted from the curated source snapshot."""

    if str(repo) not in sys.path:
        sys.path.insert(0, str(repo))

    # Keep the real namespace package rooted at this snapshot while providing
    # omitted subpackages as in-memory modules.
    core_pkg = types.ModuleType("polylogue.core")
    core_pkg.__path__ = []
    sys.modules["polylogue.core"] = core_pkg

    class Origin(str, enum.Enum):
        CLAUDE_CODE = "claude-code-session"
        CODEX = "codex-session"
        CHATGPT = "chatgpt-export"
        CLAUDE_WEB = "claude-web-export"
        GEMINI = "gemini-export"
        ANTIGRAVITY = "antigravity-session"
        HERMES = "hermes-session"
        CURSOR = "cursor-session"
        GROK = "grok-export"
        BROWSER = "browser-capture"
        FIXTURE_01 = "fixture-origin-01"
        FIXTURE_02 = "fixture-origin-02"
        FIXTURE_03 = "fixture-origin-03"
        FIXTURE_04 = "fixture-origin-04"
        UNKNOWN = "unknown-export"

        @classmethod
        def from_string(cls, value: str) -> "Origin":
            for item in cls:
                if item.value == value:
                    return item
            return cls.UNKNOWN

    def enum_values(value: type[enum.Enum]) -> tuple[str, ...]:
        return tuple(str(item.value) for item in value)

    enums = types.ModuleType("polylogue.core.enums")
    enums.Origin = Origin
    enums.enum_values = enum_values
    sys.modules["polylogue.core.enums"] = enums

    class PolylogueError(Exception):
        pass

    errors = types.ModuleType("polylogue.core.errors")
    errors.PolylogueError = PolylogueError
    sys.modules["polylogue.core.errors"] = errors

    @dataclasses.dataclass(frozen=True)
    class ObjectRef:
        kind: str
        object_id: str

        @classmethod
        def parse(cls, value: str) -> "ObjectRef":
            kind, _, object_id = value.partition(":")
            return cls(kind or "unknown", object_id)

    refs = types.ModuleType("polylogue.core.refs")
    refs.ObjectRef = ObjectRef
    sys.modules["polylogue.core.refs"] = refs

    identity = types.ModuleType("polylogue.core.query_identity")
    identity.query_ref = lambda value: value
    identity.query_run_ref = lambda value: value
    identity.result_set_ref = lambda value: value
    sys.modules["polylogue.core.query_identity"] = identity

    @dataclasses.dataclass(frozen=True)
    class SessionQuerySpec:
        query_terms: tuple[str, ...] = ()
        contains_terms: tuple[str, ...] = ()
        exclude_text_terms: tuple[str, ...] = ()
        retrieval_lane: str = "auto"
        referenced_path: tuple[str, ...] = ()
        cwd_prefix: str | None = None
        action_terms: tuple[str, ...] = ()
        excluded_action_terms: tuple[str, ...] = ()
        action_sequence: tuple[str, ...] = ()
        action_text_terms: tuple[str, ...] = ()
        tool_terms: tuple[str, ...] = ()
        excluded_tool_terms: tuple[str, ...] = ()
        origins: tuple[str, ...] = ()
        excluded_origins: tuple[str, ...] = ()
        repo_names: tuple[str, ...] = ()
        project_refs: tuple[str, ...] = ()
        tags: tuple[str, ...] = ()
        excluded_tags: tuple[str, ...] = ()
        has_types: tuple[str, ...] = ()
        filter_has_paste: bool = False
        filter_has_tool_use: bool = False
        filter_has_thinking: bool = False
        title: str | None = None
        session_id: str | None = None
        since: str | None = None
        until: str | None = None
        similar_text: str | None = None
        similar_session_id: str | None = None
        min_messages: int | None = None
        max_messages: int | None = None
        min_words: int | None = None
        max_words: int | None = None
        boolean_predicate: object | None = None
        with_units: tuple[str, ...] = ()
        with_unit_fields: dict[str, tuple[str, ...]] = dataclasses.field(default_factory=dict)
        sort: object | None = None
        reverse: bool = False
        limit: int | None = None
        sample: int | None = None
        latest: bool = False
        typed_only: bool = False
        message_type: str | None = None
        since_session_id: str | None = None
        offset: int = 0
        cursor: str | None = None

        @classmethod
        def from_params(cls, data: dict[str, Any], strict: bool = False) -> "SessionQuerySpec":
            del strict
            return cls(**data)

    class QuerySpecError(PolylogueError):
        def __init__(self, field: str, value: str) -> None:
            super().__init__(f"invalid {field}: {value}")
            self.field = field
            self.value = value

    query_spec = types.ModuleType("polylogue.archive.query.spec")
    query_spec.SessionQuerySpec = SessionQuerySpec
    query_spec.QuerySpecError = QuerySpecError
    query_spec.QUERY_ACTION_TYPES = ("file_edit", "file_read", "shell", "command_run", "search", "none")
    query_spec.normalize_retrieval_lane = lambda value: value if value in {
        "auto",
        "dialogue",
        "actions",
        "hybrid",
    } else (_ for _ in ()).throw(ValueError(value))
    query_spec.split_csv = lambda value: () if value is None else tuple(
        part.strip() for part in str(value).split(",") if part.strip()
    )
    sys.modules["polylogue.archive.query.spec"] = query_spec

    message_pkg = types.ModuleType("polylogue.archive.message")
    message_pkg.__path__ = []
    sys.modules["polylogue.archive.message"] = message_pkg
    message_types = types.ModuleType("polylogue.archive.message.types")

    class _MessageType:
        def __init__(self, value: str) -> None:
            self.value = value

    message_types.validate_message_type_filter = lambda value: _MessageType(str(value))
    sys.modules["polylogue.archive.message.types"] = message_types


def dynamic_checks(repo: Path) -> dict[str, int]:
    install_snapshot_stubs(repo)
    metadata = importlib.import_module("polylogue.archive.query.metadata")
    expression = importlib.import_module("polylogue.archive.query.expression")
    contracts = importlib.import_module("polylogue.mcp.query_contracts")

    units = metadata.QUERY_UNIT_DESCRIPTORS
    recipes = metadata.QUERY_RECIPE_DESCRIPTORS
    if len(units) != 9:
        fail(f"expected 9 terminal units, found {len(units)}")
    if len(recipes) != 9:
        fail(f"expected 9 recipes, found {len(recipes)}")
    if {item.name for item in metadata.query_recipe_descriptors(shipped_prompt=True)} != EXPECTED_SHIPPED_RECIPES:
        fail("shipped recipe set drifted")
    if {item.name for item in metadata.QUERY_RESULT_SEMANTICS} != EXPECTED_SEMANTICS:
        fail("result-semantics registry drifted")
    if set(metadata.QUERY_COVERAGE_STATES) != EXPECTED_COVERAGE_STATES:
        fail("coverage-state registry drifted")

    compiled_expressions = 0
    for recipe in recipes:
        rendered = metadata.render_query_recipe(recipe.name)
        if not rendered.strip():
            fail(f"empty generated recipe: {recipe.name}")
        for _tool, language, value in metadata.query_recipe_expressions(recipe.name):
            if language == "query-unit-dsl":
                if expression.parse_unit_source_expression(value) is None:
                    fail(f"nonterminal generated query-unit expression: {recipe.name}: {value}")
            elif language == "session-dsl":
                expression.compile_expression(value)
            else:
                fail(f"unknown expression language: {language}")
            compiled_expressions += 1

    for value in metadata.terminal_query_examples():
        if expression.parse_unit_source_expression(value) is None:
            fail(f"terminal example did not compile: {value}")
        compiled_expressions += 1

    fixture = json.loads(
        read_text(repo, "tests/fixtures/query_discovery/installed_skill_expressions.json")
    )
    bindings = fixture["bindings"]
    recipes_by_name = {item.name: item for item in recipes}
    for item in fixture["expressions"]:
        recipe = recipes_by_name[item["recipe"]]
        step = recipe.steps[item["step_index"]]
        if step.expression_template != item["template"]:
            fail(f"installed-skill template drift: {item['recipe']}")
        value = item["template"].format_map(bindings)
        if expression.parse_unit_source_expression(value) is None:
            fail(f"installed-skill expression is not terminal: {value}")
        compiled_expressions += 1

    for template in fixture["legacy_rejected"]:
        value = template.format_map(bindings)
        if expression.parse_unit_source_expression(value) is not None:
            fail(f"legacy sessions-only expression became terminal: {value}")

    plan = contracts.MCPQueryUnitPlan(
        source="actions",
        where="is_error:true",
        session_where="repo:polylogue AND since:7d",
        stages=(
            contracts.MCPQueryUnitStage(kind="sort", field="time", direction="desc"),
            contracts.MCPQueryUnitStage(kind="limit", value=20),
        ),
    )
    canonical = (
        "sessions where repo:polylogue AND since:7d | "
        "actions where is_error:true | sort by time desc | limit 20"
    )
    if plan.to_expression() != canonical:
        fail("structured plan did not lower to the canonical DSL")
    if expression.parse_unit_source_expression(canonical) is None:
        fail("canonical structured-plan expression did not compile")
    if contracts.resolve_query_unit_expression(None, plan) != canonical:
        fail("structured plan resolver drifted")
    for args in ((None, None), ("actions where is_error:true", plan)):
        try:
            contracts.resolve_query_unit_expression(*args)
        except ValueError as exc:
            if "exactly one" not in str(exc):
                fail(f"wrong exactly-one error: {exc}")
        else:
            fail("query-unit resolver accepted zero or two input forms")

    schema = contracts.MCPQueryUnitPlan.model_json_schema()
    schema_enums: set[str] = set()

    def walk(value: object) -> None:
        if isinstance(value, dict):
            schema_enums.update(item for item in value.get("enum", ()) if isinstance(item, str))
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(schema)
    if not set(metadata.terminal_query_sources()) <= schema_enums:
        fail("structured-plan schema omits terminal source declarations")
    if not set(metadata.structured_query_stage_kinds()) <= schema_enums:
        fail("structured-plan schema omits stage declarations")
    if schema.get("additionalProperties") is not False:
        fail("structured-plan schema is not closed")

    coverage = {
        "snapshot_source": "handoff-verifier",
        "observed_at": "2026-07-15T00:00:00+00:00",
        "total_sessions": 5,
        "total_messages": 12,
        "origins": {"claude-code-session": 4, "codex-session": 0},
        "unit_counts": {"message": 12, "action": 0},
        "stale_units": ("run",),
        "degraded_units": ("delegation",),
        "coverage_note": "Exercises all six coverage states.",
    }
    records = metadata.query_capability_records(coverage=coverage)
    if len({str(record["id"]) for record in records}) != len(records):
        fail("catalog record ids are not unique")
    missing = {
        str(record.get("id")): sorted(COMMON_CATALOG_KEYS - set(record))
        for record in records
        if COMMON_CATALOG_KEYS - set(record)
    }
    if missing:
        fail(f"catalog records missing common fields: {missing}")
    states = {
        str(record["coverage"]["state"])
        for record in records
        if isinstance(record.get("coverage"), dict)
    }
    if states != EXPECTED_COVERAGE_STATES:
        fail(f"catalog did not represent all coverage states: {sorted(states)}")

    catalog = metadata.query_capability_catalog(limit=999, coverage=coverage)
    if catalog["limit"] != metadata.QUERY_CAPABILITY_CATALOG_PAGE_MAX:
        fail("catalog did not clamp to the declared page cap")
    if catalog["page_count"] != metadata.QUERY_CAPABILITY_CATALOG_PAGE_MAX:
        fail("catalog first page did not fill the declared cap")
    if catalog["total"] <= catalog["page_count"] or catalog["complete"] is not False:
        fail("catalog continuation contract is not exact")
    if catalog["next_offset"] != metadata.QUERY_CAPABILITY_CATALOG_PAGE_MAX:
        fail("catalog next_offset drifted")
    continuation = catalog.get("continuation")
    if not isinstance(continuation, dict) or not str(continuation.get("uri", "")).startswith(
        "polylogue://capabilities/query/search/"
    ):
        fail("catalog did not emit a concrete continuation resource URI")
    serialized_bytes = len(
        json.dumps(catalog, indent=2, ensure_ascii=False, default=str).encode("utf-8")
    )
    if serialized_bytes >= 25_000:
        fail(f"catalog page exceeds the MCP response budget: {serialized_bytes} bytes")

    searched = metadata.query_capability_catalog(
        search="message.model", limit=999, coverage=coverage
    )
    if not any(item["id"] == "gap:message.model" for item in searched["items"]):
        fail("catalog search did not find the declared message.model gap")

    exhaustive = next(
        item for item in metadata.QUERY_RESULT_SEMANTICS if item.name == "exhaustive-relation-page"
    )
    if set(exhaustive.semantics_preserving_strategies) != {"page", "stream", "queue", "spool"}:
        fail("large-query guidance lost a semantics-preserving strategy")
    if "unsupported" not in exhaustive.large_query_guidance:
        fail("large-query guidance no longer warns against treating cost as unsupported semantics")

    return {
        "units": len(units),
        "recipes": len(recipes),
        "compiled_expressions": compiled_expressions,
        "catalog_records": len(records),
        "catalog_page_bytes": serialized_bytes,
    }


def static_checks(repo: Path) -> dict[str, int]:
    missing = [path for path in EXPECTED_CHANGED_PATHS if not (repo / path).is_file()]
    if missing:
        fail(f"expected changed files missing: {missing}")

    compiled_files = 0
    for relative in EXPECTED_CHANGED_PATHS:
        if not relative.endswith(".py"):
            continue
        source = read_text(repo, relative)
        compile(source, str(repo / relative), "exec")
        compiled_files += 1

    payload_tree = ast.parse(read_text(repo, "polylogue/surfaces/payloads.py"))
    metadata_module = sys.modules["polylogue.archive.query.metadata"]
    for descriptor in metadata_module.QUERY_UNIT_DESCRIPTORS:
        observed = class_fields(payload_tree, descriptor.payload_model)
        if observed != descriptor.compact_projection:
            fail(
                f"projection mismatch for {descriptor.unit}: payload={observed}, "
                f"declaration={descriptor.compact_projection}"
            )

    envelope_fields = set(class_fields(payload_tree, "QueryUnitEnvelope"))
    aggregate_fields = set(class_fields(payload_tree, "QueryUnitAggregateEnvelope"))
    semantic_fields = {
        "total",
        "page_count",
        "total_semantics",
        "result_semantics",
        "exactness",
        "complete",
        "continuation_required",
        "next_offset",
        "continuation",
    }
    if not semantic_fields <= envelope_fields:
        fail(f"row envelope lacks result-semantics fields: {sorted(semantic_fields - envelope_fields)}")
    if not semantic_fields <= aggregate_fields:
        fail(
            "aggregate envelope lacks result-semantics fields: "
            f"{sorted(semantic_fields - aggregate_fields)}"
        )

    executor_tree = ast.parse(read_text(repo, "polylogue/archive/query/unit_results.py"))
    executor_actions = set(assignment_dict_keys(executor_tree, "TERMINAL_ACTION_EXECUTORS"))
    if executor_actions != set(metadata_module.terminal_query_actions()):
        fail(
            f"terminal operation/executor parity failed: declared={metadata_module.terminal_query_actions()}, "
            f"runtime={sorted(executor_actions)}"
        )

    prompts_source = read_text(repo, "polylogue/mcp/server_prompts.py")
    if "query_units(expression='sessions where" in prompts_source:
        fail("production prompts still embed a sessions-only query_units expression")
    prompt_tree = ast.parse(prompts_source)
    prompt_recipes = set(literal_call_arguments(prompt_tree, "render_query_recipe"))
    if prompt_recipes != EXPECTED_SHIPPED_RECIPES:
        fail(f"prompt recipe calls drifted: {sorted(prompt_recipes)}")

    for production_relative in (
        "polylogue/mcp/server_prompts.py",
        "polylogue/mcp/server_tools.py",
        "docs/mcp-reference.md",
        "docs/search.md",
    ):
        text = read_text(repo, production_relative)
        if "sessions where repo:{repo_name} since:{since} AND exists action(output:failed)" in text:
            fail(f"legacy failure recipe remains in {production_relative}")
        if "sessions where repo:{repo_name} AND exists file(action:file_edit AND path:{path})" in text:
            fail(f"legacy file recipe remains in {production_relative}")

    resource_source = read_text(repo, "polylogue/mcp/server_resources.py")
    for token in (
        "QUERY_CAPABILITY_CATALOG_URI",
        "polylogue://capabilities/query/search/{search}/{offset}/{limit}",
        "query_capability_catalog",
        "Unknown coverage must not be interpreted as absence",
    ):
        if token not in resource_source:
            fail(f"capability resource wiring missing token: {token}")

    tool_source = read_text(repo, "polylogue/mcp/server_tools.py")
    for token in (
        "MCPQueryUnitPlan",
        "resolve_query_unit_expression",
        "query_units_recovery_payload",
        "parse_unit_source_expression",
    ):
        if token not in tool_source:
            fail(f"query_units wiring missing token: {token}")

    docs = read_text(repo, "docs/mcp-reference.md") + "\n" + read_text(repo, "docs/search.md")
    docs_normalized = docs.lower().replace("-", " ")
    for token in (
        "polylogue://capabilities/query",
        "next_offset",
        "stream",
        "queue",
        "spool",
        "structured plan",
    ):
        if token.lower() not in docs_normalized:
            fail(f"public docs omit required discovery guidance: {token}")

    result_test = read_text(repo, "tests/unit/core/test_query_result_semantics.py")
    recipe_test = read_text(repo, "tests/unit/mcp/test_query_recipe_parity.py")
    registry_test = read_text(repo, "tests/unit/core/test_query_discovery_registry.py")
    for token, source in (
        ("next_offset == 21", result_test),
        ("query_units_invalid_expression_message", recipe_test),
        ("installed_skill_expressions.json", recipe_test),
        ("MCP_RESPONSE_BUDGET_BYTES", registry_test),
        ("TERMINAL_ACTION_EXECUTORS", registry_test),
    ):
        if token not in source:
            fail(f"mutation-sensitive test assertion missing: {token}")

    return {"compiled_python_files": compiled_files, "expected_changed_files": len(EXPECTED_CHANGED_PATHS)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "repo",
        nargs="?",
        default=".",
        help="Path to the source snapshot after applying PATCHES/ in order.",
    )
    args = parser.parse_args()
    repo = Path(args.repo).resolve()
    if not repo.is_dir():
        raise SystemExit(f"repository path does not exist: {repo}")

    dynamic = dynamic_checks(repo)
    static = static_checks(repo)

    print("PASS syntax: compiled", static["compiled_python_files"], "changed Python files")
    print(
        "PASS registry:",
        dynamic["units"],
        "terminal units;",
        dynamic["recipes"],
        "recipes; six result classes and six coverage states",
    )
    print("PASS parser parity:", dynamic["compiled_expressions"], "declared/fixture expressions compiled")
    print("PASS regression: both historical sessions-only skill expressions remain rejected")
    print("PASS plan parity: structured plan lowers to the canonical executable DSL and closed schema")
    print(
        "PASS catalog:",
        dynamic["catalog_records"],
        "records; first page",
        dynamic["catalog_page_bytes"],
        "pretty-JSON bytes (<25000)",
    )
    print("PASS projection/executor/prompt/resource/docs/test parity")
    print("VERIFIED", repo)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
