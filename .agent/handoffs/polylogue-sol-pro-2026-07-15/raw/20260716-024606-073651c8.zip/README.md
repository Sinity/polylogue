# Polylogue query-discovery P0 handoff

This handoff implements the reviewable source slice for `polylogue-z9gh.3`, “Generate agent query discovery from executable query declarations.” It fixes the active contradiction in which product-owned prompts and the installed skill taught bare `sessions where …` expressions to `query_units`, even though the canonical parser accepts sessions only as a scoping stage before a terminal unit source.

The implementation extends the existing executable query metadata kernel rather than adding a parallel registry. Unit, field, operation, result-semantics, recipe, capability-gap, authority, coverage, projection, cost, order, example, and recovery declarations now generate the MCP query contract, bounded discovery catalog, prompt recipes, schema descriptions, completion candidates, and invalid-expression guidance.

## Read and apply order

1. Read `SUMMARY.md` for the outcome and acceptance matrix.
2. Read `DESIGN/source-audit.md` for the concrete regression and snapshot assumptions.
3. Read `DESIGN/query-discovery-kernel.md` for architecture and rejected alternatives.
4. Apply the patch series in lexical order:
   1. `PATCHES/0001-feat-query-declare-executable-discovery-contracts.patch`
   2. `PATCHES/0002-fix-mcp-generate-executable-query-discovery.patch`
   3. `PATCHES/0003-test-query-enforce-discovery-and-cookbook-parity.patch`
5. Run `TESTS/verify_snapshot.py` and then the project’s focused/full test suite in a complete checkout.
6. Read `TESTS/verification-results.txt` and `VERIFICATION-LIMITS.md` before merge.

## Base and dirty-state assumptions

The supplied immutable source snapshot records:

- Upstream base: `518ac33e318995539743e220c01b9883b7a688a0`
- Branch: `feature/browser/sol-pro-dispatch`
- Pre-existing upstream status: staged modification to `.beads/issues.jsonl`

The patches do not touch `.beads/issues.jsonl`. They were produced from a byte-for-byte synthetic Git baseline of the supplied selected snapshot and then applied cleanly, in order, to a second fresh copy of that snapshot. The resulting source tree exactly matched the implementation tree.

Because the recorded upstream branch has a dirty index, the safest operator workflow is a clean review worktree. Do not reset or overwrite the existing Beads change:

```bash
git worktree add ../polylogue-z9gh3-review 518ac33e318995539743e220c01b9883b7a688a0
cd ../polylogue-z9gh3-review
git am /path/to/handoff/PATCHES/0001-*.patch \
       /path/to/handoff/PATCHES/0002-*.patch \
       /path/to/handoff/PATCHES/0003-*.patch
```

If later branch commits have changed any of the 17 touched paths, use `git am --3way`, inspect every conflict against the declarations in `polylogue/archive/query/metadata.py`, and preserve the canonical-parser lowering invariant.

## Fast verification

From the extracted handoff root:

```bash
PYTHONDONTWRITEBYTECODE=1 \
  python TESTS/verify_snapshot.py /path/to/polylogue-z9gh3-review
```

The verifier uses the real `metadata.py`, `expression.py`, and Pydantic structured-plan models. The supplied snapshot omits most substrate modules, so the verifier installs narrow in-memory stubs only for those missing imports and performs AST parity checks for runtime row models and executors.

In a complete Polylogue checkout, run the focused tests added or changed by patch 3:

```bash
PYTHONPATH=. pytest -q \
  tests/unit/core/test_query_discovery_registry.py \
  tests/unit/core/test_query_result_semantics.py \
  tests/unit/mcp/test_query_capability_resource.py \
  tests/unit/mcp/test_query_recipe_parity.py \
  tests/unit/mcp/test_query_tool_schema_derivation.py
```

Then run the repository’s normal formatting, type, topology, and full-suite gates. No new module was added under `polylogue/`, so this slice does not create a topology-projection obligation by itself.

## Patch contents

Patch 1 adds the declarations, canonical structured-plan lowering, compact result exactness/continuation contract, completion recipe kind, and generated recovery payload. Patch 2 wires those declarations into MCP tools, prompts, resources, and public documentation. Patch 3 adds mutation-sensitive registry, parser, schema, prompt, skill-fixture, resource, and result-semantics parity tests.

The series changes 17 source/test/doc files: 2,992 insertions and 107 deletions.
