# Verification limits

## What was run

- Read the supplied repository instructions, selected Beads record (including all later correction notes), scope, recorded Git base/branch/status, relevant query/parser/runtime/MCP/docs files, and existing tests.
- Built a byte-identical synthetic Git baseline from the selected snapshot solely to emit ordered mail patches.
- Applied all three patches with `git am` to a second fresh snapshot copy.
- Confirmed the patched copy and implementation tree are byte-identical after excluding `.git` and disposable Python/pytest caches.
- Ran `git diff --check` across the series and `git fsck --no-dangling`.
- Compiled every changed Python source with Python’s built-in compiler.
- Imported the real query declarations, predicate/DSL parser, and Pydantic structured-plan models under narrow stubs for only the missing snapshot dependencies.
- Compiled every registry recipe expression, terminal example, and corrected installed-skill fixture expression through the canonical parser.
- Confirmed both exact historical sessions-only skill expressions remain rejected.
- Checked structured-plan canonical lowering, closed schema enums, and exactly-one-input validation.
- Checked catalog common fields, unique IDs, all six coverage states, exact search/continuation, and serialized page size under the MCP response budget with 15 normalized origins.
- Checked all nine compact projections against runtime payload class fields by AST.
- Checked declared terminal actions against runtime executor-map keys by AST.
- Checked generated prompt calls, public tool/resource/docs wiring, result-envelope fields, and mutation-sensitive tests.

## What could not be run in the supplied environment

The selected snapshot is not a complete Polylogue checkout. It omits `polylogue.core`, archive/storage implementations, many model modules, package metadata, and the external `mcp` dependency. Consequently, focused pytest collection stops before assertions with missing-module errors. This boundary is recorded verbatim in `TESTS/verification-results.txt`.

The environment also lacks `ruff`, `black`, and `mypy`, so project formatting, lint, and static type gates were not run.

No live browser, daemon, MCP server, archive database, secrets, deployment configuration, or NixOS system was available. No claim is made about live latency, real archive coverage counts, client resource navigation, transport fallback behavior, or production deployment.

The external installed shared-skill file is not included in the snapshot. Its two exact formerly shipped templates are preserved as an immutable regression fixture, but the deployment copy itself was not patched or inspected after installation.

## Intentional scope boundary

This handoff does not implement the generic bounded/resumable query transaction, queue, streaming transport, spool, progress persistence, or job lifecycle. Those belong to the separate worker named in the mission. This series provides declarations and replayable canonical plans/result semantics that such an executor can consume.

## Residual integration checks

Before merge, an operator with a complete checkout should run the focused tests, full project gates, and the live-route sequence in `TESTS/verification-plan.md`. Particular attention should go to:

- actual FastMCP resource template registration and schema rendering;
- archive-backed `query_units` page/aggregate envelopes;
- complete `Origin` inventory and catalog page-size budget in the full tree;
- deployment parity for the shared installed skill;
- merge conflicts if query metadata, prompts, resources, or payload envelopes changed after base revision `518ac33e…`.
