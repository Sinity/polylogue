# Executive result

The patch series repairs Polylogue’s self-contradictory agent curriculum and establishes the smallest extensible declare-once query-discovery kernel.

Before this change, `query_units` correctly rejected a bare session selector because it had no terminal row source, while two shipped cookbook prompts and the installed skill explicitly taught that rejected form. Cold agents saw neither valid terminal forms nor recovery examples. Discovery also lacked a bounded inventory of normalized facts, authority, coverage, projection, plan/cost, stable ordering, and result completeness.

After this change:

- The existing `QueryUnitDescriptor` registry owns executable terminal units and their public discovery contract.
- All nine terminal units declare fields, authority, applicable origins/artifacts, coverage/freshness source, compact projection, pushdown/cardinality/cost, stable order, examples, result semantics, and recovery.
- Operations, six result-semantics classes, recipes, and known capability gaps are executable declarations beside the unit registry.
- A read-only, searchable, exact, paged capability-and-coverage resource is exposed at `polylogue://capabilities/query` and its continuation/search URI.
- `query_units` accepts exactly one canonical DSL expression or typed structured plan. Structured plans lower through the same parser and AST as DSL calls.
- Invalid/nonterminal expressions receive generated valid forms, all terminal sources, executable examples, a structured-plan example, completion guidance, and catalog navigation.
- All six shipped MCP cookbook prompts are generated from the recipe declarations. The two invalid expressions are replaced with terminal `actions` and `files` forms.
- Row and aggregate envelopes distinguish page count from global totals and state exactness, completeness, continuation requirements, and `next_offset`.
- Large valid queries remain semantically valid. Discovery teaches paging now and stream/queue/spool execution when the generic transaction worker is available; cost is not converted into “unsupported.”
- Mutation-sensitive tests compile every declared recipe, every terminal example, the installed-skill fixture, and all six generated prompts through the canonical parser/schema path.

## Concrete corrected expressions

The rejected failure recipe:

```text
sessions where repo:{repo_name} since:{since} AND exists action(output:failed)
```

is replaced by:

```text
actions where session.repo:{repo_name} AND session.since:{since} AND (is_error:true OR output:failed)
```

The rejected file recipe:

```text
sessions where repo:{repo_name} AND exists file(action:file_edit AND path:{path})
```

is replaced by:

```text
files where session.repo:{repo_name} AND action:file_edit AND path:{path}
```

## Acceptance-criteria matrix

| Criterion | Result | Evidence in handoff |
| --- | --- | --- |
| Product prompts cannot teach parser-invalid terminal forms | Delivered | Six prompts render from `QUERY_RECIPE_DESCRIPTORS`; exact legacy forms are negative fixtures and parser-rejection assertions. |
| Executable unit/field/operation declarations are the source of truth | Delivered | Patch 1 extends the existing registry and adds parity against payload models, parser aliases, executor actions, and structured-stage schema. |
| Bounded, searchable capability and coverage discovery | Delivered | Exact catalog pages are capped at 7 records, expose continuation URIs, represent six coverage states, and remain below the 25,000-byte MCP budget in the 15-origin stress verifier. |
| Generated MCP descriptions, schema guidance, examples, and recovery | Delivered | Tool/schema descriptions, valid forms, terminal sources, structured-plan example, completion call, catalog URI, and errors come from declarations. |
| Valid DSL and typed structured plan share one executable path | Delivered | `MCPQueryUnitPlan.to_expression()` lowers to canonical DSL and validates with `parse_unit_source_expression`; parity tests compare the same pipeline and row envelope. |
| Compact projections are declared once and match runtime payloads | Delivered | Nine `compact_projection` declarations are checked exactly against nine runtime row payload model fields. |
| Results state exactness, totals, omissions, and continuation | Delivered | Six result classes plus additive row/aggregate envelope fields; tests pin page-count semantics and returned-row-based `next_offset`. |
| Large-query cost remains planner input, not a semantic rejection | Delivered at discovery layer | Registry records cost/cardinality/selectivity and teaches page/stream/queue/spool. The generic resumable transaction/executor is intentionally left to the separate worker. |
| Installed-skill expressions are parity checked | Delivered as immutable regression fixture | The supplied snapshot does not include the external installed shared-skill file, so the fixture captures its two exact templates and generated replacements. Deployment of that external skill remains an operator integration step. |
| Current archive coverage is honest | Delivered within available stats | Message/origin counts use bounded `archive.stats`; undeclared per-unit counts remain `unknown`, never silently “absent.” Dedicated future count providers can populate them. |
| CLI help/OpenAPI/JSON schema are generated from the registry | Kernel-ready, not wired in this slice | The selected snapshot contains MCP and query modules but not the complete CLI/OpenAPI renderer integration. No parallel static definitions were added; future surfaces can consume the same declarations. |
| Full live archive, daemon, browser, NixOS, and transport execution | Not run in supplied environment | Exact limits are recorded in `VERIFICATION-LIMITS.md`. |

## Patch series

1. `0001` — declarations, structured plans, exactness/continuation envelopes, generated recovery and completions.
2. `0002` — generated MCP prompts/tool descriptions, catalog resources, and public docs.
3. `0003` — parser/schema/prompt/skill/resource/projection/executor/result mutation tests.

Overall diff: 17 files changed, 2,992 insertions, 107 deletions.
