# Evidence boundaries and rejected alternatives

## Source-supported facts

The immutable packet includes the complete selected `polylogue-1xc.13` record. It states that the incident involved a growing Codex JSONL, five failures, cursor exclusion, later unparsed revisions, a stale index, and an excluded cursor mislabeled idle. It also reports archive-level populations: 3,821 excluded cursors, 1,890 broken active heads, 40 cursor-ahead rows, and 34 authority rows that were not comparable. Those totals motivate the work but do not establish the state of any named path.

The supplied source selection supports these relevant observations:

- the cursor relation carries source path, observed/stat size, byte offset, failure count, retry time, exclusion, and update time;
- ingest attempts carry source-path and error evidence;
- existing readiness logic excludes raw rows marked `skipped` from its accepted raw census;
- persisted `revision_authority` and raw revision application decisions are separate evidence domains;
- FTS trust depends on both a recorded invariant and maintenance triggers;
- convergence debt uses stage and target identifiers, with source-path and session-ID namespaces;
- the existing cursor-lag projection had an exclusion branch that incremented idle.

## Explicit inferences

The implementation labels rather than hides these conclusions:

- no exact source/session insight debt is treated as converged because the supplied schema exposes no positive per-source insight-completion row;
- accepted raw absent from the index while an older bounded source raw remains indexed is a broken head;
- current filesystem size minus cursor offset is pending-byte evidence;
- current filesystem size minus cursor-observed size is growth the cursor has not observed;
- cursor offset or observed size beyond the current file is inconsistent and degraded;
- missing filesystem bytes with persisted cursor/raw evidence are degraded, not unseen.

A bounded raw scope can establish a positive broken head but cannot prove the absence of every older indexed revision. `source_raw_scope_truncated` carries that uncertainty.

## Rejected alternatives

### Archive totals or a larger sample

Rejected because both can look healthy while omitting the incident source. The route starts with exact equality on the named path and follows only bounded identifiers. It does not report archive population totals.

### Prefix, substring, basename, or implicit source discovery

Rejected because alias matching can select the wrong export and a source-root walk violates the live-safe receipt requirement. The caller must name the stored path. Alias resolution, when needed, belongs in a separate explicit owner route.

### Coupling operational health to pipeline stage

Rejected because quiet and searchable are compatible, while excluded and acquired-unparsed are different dimensions. Separate axes prevent `idle` from implying completeness and prevent `searchable` from concealing missing source bytes.

### Treating excluded as idle because it is outside the lag SLO

Rejected. Excluded remains outside the existing stuck-cursor SLO, but it receives a separate degraded count, maximum age, and bounded evidence sample. SLO membership and operational health are not the same question.

### Reusing only the bounded recent raw sample as the accepted head

Rejected because many newer `skipped` rows can fill the window and hide the governing older non-skipped acquisition. A separate exact-source accepted-head query is still bounded to one row.

### Adding diagnostic columns or a new durable migration

Rejected for this scope. Retry detail already exists in owner attempt/cursor evidence, and a diagnostic-only durable schema change would create unnecessary migration and deployment work. The projection reads existing tiers conservatively.

### Deriving raw authority locally

Rejected because authority semantics belong to `polylogue-lkrc`. Hashes, source index, parse success, and index presence are evidence, not authority decisions.

### Making a replay/adoption decision

Rejected because replay prevention belongs to `polylogue-yla8`. Application ledger rows are reported without changing or reclassifying them.

### Treating absent evidence as successful convergence

Rejected for index and FTS. Missing tables, unsafe plans, bounds exceeded, read errors, missing trusted FTS state, or missing triggers leave the checkpoint unavailable or unconverged. The only negative-evidence inference is insight debt, and the payload says so explicitly.

### Scanning a whole table through an index

Rejected. `SCAN table USING INDEX ...` can still traverse the entire relation. The guard rejects ordinary-table scans whether or not SQLite names an index. Only the fixed constrained FTS virtual-table rowid lookup is exempt.

### Unbounded exact rows

Rejected because equality alone does not bound row or value size. Every data query has a row limit and one sentinel, SQLite values are capped, and VM steps are budgeted. A single oversized exact row fails conservatively.

### Whole cursor export or whole attempt log reads

Rejected. Cursor export uses a hard one-shot `limit + 1` byte read. Attempt JSONL is searched only in a bounded tail. Growth cannot bypass the export limit through a stat/read race.

### Caller-selected MCP fallback files

Rejected because it would turn a diagnostics tool into an arbitrary bounded local-file reader. MCP callers supply only `source_path`; cursor export and attempt-log paths are fixed by server configuration when the handler is constructed.

### Fabricating canonical CLI/MCP/status edits

Rejected because those owning files were not in the scoped packet. The handoff provides tested leaf adapters and an owner-wiring map. The complete checkout must make the final integration and generated-contract changes against its actual current owners.

## Conservative failure behavior

An unsafe plan, SQLite error, stat failure, missing trusted checkpoint, or exceeded bound remains visible. Strict execution returns nonzero rather than replacing missing exact evidence with an archive-wide approximation. This is intentional: a partial conservative receipt is more trustworthy than a fast but falsely complete status.
