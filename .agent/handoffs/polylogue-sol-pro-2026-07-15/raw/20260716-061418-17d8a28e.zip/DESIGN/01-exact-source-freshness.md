# Exact-source freshness design

## Incident-shaped objective

The selected Beads record describes a growing Codex JSONL whose cursor was excluded after five failures. Later raw revisions remained unparsed, an older revision remained indexed, and aggregate totals plus a bounded sample hid the named file. The existing cursor projection treated excluded as idle. The read model therefore starts from one exact source key, keeps health separate from pipeline progress, and preserves bounded evidence at every checkpoint. Archive totals are intentionally absent.

## Two independent axes

| Pipeline stage | Exact condition |
| --- | --- |
| `unseen` | No latest non-skipped raw acquisition can be read safely for the exact source. |
| `acquired-unparsed` | An accepted acquisition exists, but it has no successful parse timestamp or has a parse error. |
| `parsed-unindexed` | The accepted acquisition parsed, but no indexed session points at its raw ID. |
| `indexed-unconverged` | The accepted raw has indexed sessions, but FTS or insight evidence is not converged. |
| `searchable` | The accepted raw is indexed, all bounded exact-source searchable blocks are present in FTS, the global FTS record is trusted, maintenance triggers exist, and no exact source/session insight debt is recorded. |

Operational state is independently classified as `unseen`, `active`, `idle`, or `degraded`. The reason is one of:

```text
source-stat-error
source-missing
cursor-excluded
cursor-retrying
cursor-ahead
broken-head
pending-bytes
caught-up
cursor-missing
no-evidence
```

The evaluation order is deliberate:

1. cursor exclusion;
2. cursor failure/retry state;
3. source stat failure;
4. missing source bytes when cursor or raw evidence persists;
5. cursor offset or cursor-observed size ahead of the current filesystem size;
6. accepted raw head missing while an older bounded source revision remains indexed;
7. actual pending bytes;
8. caught-up cursor;
9. source or raw evidence without a cursor;
10. no evidence.

This prevents exclusion, retry, stat failure, missing bytes, impossible cursor position, or stale accepted head from falling through to idle. A genuinely quiet source remains `idle`, independently of whether it is `searchable`.

## Evidence path

| Checkpoint | Source | Exact key and bound | Evidence |
| --- | --- | --- | --- |
| Filesystem | Explicit source path | One `stat(2)` | existence, current size, mtime, device, inode, error |
| Cursor | `ops.db.ingest_cursor`, legacy `index.db.live_cursor`, optional bounded export | `source_path = ?`, `LIMIT 1` | observed size, offset, current pending bytes, unobserved growth, ahead bytes, failures, exclusion, retry time, age |
| Retry/exclusion | `ops.db.ingest_attempts`, optional JSONL tail | exact source key and bounded rows, or 64 KiB tail by default | current reason, attempt ID/status/phase/time |
| Raw acquisition | `source.db.raw_sessions` | exact source key, bounded recent window, separate exact accepted-head query | raw ID, origin/native ID, source index, blob hash, validation, parse fields, observed time, persisted authority |
| Replay/application | `index.db.raw_revision_applications` | accepted `raw_id = ?`, bounded rows | owner-persisted decision/detail/time |
| Index | `index.db.sessions` | accepted raw ID and bounded source raw IDs | accepted materialization, session IDs, source high-water, truncation, broken head |
| FTS | `messages`, `blocks`, `messages_fts`, `fts_freshness_state`, trigger metadata | bounded accepted session/message/block IDs | exact row coverage, trusted global ledger, trigger presence |
| Insights | `ops.db.convergence_debt` | exact `(target_type, target_id, stage)` for the source and accepted sessions | debt state/errors/truncation, or labeled no-debt inference |

## Accepted head and broken head

The recent raw display window and governing accepted acquisition are intentionally separate queries. The accepted query selects the latest exact-source row not marked `skipped`, matching the existing raw readiness census. A bounded display window full of newer skipped rows therefore cannot hide an older non-skipped head.

`accepted_by_acquisition` means only “selected by that non-skipped acquisition rule.” It does not reinterpret `revision_authority` and does not decide replay eligibility.

The index reader first looks up sessions for the accepted raw ID. It then looks up sessions for the accepted ID plus the bounded recent source raw IDs. If the accepted head has no indexed session while an older bounded source revision does, `broken_head=true`. `source_raw_scope_truncated=true` records that still-older revisions were outside the bounded scope; a negative broken-head result in that case is not proof of absence.

Timestamp-less `sessions` schemas remain observable: the reader orders by a named alias rather than an invalid positional `ORDER BY 0`, reports exact session IDs, and leaves `high_water_ms` unavailable.

## Cursor and retry semantics

Current pending bytes are `max(current_file_size - cursor_offset, 0)`. Unobserved growth is `max(current_file_size - cursor_observed_size, 0)`. Cursor-ahead evidence is reported separately for both offset and observed size.

Append-only attempt history is consulted only while the cursor is excluded, failing, retry-scheduled, or otherwise not healthy. A current cursor with zero failures, no exclusion, and no retry deadline suppresses stale historical errors. If no current attempt record is available, exclusion/failure state itself supplies a bounded fallback reason.

## Query and file safety

Each tier opens independently through a read-only SQLite URI with `PRAGMA query_only=ON` and a short busy timeout. There is no attached cross-tier query. Each protected data query is constrained by exact source/raw/session/message/block identifiers and a positive row bound plus one truncation sentinel.

Before a protected query executes, `EXPLAIN QUERY PLAN` is inspected. Any full traversal of a protected ordinary table or index is rejected, including `SCAN table USING INDEX ...`. The single fixed FTS virtual-table lookup is allowed only because SQLite reports its constrained rowid lookup as `VIRTUAL TABLE INDEX`. Rejections are retained in the receipt and make strict CLI/receipt execution fail.

Default hard limits include 250,000 SQLite VM steps per query, 64 KiB maximum SQLite string/blob value, 64 KiB attempt-log tail, 2 MiB cursor export, and bounded raw/session/message/block/debt/application rows. Cursor export uses a single hard `limit + 1` read, avoiding a stat/read race. The attempt log is read only from its tail. No source-root walk, wildcard source query, archive count, population `GROUP BY`, or whole-log read exists in this route.

## Receipt

The receipt records:

- `read_only=true`, `exact_source=true`, and `archive_wide_aggregates=false`;
- query count and configured VM/value/row bounds;
- every protected query plan and safety decision;
- every rejected scan;
- fallback bytes and lines examined;
- projection errors;
- a SHA-256 over canonical JSON excluding only the hash field itself.

The payload hash makes two receipts directly comparable while leaving the original typed evidence available for review.

## Authority and convergence boundaries

`revision_authority` is displayed exactly as persisted and attributed to `polylogue-lkrc`. The projection does not infer authority from hash, source index, parse state, or index state.

`raw_revision_applications` is displayed as owner evidence and attributed to `polylogue-yla8`. The projection does not decide whether a revision is replayable, selected, deferred, superseded, ambiguous, or terminal.

The supplied convergence ledger records negative debt rather than a positive exact-source completion receipt. `no-recorded-debt` is therefore explicitly labeled as an inference. Searchable requires that inference together with accepted-head indexing and trusted exact-source FTS coverage. A future positive completion ledger can replace the inference without changing the five-stage contract.
