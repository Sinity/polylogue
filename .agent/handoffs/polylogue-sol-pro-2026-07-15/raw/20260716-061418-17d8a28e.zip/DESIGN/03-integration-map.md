# Complete-checkout integration map

The scoped patch contains the semantic read model and leaf adapters. The full repository owners below were not supplied, so this document identifies the exact integration work rather than inventing paths or generated output.

## Substrate

`polylogue/archive/query/source_freshness.py` owns all exact-source semantics. Surfaces should call `project_named_source_freshness(...)` and must not reproduce its SQL, classification order, authority labels, or bounds.

Inputs are:

```python
project_named_source_freshness(
    archive_root: Path,
    source_path: Path,
    *,
    now: datetime | None = None,
    cursor_export: Path | None = None,
    attempt_log: Path | None = None,
    limits: ProjectionLimits | None = None,
) -> NamedSourceFreshness
```

The archive root is read-only. Optional fallback files are operator/server configuration, not discovered automatically. No source-root walk occurs.

## Query-first CLI

The direct argparse adapter exists for receipts and isolated verification. The canonical Click tree should expose the same operation through its query-first vocabulary rather than adding an unrelated root command. The exact command spelling must be selected against the complete checkout’s current grammar and generated help.

The owner route should:

1. require an explicit source-path selector;
2. resolve the active archive root through existing configuration;
3. call the substrate exactly once;
4. use `source_freshness_status_payload`, `render_source_freshness_status`, or the full `to_dict()` output;
5. return nonzero when the projection has read errors/rejected scans, and optionally when degraded/not searchable;
6. keep cursor-export and attempt-log fallbacks operator-only;
7. update generated CLI reference/help and run its focused contract tests.

Do not insert an implicit loop over every cursor or raw row into general CLI status.

## MCP

Construct the handler with server-owned configuration:

```python
handler = make_source_freshness_mcp_handler(
    archive_root_provider,
    cursor_export=configured_cursor_export_or_none,
    attempt_log=configured_attempt_log_or_none,
    limits=configured_limits_or_none,
)
register_source_freshness_mcp_tool(server, handler)
```

The proposed tool name is `named_source_freshness`. Its only caller-supplied argument is `source_path: str`. The result is the complete typed JSON projection.

The owning MCP integration must update:

- the canonical server registration module;
- declared/generated tool contracts;
- `tests/infra/mcp.py::EXPECTED_TOOL_NAMES` or its current equivalent;
- discovery, authorization, and payload-contract tests;
- generated MCP reference documentation where applicable.

Do not expose arbitrary `cursor_export` or `attempt_log` arguments to MCP callers.

## Status and health

The existing aggregate cursor projection receives additive fields:

- `degraded_file_count`;
- `max_degraded_lag_s`;
- bounded `degraded` items with `classification`, `degradation_reason`, and `excluded`.

This makes excluded and cursor-ahead populations visible without placing them in the existing stuck-cursor SLO. It is not a substitute for exact-source evidence.

For a status request that already names a source, append `source_freshness_status_payload(projection)`. The compact record includes current file stat, cursor observed/offset bytes, operational state and reason, exclusion/failure, pending/growth/ahead bytes, accepted raw and authority, parse/index/high-water, broken head, FTS/insight convergence, scan/error counts, owner labels, and the projection hash.

Do not make general readiness status enumerate the archive to create one record per source.

## Named query misses

When a query miss already carries an explicit source path:

1. obtain the exact projection;
2. call `diagnose_named_source_miss(projection)`;
3. append or return its shared `QueryMissDiagnostics` envelope.

The codes are:

```text
named_source_unseen
named_source_acquired_unparsed
named_source_parsed_unindexed
named_source_indexed_unconverged
named_source_searchable
```

The named envelope intentionally leaves generic `archive_session_count` and `raw_session_count` unset. Source-specific values are labeled as lower bounds or sample counts in detail. `named_source_searchable` says the miss is downstream of source freshness; it does not claim the session should match unrelated filters.

Do not invoke this route for a general search that has no named source.

## Generated topology and references

The patch adds:

```text
polylogue/archive/query/source_freshness.py
polylogue/archive/query/source_freshness_surfaces.py
```

Repository instructions require, in the complete checkout:

```bash
devtools render topology-projection
devtools render topology-status
devtools render all --check
```

Commit the resulting topology projection/status changes together with canonical owner wiring. Also regenerate CLI/MCP references if their owners require it.

## Focused owner verification

Run the exact tests first:

```bash
devtools test tests/unit/archive/test_source_freshness.py
devtools test tests/unit/archive/test_query_miss_diagnostics.py -k named_source
devtools test tests/unit/daemon/test_cursor_lag_status.py -k 'excluded or cursor_ahead'
```

After MCP registration, run the focused inventory/discovery/authorization test that owns the expected tool list. Then run:

```bash
devtools verify --quick
```

Do not substitute a broad directory run for these owner checks.

## Deployment and receipt sequence

1. Apply and review the four patches.
2. Wire canonical CLI/MCP/status/miss owners in the complete checkout.
3. Regenerate topology and declared surface contracts.
4. Run focused tests and `devtools verify --quick`.
5. Capture a live receipt for the excluded incident path.
6. Capture a live receipt for a known healthy quiet path.
7. Confirm the excluded receipt is `degraded`, not idle, with retained reason and byte evidence.
8. Confirm the healthy receipt is `idle` and `searchable`, with zero pending/growth/ahead bytes and no scan/error evidence.
9. Preserve both receipts before any reset, replay, exclusion clearing, or index rebuild.
10. Perform remediation only under the existing `polylogue-lkrc` authority and `polylogue-yla8` replay owners.

A live receipt containing `errors`, `unsafe_scan_rejections`, a truncated governing scope, or an unavailable production-schema checkpoint is incomplete evidence. Investigate that exact limitation rather than replacing it with an archive total.
