# Typed payload contract

## Full projection

`NamedSourceFreshness` is a frozen, slot-backed dataclass. Its JSON form is produced by `to_dict()` and contains:

| Field | Type / meaning |
| --- | --- |
| `source_path` | Exact lookup key used for filesystem and archive evidence |
| `observed_at` | UTC projection timestamp |
| `stage` | Five-state pipeline stage enum |
| `operational_state` | `unseen`, `active`, `idle`, or `degraded` |
| `operational_reason` | Typed reason for the operational classification |
| `source_stat` | existence, size, mtime, device, inode, and stat error |
| `cursor` | presence/state/source, observed size, offset, pending/growth/ahead bytes, failures, exclusion, retry/update/age |
| `retry` | reason and evidence source, attempt ID/status/phase/time |
| `accepted_raw_revision` | governing latest non-skipped raw row, or null |
| `raw_revisions` | bounded recent raw sample |
| `raw_revisions_truncated` | recent raw sample exceeded bound |
| `parse` | `unseen`, `pending`, `failed`, or `parsed` for the accepted raw |
| `revision_applications` | bounded persisted replay/application evidence |
| `revision_applications_truncated` | application evidence exceeded bound |
| `index` | accepted/source session IDs, lower bound, high-water, truncation, broken head |
| `fts` | availability, exact coverage, global state, triggers, truncation, reason |
| `insights` | availability, debt/no-debt inference, lower bound, stages/errors, truncation |
| `ownership` | authority owner `polylogue-lkrc`, replay owner `polylogue-yla8`, read-only observer role |
| `receipt` | read/query bounds, protected plans, rejected scans, fallback byte counts |
| `errors` | conservative read/stat/schema/budget failures |
| `projection_sha256` | canonical payload hash excluding only itself |

All child evidence records are frozen dataclasses. All limits must be positive integers; booleans are rejected as limits.

## Stage contract

```text
unseen
acquired-unparsed
parsed-unindexed
indexed-unconverged
searchable
```

The progression is based on the accepted raw head, not the newest row in the bounded display sample. FTS and insights must both converge for `searchable`.

## Operational contract

```text
state       reason
----------  -------------------
degraded    cursor-excluded
degraded    cursor-retrying
degraded    source-stat-error
degraded    source-missing
degraded    cursor-ahead
degraded    broken-head
active      pending-bytes
idle        caught-up
active      cursor-missing
unseen      no-evidence
```

Reason ordering is authoritative. Exclusion and retry are evaluated before any idle check. Operational state does not override or rewrite pipeline stage.

## Compact status payload

`NamedSourceFreshnessStatusPayload` is a `TypedDict` intended for an already named source in status/health output. It contains:

```text
source_path
stage
operational_state
operational_reason
source_exists
source_size_bytes
source_mtime_ns
source_stat_error
cursor_observed_size_bytes
cursor_byte_offset
excluded
failure_count
pending_bytes
unobserved_growth_bytes
cursor_ahead_bytes
observed_size_ahead_bytes
reason
accepted_raw_id
accepted_by_acquisition
revision_authority
revision_authority_owner
replay_prevention_owner
revision_application_count
parse_state
accepted_raw_indexed
broken_head
source_raw_scope_truncated
index_high_water_ms
fts_converged
insights_converged
unsafe_scan_rejections
projection_error_count
projection_sha256
```

It deliberately omits archive-level totals and unbounded samples. `reason` is the current bounded retry/exclusion reason; `operational_reason` is the typed classifier result.

## Named-miss envelope

`diagnose_named_source_miss` returns the existing shared `QueryMissDiagnostics` model with one typed reason code. It leaves generic archive and raw counts null. Detail includes exact source path, stage, operational state/reason, source existence/stat error, exclusion, pending/ahead bytes, broken head, source-indexed session lower bound, bounded raw sample count, and retained retry reason when available.

## CLI contract

`source_freshness_cli` supports text or full JSON output. Exit codes are:

| Exit | Meaning |
| ---: | --- |
| `0` | Projection completed; and, when `--strict` is set, source is searchable and not degraded |
| `2` | `--strict` requested and the source is degraded or not searchable |
| `3` | Projection contains a read error or rejected protected scan |

The durable receipt utility adds exit `4` for import or receipt-invariant failure and rejects relative source paths or output inside the archive root through argparse exit `2`.

## MCP contract

`make_source_freshness_mcp_handler` returns an async function with exactly one caller argument:

```python
async def named_source_freshness(source_path: str) -> dict[str, object]: ...
```

The handler returns the complete full projection. Archive root, fallback file paths, and limits are fixed at construction. `register_source_freshness_mcp_tool` provides one-line FastMCP-style registration, but the complete checkout retains ownership of inventory, contract, authorization, and generated references.

## Forward compatibility

Optional or unavailable schema evidence remains explicit rather than being synthesized. The reader probes existing columns and supports representative variants, including legacy cursor location, absent high-water timestamp, and legacy insight debt without `target_type`. A schema variant that cannot be queried safely yields unavailable evidence and a nonzero strict receipt, preserving trust over optimistic compatibility.
