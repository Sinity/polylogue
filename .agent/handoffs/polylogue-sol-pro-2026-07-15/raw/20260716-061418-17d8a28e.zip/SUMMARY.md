# Executive result

The four-patch series implements a typed, read-only, bounded freshness projection for one exact Polylogue source path and fixes the incident’s classification-ordering defect.

For the named path, the projection reports current filesystem stat, cursor-observed size and byte offset, pending bytes against the current file, growth the cursor has not observed, cursor-ahead inconsistencies, failure/exclusion state, bounded retry evidence, recent raw revisions, the latest non-skipped accepted acquisition, persisted raw authority, parse state, revision-application evidence, accepted-session materialization, bounded source index high-water, exact FTS row coverage, and exact source/session insight debt. It emits a deterministic payload hash and an execution receipt containing every protected SQLite query plan and every rejected scan.

Pipeline progress and operational health are separate axes. Pipeline stage is one of `unseen`, `acquired-unparsed`, `parsed-unindexed`, `indexed-unconverged`, or `searchable`. Operational state is `unseen`, `active`, `idle`, or `degraded`, with a typed reason. Exclusion is evaluated before failure, stat/missing-source anomalies, cursor-ahead state, broken accepted head, pending bytes, and caught-up idle. A healthy quiet source can therefore be both `idle` and `searchable`, while an excluded source remains degraded regardless of age or apparent cursor catch-up.

Raw authority is reported verbatim and attributed to `polylogue-lkrc`. Revision-application/replay evidence is observed without deciding it and attributed to `polylogue-yla8`. The projection does not reconstruct either owner’s semantics.

## Concrete changes

The ordered patch series contains four review commits:

1. `fix(daemon): classify invalid cursors as degraded` — adds bounded degraded counts and samples to the existing cursor-lag projection. Excluded and cursor-ahead rows retain age, offsets, observed size, failures, and explicit reasons while remaining outside the existing stuck-cursor SLO.
2. `feat(archive): add bounded named-source freshness projection` — adds frozen dataclass/enum payloads; exact stat/cursor/retry/raw/parse/application/index/FTS/insight reads; positive hard limits; read-only SQLite mode; VM and value-size budgets; query-plan rejection; bounded file fallbacks; accepted-head and broken-head evidence; and a canonical receipt hash.
3. `feat(archive): expose freshness diagnostics to leaf surfaces` — adds the five named-miss codes, a compact status `TypedDict`, operator text rendering, a direct CLI adapter, an async MCP handler, and a FastMCP-style registration adapter. MCP callers can supply only the source path; fallback files are server-owned configuration.
4. `test(archive): cover degraded and converged source paths` — adds excluded-growing and healthy-quiet fixtures plus 27 real SQLite/FTS tests covering the five stages, operational reasons, safe query behavior, schema variants, fallbacks, serialization, status, CLI, and MCP adapters.

The exact-source reader never performs an archive total, source-root walk, wildcard source query, or unconstrained protected data-table traversal. It opens each tier independently with `mode=ro` and `query_only`, follows only the named path and bounded raw/session/message/block IDs, and rejects a protected query plan that would traverse the full table or index. Content values are capped at 64 KiB by default, data reads use a one-row truncation sentinel, each query has a 250,000-step default VM budget, cursor exports use a hard `limit + 1` read, and attempt evidence comes from a bounded tail.

## Acceptance-criteria matrix

| Acceptance criterion | Result | Evidence and boundary |
| --- | --- | --- |
| Growing excluded fixture reports exclusion, byte lag/growth, retained reason, and never idle | Implemented and scoped-verified | `excluded-growing.json` plus route tests assert `degraded`, reason `cursor-excluded`, five failures, 2,048 pending bytes, 2,048 unobserved-growth bytes, the retained decoder failure, a newer accepted unparsed head, an older indexed high-water, and `broken_head=true`. |
| Healthy quiet source reports every acquisition-to-searchable checkpoint | Implemented and scoped-verified | `healthy-quiet.json` asserts caught-up cursor, no stale attempt reason, accepted raw and persisted authority, parse success, `yla8` application evidence, index high-water, exact FTS row/trigger convergence, no exact insight debt, `idle`, and `searchable`. |
| Excluded classifies degraded before idle | Implemented in exact and aggregate routes | Exact operational ordering begins with exclusion. Aggregate `_project_rows` places excluded rows in a separate degraded count/sample before idle and retains `degradation_reason="excluded"`. |
| Cursor-ahead and broken-head states are visible before reset | Implemented for exact source; cursor-ahead also aggregate | Cursor-ahead exposes both offset-ahead and observed-size-ahead bytes. A newer accepted raw absent from the index while an older bounded source revision remains indexed yields `broken_head=true` and operational reason `broken-head`. Truncated raw scope remains explicitly uncertain. |
| Named misses distinguish all five required states | Implemented and portable-check verified | `diagnose_named_source_miss` emits `named_source_unseen`, `named_source_acquired_unparsed`, `named_source_parsed_unindexed`, `named_source_indexed_unconverged`, or `named_source_searchable`. Generic archive totals remain unset. |
| Exact-source execution avoids archive-wide scans | Implemented and scoped-verified | Equality/ID-constrained queries, row sentinels, VM/value limits, and `EXPLAIN QUERY PLAN` guard. Tests reject unindexed `raw_sessions`, unindexed FTS ledger, and full index traversal while accepting the constrained FTS virtual-table lookup. |
| Typed payloads and CLI/MCP/status integration are useful | Implemented as substrate plus leaf adapters | Frozen typed full payload, compact status `TypedDict`, text/JSON CLI, async MCP handler, and registration adapter are exercised. Canonical owner registration remains a complete-checkout task because its files were not supplied. |
| Raw authority remains owned by lkrc; replay prevention remains owned by yla8 | Preserved | Authority and application decisions are reported verbatim with explicit owners. No new authority or replay decision is derived or persisted. |
| Focused tests and quick gate pass | Scoped portion passed; quick gate unavailable | Fresh replay: 27 tests, compilation, two portable checks, four patch checks, clean diff, and nine byte-equivalent changed files. `devtools verify --quick`, Ruff, mypy, and generated topology checks require the complete checkout. |
| Live excluded and healthy receipts exist | Live-safe procedure delivered; synthetic exercise passed; live execution not claimed | `TESTS/live-safe-receipt.py` was exercised against healthy, excluded-growing, cursor-ahead, and invalid-relative-path cases. No operator archive, daemon, or secrets were available. Live receipts must be captured before remediation. |

## Key design decisions

A named-source receipt cannot infer completeness from archive-level counts. The route begins with exact equality on the supplied source path and follows only bounded identifiers. The accepted raw head is queried separately from the recent display window so a burst of newer `skipped` rows cannot hide the governing non-skipped acquisition. A positive broken head is observable within the bounded raw scope; an absent broken head with `source_raw_scope_truncated=true` is not treated as proof that no older indexed revision exists.

A healthy current cursor suppresses historical append-only attempt errors. Missing source bytes with persisted cursor or raw evidence are degraded rather than unseen. Stat failures are explicit degraded evidence. Cursor offset or observed size beyond the current file is degraded rather than caught-up. Insight convergence without recorded debt is labeled as an inference because the supplied owner schema has no positive per-source completion ledger.

## Residual integration work

Apply the series in the complete checkout, wire the leaf adapters into the canonical query-first CLI, MCP inventory/contract, and named-source status/miss owners, regenerate topology projection/status, run focused owner tests and `devtools verify --quick`, then capture the two live receipts. No production reset, replay, exclusion clearing, or index rebuild should precede those receipts.
