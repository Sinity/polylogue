# Polylogue named-source freshness handoff

This package is the durable review handoff for `polylogue-1xc.13`, “Expose named-source freshness and excluded cursor degradation.” It makes one explicitly named source path observable from filesystem bytes through cursor state, retry or exclusion evidence, raw acquisition and authority, parsing, index materialization, FTS, and insight convergence. It also fixes the aggregate cursor projection so an excluded or impossible cursor-ahead row is degraded before it can be counted as idle.

## Base and worktree assumptions

The supplied immutable context packet identifies Polylogue base revision `518ac33e318995539743e220c01b9883b7a688a0` on branch `feature/browser/sol-pro-dispatch`. Its SHA-256 is `da23130588a9fa0021f52e5f0a41d2edf3d9433f36ddb633e1348ce3683c2932`. The packet contains a scoped 93-file repository selection rather than the complete checkout.

The packet records one pre-existing dirty path, `.beads/issues.jsonl`. The patch series does not touch it. Do not reset, replace, or stage that operator-owned change while applying this handoff. A synthetic scoped Git base, `bd1ef985b0e7bf6e89f39f8dffa6881349172d35`, was used only to produce and independently replay the patches; it is not a Polylogue project revision.

Two new modules are added below `polylogue/`. Repository instructions therefore require topology projection/status regeneration in the complete checkout. Canonical Click, MCP inventory, aggregate named-source status, generated topology files, and several full-suite dependencies were absent from the packet. The series provides tested substrate logic and leaf adapters, plus an exact owner-wiring map, without fabricating edits to missing owners.

## Read and apply order

1. Read `SUMMARY.md` for the result and acceptance-criteria matrix.
2. Read `DESIGN/01-exact-source-freshness.md` for the state model and safety invariants.
3. Read `DESIGN/02-evidence-and-rejected-alternatives.md` for ownership boundaries, inferences, and rejected designs.
4. Read `DESIGN/03-integration-map.md` before wiring the complete checkout’s query-first CLI, MCP registry, status route, and miss path.
5. Read `DESIGN/04-payload-contract.md` for the typed full and compact payload contracts.
6. Apply `PATCHES/SERIES` in order.
7. Run `TESTS/scoped-verification.py`, then the complete-checkout owner and generated checks in `TESTS/README.md`.
8. Review `TESTS/SCOPED-RESULTS.json` and `VERIFICATION-LIMITS.md`.
9. Capture one live receipt for the incident source and one for a known healthy quiet source with `TESTS/live-safe-receipt.py` before reset, replay, exclusion clearing, or index repair.

## Applying the four-patch series

From a clean worktree at the supplied base, while preserving the existing Beads edit:

```bash
git status --short
while IFS= read -r patch; do
  git apply --check "/path/to/handoff/PATCHES/$patch"
  git apply "/path/to/handoff/PATCHES/$patch"
done < /path/to/handoff/PATCHES/SERIES
```

The files are mail-formatted unified patches. To preserve the review commits, use `git am` instead:

```bash
while IFS= read -r patch; do
  git am "/path/to/handoff/PATCHES/$patch"
done < /path/to/handoff/PATCHES/SERIES
```

If an owning file has changed after `518ac33e3`, stop on the conflict and reconcile it explicitly. Do not silently replace the newer owner implementation with a full-file copy.

## Verification

The portable verifier compiles every changed Python route, runs the real SQLite/FTS exact-source suite, and exercises the aggregate invalid-cursor classifier and all five named-source miss codes:

```bash
python /path/to/handoff/TESTS/scoped-verification.py --repo-root "$PWD"
```

The independently replayed scoped tree produced `27 passed`, plus `cursor projection check: PASS` and `named-source miss check: PASS`. The complete-checkout commands and unavailable scoped checks are listed in `TESTS/README.md` and `VERIFICATION-LIMITS.md`.

## Live-safe receipt

The receipt command requires an explicit archive root and an absolute source path. It does not walk a source root, count the archive, use a wildcard path, or write an archive database. It preserves the supplied absolute path as the archive lookup key and does not resolve a symlink spelling for the source.

```bash
python /path/to/handoff/TESTS/live-safe-receipt.py   --repo-root "$PWD"   --archive-root "$POLYLOGUE_ARCHIVE_ROOT"   --source "$SOURCE_JSONL"   --output .local/receipts/named-source.json   --require-searchable
```

`--cursor-export` and `--attempt-log` are optional operator-only fallbacks with hard byte bounds. `--sqlite-vm-steps`, `--sqlite-value-bytes`, `--attempt-tail-bytes`, and `--cursor-export-bytes` allow tighter positive limits. The script refuses an output path inside the archive root.

Run it once for the excluded incident source and once for a healthy quiet control. Preserve both receipts with the incident record before any owner-approved remediation under `polylogue-lkrc` or `polylogue-yla8` semantics.
