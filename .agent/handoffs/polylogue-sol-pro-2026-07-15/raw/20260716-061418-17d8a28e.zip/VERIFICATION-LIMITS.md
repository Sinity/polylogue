# Verification performed and limits

## Environment and immutable base

Verification ran in the supplied container with Python 3.13.5, pytest 9.0.2, Pydantic 2.13.4, and SQLite 3.46.1.

The supplied context archive is `polylogue-sol-pro-context-da23130588a9fa00.tar.gz`, SHA-256 `da23130588a9fa0021f52e5f0a41d2edf3d9433f36ddb633e1348ce3683c2932`, size 238,300 bytes. Its metadata identifies Polylogue revision `518ac33e318995539743e220c01b9883b7a688a0`, branch `feature/browser/sol-pro-dispatch`, and pre-existing dirty path `.beads/issues.jsonl`. No patch touches that path.

The packet is a scoped 93-source-file selection, not a complete checkout. Synthetic local base `bd1ef985b0e7bf6e89f39f8dffa6881349172d35` exists only to generate and replay unified patches over the supplied `REPO/` tree.

## Patch and source hygiene

The final review series contains four commits:

```text
c468663ec82501fdd9b1900949622ed11f5d0ccd  fix(daemon): classify invalid cursors as degraded
bd0fa0d0a0cfb605284d7ecfa551100a76f2bfa4  feat(archive): add bounded named-source freshness projection
8e50b71c1daf8c8cf877d5beea6caf952c9ee486  feat(archive): expose freshness diagnostics to leaf surfaces
bb58136c11fab8925df2ee7b67735ba706b24381  test(archive): cover degraded and converged source paths
```

The series changes nine repository files: four production files, three test modules, and two fixtures. `git diff --check` passed. All changed Python routes compiled. Generated `__pycache__` files were removed before packaging.

## Independent patch replay

A new replay tree was created from the synthetic immutable base, not from the modified worktree. For every entry in `PATCHES/SERIES`, verification ran:

```text
git apply --check PATCH
git apply PATCH
```

All four checks and applications passed. `git diff --check` passed in the replay tree. The nine replayed repository files were compared byte-for-byte with the final review worktree and all matched. Their SHA-256 values are in `TESTS/CHANGED-FILES.sha256` and `TESTS/SCOPED-RESULTS.json`.

## Exact-source route tests

Fresh-replay command:

```bash
python -m pytest -q tests/unit/archive/test_source_freshness.py
```

Observed output:

```text
...........................                                              [100%]
27 passed in 0.55s
```

These tests use real files and real SQLite databases, including FTS5. They exercise every named stage and operational reason needed by the mission, excluded growth, healthy quiet convergence, current retry reason, stale attempt suppression, accepted head selection, broken head, high-water variants, FTS and insight evidence, query-plan rejection, row/value/file bounds, typed payloads, CLI, MCP, and status adapters.

The healthy fixture’s exact protected plans produced no rejection. Tests specifically prove that an unindexed exact `raw_sessions` query and an unindexed `fts_freshness_state` query are rejected, that `SCAN table USING INDEX ...` is still considered unsafe, and that the constrained FTS virtual-table rowid lookup is allowed.

## Portable owner checks

`TESTS/scoped-verification.py` uses minimal import stubs only for owner dependencies absent from the packet. It verified:

```text
cursor projection check: PASS
named-source miss check: PASS
```

The cursor sample contains an excluded five-failure row, a cursor-ahead row, and a healthy quiet row. It asserts two degraded rows, one idle row, zero stuck rows, explicit reasons, retained failure/offset evidence, and no excluded-to-idle fallthrough.

The miss check exercises all five codes and verifies that operational reason/source existence are included while generic archive totals remain unset.

The full scoped verifier completed in 5.86 seconds in the replay tree. Its output is preserved in `TESTS/SCOPED-VERIFICATION.log`.

## Synthetic live-safe receipt exercise

`TESTS/live-safe-receipt.py` was run with `--require-searchable` against three synthetic archives and once with an invalid relative path:

| Case | Exit | Operational reason/state | Stage | Key evidence |
| --- | ---: | --- | --- | --- |
| healthy quiet | 0 | `caught-up` / `idle` | `searchable` | size/observed/offset 1,024; zero pending/growth/ahead; no broken head, errors, or rejected scans |
| excluded growing | 2 | `cursor-excluded` / `degraded` | `acquired-unparsed` | size 4,096; observed/offset 2,048; five failures; 2,048 pending and growth; `broken_head=true`; no errors or rejected scans |
| cursor ahead | 2 | `cursor-ahead` / `degraded` | `unseen` | current size 1,000; offset 1,100; observed size 1,050; 100 and 50 ahead bytes |
| relative source | 2 | rejected before projection | not executed | absolute source key required |

Every emitted synthetic receipt reported `read_only=true`, `exact_source=true`, and `archive_wide_aggregates=false`. The summarized payloads and hashes are in `TESTS/SYNTHETIC-RECEIPT-RESULTS.json`.

## Checks not performed

No operator live browser, daemon, secrets, databases, source corpus, configured archive root, MCP service, HTTP service, or NixOS deployment was available or accessed. No live excluded or healthy receipt is claimed.

The scoped packet omits canonical Click and MCP owner modules, generated tool contracts/inventory, aggregate named-source status owner, topology projection outputs, `devtools`, Ruff, mypy, full schema modules, and several imports required by pre-existing suites. Therefore:

- canonical query-first CLI registration was not patched or executed;
- canonical MCP registration, discovery, authorization, expected-tool inventory, and generated contract tests were not run;
- aggregate named-source status owner wiring was not patched;
- topology projection/status and generated CLI/MCP references were not regenerated;
- `devtools verify`, `devtools verify --quick`, Ruff, mypy, and repository render gates were unavailable;
- the pre-existing named-miss owner test file cannot collect in the scoped packet because `polylogue.archive.query.spec` is absent; its new route was checked by the portable harness;
- the pre-existing cursor owner suite cannot execute through all storage/daemon dependencies because those files are absent; the changed pure classifier was checked by the portable harness;
- no broad test directory or full suite was run, consistent with repository instructions;
- production schema/index compatibility was exercised with representative real SQLite variants, not with the operator’s live archive.

## Residual verification required

In the complete checkout:

1. integrate the adapters into canonical CLI/MCP/status/miss owners;
2. update MCP inventory and generated contracts;
3. regenerate topology projection/status and surface references;
4. run the focused owner tests and `devtools verify --quick`;
5. capture one exact live receipt for the excluded incident path and one for a healthy quiet control before remediation.

Treat a live receipt as incomplete when it contains `errors`, any `unsafe_scan_rejections`, a governing scope truncation that matters to the decision, or an unavailable checkpoint caused by a production schema variant. Do not replace that conservative result with archive totals.
