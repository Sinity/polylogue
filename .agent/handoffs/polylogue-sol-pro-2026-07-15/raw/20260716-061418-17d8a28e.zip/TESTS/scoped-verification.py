#!/usr/bin/env python3
"""Run the focused checks available in either the scoped packet or full tree."""

from __future__ import annotations

import argparse
import importlib.util
import subprocess
import sys
import types
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace


def _run(repo: Path, *args: str) -> None:
    command = [sys.executable, *args]
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=repo, check=True)


def _cursor_projection_check(repo: Path) -> None:
    def install(name: str, module: types.ModuleType) -> None:
        sys.modules[name] = module

    payload = types.ModuleType("polylogue.core.payload_coercion")
    payload.required_str = lambda value: str(value)  # type: ignore[attr-defined]
    payload.row_int = lambda value: int(value or 0)  # type: ignore[attr-defined]
    install("polylogue.core.payload_coercion", payload)

    logging_module = types.ModuleType("polylogue.logging")

    class Logger:
        def warning(self, *args: object, **kwargs: object) -> None:
            del args, kwargs

    logging_module.get_logger = lambda _name: Logger()  # type: ignore[attr-defined]
    install("polylogue.logging", logging_module)

    connection = types.ModuleType("polylogue.storage.sqlite.connection_profile")
    connection.open_readonly_connection = lambda _path: None  # type: ignore[attr-defined]
    install("polylogue.storage.sqlite.connection_profile", connection)

    families = types.ModuleType("polylogue.daemon.convergence_debt_alert")
    families.source_family_for_path = (  # type: ignore[attr-defined]
        lambda path: "codex" if "codex" in path else "unknown"
    )
    install("polylogue.daemon.convergence_debt_alert", families)

    module_path = repo / "polylogue/daemon/cursor_lag_status.py"
    spec = importlib.util.spec_from_file_location("cursor_lag_status_scoped_check", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)

    rows = [
        (
            "/operator/.codex/sessions/growing.jsonl",
            2_048,
            2_048,
            5,
            1,
            "2026-07-16T10:00:00+00:00",
        ),
        (
            "/operator/.codex/sessions/ahead.jsonl",
            1_024,
            1_200,
            0,
            0,
            "2026-07-16T11:00:00+00:00",
        ),
        (
            "/operator/.codex/sessions/quiet.jsonl",
            1_024,
            1_024,
            0,
            0,
            "2026-07-15T10:00:00+00:00",
        ),
    ]
    summary = module._project_rows(rows, now=datetime(2026, 7, 16, 12, 0, tzinfo=UTC))
    assert summary.degraded_file_count == 2
    assert summary.idle_file_count == 1
    assert summary.stuck_file_count == 0
    assert {item.degradation_reason for item in summary.degraded} == {"excluded", "cursor-ahead"}
    assert summary.degraded[0].classification == "degraded"
    assert summary.degraded[0].excluded is True
    assert summary.max_degraded_lag_s == 7_200.0
    print("cursor projection check: PASS")


def _named_source_miss_check(repo: Path) -> None:
    spec_module = types.ModuleType("polylogue.archive.query.spec")
    spec_module.SessionQuerySpec = type("SessionQuerySpec", (), {})  # type: ignore[attr-defined]
    sys.modules["polylogue.archive.query.spec"] = spec_module

    enums_module = types.ModuleType("polylogue.core.enums")

    class Origin:
        @classmethod
        def from_string(cls, _value: str) -> object:
            return SimpleNamespace(value="unknown")

    enums_module.Origin = Origin  # type: ignore[attr-defined]
    sys.modules["polylogue.core.enums"] = enums_module

    json_module = types.ModuleType("polylogue.core.json")
    json_module.JSONDocument = dict[str, object]  # type: ignore[attr-defined]
    sys.modules["polylogue.core.json"] = json_module

    sources_module = types.ModuleType("polylogue.core.sources")
    sources_module.provider_from_origin = lambda value: value  # type: ignore[attr-defined]
    sys.modules["polylogue.core.sources"] = sources_module

    readiness_module = types.ModuleType("polylogue.readiness")
    readiness_module.VerifyStatus = SimpleNamespace(OK="ok")  # type: ignore[attr-defined]
    readiness_module.get_readiness = lambda *_args, **_kwargs: None  # type: ignore[attr-defined]
    sys.modules["polylogue.readiness"] = readiness_module

    module_path = repo / "polylogue/archive/query/miss_diagnostics.py"
    spec = importlib.util.spec_from_file_location("miss_diagnostics_scoped_check", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)

    expected = {
        "unseen": "named_source_unseen",
        "acquired-unparsed": "named_source_acquired_unparsed",
        "parsed-unindexed": "named_source_parsed_unindexed",
        "indexed-unconverged": "named_source_indexed_unconverged",
        "searchable": "named_source_searchable",
    }
    for stage, code in expected.items():
        projection = SimpleNamespace(
            source_path="/exact/source.jsonl",
            stage=SimpleNamespace(value=stage),
            operational_state=SimpleNamespace(value="idle"),
            operational_reason=SimpleNamespace(value="caught-up"),
            source_stat=SimpleNamespace(exists=True, error=None),
            cursor=SimpleNamespace(excluded=False, pending_bytes=0, cursor_ahead_bytes=0),
            retry=SimpleNamespace(reason=None),
            index=SimpleNamespace(session_count_lower_bound=1, broken_head=False),
            raw_revisions=(object(),),
        )
        diagnostics = module.diagnose_named_source_miss(projection)
        assert diagnostics.reasons[0].code == code
        assert diagnostics.archive_session_count is None
        assert diagnostics.raw_session_count is None
        assert "operational_reason=caught-up" in diagnostics.reasons[0].detail
        assert "source_exists=True" in diagnostics.reasons[0].detail
        assert "source_indexed_session_lower_bound=1" in diagnostics.reasons[0].detail
    print("named-source miss check: PASS")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path.cwd())
    args = parser.parse_args()
    repo = args.repo_root.expanduser().resolve()

    compile_targets = [
        "polylogue/archive/query/source_freshness.py",
        "polylogue/archive/query/source_freshness_surfaces.py",
        "polylogue/archive/query/miss_diagnostics.py",
        "polylogue/daemon/cursor_lag_status.py",
        "tests/unit/archive/test_source_freshness.py",
        "tests/unit/archive/test_query_miss_diagnostics.py",
        "tests/unit/daemon/test_cursor_lag_status.py",
    ]
    _run(repo, "-m", "py_compile", *compile_targets)
    _run(repo, "-m", "pytest", "-q", "tests/unit/archive/test_source_freshness.py")
    _cursor_projection_check(repo)
    _named_source_miss_check(repo)

    if (repo / "polylogue/archive/query/spec.py").exists():
        _run(
            repo,
            "-m",
            "pytest",
            "-q",
            "tests/unit/archive/test_query_miss_diagnostics.py",
            "-k",
            "named_source",
        )
    else:
        print("named-source miss owner test: SKIP (query/spec.py absent from scoped packet)")

    required_cursor_owner = [
        repo / "polylogue/storage/sqlite/archive_tiers/ops_write.py",
        repo / "polylogue/daemon/convergence_debt_alert.py",
    ]
    if all(path.exists() for path in required_cursor_owner):
        _run(
            repo,
            "-m",
            "pytest",
            "-q",
            "tests/unit/daemon/test_cursor_lag_status.py",
            "-k",
            "excluded or cursor_ahead",
        )
    else:
        print("cursor owner test: SKIP (full storage/daemon dependencies absent from scoped packet)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
