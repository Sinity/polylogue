#!/usr/bin/env python3
"""Capture one bounded, read-only Polylogue named-source freshness receipt.

The script never walks source roots, performs archive-wide counts, or writes to
an archive database. It imports the patched checkout supplied by --repo-root
and asks only for the explicit source path and sibling archive tier files.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def _resolved(path: Path) -> Path:
    return path.expanduser().resolve(strict=False)


def _inside(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
    except ValueError:
        return False
    return True


def _write_receipt(output: Path | None, payload: dict[str, object]) -> None:
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    if output is None:
        sys.stdout.buffer.write(encoded)
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(f".{output.name}.tmp-{os.getpid()}")
    try:
        temporary.write_bytes(encoded)
        os.replace(temporary, output)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path.cwd())
    parser.add_argument("--archive-root", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--cursor-export", type=Path)
    parser.add_argument("--attempt-log", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--sqlite-vm-steps", type=int, default=250_000)
    parser.add_argument("--sqlite-value-bytes", type=int, default=64 * 1024)
    parser.add_argument("--attempt-tail-bytes", type=int, default=64 * 1024)
    parser.add_argument("--cursor-export-bytes", type=int, default=2 * 1024 * 1024)
    parser.add_argument(
        "--require-searchable",
        action="store_true",
        help="return 2 unless the source is searchable and not degraded",
    )
    args = parser.parse_args()

    repo_root = _resolved(args.repo_root)
    archive_root = _resolved(args.archive_root)
    source = args.source.expanduser()
    if not source.is_absolute():
        parser.error("--source must be an absolute path so its exact stored key is preserved")
    output = None if args.output is None else _resolved(args.output)
    if output is not None and _inside(output, archive_root):
        parser.error("--output must not be inside --archive-root")
    bounds = (
        args.sqlite_vm_steps,
        args.sqlite_value_bytes,
        args.attempt_tail_bytes,
        args.cursor_export_bytes,
    )
    if any(value <= 0 for value in bounds):
        parser.error("all bounds must be positive")

    sys.path.insert(0, str(repo_root))
    try:
        from polylogue.archive.query.source_freshness import (
            NamedSourceOperationalState,
            NamedSourceStage,
            ProjectionLimits,
            project_named_source_freshness,
        )
    except ImportError as exc:
        print(f"cannot import patched Polylogue checkout: {exc}", file=sys.stderr)
        return 4

    projection = project_named_source_freshness(
        archive_root,
        source,
        cursor_export=None if args.cursor_export is None else _resolved(args.cursor_export),
        attempt_log=None if args.attempt_log is None else _resolved(args.attempt_log),
        limits=ProjectionLimits(
            sqlite_vm_steps=args.sqlite_vm_steps,
            sqlite_value_bytes=args.sqlite_value_bytes,
            attempt_tail_bytes=args.attempt_tail_bytes,
            cursor_export_bytes=args.cursor_export_bytes,
        ),
    )
    payload = projection.to_dict()
    _write_receipt(output, payload)

    receipt = projection.receipt
    if not receipt.read_only or not receipt.exact_source or receipt.archive_wide_aggregates:
        print("receipt invariant failure", file=sys.stderr)
        return 4
    if receipt.unsafe_scan_rejections or projection.errors:
        print("receipt completed with rejected scans or read errors", file=sys.stderr)
        return 3
    if args.require_searchable and (
        projection.operational_state is NamedSourceOperationalState.DEGRADED
        or projection.stage is not NamedSourceStage.SEARCHABLE
    ):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
