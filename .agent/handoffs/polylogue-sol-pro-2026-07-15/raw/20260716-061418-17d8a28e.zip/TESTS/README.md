# Focused verification, fixtures, and receipts

## Fixtures

`fixtures/excluded-growing.json` captures the incident shape: file size 4,096 bytes, cursor observed size and offset 2,048, five failures, exclusion, and a retained decoder reason. The route test adds an older searchable raw revision and a newer accepted unparsed revision, yielding `broken_head=true` and preserving the older index high-water without treating it as current completeness.

`fixtures/healthy-quiet.json` captures the control: current file, observed size, and cursor offset are all 1,024; there are no failures or exclusion; the accepted raw is parsed and carries persisted authority; revision-application evidence exists; the current session is indexed; FTS row coverage and triggers are trusted; and there is no exact insight debt.

## Portable scoped verifier

After applying all four patches:

```bash
python /path/to/handoff/TESTS/scoped-verification.py --repo-root "$PWD"
```

It performs:

- `py_compile` on all seven changed production/test Python routes;
- the complete `tests/unit/archive/test_source_freshness.py` route suite;
- a pure aggregate-cursor check for excluded, cursor-ahead, and healthy quiet rows;
- a pure named-source miss check for all five codes;
- conditional execution of the two owner suites when their packet-omitted dependencies are present.

Observed fresh-replay output is preserved in `SCOPED-VERIFICATION.log`; the exact suite produced `27 passed`.

## Exact route coverage

The 27 collected cases cover:

- all five pipeline stages;
- excluded-growing priority and retained attempt reason;
- isolated broken-head degradation;
- healthy quiet end-to-end convergence;
- missing source with persisted evidence;
- source stat failure;
- timestamp-less sessions schema;
- active growth and cursor missing;
- no-evidence unseen;
- cursor ahead and retrying cursor;
- stale attempt suppression after recovery;
- unindexed FTS ledger rejection;
- insight target-type collision isolation;
- positive-limit validation;
- oversized exact SQLite value rejection;
- unindexed raw-table scan rejection;
- full index-scan rejection and constrained FTS virtual lookup acceptance;
- accepted head not hidden by newer skipped rows;
- bounded attempt tail and native-boolean cursor export;
- hard cursor-export byte bound;
- typed status, text rendering, JSON CLI, async MCP handler, and registration adapter.

## Complete-checkout focused commands

Use the repository’s managed harness:

```bash
devtools test tests/unit/archive/test_source_freshness.py
devtools test tests/unit/archive/test_query_miss_diagnostics.py -k named_source
devtools test tests/unit/daemon/test_cursor_lag_status.py -k 'excluded or cursor_ahead'
```

After canonical MCP registration, run the focused tool inventory/discovery/authorization contract that owns the expected tool list. Because the series adds two `polylogue/` modules, regenerate and check topology:

```bash
devtools render topology-projection
devtools render topology-status
devtools render all --check
devtools verify --quick
```

The scoped packet does not contain those owners or `devtools`, so these commands are required residual verification rather than claimed results.

## Live-safe receipt

Run once for the excluded incident source and once for a known healthy quiet source, before remediation:

```bash
python /path/to/handoff/TESTS/live-safe-receipt.py   --repo-root "$PWD"   --archive-root "$POLYLOGUE_ARCHIVE_ROOT"   --source "$ABSOLUTE_SOURCE_JSONL"   --output .local/receipts/source-freshness.json   --require-searchable
```

The command never walks a source root, performs an archive total, or writes an archive database. Default safety limits are 250,000 SQLite VM steps per query, 64 KiB per SQLite string/blob value, 64 KiB attempt-log tail, and 2 MiB cursor export. All can be tightened with positive command-line values.

Optional fallbacks:

```text
--cursor-export ABSOLUTE_OR_OPERATOR_CONTROLLED_PATH
--attempt-log ABSOLUTE_OR_OPERATOR_CONTROLLED_PATH
```

Exit statuses:

| Exit | Meaning |
| ---: | --- |
| `0` | Valid receipt; strict requirement satisfied when requested |
| `2` | Source is degraded/not searchable under `--require-searchable`, or argparse rejected unsafe input |
| `3` | Receipt contains a read error or rejected protected query plan |
| `4` | Patched checkout import or receipt invariant failed |

The script refuses a relative source path and refuses output inside the archive root. It writes the JSON atomically outside the archive.

## Recorded results

- `SCOPED-RESULTS.json` contains environment, patch replay, commits, changed-file hashes, checks, and limitations.
- `SCOPED-VERIFICATION.log` preserves the fresh verifier output.
- `SYNTHETIC-RECEIPT-RESULTS.json` summarizes healthy, excluded-growing, cursor-ahead, and invalid-path exercises.
- `CHANGED-FILES.sha256` records the exact replayed repository file hashes.

Synthetic receipts demonstrate the procedure; they are not substitutes for the two required operator live receipts.
