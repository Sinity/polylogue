# Source-to-design traceability

## Evidence identity

| Evidence | SHA-256 |
|---|---|
| Complete selected Beads export | `1510595bf26794e4bb840b626d862f595dd162d76a2017fc5909112c800f5a1b` |
| Checked-in redesign README | `e7950cae651bb7cced720cad7272354eadc1b9fe2f3cea255c5b316927adadab` |
| Checked-in / attached prototype HTML | `ad8ec0b8cf0c7b878b03f24c57a1fda2c7541b4a41b690ae997e71bcfa811b79` |
| Checked-in / attached prototype support JS | `78f6b3cb83ef645c2d98f2b3f38bb05517e8525753b57d1c9c3e4e21d75a78f3` |
| Prototype Beads handoff | `48473eb80126bc221a1b7b0b76c1d95a3efb9e9a2b6e6601ec78defa83de63a1` |
| Prototype uploaded brief | `ccca6ed99ea71114e45c4cef00a702d7a84ea77f47b9ce4295fde1d4dbd94e88` |
| Supplied dirty completion-monitor patch | `5394855b4c10488bb34991922c7ca7f879bc3c4f4840072758986ce02a21f721` |

The attached prototype and checked-in prototype are byte-identical for HTML and support JS. The prototype uses CDN-hosted React, Babel, and Google Fonts; those implementation details were rejected while its information architecture and states were retained.

## Matrix

| Source | Source requirement / superseding note | Design decision | Implementation | Executable evidence | Status / residual |
|---|---|---|---|---|---|
| `polylogue-3v1`; F1/F6 | Reliability must be observable; N tabs; calm offline; actual reasons; seeing and doing nothing must be visible | Popup becomes multi-tab mission control; no-op is a first-class event; offline is preservation, not loss | `popup.{html,js}`, `background.js`, `operator_status.js` | Popup fixtures; no-op dedupe background fixture; offline/cached fixtures | Local event trail satisfied; daemon event mirror deferred because no route exists |
| `polylogue-3v1` live notes | Missing/stale receiver endpoint and captured-once-then-grew gap | Separate receiver identity from endpoint and expose recovery/mismatch | `/v1/status` schema + pairing store + canonical recovery | Pairing/recovery/mismatch/reset tests; isolated HTTP smoke | Stable once status contract is observed; legacy first-contact compatibility remains |
| `polylogue-90y`; F2/F3 | Ambient chip/slide-over, Shadow DOM, zero layout shift, per-site control, archive status | Fixed zero-flow host, closed Shadow DOM, runtime mission snapshot, per-site hide | `ambient_surface.js`, manifest injection | DOM tests for host dimensions, closed root, dark/reduced motion, hide, focus | Read side satisfied on ChatGPT/Claude; no real-browser visual proof |
| `polylogue-90y`; F5 | Select passage and save assertion with evidence | Implement safe local candidate architecture only; reject cross-message selection; disable save | `deriveSelectionCandidate`, assertion capability seam | Selection fixtures and disabled-button mutation proof | Persistence deferred: no authenticated assertion route in supplied receiver |
| `polylogue-90y` resolved two-layer rule; `polylogue-yyvg` later note | “Per-message state blends in; cross-conversation intelligence floats”; ProviderAdapter owns message identity | Implement only floating deep-dive now; do not add provider-specific per-message identity mapping | Ambient chip/panel only | Manifest/content tests | F4 blended layer deferred until shared ProviderAdapter contract is available |
| `polylogue-yyvg.5` later notes | Receiver-owned queue; concurrent submitted chats; exact ordinary Chat / GPT-5.6 Sol / Pro; no parallel launch stack; ambiguous outcomes quarantined | Present and control existing jobs; never clone launch state; preserve safeguards | Existing launch helpers/routes plus normalized presentation and offline cache | Existing launch tests + popup/background mission fixtures; launch files hash-identical | Satisfied for mission-control phase; live provider flow not rerun here |
| `polylogue-jlme.5` | Stable runtime identity and actionable stale endpoint | Token-derived non-secret receiver ID, API schema, explicit mismatch/reset, one canonical recovery probe | Receiver model/status + background pairing state machine | Python model/route tests, isolated HTTP smoke, fail-closed mutation proof | Packaged multi-profile proof deferred |
| `polylogue-ptx`; F1 agent control | Reverse channel needs a home; design recommends dry-run draft, never auto-send | Show safe home and double-gate status; ambient never actuates | Popup/ambient reverse sections; existing posting gates unchanged | Popup/ambient fixtures | Posting actuator, attachments, and dry-run composer draft deferred |
| Prototype visual constraints | Dark/light, distinct identity, no host collision, no remote assets | System-font, self-contained popup and Shadow-DOM tokens; no prototype runtime copied | Local CSS, `prefers-color-scheme`, reduced motion, fixed host | Static source/package scans and DOM assertions | Pixel/screenshot review deferred |
| Active completion-monitor branch | Snapshot is newer than master; preserve exact monitor/reconciliation work | Package supplied dirty work as patch 0001 and base phase patch after it | Patch series | Two-path byte-identical apply proof; launch files hash-identical | Satisfied |
| Existing ordinary capture handling | Do not regress supported capture, retries, backfill, or direct capture | Add trust/presentation around existing helpers rather than replace them | `background.js` integration | Full 286-test extension suite | Satisfied in self-contained suite; live daemon/browser boundary remains |

## Prototype elements intentionally not copied

The prototype's JSX-in-HTML, Babel transform, React/ReactDOM CDNs, Google Fonts, synthetic cost/assertion data, and independent internal state were not reused. The production implementation derives every displayed runtime state from existing extension storage, coordinators, or receiver routes.
