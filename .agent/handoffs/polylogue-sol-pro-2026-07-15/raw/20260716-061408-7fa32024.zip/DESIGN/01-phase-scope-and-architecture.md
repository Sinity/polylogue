# Phase scope and architecture

## Chosen phase

The chosen vertical phase is **trusted ambient mission control**: establish one receiver-backed information contract, use it in the popup and in-page surface, and add the minimum receiver identity schema required to make those surfaces trustworthy.

This was selected over a broader visual replica because it unlocks multiple requested surfaces at once while staying inside real routes and existing ownership boundaries. The receiver remains authoritative for Sol Pro launch jobs; the backfill coordinator remains authoritative for history jobs; the capture retry queue and conversation ledger remain existing extension storage. The new layer is presentation and trust orchestration, not a second scheduler.

## Evidence classification

- **Source-supported facts:** the six complete Beads records, checked-in redesign files, prototype handoff, supplied Git metadata/patch, route/model code, and executable tests.
- **Implementation inference:** the persisted high-entropy receiver bearer token is the only stable runtime root in this partial snapshot, so a domain-separated digest is the safest non-secret pairing identifier without adding persistence or a database.
- **Proposal/deferred work:** authenticated assertion persistence, daemon event mirroring, F4 per-message blending, relevant assertion retrieval, and dry-run reverse posting require contracts absent from this snapshot.

## Runtime architecture

```text
Receiver /v1/status
  api_schema + receiver_id + existing status
                  │
                  ▼
background.js trust layer
  pairing state ─ bounded recovery ─ fail-closed GET/POST preflight
                  │
                  ├── existing capture ledger + retry queue
                  ├── existing backfill coordinator status
                  ├── existing receiver launch-job routes
                  ├── existing conversation timeline storage
                  └── ambient/reverse/assertion capability seams
                  │
                  ▼
polylogue.missionControl.status
  one typed snapshot, no duplicate scheduler
             │                         │
             ▼                         ▼
operator_status.js                operator_status.js
             │                         │
             ▼                         ▼
popup mission control         closed-Shadow-DOM ambient panel
  full controls                  read-only status + local selection candidate
```

## Important ownership decisions

1. **Sol Pro remains receiver-owned.** The extension only lists, claims, controls, and monitors through existing routes/helpers. Cached job state is presentation-only and cannot actuate controls.
2. **Pairing identity is separate from endpoint.** Endpoint can recover; identity cannot silently change. A changed identity requires explicit reset.
3. **No-op is an event.** Archive-safe and receiver-processing observations append a deduplicated timeline decision rather than disappearing.
4. **One status mapper serves both surfaces.** Raw archive/provider/queue states are normalized once in `operator_status.js`.
5. **Assertion selection is a candidate, not a write.** It is bounded to one provider message and remains ephemeral until a real authenticated route exists.
6. **Ambient reverse control is non-actuating.** It communicates the double gate and safe default, but never drafts, posts, or submits.

## Changed source map

- `polylogue/browser_capture/models.py` — status API schema and receiver identity fields.
- `polylogue/browser_capture/receiver.py` — stable non-secret receiver identity and status emission.
- `browser-extension/src/background.js` — pairing, trust preflight, recovery, mission snapshot, offline Sol Pro cache, ambient settings, and no-op event.
- `browser-extension/src/operator_status.js` — canonical conversation/work/event/pairing presentation contract.
- `browser-extension/src/popup.{html,js}` — mission-control IA and controls.
- `browser-extension/src/content/ambient_surface.js` — fixed closed-Shadow-DOM status surface and local selection candidate.
- `browser-extension/manifest.json` — shared status and ambient injection for ChatGPT/Claude while preserving MAIN-world bridges.
- Tests — receiver, background, shared status, popup, ambient, and build-budget coverage.

## Phase exclusions

The phase does not implement backend assertions, relevant-memory retrieval, per-message capture dots/actions, daemon event ingestion, automatic reverse posting, attachments, Gemini, or live browser proof. These are not mock-disabled features presented as complete; they are named seams with disabled controls or absent UI.
