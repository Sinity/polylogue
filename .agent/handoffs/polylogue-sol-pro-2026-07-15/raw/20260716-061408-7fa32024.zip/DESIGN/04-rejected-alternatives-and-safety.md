# Rejected alternatives and safety decisions

## Copy the prototype implementation

Rejected. The prototype loads React, ReactDOM, Babel, and Google Fonts from CDNs and carries synthetic independent state. Manifest V3 requires packaged executable code, and Polylogue's privacy posture prohibits remote assets. Only the information architecture, state language, and interaction hierarchy were translated.

## Create a new mission-control store

Rejected. A parallel store would diverge from capture retry storage, the backfill coordinator, receiver launch jobs, and the conversation ledger. `missionControlSnapshot()` reads those owners and returns a transient view.

## Fabricate an assertion API

Rejected. The supplied receiver exposes no authenticated assertion-write route or capability. The phase implements a bounded local candidate and an explicit disabled control. It does not POST to an invented path, write directly to `user.db`, or bypass the daemon's single-writer/product-layer rules.

## Implement F4 per-message blending independently per provider

Rejected for this phase. Later `polylogue-yyvg` notes make a shared ProviderAdapter the owner of conversation/message identity. Adding provider-specific DOM-to-archive mappings now would create the parallel identity model those notes explicitly prohibit.

## Auto-adopt a different receiver

Rejected. A healthy HTTP response is not sufficient once an identity is paired. Identity/schema mismatch is actionable and fail-closed. Reset is explicit and preserves work.

## Scan localhost for a receiver

Rejected. Port scanning would broaden trust and surprise the operator. Recovery is one bounded probe of the documented canonical endpoint and requires the same stable identity.

## Treat cached Sol Pro state as live

Rejected. Last-known jobs remain visible to preserve situational awareness, but are labeled with cache time and all mutating controls are disabled until live trusted status returns.

## Enable reverse posting as part of the redesign

Rejected. `polylogue-ptx` has separate actuator, attachment, and dry-run-draft work. This phase gives reverse state a visible safe home without changing the existing double gate or submitting from the ambient surface.

## Rewrite the Sol Pro launch stack

Rejected. Later `polylogue-yyvg.5` notes explicitly say the receiver owns jobs and that a proposed parallel launch stack was not adopted. The supplied completion-monitor patch is preserved exactly; the redesign only presents and controls its current contracts.

## Use receiver endpoint as identity

Rejected. The diagnosed failure is precisely that an endpoint can be stale while the intended receiver moves or restarts. Pairing binds to a non-secret stable identity and treats endpoint as recoverable location.

## Make “offline” an error screen

Rejected. The daemon is commonly stopped. Offline presentation preserves local work, last contact, and last-known external state without claiming currentness or data loss.

## Put paint containment on the zero-size ambient host

Rejected after review. `contain: paint` clips fixed descendants to the host's zero-size paint box in relevant rendering models. The host uses `contain: style`, `overflow: visible`, fixed positioning, zero dimensions, and pointer-event delegation instead.
