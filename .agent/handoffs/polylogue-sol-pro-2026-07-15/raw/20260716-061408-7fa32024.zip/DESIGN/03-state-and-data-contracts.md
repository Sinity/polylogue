# State and data contracts

## Canonical operator vocabulary

| Code | Label | Source states / meaning |
|---|---|---|
| `safe_current` | Safe / current | Archived or positively captured; may carry a separate partial-fidelity flag |
| `catching_up` | Catching up | `spooled_only`, `ingest_pending`, or `stale` durable evidence progressing toward queryable/current |
| `partial_fidelity` | Partial fidelity | `capture_mode=dom_degraded`; orthogonal fidelity flag, not a replacement for archive state |
| `needs_attention` | Needs attention | Missing capture, pairing mismatch, authorization, submission unknown, challenge/operator block |
| `failed` | Failed | Terminal/rejected capture or work failure with concrete reason |
| `receiver_offline` | Receiver offline | Paired receiver unavailable; local queues/evidence remain preserved |
| `provider_warning` | Provider warning | Rate/safety/provider circuit warning; provider owns the backoff |
| `queued` | Queued | Waiting for cadence, transport retry, or unclaimed external work |
| `running` | Running | Active backfill or leased/uploading/submitting/submitted Sol Pro work |
| `completed` | Completed | Terminal successful external work, including handoff result where available |
| `stopped` | Stopped | Cancelled external work |

Automatic cadence/transport waits map to Queued, not Needs attention. Provider rate/safety circuits map to Provider warning. Actual authentication/challenge/submission-unknown holds map to Needs attention.

## Mission snapshot

`polylogue.missionControl.status` returns one presentation snapshot:

```json
{
  "ok": true,
  "generated_at": "ISO-8601",
  "tab": { "id": 1, "title": "…", "url": "…" },
  "state": { "provider": "chatgpt", "provider_session_id": "…", "archive_state": {} },
  "timeline": [],
  "receiver": {
    "health": {},
    "pairing": {},
    "configured_url": "http://127.0.0.1:8765"
  },
  "work": {
    "capture_queue": {},
    "backfill_jobs": [],
    "launch_jobs": [],
    "launch_enabled": false,
    "launch_owner_instance_id": "…",
    "launch_source": "live|cached|unavailable",
    "launch_cached_at": null,
    "launch_error": null
  },
  "ambient": { "enabled": true, "site_enabled": true, "site": "chatgpt.com" },
  "reverse": { "enabled": false, "default_state": "off", "receiver_gate_required": true },
  "assertions": {
    "selection_candidate_supported": true,
    "persistence_supported": false,
    "reason": "receiver_assertion_route_not_advertised"
  }
}
```

The snapshot is assembled from existing owners. It is not persisted as a parallel source of truth. Only the last successful launch-job listing is cached for offline presentation, marked `cached` with `cached_at`, and rendered non-actionable.

## Receiver status and pairing

Receiver status adds:

```json
{
  "api_schema": "polylogue-browser-capture/v1",
  "receiver_id": "rx-<20 hex>"
}
```

With authentication enabled, `receiver_id` is the first 20 hex characters of SHA-256 over a domain-separated token material and is therefore stable across daemon/spool replacement while not disclosing the token. In explicit no-auth mode it falls back to a domain-separated resolved spool path, consistent with that already opt-in local-only mode.

Pairing states:

- `online` — expected identity/schema answered at the configured or recovered endpoint.
- `offline` — expected receiver unavailable; last identity and last seen time retained.
- `unauthorized` — endpoint answered but token was rejected.
- `mismatch` — identity/schema changed or pairing metadata disappeared after a stable pairing.
- `legacy` — reachable receiver did not advertise pairing metadata before this profile established a stable identity.

Trust rules:

1. A known identity is never replaced automatically.
2. Paired GET/POST traffic requires a fresh or at-most-10-second cached identity check.
3. Mismatch, unauthorized, and unavailable results fail before the application route is called.
4. Recovery probes only the canonical `http://127.0.0.1:8765`, only from a noncanonical configured endpoint, and adopts it only when identity and schema match.
5. No port range, process, profile, or arbitrary localhost scan occurs.
6. Reset removes only the pairing key; capture/backfill/Sol Pro queues are preserved.

## Unified work-item presentation

Every work item exposes:

```text
id, kind, title, status{code,label,tone}, phase, cadence,
owner, cooldown, handoff, updated_at, raw
```

Kinds:

- `capture_retry` — local extension retry queue; receiver ACK pending.
- `backfill` — existing backfill coordinator job; inventory/capture phase and learned cadence.
- `sol_pro` — existing receiver launch job; queue phase, lease owner, provider circuit, and handoff acquisition/validation.

The `raw` reference is retained inside the renderer contract for control/detail panels; no new durable representation is written.

## Event contract

Per-conversation events remain bounded in `chrome.storage.local` and are newest-first. New event:

```json
{
  "event": "observed_no_action",
  "reason": "tab_activated|tab_updated|…",
  "detail": "already_safe|receiver_already_processing",
  "tab_id": 1,
  "at": "ISO-8601"
}
```

Equivalent consecutive observations are deduplicated for five minutes. This records a decision without generating duplicate captures.

## Selection candidate contract

A candidate is created only when selection endpoints are inside the same recognized ChatGPT/Claude message element:

```json
{
  "kind": "selection_assertion_candidate",
  "provider": "chatgpt|claude-ai",
  "source_url": "…",
  "captured_at": "ISO-8601",
  "text": "up to 2000 characters",
  "truncated": false,
  "persistence": "not_supported"
}
```

It is not stored or transmitted. The save control remains disabled even if a future receiver advertises support, because this extension phase deliberately contains no unaudited write handler.

## Reverse-channel seam

The snapshot reports the existing extension `postingEnabled` gate and states that the independent receiver gate is also required. The ambient surface has no command, draft, post, submit, or attachment handler. This avoids converting a status redesign into an unsafe actuator change.
