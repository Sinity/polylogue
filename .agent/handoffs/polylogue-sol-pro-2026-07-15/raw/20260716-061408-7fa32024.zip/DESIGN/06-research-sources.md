# External research sources

Accessed 2026-07-16. Primary/official sources were used only to convert platform constraints into implementation decisions.

1. Chrome for Developers, “Extensions / Manifest V3” — https://developer.chrome.com/docs/extensions/develop/migrate/what-is-mv3
   - Decision: do not copy the prototype's CDN React/Babel/Google Fonts; all executable code and styling are packaged locally.
2. Chrome for Developers, “Deal with remote hosted code violations” — https://developer.chrome.com/docs/extensions/develop/migrate/remote-hosted-code
   - Decision: add a static source/package scan for remote HTML/CSS assets and avoid dynamic code loading.
3. Chrome for Developers, “Content scripts” — https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts
   - Decision: keep the ambient/status scripts in the isolated content-script world and preserve only the existing provider bridges in MAIN world.
4. MDN, “Using shadow DOM” — https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_shadow_DOM
   - Decision: use a closed shadow root as practical style/DOM encapsulation; do not describe it as a security boundary.
5. W3C WAI-ARIA Authoring Practices, “Dialog (Modal) Pattern” — https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/
   - Decision: use a named `role=dialog`, move focus on open, support Escape, and restore focus. The Polylogue panel is explicitly nonmodal (`aria-modal=false`), so it does not inert the host page or trap focus.

No external library or remote asset from these sources is included in the patch.
