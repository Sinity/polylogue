# Polylogue Sol Pro launch handoff

This archive is a reviewable patch handoff for the **trusted ambient mission-control phase** of the Polylogue browser extension. It starts from the supplied snapshot of `feature/browser/adopt-completion-monitors` at commit `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`, including the four supplied uncommitted completion-monitor changes. It does not assume current `master` and does not replace the receiver-owned Sol Pro launch state machine.

## Read order

1. `SUMMARY.md` — executive result, acceptance matrix, exclusions, and verification headline.
2. `DESIGN/01-phase-scope-and-architecture.md` — chosen vertical phase and architecture.
3. `DESIGN/02-source-to-design-traceability.md` — Beads/prototype/source-to-change matrix.
4. `DESIGN/03-state-and-data-contracts.md` — operator vocabulary, pairing, event, work, assertion, and reverse-channel contracts.
5. `DESIGN/04-rejected-alternatives-and-safety.md` — approaches deliberately not taken.
6. `PATCHES/SERIES.md` — exact patch bases and application modes.
7. `TESTS/verification-plan.md`, `TESTS/results.txt`, and `TESTS/anti-vacuity-proof.md` — executable evidence.
8. `VERIFICATION-LIMITS.md` — exact environment boundary and residual uncertainty.
9. `DESIGN/05-continuation-plan.md` — ordered work that remains.

## Base and dirty-state assumptions

Supplied Git metadata:

- Branch: `feature/browser/adopt-completion-monitors`
- HEAD: `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- `origin/master` in the supplied log: `934a12e69`
- Expected pre-existing dirty paths:
  - `browser-extension/src/background.js`
  - `browser-extension/tests/background.test.js`
  - `polylogue/browser_capture/launch_jobs.py`
  - `tests/unit/browser_capture/test_launch_jobs.py`

`PATCHES/0001-preserve-active-completion-monitor-work.patch` is the supplied immutable working-tree patch, byte for byte. `PATCHES/0002-ambient-mission-control-phase.patch` is based on the supplied **dirty** snapshot after patch 0001. The implementation deliberately leaves `launch_jobs.py` and `test_launch_jobs.py` byte-identical to that supplied dirty snapshot.

## Apply to the supplied dirty snapshot

From the repository root that already contains the four dirty changes above:

```bash
git status --short
git apply --check /path/to/handoff/PATCHES/0002-ambient-mission-control-phase.patch
git apply /path/to/handoff/PATCHES/0002-ambient-mission-control-phase.patch
```

Do not apply patch 0001 again in this mode.

## Apply from clean HEAD `76ee0d384…`

From a clean checkout of the exact supplied HEAD:

```bash
git apply --check /path/to/handoff/PATCHES/0001-preserve-active-completion-monitor-work.patch
git apply /path/to/handoff/PATCHES/0001-preserve-active-completion-monitor-work.patch
git apply --check /path/to/handoff/PATCHES/0002-ambient-mission-control-phase.patch
git apply /path/to/handoff/PATCHES/0002-ambient-mission-control-phase.patch
```

Both application modes were executed in disposable Git repositories and produced a 64-file source tree byte-identical to the tested implementation, excluding generated caches and dependencies. See `TESTS/patch-application-proof.txt`.

## Review focus

The highest-risk review areas are receiver pairing in `browser-extension/src/background.js`, the new receiver identity fields in `polylogue/browser_capture/{models,receiver}.py`, the shared status/work normalizer in `browser-extension/src/operator_status.js`, and the closed-Shadow-DOM ambient surface in `browser-extension/src/content/ambient_surface.js`.

The assertion and reverse/posting areas are intentionally honest seams: selection creates only an ephemeral candidate, assertion save remains disabled because no authenticated receiver assertion route exists in this snapshot, and the ambient surface cannot post or submit. Existing reverse-channel gates and exact Chat / GPT-5.6 Sol / Pro launch safeguards remain in their existing runtime paths.
