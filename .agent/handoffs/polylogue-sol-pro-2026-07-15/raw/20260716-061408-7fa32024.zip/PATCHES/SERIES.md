# Patch series

## 0001 — preserve active completion-monitor work

`0001-preserve-active-completion-monitor-work.patch` is the exact supplied `GIT/working-tree.patch` (SHA-256 `5394855b4c10488bb34991922c7ca7f879bc3c4f4840072758986ce02a21f721`). It applies to clean commit `76ee0d3842f12920ee71ad06f22b9cd8d2f88730` and restores the snapshot's four pre-existing dirty paths.

Purpose: keep the newer completion-monitor, launch reconciliation, and tests ahead of current master intact. This handoff does not rewrite or supersede that work.

## 0002 — trusted ambient mission-control phase

`0002-ambient-mission-control-phase.patch` applies after 0001, or directly to the supplied dirty snapshot. It contains the shared operator model, receiver pairing/schema contract, mission snapshot, popup redesign, ambient surface, event trail, fixtures, and verification-timeout adjustment.

## Application modes

Clean exact HEAD:

```bash
git apply 0001-preserve-active-completion-monitor-work.patch
git apply 0002-ambient-mission-control-phase.patch
```

Supplied dirty snapshot:

```bash
git apply 0002-ambient-mission-control-phase.patch
```

Both paths were tested with `git apply --check`, applied, and compared byte-for-byte to the tested implementation. Do not apply 0001 twice.
