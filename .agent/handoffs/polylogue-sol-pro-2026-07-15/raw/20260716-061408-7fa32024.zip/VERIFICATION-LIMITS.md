# Verification limits

## What was run

- Complete self-contained browser-extension Vitest suite: 286/286 passed.
- Focused post-mutation restoration suite: 85/85 passed.
- ESLint over extension source/tests.
- Manifest validator.
- Chrome ZIP and Firefox XPI build with explicit version override and no source sync.
- Archive inventory/path/symlink safety checks.
- Static runtime scan for remote HTML/CSS assets and dynamic-code execution.
- Python syntax compilation for changed receiver/model/test files.
- Isolated HTTP smoke executing the actual supplied `models.py`, `receiver.py`, and `server.py`, with stubs only for repository modules omitted from the partial archive.
- Three anti-vacuity mutations and focused failure checks.
- Two independent patch application modes and byte-for-byte source inventory comparison.
- Hash comparison proving supplied completion-monitor launch implementation/tests were not changed by patch 0002.

## What could not be run

- Native receiver pytest through the repository harness. Collection stops because the supplied partial snapshot omits `polylogue.archive` and other imported full-repository modules.
- `devtools verify`, mypy, ruff, generated-surface checks, or topology checks. The supplied archive omits the root tooling/configuration and most repository modules.
- A running `polylogued` daemon, real receiver token file, real archive databases, SQLite tier migrations, ingestion, or NixOS deployment.
- The operator's live Chrome/Firefox profiles, authenticated ChatGPT/Claude cookies, multiple extension profiles, real tabs, service-worker lifecycle under a browser, or provider network traffic.
- Exact live Chat / GPT-5.6 Sol / Pro submission. Existing safeguards were preserved and their self-contained tests passed, but no provider submission was performed.
- Live completion-monitor/handoff acquisition against an actual Sol Pro conversation.
- Screenshot/pixel regression, browser-computed layout shift, browser accessibility tree, keyboard testing outside JSDOM, or screen-reader/assistive-technology proof.
- Live reverse/posting, attachments, assertion persistence, or daemon event mirroring; these capabilities were deliberately not implemented.

## Interpretation boundary

Passing JSDOM tests proves DOM structure, state rendering, focus calls, selection filtering, and zero-flow host intent. It does not prove browser paint/compositing or host-site selector stability. The code review removed a concrete paint-containment clipping risk, but packaged browser visual proof remains required.

The isolated receiver smoke proves the changed identity/status logic and actual HTTP route can execute in this partial snapshot. It does not replace native tests in the complete repository, daemon startup, token-file permissions, or deployment restart proof.

The phase preserves legacy-compatible behavior before a profile has observed a stable receiver ID. Once paired, traffic is fail-closed. Requiring pairing before the very first application write is an ordered follow-up, not claimed complete here.
