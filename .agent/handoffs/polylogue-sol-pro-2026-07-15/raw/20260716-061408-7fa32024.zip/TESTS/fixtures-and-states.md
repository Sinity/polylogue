# Test fixtures and state coverage

The patch contains executable fixtures rather than static mock screens.

## Shared vocabulary fixtures

`browser-extension/tests/operator_status.test.js` covers:

- archived → Safe / current
- spooled-only / ingest-pending / stale → Catching up
- missing / authorization / identity mismatch / submission unknown → Needs attention
- failed → Failed
- offline → Receiver offline
- provider rate/safety circuits → Provider warning
- DOM-derived capture → Partial fidelity flag
- cadence/transport waits → Queued
- active jobs → Running
- completed/cancelled → Completed/Stopped

It also builds one mixed queue with readable capture, backfill, and Sol Pro titles, phases, cadence, owners, receiver ACKs, and validated handoff metadata.

## Background trust fixtures

`browser-extension/tests/background.test.js` covers:

- paired writes perform identity preflight and use the bounded trust cache
- a different receiver fails closed before capture POST
- canonical recovery occurs only for the same identity
- a different canonical identity is not adopted
- reset removes pairing while preserving queued work
- live Sol Pro state is cached and remains visibly last-known offline
- an already-safe chat records one deduplicated `observed_no_action` event
- ambient site disable is persisted without changing the global default

These run through the actual service-worker message listener and fetch/storage mocks, not a separate mission-control implementation.

## Ambient fixtures

`browser-extension/tests/content/ambient_surface.test.js` covers:

- fixed zero-width/zero-height host attached outside provider body flow
- `overflow: visible` and no paint containment clipping
- closed Shadow DOM (`host.shadowRoot === null`)
- no remote CSS assets, dark mode, reduced motion
- named nonmodal dialog, open focus, Escape close, focus return
- same status/event/work/pairing contracts as popup
- offline last-known Sol Pro state
- local candidate only for selection inside one supported message
- page-chrome and cross-message selection rejection
- disabled assertion save and reverse-safe copy
- global/per-site disable removal

## Popup fixtures

`browser-extension/tests/popup.test.js` covers the mission snapshot, multi-tab ledger, full archive-state vocabulary, no-op timeline, pairing/offline/mismatch labels, unified work queue, backfill controls, exact receiver-owned Sol Pro controls, cached-control disabling, ambient settings, and assertion/reverse seams.

## Receiver fixtures

`tests/unit/browser_capture/test_receiver.py` adds stable restart, token rotation, no-auth spool identity, typed status/no-secret, and HTTP route tests. `receiver_pairing_isolated_smoke.py` executes the actual changed receiver modules in this partial snapshot and verifies authenticated/unauthenticated status behavior.
