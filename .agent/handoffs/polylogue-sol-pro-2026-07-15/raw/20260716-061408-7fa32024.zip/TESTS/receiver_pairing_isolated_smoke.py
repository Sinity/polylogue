#!/usr/bin/env python3
"""Exercise the supplied receiver pairing contract with minimal missing-repo stubs.

This imports and executes the actual browser_capture/models.py, receiver.py, and
server.py from the supplied snapshot. Stubs cover only modules omitted from the
immutable partial archive; no receiver behavior under test is reimplemented.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
import tempfile
import threading
import types
from datetime import UTC, datetime
from enum import Enum
from http.client import HTTPConnection
from pathlib import Path
from typing import Any


def install_module(name: str, **attrs: Any) -> types.ModuleType:
    module = types.ModuleType(name)
    for key, value in attrs.items():
        setattr(module, key, value)
    sys.modules[name] = module
    return module


def install_package(name: str, path: Path | None = None) -> types.ModuleType:
    module = install_module(name)
    module.__path__ = [str(path)] if path is not None else []
    module.__package__ = name
    return module


def load_module(name: str, path: Path) -> types.ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {name} from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class Role(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"
    UNKNOWN = "unknown"

    @classmethod
    def normalize(cls, value: str) -> "Role":
        normalized = str(value or "unknown").strip().lower()
        aliases = {"human": "user", "ai": "assistant"}
        try:
            return cls(aliases.get(normalized, normalized))
        except ValueError:
            return cls.UNKNOWN


class Provider(str, Enum):
    CHATGPT = "chatgpt"
    CLAUDE_AI = "claude-ai"
    GROK = "grok"
    UNKNOWN = "unknown"

    @classmethod
    def from_string(cls, value: str | None) -> "Provider":
        normalized = str(value or "unknown").strip().lower()
        aliases = {"claude": "claude-ai", "openai": "chatgpt"}
        try:
            return cls(aliases.get(normalized, normalized))
        except ValueError:
            return cls.UNKNOWN


class DummyLogger:
    def debug(self, *_args: Any, **_kwargs: Any) -> None: pass
    def info(self, *_args: Any, **_kwargs: Any) -> None: pass
    def warning(self, *_args: Any, **_kwargs: Any) -> None: pass
    def error(self, *_args: Any, **_kwargs: Any) -> None: pass


def install_stubs(repo_root: Path, temp_root: Path) -> None:
    polylogue_root = repo_root / "polylogue"
    browser_root = polylogue_root / "browser_capture"
    install_package("polylogue", polylogue_root)
    install_package("polylogue.browser_capture", browser_root)
    install_package("polylogue.archive")
    install_package("polylogue.archive.message")
    install_module("polylogue.archive.message.roles", Role=Role)
    install_package("polylogue.core")
    install_module("polylogue.core.enums", Provider=Provider)
    install_module(
        "polylogue.core.json",
        is_json_document=lambda value: isinstance(value, dict),
        json_document=lambda value: value if isinstance(value, dict) else {},
        dumps_bytes=lambda value, option=None: json.dumps(
            value, separators=(",", ":"), sort_keys=True
        ).encode("utf-8"),
    )
    install_module(
        "polylogue.core.hashing",
        hash_text_short=lambda value, length=12: hashlib.sha256(value.encode("utf-8")).hexdigest()[:length],
    )
    install_module(
        "polylogue.core.timestamps",
        parse_timestamp=lambda value: datetime.fromisoformat(str(value).replace("Z", "+00:00")) if value else None,
    )
    install_module(
        "polylogue.core.loopback",
        is_loopback_host=lambda host: host in {"127.0.0.1", "::1", "localhost"},
    )
    install_module("polylogue.logging", get_logger=lambda _name: DummyLogger())
    install_module(
        "polylogue.paths",
        archive_root=lambda: temp_root / "archive",
        browser_capture_receiver_token_path=lambda: temp_root / "receiver-token",
        browser_capture_spool_root=lambda: temp_root / "spool",
    )

    launch = install_module("polylogue.browser_capture.launch_jobs")
    for exc_name in (
        "BrowserLaunchConflictError",
        "BrowserLaunchLeaseError",
        "BrowserLaunchQuotaError",
        "BrowserLaunchStateError",
    ):
        setattr(launch, exc_name, type(exc_name, (RuntimeError,), {}))
    for fn_name in (
        "claim_due_launch_job",
        "control_launch_job",
        "enqueue_launch_job",
        "list_launch_jobs",
        "read_launch_attachment",
        "reconcile_launch_handoff_capture",
        "update_launch_job",
    ):
        setattr(launch, fn_name, lambda *_args, **_kwargs: None)


def request_json(host: str, port: int, *, token: str | None, request_id: str) -> tuple[int, dict[str, Any], str | None]:
    connection = HTTPConnection(host, port, timeout=5)
    headers = {
        "Origin": "chrome-extension://pairing-isolated-smoke",
        "X-Request-ID": request_id,
    }
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    connection.request("GET", "/v1/status", headers=headers)
    response = connection.getresponse()
    raw = response.read()
    echoed = response.getheader("X-Request-ID")
    status = response.status
    connection.close()
    return status, json.loads(raw), echoed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo_root", type=Path)
    args = parser.parse_args()
    repo_root = args.repo_root.resolve()
    browser_root = repo_root / "polylogue" / "browser_capture"
    for required in ("models.py", "receiver.py", "server.py"):
        if not (browser_root / required).is_file():
            raise SystemExit(f"missing supplied module: {browser_root / required}")

    with tempfile.TemporaryDirectory(prefix="polylogue-pairing-isolated-") as temp:
        temp_root = Path(temp)
        install_stubs(repo_root, temp_root)
        models = load_module("polylogue.browser_capture.models", browser_root / "models.py")
        receiver = load_module("polylogue.browser_capture.receiver", browser_root / "receiver.py")
        server_module = load_module("polylogue.browser_capture.server", browser_root / "server.py")

        token = "stable-high-entropy-pairing-root-for-isolated-proof"
        first = receiver.BrowserCaptureReceiverConfig(spool_path=temp_root / "spool-a", auth_token=token)
        restarted = receiver.BrowserCaptureReceiverConfig(spool_path=temp_root / "spool-b", auth_token=token)
        rotated = receiver.BrowserCaptureReceiverConfig(spool_path=temp_root / "spool-a", auth_token=f"{token}-rotated")
        stable_id = receiver.receiver_identity(first)
        assert stable_id == receiver.receiver_identity(restarted)
        assert stable_id != receiver.receiver_identity(rotated)
        assert token not in stable_id
        assert stable_id.startswith("rx-") and len(stable_id) == 23

        no_auth_a = receiver.BrowserCaptureReceiverConfig(spool_path=temp_root / "same" / ".." / "open-spool")
        no_auth_b = receiver.BrowserCaptureReceiverConfig(spool_path=temp_root / "open-spool")
        no_auth_other = receiver.BrowserCaptureReceiverConfig(spool_path=temp_root / "other-open-spool")
        assert receiver.receiver_identity(no_auth_a) == receiver.receiver_identity(no_auth_b)
        assert receiver.receiver_identity(no_auth_a) != receiver.receiver_identity(no_auth_other)

        typed = models.BrowserCaptureReceiverStatusPayload.model_validate(receiver.receiver_status_payload(first))
        assert typed.api_schema == "polylogue-browser-capture/v1"
        assert typed.receiver_id == stable_id
        assert typed.auth_required is True
        assert token not in json.dumps(typed.model_dump(mode="json"))

        http_server = server_module.make_server(
            "127.0.0.1",
            0,
            spool_path=temp_root / "http-spool",
            auth_token=token,
        )
        thread = threading.Thread(target=http_server.serve_forever, daemon=True)
        thread.start()
        try:
            host, port = http_server.server_address
            status, body, echoed = request_json(host, port, token=token, request_id="pairing-proof-ok")
            assert status == 200
            assert echoed == "pairing-proof-ok"
            routed = models.BrowserCaptureReceiverStatusPayload.model_validate(body)
            assert routed.api_schema == "polylogue-browser-capture/v1"
            assert routed.receiver_id == stable_id
            assert token not in json.dumps(body)

            denied_status, denied, denied_echo = request_json(
                host, port, token=None, request_id="pairing-proof-denied"
            )
            assert denied_status == 401
            assert denied_echo == "pairing-proof-denied"
            assert denied.get("error") == "unauthorized"
            assert "receiver_id" not in denied
            assert token not in json.dumps(denied)
        finally:
            http_server.shutdown()
            http_server.server_close()
            thread.join(timeout=5)

        print(json.dumps({
            "ok": True,
            "actual_modules_executed": [
                "polylogue/browser_capture/models.py",
                "polylogue/browser_capture/receiver.py",
                "polylogue/browser_capture/server.py",
            ],
            "api_schema": typed.api_schema,
            "receiver_id": stable_id,
            "stable_across_spool_move": True,
            "changes_on_token_rotation": True,
            "http_status_route": "200 authenticated / 401 unauthenticated",
            "token_disclosed": False,
            "stub_boundary": "only modules omitted from supplied partial snapshot",
        }, sort_keys=True))


if __name__ == "__main__":
    main()
