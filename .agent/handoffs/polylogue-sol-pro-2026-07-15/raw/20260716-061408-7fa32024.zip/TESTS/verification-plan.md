# Executable verification plan

Run from a complete repository after applying the patches.

## Browser extension

```bash
cd browser-extension
npm ci
npm test
npm run lint
npm run validate
npm run build -- --version 0.1.0 --out /tmp/polylogue-build-proof --no-source-sync
```

The explicit version is required only for this supplied partial snapshot, which omits the root `pyproject.toml` used by the build script's normal version discovery.

Focused trust/ambient loop:

```bash
npx vitest run \
  tests/operator_status.test.js \
  tests/content/ambient_surface.test.js \
  tests/background.test.js \
  tests/popup.test.js
```

## Receiver in a complete checkout

Use the repository-managed affected-test command required by its contributor instructions, for example:

```bash
devtools test tests/unit/browser_capture/test_receiver.py
```

The standalone fallback included here exercises the actual changed `models.py`, `receiver.py`, and `server.py` while stubbing only modules omitted from the partial snapshot:

```bash
python3 TESTS/receiver_pairing_isolated_smoke.py /path/to/applied/repository
```

## Static safety checks

- Reject duplicate, absolute, backslash, traversal, and symlink entries in built ZIP/XPI files.
- Scan `manifest.json` and `src/` for remote HTML/CSS assets and dynamic code execution.
- Confirm `polylogue/browser_capture/launch_jobs.py` and `tests/unit/browser_capture/test_launch_jobs.py` match the supplied dirty snapshot.
- Run `git diff --check` and both patch application modes described in `PATCHES/SERIES.md`.

## Packaged browser proof still required

Load the actual ZIP/XPI in isolated profiles and verify layout, light/dark, focus, reduced motion, disabled-site behavior, receiver restart/mismatch, and exact Sol Pro safeguards against a real authenticated provider page. This environment did not contain the operator's browser, cookies, daemon, archive, or secrets.
