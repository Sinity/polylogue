# Anti-vacuity proof

Three deliberate source mutations were made one at a time in the tested implementation. Each mutation was required to produce a non-zero focused test run; the original file was restored byte-for-byte afterward.

| Mutation | Command | Observed failure |
|---|---|---|
| Change canonical `Safe / current` label to `Safe / stale` | `npx vitest run tests/operator_status.test.js tests/content/ambient_surface.test.js tests/popup.test.js` | 4 failures across all three surfaces: canonical mapping, popup pipeline mapping/fidelity, and ambient shared rendering |
| Disable the receiver-ID inequality branch so a different receiver is accepted | `npx vitest run tests/background.test.js -t 'fails closed before a paired capture reaches a different receiver'` | Expected `{ok:false,error:'receiver_pairing_mismatch'}` but received a successful capture result |
| Change both assertion-button assignments from disabled to enabled | `npx vitest run tests/content/ambient_surface.test.js -t 'renders the same conversation, receiver, event, queue, assertion, and reverse contracts as the popup'` | Expected the assertion control to be disabled but received `false` |

After restoration, a focused run of operator status, ambient, and background tests passed **85/85**. This proves the new tests are sensitive to the central vocabulary, pairing fail-closed behavior, and honest assertion seam rather than merely asserting that files load.
