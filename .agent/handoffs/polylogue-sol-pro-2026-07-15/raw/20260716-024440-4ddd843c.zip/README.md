# Polylogue Definition Closure launch handoff

This archive is a reviewable patch handoff for Bead `polylogue-9e5.31.1` against immutable base revision `5abb30afc0b30348c4332ede1e592704e971f0a8` on source branch `feature/browser/sol-pro-dispatch`.

The supplied snapshot reported only one pre-existing dirty path: `.beads/issues.jsonl` (`MM`). The patch series does not read, modify, or overwrite that path. It changes only two existing repository files plus one architecture document, and adds two `devtools` modules and one focused test module.

## Read order

1. `SUMMARY.md` — executive result and acceptance-criteria matrix.
2. `DESIGN/definition-closure-design.md` — graph model, authority/evidence split, policy behavior, and extension method.
3. `DESIGN/source-evidence.md` — exact production sources inspected at the recorded commit and source-supported conclusions.
4. `VERIFICATION-LIMITS.md` — exact verification boundary.
5. `PATCHES/SERIES.md` — patch contents and apply sequence.
6. `TESTS/verification-plan.md` — commands to rerun in a complete checkout.

## Apply order

From a clean checkout at `5abb30afc0b30348c4332ede1e592704e971f0a8`, preserve any local `.beads/issues.jsonl` work and apply:

```bash
git apply --check PATCHES/0001-add-definition-closure-kernel.patch
git apply PATCHES/0001-add-definition-closure-kernel.patch

git apply --check PATCHES/0002-wire-representative-closure-policies.patch
git apply PATCHES/0002-wire-representative-closure-policies.patch

git apply --check PATCHES/0003-add-closure-mutation-tests.patch
git apply PATCHES/0003-add-closure-mutation-tests.patch
```

The patches were independently reapplied in this order to a fresh copy of the supplied source snapshot and every resulting changed file was compared byte-for-byte with the verified implementation.

## Verification order in the complete repository

```bash
devtools test tests/unit/devtools/test_definition_closure.py
devtools test tests/unit/devtools/test_artifact_graph.py
devtools lab graph --json
devtools verify --quick
```

`devtools lab graph` is already listed in `VERIFICATION_LAB_COMMAND_NAMES`; the patch makes its normal entrypoint fail on missing, unavailable, tests-only, bypass, or divergent definition closure. `--strict` continues to add the pre-existing scenario-coverage strictness.

No new `polylogue/` module is added, so topology projection regeneration is not required. No new devtools command is added, so command-catalog/generated devtools-reference regeneration is not required.
