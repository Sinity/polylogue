# Verification limits

## What was run

- Read the complete selected Bead record `polylogue-9e5.31.1`, repository instructions, selected architecture/code/tests, base revision, branch, status, and zero-byte selected source patches.
- Inspected exact production sources for all five policy families at commit `5abb30afc0b30348c4332ede1e592704e971f0a8`.
- Built and evaluated the representative graph against those sources: status `closed`; 5 policies; 5 definitions; 49 edges; 72 evidence refs; 21/21 satisfied findings.
- Ran the focused closure test file: 10 passed.
- Ran ruff checking on all touched Python files.
- Ran ruff format checking on the three new/fully formatted files.
- Ran strict mypy on the kernel, policy adapters, and focused test module.
- Ran Python bytecode compilation on every touched Python file.
- Exercised `devtools/artifact_graph.py` with isolated stubs for the omitted artifact/scenario dependencies while using the real closure report; text/JSON integration and `main([]) == 0` passed.
- Generated the report twice and confirmed byte-for-byte determinism.
- Profiled a no-site report run: 0.39 seconds elapsed, 67,436 KiB maximum RSS, exit 0 in this container.
- Applied all three patches with `git apply --check` and `git apply` to a fresh copy of the supplied snapshot, then compared every changed file byte-for-byte with the tested implementation.
- Reopened and validated the final ZIP after creation; the final response reports its exact byte size and entry count.

## What was not run

- `devtools verify --quick`, because the immutable pack contains only eight selected repository files and omits the full generated surfaces, configuration, command harness, and dependency graph required by that command.
- The existing full `tests/unit/devtools/test_artifact_graph.py` route against the real artifact/scenario modules, because those modules were not supplied as a complete importable repository. The integration-specific behavior was exercised with isolated stubs; the complete-checkout rerun remains required.
- Full pytest, broad unit directories, property/integration/benchmark/fuzz suites, or testmon selection.
- The operator’s live browser extension, daemon, secrets, archive databases, network listeners, NixOS deployment, or private data.
- Any schema migration, generated-surface render, topology projection, or live database mutation; the patch does not require those changes.
- Beads mutation or parent-Bead retrieval. The parent `polylogue-9e5.31` record was absent from the supplied snapshot.

## Residual verification boundary

A maintainer must apply the series in a complete checkout at the recorded base and run the four commands in `TESTS/verification-plan.md`. The likely conflict points are only concurrent edits to `devtools/artifact_graph.py`, `docs/architecture-spine.md`, or `tests/unit/devtools/test_artifact_graph.py`; the pre-existing `.beads/issues.jsonl` dirty state is non-overlapping and intentionally untouched.

The policies are representative, not exhaustive. Future definitions remain unguarded until a new policy references their authoritative inventory and supplies independent production evidence plus an anti-vacuity mutation.
