# Definition closure design

## Goal

Convert the completed wiring-census method into an executable invariant: a domain definition is closed only when independent production evidence proves every required wiring edge. The mechanism must fail when real wiring is removed even if the authoritative declaration itself remains internally consistent.

## Authority/evidence split

A `ClosurePolicy` points to one domain-owned `InventoryRef`. The inventory answers **what definitions exist**. The devtools adapter answers **where production proves their wiring**. Those sources are intentionally distinct.

Examples:

- `RUNTIME_OPERATION_SPECS` identifies the ingest and archive-debt operations; independent AST resolution proves parser, writer, lifecycle, CLI, API, HTTP, and MCP definitions and call routes.
- `_DAEMON_EVENTS_DDL` identifies the event ledger; independent SQL literals and function calls prove bootstrap, persistence, producers, and readers.
- `INSIGHT_REGISTRY` identifies the descriptor registry; independent `register(InsightType(...))` calls and actual CLI/MCP symbol usage prove declaration and consumption.
- `QUERY_UNIT_DESCRIPTORS` identifies query units; independent parser, terminal/attached execution, and concrete `surface_payloads[descriptor.payload_model]` resolution prove parse-to-render closure.

Domain modules never import `devtools`. Future policy adapters read stable public or authored source structures and project evidence into the graph.

## Typed model

`DefinitionClosureGraph` contains:

- `DefinitionNode`: stable definition ref, kind, authoritative inventory ref, policy scopes, label.
- `ClosureEdge`: typed edge kind, source definition, target ref, role, evidence tuple, and direct/bypass/divergent quality.
- `EvidenceRef`: stable path/line/symbol ref, origin (`production`, `test`, `generated`, `live`, `synthetic`), and detail.
- `UnavailableEvidence`: an explicit reason that source or inventory could not be inspected; absence is never interpreted as success.
- `ClosureException`: definition/edge/role absence authorized by a named authority and accepted only when the policy allowlists that authority.
- `ClosureRequirement`: required edge kind, roles, minimum evidence per role, allowed origins, optional convergence target bound, and repair text.
- `RepairDiagnostic`: stable code of the form `<status>:<definition>:<edge>:<role>`, message, repair action, targets, and evidence refs.

The evaluator emits `satisfied`, `intentional`, `unavailable`, `missing`, `tests-only`, `bypass`, or `divergent`. `missing`, `tests-only`, `bypass`, and `divergent` are blocking; the verification entrypoint also treats `unavailable` as blocking. Every evidence ref in a satisfying edge must come from an allowed origin, preventing a production wrapper from laundering a test/synthetic dependency.

## Bounded execution

`ClosureLimits` bounds:

- policies/definitions via `max_nodes`;
- graph edges, unavailable entries, exceptions, and findings via `max_edges`;
- evidence refs via `max_evidence_refs`;
- enumerated source files via `max_source_files`;
- individual and aggregate source bytes via `max_source_bytes` and `max_total_source_bytes`.

`PythonSourceIndex` rejects root escape, oversized source, excessive enumeration, ambiguous dotted symbols, missing symbols, and syntax failures as explicit unavailable evidence. It resolves top-level, class-member, and unique nested definitions; the latter is required for the real MCP `archive_debt` tool nested in `server_tools.register_tools`.

## Representative policies

### Storage/lifecycle — `storage.raw-ingest-lifecycle`

The adapter selects the operation semantically from `RUNTIME_OPERATION_SPECS`: it must consume validation/parse backlog artifacts, produce archive rows, and mutate state. It then resolves the independently authored parser, archive writer, and raw-state lifecycle definitions. Required roles are parser, archive writer, validated, and parsed.

### Event/write-effect — `event.daemon-ledger`

The authority is `_DAEMON_EVENTS_DDL`. Required evidence is bootstrap through `_ensure_events_db`, an `INSERT INTO daemon_events` writer, at least one production helper calling `emit_daemon_event`, and at least one production `FROM daemon_events` reader. The reader scan includes test locations only to classify a mutation as `tests-only`, never to satisfy production closure.

### Declaration/registry — `registry.insight-surfaces`

The registry assignment is authoritative. Registration requires an actual `register(InsightType(...))` AST shape. CLI and MCP roles require both an import from `polylogue.insights.registry` and load-use of the expected imported symbols; an unused declaration/import cannot satisfy closure.

### Query parse-to-render — `query.parse-to-render`

The exact base uses `polylogue/archive/query/metadata.py:QUERY_UNIT_DESCRIPTORS` as authority. The policy requires descriptor registration, expression parsing, terminal and attached-unit execution, and terminal/attached rendering. Rendering evidence is the concrete `getattr(surface_payloads, descriptor.payload_model, ...)` connection, not mere presence of both names in a file.

### Cross-surface semantic operation — `operation.archive-debt-surfaces`

The adapter selects the operation by its produced `archive_debt_results` artifact and required surfaces, then resolves the shared `archive_debt_list` operation. CLI and Python routes require a call whose symbol is bound by an import from `polylogue.operations.archive_debt`. HTTP and MCP require a recognized public-facade call and then reuse the independently proven Python route. All four roles must converge on one target; alternate archive-debt calls become `divergent`, and a handler that no longer reaches the shared operation becomes `bypass`.

## Entry-point integration

The existing `devtools lab graph` command remains the sole command surface. Its JSON payload gains `definition_closure`; text output gains a matrix section. The normal command exits nonzero for blocking or unavailable closure, so the check participates in the existing `VERIFICATION_LAB_COMMAND_NAMES` lane. Existing `--strict` scenario-coverage behavior remains additive.

No command-catalog entry is added, avoiding generated devtools-reference churn. No file under `polylogue/` is added, avoiding topology-projection churn.

## Future policy declaration

A future policy should:

1. Reference a stable domain-owned `InventoryRef`; do not mirror the entire inventory in devtools.
2. Select representative definitions by domain attributes, not a copied universal list.
3. Collect proof from independent production source, generated contracts, DDL, or live evidence.
4. Declare required edge kinds and roles plus a precise repair instruction.
5. Add an intentional absence only through a named authority explicitly allowlisted by the policy.
6. Add a copied-production mutation that removes the real edge while leaving the authority intact.
7. Stay inside explicit graph/source limits.

## Rejected alternatives

- **Universal closure registry in domain code:** couples runtime packages to verification and creates a second source of truth.
- **Self-authorized catalog check:** deriving both inventory and evidence from the same registry can remain green after production wiring disappears.
- **Import-only completeness:** unused imports are not consumers; the registry policy requires load-use.
- **String-only semantic convergence:** same-name calls can bind to twins; direct archive-debt routes require the exact shared import and transitive routes require the public facade.
- **Tests as production evidence:** test/synthetic origins are reported as `tests-only` unless a policy explicitly allows them.
- **Unbounded repository crawl:** all source resolution and enumeration is bounded and path-confined.
