# Source evidence and assumptions

## Immutable scope

The supplied pack records base revision `5abb30afc0b30348c4332ede1e592704e971f0a8`, branch `feature/browser/sol-pro-dispatch`, and source-footprint patches of zero bytes. The working-tree status contains only `MM .beads/issues.jsonl`; this handoff deliberately excludes Beads mutation.

The pack contains the complete selected child Bead `polylogue-9e5.31.1`, including design and acceptance criteria. Its parent `polylogue-9e5.31` record and related plan files were not present, so no claim is made that their text was reviewed. The child record, repository instructions, selected architecture source, and exact production files below were used as the decision basis.

## Exact production-source augmentation

The immutable pack is intentionally narrow and omits the production files referenced by `OperationSpec.code_refs`. Those files were inspected from the public repository at the exact recorded commit, not from moving `master`. Primary source URL prefix:

`https://github.com/Sinity/polylogue/blob/5abb30afc0b30348c4332ede1e592704e971f0a8/`

Access date: **2026-07-15**.

Key source-supported findings:

| Family | Authoritative source | Independent evidence inspected | Decision |
|---|---|---|---|
| Storage/lifecycle | `polylogue/operations/specs.py` | `pipeline/services/parsing_workflow.py`, `storage/sqlite/archive_tiers/write.py`, `storage/repository/raw/repository_raw.py` | Select ingest by artifacts/effect; prove parser, writer, validated, parsed roles. |
| Event/write-effect | `polylogue/daemon/events.py:_DAEMON_EVENTS_DDL` | Same module’s bootstrap/INSERT/helper calls/SELECT readers, plus bounded test-pattern scan for classification | Model one event-ledger definition with lifecycle, persistence, producer, and reader edges. |
| Registry/declaration | `polylogue/insights/registry.py:INSIGHT_REGISTRY` | Registry `register(InsightType(...))`, `cli/commands/insights.py`, `mcp/server_insight_tools.py` | Require real descriptor construction and actual imported-symbol use in both surfaces. |
| Query | `polylogue/archive/query/metadata.py:QUERY_UNIT_DESCRIPTORS` | `expression.py`, `unit_results.py`, `attached_units.py` | The current authority is `metadata.py`, not older `units.py` planning vocabulary; require parse, execute, and typed payload resolution. |
| Semantic operation | `polylogue/operations/specs.py` archive-debt operation | `operations/archive_debt.py`, CLI, API, daemon HTTP, MCP server tools | CLI/Python reach shared operation directly; HTTP/MCP transit the public Python facade; all converge on `archive_debt_list`. |

`TESTS/source-receipt.tsv` records path, byte count, line count, and SHA-256 for every production file inspected by the representative policy builder.

## Important exact-source corrections

- Query-unit authority is `polylogue/archive/query/metadata.py:QUERY_UNIT_DESCRIPTORS` at the base revision.
- The MCP archive-debt tool is a nested function in `polylogue/mcp/server_tools.py`; it is not supplied by the generic insight-tool registry loop.
- The API method imports `archive_debt_list` inside the method body; the CLI imports it at module scope. The route resolver therefore checks the whole candidate module for symbol binding and the selected function for the actual call.
- The HTTP handler calls `Polylogue(...).archive_debt`; the MCP tool calls `hooks.get_polylogue().archive_debt`. Those are treated as transitive facade routes, not direct shared-operation calls.

## Inferences and proposals

- **Inference:** Reusing `devtools lab graph` is the least-coupled verification gate because it is already in `VERIFICATION_LAB_COMMAND_NAMES` and already renders artifact/operation coverage.
- **Proposal implemented:** Representative policy adapters remain in `devtools`; broad adoption should add policies incrementally rather than create a universal inventory.
- **Proposal implemented:** Unavailable source is a first-class status and blocks the verification entrypoint, preventing narrow/synthetic runs from claiming production closure.
