# Patch series

Base: `5abb30afc0b30348c4332ede1e592704e971f0a8`

The series is ordered and must be applied sequentially.

1. `0001-add-definition-closure-kernel.patch`
   - Adds `devtools/definition_closure.py`.
   - Contains only verification-domain types, evaluator, diagnostics, bounded graph builder, and bounded AST source index.

2. `0002-wire-representative-closure-policies.patch`
   - Adds `devtools/definition_closure_policies.py`.
   - Modifies `devtools/artifact_graph.py` to render JSON/text closure status and fail the existing verification-lab entrypoint on closure failure.
   - Records the architecture decision in `docs/architecture-spine.md`.

3. `0003-add-closure-mutation-tests.patch`
   - Adds `tests/unit/devtools/test_definition_closure.py`.
   - Extends `tests/unit/devtools/test_artifact_graph.py` with text/JSON closure assertions.

Patch SHA-256 values:

```text
2bfca18845d30d800d8a5dd44d1d81b36598be7f37dacac7734e0e1817004041  0001-add-definition-closure-kernel.patch
89ec4fe0eb8bc975003a7ddebcddcd17fbd27a557772b3df28a1412e72bec867  0002-wire-representative-closure-policies.patch
e477ff649082351304e75f0d3bdb09a3887cc5ce70ecdfc32fc5ab2f2a26c0c6  0003-add-closure-mutation-tests.patch
```

`TESTS/patch-apply.txt` records successful `git apply --check` runs and byte-for-byte reproduction against a fresh copy of the supplied source snapshot.
