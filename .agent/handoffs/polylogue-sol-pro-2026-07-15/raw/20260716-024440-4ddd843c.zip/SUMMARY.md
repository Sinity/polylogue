# Executive result

The handoff implements a verification-owned `DefinitionClosureGraph` kernel and five production-backed policies without introducing a universal domain registry. Domain declarations remain authoritative; independent AST, DDL, import, call-route, and source-origin evidence proves that each selected definition reaches its required production wiring.

The existing `devtools lab graph` output gains a deterministic `definition_closure` JSON object and a human-readable matrix. Its normal exit status now blocks on missing, unavailable, tests-only, bypass, or divergent closure evidence, which places the check in the existing verification-lab command set without adding a new command or generated-reference surface.

The exact recorded production sources close with 5 policies, 5 authoritative definitions, 49 edges, 72 evidence refs, and 21/21 satisfied matrix cells. Five copied-production mutations produce stable, definition-specific failures for deleted producer, tests-only consumer substitution, removed lifecycle transition, shared-substrate bypass, and divergent surface twin.

## Patch contents

| Patch | Result |
|---|---|
| `0001-add-definition-closure-kernel.patch` | Typed graph, policies, evidence origins, exceptions, evaluator statuses/diagnostics, bounded builder, and bounded Python AST source index. |
| `0002-wire-representative-closure-policies.patch` | Five production policies, deterministic report, `lab graph` integration, verification-lab exit behavior, and architecture decision. |
| `0003-add-closure-mutation-tests.patch` | Real-source policy test, five anti-vacuity mutations, evidence-mode/exception/bounds tests, and artifact-graph output assertions. |

## Acceptance-criteria matrix

| AC | Status | Durable evidence |
|---|---|---|
| 1. Types express inventory authority, required edges, evidence, exception authority, status, and repair diagnostics without a universal registry. | Satisfied | `devtools/definition_closure.py`; design sections “Typed model” and “Authority/evidence split”. |
| 2. Storage/lifecycle, event, registry/declaration, query, and cross-surface operation policies evaluate production source and expose JSON/matrix output. | Satisfied | `devtools/definition_closure_policies.py`; `TESTS/definition-closure-report.json` shows five closed policies and 21 satisfied rows. |
| 3. Producer deletion, tests-only consumer, shared-substrate bypass, lifecycle deletion, and divergent twins fail with exact definition/edge. | Satisfied | `tests/unit/devtools/test_definition_closure.py`; `TESTS/mutation-evidence.json` records stable diagnostic codes. |
| 4. Empty/synthetic/live/intentional modes remain distinct. | Satisfied | Focused tests cover `unavailable`, `tests-only`, `satisfied` live evidence, and authorized `intentional` absence. An empty representative source tree produces one `unavailable` inventory finding per policy. |
| 5. Entry point is bounded, verification-gated, and focused checks plus `devtools verify --quick` pass. | Implemented; full-checkout verification pending | Hard limits and source-enumeration mutation test are present; `lab graph` is already in the verification-lab set; focused pytest/ruff/mypy/compile/apply checks pass. `devtools verify --quick` could not run because the supplied immutable pack omits the full repository and its generated surfaces. |

## Scope discipline

The patches do not alter `.beads/issues.jsonl`, domain registries, runtime database code, schemas, topology manifests, generated docs, or public API contracts. Broad policy adoption remains outside this representative-kernel slice.
