# Verification plan and captured results

## Captured self-contained checks

The following commands were run against the patched implementation plus the exact production source files needed by the five policies:

```bash
ruff check devtools/definition_closure.py devtools/definition_closure_policies.py devtools/artifact_graph.py tests/unit/devtools/test_definition_closure.py tests/unit/devtools/test_artifact_graph.py
ruff format --check devtools/definition_closure.py devtools/definition_closure_policies.py tests/unit/devtools/test_definition_closure.py
MYPYPATH=. mypy --strict --explicit-package-bases devtools/definition_closure.py devtools/definition_closure_policies.py tests/unit/devtools/test_definition_closure.py
PYTHONPATH=. pytest -q tests/unit/devtools/test_definition_closure.py
python -m py_compile devtools/definition_closure.py devtools/definition_closure_policies.py devtools/artifact_graph.py tests/unit/devtools/test_definition_closure.py tests/unit/devtools/test_artifact_graph.py
```

Captured results are in the adjacent text files. The focused pytest result is `10 passed`.

The report was generated twice with `python -S`; byte comparison succeeded. `definition-closure-report.json` has status `closed`, 5 policies, 49 edges, 72 evidence refs, and 21 satisfied findings.

`mutation-evidence.json` records the exact stable outcomes:

- deleted archive producer → `missing:operation:ingest-archive-runtime:produces:archive-writer`
- test-only event reader → `tests-only:event-ledger:daemon_events:consumes:reader`
- removed parsed lifecycle method → `missing:operation:ingest-archive-runtime:lifecycle:parsed`
- Python archive-debt bypass → `bypass:operation:query-archive-debt:delegates:python`
- divergent MCP twin → `divergent:operation:query-archive-debt:delegates:mcp`

Patch application was checked sequentially against a fresh snapshot copy; see `patch-apply.txt`.

## Required complete-checkout rerun

After applying the patches to a complete checkout at the recorded base:

```bash
devtools test tests/unit/devtools/test_definition_closure.py
devtools test tests/unit/devtools/test_artifact_graph.py
devtools lab graph --json > /tmp/definition-closure-graph.json
devtools verify --quick
```

Review `/tmp/definition-closure-graph.json` and confirm:

```text
definition_closure.status == "closed"
definition_closure.summary.policy_count == 5
all matrix rows have status "satisfied" (unless a separately reviewed intentional exception is added)
```

Do not run broad test directories solely for this patch; repository guidance prefers focused selections and the testmon-based default verification path.
