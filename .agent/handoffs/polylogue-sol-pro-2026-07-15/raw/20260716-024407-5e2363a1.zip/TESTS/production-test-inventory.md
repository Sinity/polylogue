# Production-route test inventory

These are the supplied tests that reference the real lineage repository/storage path. The executable runner treats an empty collection as failure, so a green command cannot be vacuous.

## `REPO/tests/property/test_write_path_state_machine.py`

Relevant tokens: session_links, evidence_json, variant_index, lineage, branch_point

### `test_session_link_resolver_quarantines_cycle` at line 484

```
def test_session_link_resolver_quarantines_cycle() -> None:
    """The async resolver quarantines a late link that would close a cycle."""
    with tempfile.TemporaryDirectory(prefix="polylogue-write-model-", dir="/realm/tmp") as root_text:
        archive_root = Path(root_text)
        initialize_active_archive_root(archive_root)
        db_path = archive_root / "index.db"
        conn = sqlite3.connect(str(db_path))
        try:
            parent = ParsedSession(
                source_name=Provider.CLAUDE_CODE,
                provider_session_id="cycle-parent",
                messages=[ParsedMessage(provider_message_id="parent-0", role=Role.USER, text="parent", position=0)],
            )
            child = ParsedSession(
                source_name=Provider.CLAUDE_CODE,
                provider_session_id="cycle-child",
                parent_session_provider_id="cycle-parent",
                branch_type=BranchType.FORK,
                messages=[ParsedMessage(provider_message_id="child-0", role=Role.USER, text="child", position=0)],
            )
            parent_id = write_parsed_session_to_archive(conn, parent, content_hash=session_content_hash(parent))
            write_parsed_session_to_archive(conn, child, content_hash=session_content_hash(child))
            conn.execute(
                """
                INSERT INTO session_links (
                    src_session_id, dst_origin, dst_native_id, link_type,
                    status, method, confidence, evidence_json, observed_at_ms
                ) VALUES (?, 'claude-code-session', 'cycle-child', 'fork', NULL, 'test', 1.0, '[]', 0)
                """,
                (parent_id,),
            )
            conn.commit()
        finally:
            conn.close()

        async def resolve_cycle() -> int:
            async with aiosqlite.connect(db_path) as async_conn:
                await configure_connection(async_conn)
                resolved = await resolve_unresolved_links_for_child(
                    async_conn,
                    src_session_id=parent_id,
                    resolved_at="2026-01-01T00:00:00Z",
                )
                await async_conn.commit()
            return resolved

        assert asyncio.run(resolve_cycle()) == 0
        with sqlite3.connect(str(db_path)) as verify_conn:
            row = verify_conn.execute(
                "SELECT resolved_dst_session_id, status, evidence_json FROM session_links WHERE src_session_id = ?",
```

### `_check_invariants` at line 369

```
    def _check_invariants(self) -> None:
        status_rows = self._conn.execute("SELECT status FROM session_links").fetchall()
        assert {row[0] for row in status_rows}.issubset(
            {None, TopologyEdgeStatus.REPAIRED.value, TopologyEdgeStatus.QUARANTINED.value}
        )

        indexed_docids = {row[0] for row in self._conn.execute("SELECT id FROM messages_fts_docsize").fetchall()}
        indexable_docids = {
            row[0] for row in self._conn.execute("SELECT rowid FROM blocks WHERE search_text != ''").fetchall()
        }
        assert indexed_docids == indexable_docids

        for session_id, model in self._models.items():
            pending = self._pending_children.get(session_id)
            if pending is not None:
                self._assert_pending_link(session_id, pending[0])
                continue
            envelope = read_archive_session_envelope(self._conn, session_id)
            actual = self._texts_from_envelope(envelope)
            if envelope.lineage_complete:
                assert actual == self._logical_texts(session_id)
            else:
                # #4ts.6: a dangling branch point may only return the child
                # tail or a surviving suffix; it must never over-extend the
                # model transcript with messages beyond that logical branch.
                logical = self._logical_texts(session_id)
                assert actual == logical[len(logical) - len(actual) :]

            if model.parent_id is not None and envelope.lineage_complete:
                self._assert_resolved_link(session_id, model)
                physical = self._conn.execute(
                    "SELECT COUNT(*) FROM messages WHERE session_id = ?", (session_id,)
                ).fetchone()[0]
                assert physical == len(model.own_texts)

            variant_rows = self._conn.execute(
                "SELECT position, variant_index FROM messages WHERE session_id = ?", (session_id,)
            ).fetchall()
            assert len({(int(row[0]), int(row[1])) for row in variant_rows}) == len(variant_rows)
```

### `delete_parent_branch_point` at line 248

```
    def delete_parent_branch_point(self) -> None:
        """Hard-delete a parent branch point: child reads must tail-truncate."""
        if self._deletion_done:
            return
        children = [
            (session_id, model)
            for session_id, model in self._models.items()
            if model.parent_id is not None
            and model.prefix_length > 0
            and self._models[model.parent_id].parent_id is None
            and self._models[model.parent_id].can_be_parent
        ]
        if not children:
            return
        child_id, child = children[self._next_text % len(children)]
        parent_id = child.parent_id
        assert parent_id is not None
        parent_messages = read_archive_session_envelope(self._conn, parent_id).messages
        branch_point = parent_messages[child.prefix_length - 1].message_id
        self._conn.execute("DELETE FROM messages WHERE message_id = ?", (branch_point,))
        self._conn.commit()
        self._deletion_done = True
        self._models[parent_id].own_texts.pop(child.prefix_length - 1)
        self._models[parent_id].can_be_parent = False
        for candidate_id, candidate in self._models.items():
            if self._has_ancestor(candidate_id, parent_id):
                candidate.can_be_parent = False

        envelope = read_archive_session_envelope(self._conn, child_id)
        assert envelope.lineage_complete is False
        assert self._texts_from_envelope(envelope) == child.own_texts
        self._check_invariants()
```

### `_assert_pending_link` at line 409

```
    def _assert_pending_link(self, child_id: str, parent_native_id: str) -> None:
        row = self._conn.execute(
            """
            SELECT resolved_dst_session_id, branch_point_message_id, inheritance, status
            FROM session_links
            WHERE src_session_id = ? AND dst_native_id = ?
            """,
            (child_id, parent_native_id),
        ).fetchone()
        assert tuple(row) == (None, None, None, None)
```

### `_assert_resolved_link` at line 420

```
    def _assert_resolved_link(self, child_id: str, model: _SessionModel) -> None:
        assert model.parent_id is not None
        row = self._conn.execute(
            """
            SELECT resolved_dst_session_id, branch_point_message_id, inheritance, status
            FROM session_links
            WHERE src_session_id = ?
            """,
            (child_id,),
        ).fetchone()
        assert row is not None
        assert row[0] == model.parent_id
        assert row[2] == ("prefix-sharing" if model.prefix_length else "spawned-fresh")
        assert row[3] is None
        if model.prefix_length:
            parent_messages = read_archive_session_envelope(self._conn, model.parent_id).messages
            assert row[1] == parent_messages[model.prefix_length - 1].message_id
        else:
            assert row[1] is None
```

### `full_replace_with_sibling_variants` at line 202

```
    def full_replace_with_sibling_variants(self) -> None:
        """A full replacement must preserve same-position variant ordering."""
        candidates = sorted(
            session_id
            for session_id, model in self._models.items()
            if model.parent_id is None
            and session_id not in self._pending_children
            and not any(other.parent_id == session_id for other in self._models.values())
        )
        if not candidates:
            return
        session_id = candidates[self._next_text % len(candidates)]
        model = self._models[session_id]
        variant_texts = [self._new_text("replace-primary"), self._new_text("replace-variant")]
        self._write(
            model.native_id,
            variant_texts,
            updated_at=self._fresh_timestamp(),
            message_id_prefix=f"replace-{model.appended_batches}",
            variant_batch=True,
        )
        model.own_texts = variant_texts
        model.can_be_parent = False
        rows = self._conn.execute(
            "SELECT position, variant_index FROM messages WHERE session_id = ? ORDER BY position, variant_index",
            (session_id,),
        ).fetchall()
        assert [tuple(row) for row in rows] == [(0, 0), (0, 1)]
        self._check_invariants()
```

### `_write` at line 287

```
    def _write(
        self,
        native_id: str,
        texts: list[str],
        *,
        parent_native_id: str | None = None,
        updated_at: str = "2026-01-01T00:00:00Z",
        merge_append: bool = False,
        message_id_prefix: str = "message",
        variant_batch: bool = False,
    ) -> str:
        parsed = ParsedSession(
            source_name=Provider.CLAUDE_CODE,
            provider_session_id=native_id,
            parent_session_provider_id=parent_native_id,
            branch_type=BranchType.FORK if parent_native_id else None,
            updated_at=updated_at,
            messages=[
                ParsedMessage(
                    provider_message_id=f"{native_id}-{message_id_prefix}-{index}",
                    role=Role.USER if index % 2 == 0 else Role.ASSISTANT,
                    text=text,
                    # Full snapshots use active-path messages.  Append windows
                    # add a sibling variant at one position, exercising the
                    # variant-index regeneration branch without pretending a
                    # sibling is part of a lineage-replayable prefix.
                    position=0 if variant_batch else index,
                    variant_index=index if variant_batch else 0,
                )
                for index, text in enumerate(texts)
            ],
        )
        return write_parsed_session_to_archive(
            self._conn,
            parsed,
            content_hash=session_content_hash(parsed),
            merge_append=merge_append,
        )
```

## `REPO/tests/unit/storage/test_lineage_normalization.py`

Relevant tokens: session_links, variant_index, lineage, branch_point

### `test_hermes_compression_tail_composes_and_delegate_stays_fresh` at line 915

```
def test_hermes_compression_tail_composes_and_delegate_stays_fresh(
    tmp_path: Path,
    end_reason: str,
) -> None:
    state_db = tmp_path / "state.db"
    with sqlite3.connect(state_db) as source:
        source.executescript(
            """
            CREATE TABLE schema_version(version INTEGER NOT NULL);
            INSERT INTO schema_version VALUES (16);
            CREATE TABLE sessions (
                id TEXT PRIMARY KEY,
                source TEXT,
                model_config TEXT,
                parent_session_id TEXT,
                started_at REAL,
                ended_at REAL,
                end_reason TEXT,
                title TEXT
            );
            CREATE TABLE messages (
                id INTEGER PRIMARY KEY,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT,
                timestamp REAL NOT NULL,
                tool_calls TEXT,
                observed INTEGER,
                active INTEGER,
                compacted INTEGER
            );
            INSERT INTO sessions VALUES
                ('parent', 'cli', '{}', NULL, 1.0, 3.0, 'compression', 'Parent'),
                ('continuation', 'cli', '{}', 'parent', 4.0, NULL, NULL, 'Continuation'),
                ('delegate', 'tool', '{}', 'parent', 5.0, NULL, NULL, 'Delegate');
            INSERT INTO messages VALUES
                (1, 'parent', 'user', 'before', 1.0, NULL, 0, 1, 0),
                (2, 'parent', 'assistant', 'summary', 2.0, NULL, 0, 1, 0),
                (3, 'continuation', 'user', 'after', 4.0, NULL, 0, 1, 0),
                (4, 'continuation', 'assistant', 'continued', 4.5, NULL, 0, 1, 0),
                (5, 'delegate', 'assistant', 'fresh work', 5.0, NULL, 0, 1, 0);
            """
        )
        source.execute(
            "UPDATE sessions SET model_config = ? WHERE id = 'delegate'",
            (json.dumps({"_delegate_from": "parent"}),),
        )
        source.execute(
            "UPDATE sessions SET end_reason = ? WHERE id = 'parent'",
            (end_reason,),
```

### `test_stale_immediate_parent_branch_point_repairs_to_composed_ancestor` at line 387

```
def test_stale_immediate_parent_branch_point_repairs_to_composed_ancestor(tmp_path: Path) -> None:
    db = tmp_path / "index.db"
    conn = _connect(db)

    ancestor = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="ancestor",
        title="ancestor",
        messages=[
            _msg("a0", Role.USER, "hello", 0),
            _msg("a1", Role.ASSISTANT, "hi there", 1),
        ],
    )
    ancestor_id = write_parsed_session_to_archive(conn, ancestor)
    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        parent_session_provider_id="ancestor",
        branch_type=BranchType.FORK,
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
        ],
    )
    parent_id = write_parsed_session_to_archive(conn, parent)
    assert conn.execute("SELECT COUNT(*) FROM messages WHERE session_id = ?", (parent_id,)).fetchone()[0] == 0

    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("c0", Role.USER, "hello", 0),
            _msg("c1", Role.ASSISTANT, "hi there", 1),
            _msg("c2", Role.USER, "child tail", 2),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)
    stale_branch_point = f"{parent_id}:a1"
    conn.execute(
        """
        UPDATE session_links
        SET branch_point_message_id = ?
        WHERE src_session_id = ?
        """,
        (stale_branch_point, child_id),
    )
```

### `test_stale_non_materialized_msg_branch_point_repairs_to_predecessor` at line 459

```
def test_stale_non_materialized_msg_branch_point_repairs_to_predecessor(tmp_path: Path) -> None:
    db = tmp_path / "index.db"
    conn = _connect(db)

    ancestor = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="ancestor",
        title="ancestor",
        messages=[
            _msg("msg-10", Role.USER, "inherited prompt", 0),
        ],
    )
    ancestor_id = write_parsed_session_to_archive(conn, ancestor)
    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        parent_session_provider_id="ancestor",
        branch_type=BranchType.FORK,
        messages=[
            _msg("msg-10", Role.USER, "inherited prompt", 0),
            _msg("msg-20", Role.USER, "parent tail", 1),
        ],
    )
    parent_id = write_parsed_session_to_archive(conn, parent)
    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("msg-10", Role.USER, "inherited prompt", 0),
            _msg("msg-21", Role.USER, "child tail", 1),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)

    conn.execute(
        """
        UPDATE session_links
        SET branch_point_message_id = ?
        WHERE src_session_id = ?
        """,
        (f"{parent_id}:msg-12", child_id),
    )
    conn.commit()
    assert [message.blocks[0].text for message in read_archive_session_envelope(conn, child_id).messages] == [
        "child tail"
    ]
```

### `test_sync_and_async_report_incomplete_on_dangling_branch_point` at line 1358

```
def test_sync_and_async_report_incomplete_on_dangling_branch_point(tmp_path: Path) -> None:
    """4ts.6: a dangling branch point (parent message hard-deleted) must
    report lineage_complete=False, not silently serve the child's own tail
    as if it were the whole transcript."""
    db = tmp_path / "index.db"
    conn = _connect(db)

    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
        ],
    )
    write_parsed_session_to_archive(conn, parent)

    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("c0", Role.USER, "hello", 0),
            _msg("c1", Role.ASSISTANT, "hi there", 1),
            _msg("cx", Role.USER, "child diverges", 2),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)

    # Hard-delete the parent's messages, leaving a dangling branch point --
    # session_links.branch_point_message_id is deliberately not a FK (see
    # module docstring), so this doesn't cascade-null the link.
    conn.execute("DELETE FROM messages WHERE session_id = (SELECT session_id FROM sessions WHERE native_id = 'parent')")
    conn.commit()

    envelope = read_archive_session_envelope(conn, child_id)
    assert envelope.lineage_complete is False
    assert envelope.lineage_truncation_reason == "dangling_branch_point"
    # The child's own tail is still returned, just flagged incomplete.
    assert ["".join(b.text or "" for b in m.blocks) for m in envelope.messages] == ["child diverges"]

    conn.close()

    async def _run() -> tuple[list[str | None], LineageCompleteness]:
        reader = await aiosqlite.connect(db)
        try:
            reader.row_factory = aiosqlite.Row
```

### `test_child_before_parent_is_reextracted_on_resolution` at line 331

```
def test_child_before_parent_is_reextracted_on_resolution(tmp_path: Path) -> None:
    """A prefix-sharing child ingested before its parent is stored whole, then
    normalized (inherited prefix deleted) once the parent arrives."""
    db = tmp_path / "index.db"
    conn = _connect(db)

    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("c0", Role.USER, "hello", 0),
            _msg("c1", Role.ASSISTANT, "hi there", 1),
            _msg("cx", Role.USER, "child diverges here", 2),
            _msg("cy", Role.ASSISTANT, "child reply", 3),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)
    # Parent absent → stored whole, edge not yet extracted.
    assert conn.execute("SELECT COUNT(*) FROM messages WHERE session_id = ?", (child_id,)).fetchone()[0] == 4
    assert (
        conn.execute("SELECT inheritance FROM session_links WHERE src_session_id = ?", (child_id,)).fetchone()[0]
        is None
    )

    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
            _msg("p2", Role.USER, "parent continues alone", 2),
        ],
    )
    write_parsed_session_to_archive(conn, parent)

    # Resolution re-extracted the child: only its tail remains, edge recorded.
    stored = conn.execute(
        "SELECT position FROM messages WHERE session_id = ? ORDER BY position", (child_id,)
    ).fetchall()
    assert [row[0] for row in stored] == [2, 3]
    link = conn.execute(
        "SELECT inheritance, branch_point_message_id FROM session_links WHERE src_session_id = ?",
        (child_id,),
    ).fetchone()
    assert link["inheritance"] == "prefix-sharing"
    assert link["branch_point_message_id"] is not None
```

### `test_parent_reingest_keeps_child_composing` at line 804

```
def test_parent_reingest_keeps_child_composing(tmp_path: Path) -> None:
    """Regression for the FK-cascade bug (#2467 audit H1): re-ingesting a parent
    via full replace must NOT null the child's branch point. branch_point_message_id
    is deliberately not a FK, so the deterministic message id survives the parent's
    DELETE+re-INSERT and the child keeps composing the full transcript."""
    db = tmp_path / "index.db"
    conn = _connect(db)

    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
        ],
    )
    write_parsed_session_to_archive(conn, parent)

    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("c0", Role.USER, "hello", 0),
            _msg("c1", Role.ASSISTANT, "hi there", 1),
            _msg("cx", Role.USER, "child diverges", 2),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)
    assert [
        "".join(b.text or "" for b in m.blocks) for m in read_archive_session_envelope(conn, child_id).messages
    ] == ["hello", "hi there", "child diverges"]

    # Parent grows and is re-ingested (full replace) — the common production case.
    parent_grown = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
            _msg("p2", Role.USER, "parent keeps going", 2),
        ],
    )
    write_parsed_session_to_archive(conn, parent_grown)

    # The child's branch point survived; it still composes the full transcript.
```

### `test_sync_report_incomplete_at_depth_limit` at line 1419

```
def test_sync_report_incomplete_at_depth_limit(tmp_path: Path) -> None:
    """4ts.6: a lineage chain deeper than _MAX_LINEAGE_DEPTH must report
    lineage_complete=False with reason depth_limit -- ancestors beyond the
    cutoff are silently dropped otherwise."""
    db = tmp_path / "index.db"
    conn = _connect(db)

    # Build a chain of _MAX_LINEAGE_DEPTH + 1 sessions, each forking from the
    # previous with a one-message divergent tail. The leaf is beyond the cutoff.
    provider_session_id = "root"
    write_parsed_session_to_archive(
        conn,
        ParsedSession(
            source_name=Provider.CODEX,
            provider_session_id=provider_session_id,
            title="root",
            messages=[_msg("root-0", Role.USER, "root message", 0)],
        ),
    )
    leaf_id = None
    for level in range(_MAX_LINEAGE_DEPTH + 1):
        child_provider_id = f"level-{level}"
        leaf_id = write_parsed_session_to_archive(
            conn,
            ParsedSession(
                source_name=Provider.CODEX,
                provider_session_id=child_provider_id,
                title=child_provider_id,
                parent_session_provider_id=provider_session_id,
                branch_type=BranchType.FORK,
                messages=[
                    _msg("root-0", Role.USER, "root message", 0),
                    _msg(f"tail-{level}", Role.ASSISTANT, f"level {level} tail", 1),
                ],
            ),
        )
        provider_session_id = child_provider_id
    assert leaf_id is not None

    envelope = read_archive_session_envelope(conn, leaf_id)
    assert envelope.lineage_complete is False
    assert envelope.lineage_truncation_reason == "depth_limit"

    conn.close()
```

### `test_prefix_sharing_child_stores_only_tail_and_composes` at line 79

```
def test_prefix_sharing_child_stores_only_tail_and_composes(tmp_path: Path) -> None:
    db = tmp_path / "index.db"
    conn = _connect(db)

    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
            _msg("p2", Role.USER, "parent continues alone", 2),
        ],
    )
    parent_id = write_parsed_session_to_archive(conn, parent)

    # Child forked after parent[1]: it replays p0/p1 (identical content, fresh
    # provider ids, as a real fork does) then diverges into its own work.
    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("c0", Role.USER, "hello", 0),
            _msg("c1", Role.ASSISTANT, "hi there", 1),
            _msg("cx", Role.USER, "child diverges here", 2),
            _msg("cy", Role.ASSISTANT, "child reply", 3),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)

    # Only the divergent tail is physically stored under the child, at its
    # original positions (2, 3) — the inherited prefix is not duplicated.
    stored = conn.execute(
        "SELECT position FROM messages WHERE session_id = ? ORDER BY position",
        (child_id,),
    ).fetchall()
    assert [row[0] for row in stored] == [2, 3]

    # Aggregate count reflects the child's own messages only (no double count).
    message_count = conn.execute(
        "SELECT message_count FROM sessions WHERE session_id = ?",
        (child_id,),
    ).fetchone()[0]
    assert message_count == 2

    # The lineage edge records the branch point and the inheritance kind.
    link = conn.execute(
```

## `REPO/tests/unit/storage/test_session_topology.py`

Relevant tokens: session_links, lineage, insight

### `test_topology_unresolved_native_parent_via_session_links` at line 133

```
async def test_topology_unresolved_native_parent_via_session_links(workspace_env: dict[str, Path]) -> None:
    db_path = db_setup(workspace_env)

    # An orphan: it asserts a native parent pointer whose parent
    # session has not been ingested, so the archive link resolver leaves
    # the session_links row unresolved (dst_session_id IS NULL). The topology
    # must surface this as an unresolved edge so late repair (#866 AC) has
    # something to reconcile.
    SessionBuilder(db_path, "orphan").provider("claude-code").title("Orphan child").parent_session(
        "missing-parent-uuid"
    ).add_message(role="user", text="orphan").save()

    polylogue = Polylogue(archive_root=workspace_env["archive_root"], db_path=db_path)
    try:
        topo = await polylogue.get_session_topology(_native("orphan"))
    finally:
        await polylogue.close()
    assert topo is not None
    # The orphan is its own topology root in the resolved subtree.
    assert str(topo.root_id) == _native("orphan")

    unresolved = topo.unresolved_edges()
    assert len(unresolved) == 1
    edge = unresolved[0]
    assert edge.resolved is False
    assert edge.parent_id is None
    assert edge.parent_native_id == "missing-parent-uuid"
    assert edge.kind is TopologyEdgeKind.UNRESOLVED_NATIVE
```

### `_seed_lineage` at line 35

```
def _seed_lineage(db_path: Path) -> None:
    """Seed: root → continuation child → fork grandchild, plus subagent + sidechain off the root."""

    SessionBuilder(db_path, "root").provider("claude-code").title("Root session").add_message(
        role="user", text="kickoff"
    ).save()

    SessionBuilder(db_path, "continuation").provider("claude-code").title("Resume").parent_session(
        "ext-root"
    ).branch_type("continuation").add_message(role="user", text="continue").save()

    SessionBuilder(db_path, "fork").provider("claude-code").title("Fork from continuation").parent_session(
        "ext-continuation"
    ).branch_type("fork").add_message(role="user", text="fork").save()

    SessionBuilder(db_path, "subagent").provider("claude-code").title("Subagent off root").parent_session(
        "ext-root"
    ).branch_type("subagent").add_message(role="assistant", text="agent").save()

    SessionBuilder(db_path, "sidechain").provider("claude-code").title("Sidechain off root").parent_session(
        "ext-root"
    ).branch_type("sidechain").add_message(role="user", text="side").save()
```

### `test_topology_rooted_subtree_from_any_node` at line 60

```
async def test_topology_rooted_subtree_from_any_node(workspace_env: dict[str, Path]) -> None:
    db_path = db_setup(workspace_env)
    _seed_lineage(db_path)

    polylogue = Polylogue(archive_root=workspace_env["archive_root"], db_path=db_path)
    try:
        # Requesting topology from a deep descendant must still anchor at the root.
        topo = await polylogue.get_session_topology(_native("fork"))
    finally:
        await polylogue.close()

    assert isinstance(topo, SessionTopology)
    assert str(topo.root_id) == _native("root")
    assert str(topo.target_id) == _native("fork")
    assert not topo.cycle_detected

    node_ids = {str(node.session_id) for node in topo.nodes}
    assert node_ids == {_native(t) for t in ("root", "continuation", "fork", "subagent", "sidechain")}

    by_id = {str(node.session_id): node for node in topo.nodes}
    assert by_id[_native("root")].is_root is True
    assert by_id[_native("root")].depth == 0
    assert by_id[_native("continuation")].depth == 1
    assert by_id[_native("fork")].depth == 2  # via continuation
    assert by_id[_native("subagent")].depth == 1
    assert by_id[_native("sidechain")].depth == 1

    edge_by_child = {str(edge.child_id): edge for edge in topo.edges if edge.resolved}
    assert edge_by_child[_native("continuation")].kind is TopologyEdgeKind.CONTINUATION
    assert edge_by_child[_native("fork")].kind is TopologyEdgeKind.FORK
    assert edge_by_child[_native("subagent")].kind is TopologyEdgeKind.SUBAGENT
    assert edge_by_child[_native("sidechain")].kind is TopologyEdgeKind.SIDECHAIN
```

### `test_topology_ancestors_descendants_siblings` at line 95

```
async def test_topology_ancestors_descendants_siblings(workspace_env: dict[str, Path]) -> None:
    db_path = db_setup(workspace_env)
    _seed_lineage(db_path)

    polylogue = Polylogue(archive_root=workspace_env["archive_root"], db_path=db_path)
    try:
        topo = await polylogue.get_session_topology(_native("root"))
    finally:
        await polylogue.close()
    assert topo is not None

    assert [str(cid) for cid in topo.ancestors(_native("fork"))] == [_native("root"), _native("continuation")]
    assert [str(cid) for cid in topo.ancestors(_native("root"))] == []

    assert {str(cid) for cid in topo.descendants(_native("root"))} == {
        _native("continuation"),
        _native("fork"),
        _native("subagent"),
        _native("sidechain"),
    }
    assert [str(cid) for cid in topo.descendants(_native("continuation"))] == [_native("fork")]

    sibling_ids = {str(cid) for cid in topo.siblings(_native("subagent"))}
    assert sibling_ids == {_native("continuation"), _native("sidechain")}
```
