from __future__ import annotations

import importlib.util
import itertools
from pathlib import Path
import sys

ROOT = Path(__file__).resolve()
while ROOT != ROOT.parent and not (ROOT / 'REPO/polylogue/storage/sqlite/archive_tiers/lineage_cut_witness.py').exists():
    ROOT = ROOT.parent
HELPER = ROOT / 'REPO/polylogue/storage/sqlite/archive_tiers/lineage_cut_witness.py'
spec = importlib.util.spec_from_file_location("_polylogue_lineage_cut_witness", HELPER)
assert spec is not None and spec.loader is not None, f"cannot load {HELPER}"
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)


def row(position: int, variant: int, content: str) -> dict[str, object]:
    return {"position": position, "variant_index": variant, "role": "user", "content": content}


def test_witness_is_permutation_invariant_and_includes_sibling_variants() -> None:
    history = [row(0, 0, "root"), row(1, 0, "primary"), row(1, 1, "sibling")]
    witnesses = {
        module.attach_cut_witness_json({"source": "test"}, permutation)
        for permutation in itertools.permutations(history)
    }
    assert len(witnesses) == 1
    witness = module.build_cut_witness(history)
    assert witness["message_count"] == 3
    assert witness["terminal"]["position"] == 1
    assert witness["terminal"]["variant_index"] == 1


def test_deleted_branch_point_is_typed_and_does_not_guess_a_prefix() -> None:
    original = [row(0, 0, "root"), row(1, 0, "branch")]
    evidence = module.attach_cut_witness_json({}, original)
    result = module.assess_and_bound_lineage_prefix(evidence, original[:1])
    assert result == []
    assert result.state.kind is module.LineageReadKind.MISSING_BRANCH_POINT
    assert result.state.expected_count == 2
    # The child-owned tail remains readable through list-compatible composition.
    composed = result + [row(2, 0, "child tail")]
    assert [item["content"] for item in composed] == ["child tail"]
    assert composed.state.kind is module.LineageReadKind.MISSING_BRANCH_POINT


def test_replacement_at_same_coordinate_requires_terminal_identity() -> None:
    original = [row(0, 0, "root"), row(1, 0, "old branch")]
    evidence = module.attach_cut_witness_json({}, original)
    replacement = [row(0, 0, "root"), row(1, 0, "new branch")]
    result = module.assess_and_bound_lineage_prefix(evidence, replacement)
    assert result == []
    assert result.state.kind is module.LineageReadKind.STALE_BRANCH_POINT


def test_cycle_quarantine_is_a_typed_bounded_read() -> None:
    history = [row(0, 0, "root")]
    evidence = module.attach_cut_witness_json({}, history)
    result = module.assess_and_bound_lineage_prefix(evidence, history, cycle_quarantined=True)
    assert result == []
    assert result.state.kind is module.LineageReadKind.CYCLE_QUARANTINED


def test_exact_witness_returns_only_the_witnessed_cut() -> None:
    inherited = [row(0, 0, "root"), row(1, 0, "branch")]
    evidence = module.attach_cut_witness_json({}, inherited)
    parent_after_append = [*inherited, row(2, 0, "later parent tail")]
    result = module.assess_and_bound_lineage_prefix(evidence, parent_after_append)
    assert [item["content"] for item in result] == ["root", "branch"]
    assert result.state.kind is module.LineageReadKind.RESOLVED
