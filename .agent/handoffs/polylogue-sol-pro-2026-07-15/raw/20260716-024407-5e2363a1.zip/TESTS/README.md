# Test application and execution

The regression patch adds `REPO/tests/test_lineage_cut_witness.py` and the runner also selects every supplied production-route test listed in `production-test-inventory.md`.

After applying the patch series:

```bash
bash TESTS/run-production-lineage-tests.sh
```

The runner first performs collection and rejects zero collected tests. The fixture in `fixtures/lineage-histories.json` documents the minimal reconstructed histories used when the exact live state-machine seeds are absent from the supplied snapshot.
