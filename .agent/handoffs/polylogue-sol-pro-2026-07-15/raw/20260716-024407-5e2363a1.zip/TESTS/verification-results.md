# Baseline production-route results

## targeted pytest: FAIL (exit 1)

Command: `/opt/pyvenv/bin/python3 -m pytest -q --disable-warnings --maxfail=1 REPO/tests/property/test_write_path_state_machine.py REPO/tests/unit/storage/test_lineage_normalization.py REPO/tests/unit/storage/test_session_topology.py`

Started: `2026-07-15T22:38:52.761766+00:00`

### stdout

```text

==================================== ERRORS ====================================
____ ERROR collecting REPO/tests/property/test_write_path_state_machine.py _____
ImportError while importing test module '/mnt/data/polylogue-sol-pro-work/base/REPO/tests/property/test_write_path_state_machine.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/usr/lib/python3.13/importlib/__init__.py:88: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
REPO/tests/property/test_write_path_state_machine.py:16: in <module>
    import aiosqlite
E   ModuleNotFoundError: No module named 'aiosqlite'
=========================== short test summary info ============================
ERROR REPO/tests/property/test_write_path_state_machine.py
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 error in 0.11s

```

### stderr

```text
(empty)
```


# Patched results

## compile changed Python: PASS

Command: `/opt/pyvenv/bin/python3 -m py_compile REPO/polylogue/storage/sqlite/archive_tiers/lineage_cut_witness.py REPO/polylogue/storage/sqlite/archive_tiers/write.py REPO/polylogue/storage/sqlite/queries/message_query_reads.py REPO/tests/test_lineage_cut_witness.py`

Started: `2026-07-15T22:39:02.494935+00:00`

### stdout

```text
(empty)
```

### stderr

```text
(empty)
```

## targeted pytest: FAIL (exit 1)

Command: `/opt/pyvenv/bin/python3 -m pytest -q --disable-warnings --maxfail=1 REPO/tests/test_lineage_cut_witness.py REPO/tests/property/test_write_path_state_machine.py REPO/tests/unit/storage/test_lineage_normalization.py REPO/tests/unit/storage/test_session_topology.py`

Started: `2026-07-15T22:38:56.771202+00:00`

### stdout

```text

==================================== ERRORS ====================================
____ ERROR collecting REPO/tests/property/test_write_path_state_machine.py _____
ImportError while importing test module '/mnt/data/polylogue-sol-pro-work/worktree/REPO/tests/property/test_write_path_state_machine.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/usr/lib/python3.13/importlib/__init__.py:88: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
REPO/tests/property/test_write_path_state_machine.py:16: in <module>
    import aiosqlite
E   ModuleNotFoundError: No module named 'aiosqlite'
=========================== short test summary info ============================
ERROR REPO/tests/property/test_write_path_state_machine.py
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 error in 0.13s

```

### stderr

```text
(empty)
```

## full pytest: FAIL (exit 1)

Command: `/opt/pyvenv/bin/python3 -m pytest -q --disable-warnings --maxfail=1`

Started: `2026-07-15T22:38:59.756474+00:00`

### stdout

```text

==================================== ERRORS ====================================
____ ERROR collecting REPO/tests/property/test_write_path_state_machine.py _____
ImportError while importing test module '/mnt/data/polylogue-sol-pro-work/worktree/REPO/tests/property/test_write_path_state_machine.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/usr/lib/python3.13/importlib/__init__.py:88: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
REPO/tests/property/test_write_path_state_machine.py:16: in <module>
    import aiosqlite
E   ModuleNotFoundError: No module named 'aiosqlite'
=========================== short test summary info ============================
ERROR REPO/tests/property/test_write_path_state_machine.py
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 error in 0.09s

```

### stderr

```text
(empty)
```
