#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT/src:$ROOT${PYTHONPATH:+:$PYTHONPATH}"
TARGETS=('REPO/tests/test_lineage_cut_witness.py' 'REPO/tests/property/test_write_path_state_machine.py' 'REPO/tests/unit/storage/test_lineage_normalization.py' 'REPO/tests/unit/storage/test_session_topology.py')
if [[ ${#TARGETS[@]} -eq 0 ]]; then
  echo "no lineage tests selected" >&2
  exit 64
fi
python -m pytest --collect-only -q "${TARGETS[@]}" >/tmp/polylogue-lineage-collect.txt
if ! grep -Eq '[1-9][0-9]* tests? collected|::' /tmp/polylogue-lineage-collect.txt; then
  cat /tmp/polylogue-lineage-collect.txt >&2
  echo "lineage test collection was vacuous" >&2
  exit 65
fi
python -m pytest -q --disable-warnings --maxfail=1 "${TARGETS[@]}"
