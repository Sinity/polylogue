# Patch baseline and conflict notes

- Supplied archive: `polylogue-sol-pro-context-3be7ecbc6303e8d0.tar.gz`
- Archive SHA-256: `3be7ecbc6303e8d071604c5344371c8d364e4fc5e3f7ca02f527ceea5ebbbd33`
- Selected content root inside archive: `.`
- Git revision recorded by snapshot: `not available in scoped snapshot`
- Patch paths are relative to that selected content root.
- Prompt profile: `polylogue-sol-pro-worker-v1`

## Pre-existing dirty state

```text
(no Git status available; no source overwrite was assumed)
```

The patch generator never edits `.beads/issues.jsonl`. Apply in the order listed by `PATCHES/series`, first with `git apply --check`. If the operator checkout has moved, resolve conflicts against the functions identified in `DESIGN/production-path.md`; do not apply by fuzz across unrelated SQL.
