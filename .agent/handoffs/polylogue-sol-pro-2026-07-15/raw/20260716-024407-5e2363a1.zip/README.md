# Polylogue lineage repair handoff

## Read order

1. `SUMMARY.md` — result and acceptance matrix.
2. `DESIGN/bead-evidence.md` and `DESIGN/production-path.md` — failure evidence and actual production route.
3. `DESIGN/invariant-and-schema.md` — invariant, evidence shape, and typed read states.
4. `DESIGN/change-map.json` and `DESIGN/rejected-alternatives.md` — exact touched/uncovered sites and design tradeoffs.
5. `PATCHES/BASELINE.md`, then patches in `PATCHES/series` order.
6. `TESTS/README.md`, `TESTS/production-test-inventory.md`, and `TESTS/verification-results.md`.
7. `VERIFICATION-LIMITS.md` before merge/deployment.

## Apply order

```bash
git apply --check PATCHES/0001-canonical-message-order-and-descendant-repair.patch
git apply PATCHES/0001-canonical-message-order-and-descendant-repair.patch
git apply --check PATCHES/0002-persist-and-verify-lineage-cut-witness.patch
git apply PATCHES/0002-persist-and-verify-lineage-cut-witness.patch
git apply --check PATCHES/0003-lineage-cut-regressions.patch
git apply PATCHES/0003-lineage-cut-regressions.patch
bash TESTS/run-production-lineage-tests.sh
```

Do not apply patch 0002 without 0001: the witness must be computed over the same canonical stream used by composition. Do not regenerate a missing branch cut by selecting a nearby row.
