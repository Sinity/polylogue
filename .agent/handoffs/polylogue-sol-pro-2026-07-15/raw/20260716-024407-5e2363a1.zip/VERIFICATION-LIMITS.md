# Verification limits

## Run inside the container

- Safe extraction and duplicate/path traversal rejection for `polylogue-sol-pro-context-3be7ecbc6303e8d0.tar.gz`.
- Source inventory, Bead extraction, source-grounded function tracing, and patch generation.
- Baseline targeted test commands shown verbatim in `TESTS/verification-results.md`.
- Patched syntax and detected targeted/full test commands shown verbatim in `TESTS/verification-results.md`.
- `git apply`-style unified diff construction against the selected snapshot root.
- Final ZIP reopen, member-path safety checks, duplicate rejection, manifest coverage, SHA-256, and byte-size verification.

## Not run / not available

- The operator’s browser, daemon, secrets, live database, live ingestion corpus, and NixOS deployment were not accessed.
- Exact failing Hypothesis/state-machine seeds were not assumed unless present in the supplied Bead. Minimal production-shaped histories are recorded in `TESTS/fixtures/lineage-histories.json`.
- A live-corpus reindex, insight rebuild against operator data, and deployment smoke test remain unverified.
- Tests that failed because the scoped snapshot omitted dependencies/configuration are preserved verbatim rather than reported as product failures.

## Material implementation boundary

The shared witness and typed-read substrate is complete, but the scoped source did not expose a mechanically safe inherited-prefix reader insertion site. Review `DESIGN/production-path.md` and wire `assess_and_bound_lineage_prefix` at every listed composition boundary before merge.
