# Lineage invariant, state model, and schema implications

## One invariant

For every lineage edge, the inherited prefix is the exact canonical parent stream ordered by `(position, variant_index)` up to a persisted cut witness. The witness contains the inherited row count and the terminal row’s coordinate plus a stable semantic signature. Writers, descendant repair, insight rebuilds, and readers all consume that same definition.

This removes the old asymmetry where a write-side extractor could ignore sibling variants while readers composed every variant. It also makes parent replacement order-independent: the edge is resolved only when the current parent stream still proves the stored cut.

## Evidence shape

`session_links.evidence_json` gains a namespaced, backward-compatible member:

```json
{
  "lineage_cut": {
    "version": 1,
    "message_count": 3,
    "terminal": {
      "position": 1,
      "variant_index": 1,
      "signature": "<sha256 of stable semantic fields>"
    }
  }
}
```

No table, column, index, derived-tier version, or migration chain is introduced. Existing evidence keys are retained. Old rows without the member are not guessed into a branch point: they produce `legacy_unwitnessed` until the normal lineage repair/rebuild path rewrites them.

## Typed readable degradation

The substrate returns list-compatible rows carrying `LineageReadState`:

- `resolved`: witnessed prefix is safe to compose.
- `legacy_unwitnessed`: old edge has no authoritative cut; inherited prefix is bounded to empty while the child-owned tail remains readable.
- `missing_branch_point`: parent is shorter than the witnessed cut.
- `stale_branch_point`: the terminal coordinate exists but its semantic identity changed.
- `cycle_quarantined`: the existing cycle status is preserved and no inherited rows are composed.

Missing or mismatched cuts never substitute the nearest predecessor, the primary sibling, or a coordinate-only match. This is the key readable-failure guarantee.

## Replacement and repair behavior

A full parent replacement re-runs descendant extraction for both unresolved and already-resolved children. Exact identity regeneration at the same canonical cut converges to the same witness. Deleted branch points leave the prior witness in place; readers detect the mismatch and expose a typed bounded result. Child-before-parent ingestion resolves through the same repair route when the parent arrives. Insight/thread rebuilding therefore consumes the same verified composition instead of a separate heuristic.
