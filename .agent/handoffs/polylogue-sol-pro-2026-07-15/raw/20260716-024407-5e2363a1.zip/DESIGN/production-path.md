# Production lineage path: source-grounded trace

This trace was generated from the supplied source, before modification. It lists concrete functions and excerpts that participate in persistence, replacement, resolution, composition, cycle handling, and insight projection. The ordered route below is an inference from call-site vocabulary and SQL effects; each inference is paired with source evidence.

## Freshness and normalization

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:1811` — `_resolve_session_graph`

Score: 148

```python
def _resolve_session_graph(
    conn: sqlite3.Connection,
    session_id: str,
    native_id: str,
    origin: str,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    add_timing: Callable[[str, float], None] | None = None,
) -> None:
    def record_substage(name: str, started_at: float) -> None:
        if add_timing is not None:
            add_timing(f"index.graph_resolve.{name}", started_at)

    t0 = time.perf_counter()
    conn.execute(
        """
        UPDATE sessions
        SET root_session_id = session_id
        WHERE session_id = ? AND root_session_id IS NULL
        """,
        (session_id,),
    )
    record_substage("root_init", t0)
    t0 = time.perf_counter()
    _resolve_outbound_session_links(conn, session_id, origin)
    record_substage("outbound_links", t0)
    t0 = time.perf_counter()
    has_outbound_link = (
        conn.execute("SELECT 1 FROM session_links WHERE src_session_id = ? LIMIT 1", (session_id,)).fetchone()
        is not None
    )
    inbound_rows = conn.execute(
        """
        SELECT links.src_session_id
        FROM session_links links
        WHERE links.dst_native_id = ?
          AND links.resolved_dst_session_id IS NULL
          AND links.dst_origin = ?
        """,
        (native_id, origin),
    ).fetchall()
    record_substage("inbound_lookup", t0)
    t0 = time.perf_counter()
    if not has_outbound_link and not inbound_rows and _root_projection_current(conn, session_id):
        record_substage("root_current_check", t0)
        return
    record_substage("root_current_check", t0)
    composed_cache: dict[str, list[tuple[str, str]]] = {}
    t0 = time.perf_counter()
    for row in inbound_rows:
        conn.execute(
            """
            UPDATE session_links
            SET resolved_dst_session_id = ?,
                resolved_at_ms = COALESCE(resolved_at_ms, observed_at_ms)
            WHERE src_session_id = ?
              AND dst_native_id = ?
              AND resolved_dst_session_id IS NULL
            """,
            (session_id, row[0], native_id),
        )
        # Deferred tail extraction (#2467): a child ingested before its parent was
        # stored whole (the inherited prefix could not be aligned yet). Now that
        # the parent exists, normalize the child the same way the parent-known
        # write path does — drop the inherited prefix rows and record the edge.
        _reextract_prefix_tail_db(
            conn,
            str(row[0]),
            session_id,
            cache=cache,
            composed_cache=composed_cache,
            add_timing=add_timing,
        )
    record_substage("reextract_prefix_tails", t0)

    impacted_session_ids = {session_id, *(str(row[0]) for row in inbound_rows)}
    t0 = time.perf_counter()
    _repair_stale_prefix_branch_points_db(conn, impacted_session_ids, cache=cache, composed_cache=composed_cache)
    record_substage("repair_stale_branch_points", t0)
    t0 = time.perf_counter()
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:183` — `write_parsed_session_to_archive`

Score: 134

```python
def write_parsed_session_to_archive(
    conn: sqlite3.Connection,
    session: ParsedSession,
    *,
    content_hash: str | None = None,
    raw_id: str | None = None,
    merge_append: bool = False,
    force_replace: bool = False,
    stage_timings_s: dict[str, float] | None = None,
    stage_timing_prefix: str = "append",
    signature_cache: dict[str, list[tuple[str, str]]] | None = None,
    preacquired_attachment_blobs: dict[int, tuple[bytes | None, int, str]] | None = None,
    manage_transaction: bool = True,
) -> str:
    """Write one parsed session into an initialized archive index DB.

    By default the whole write runs in its own transaction (``with conn:``)
    committed on success. A bulk caller that wants many sessions in one
    transaction — to amortize the per-commit fsync and WAL page churn that
    dominate re-ingest I/O — passes ``manage_transaction=False`` and owns the
    surrounding commit and any rollback-on-error itself.
    """
    t0 = time.perf_counter()

    def add_timing(name: str, started_at: float) -> None:
        _add_stage_timing(
            stage_timings_s,
            stage_timing_prefix=stage_timing_prefix,
            name=name,
            started_at=started_at,
        )

    conn.execute("PRAGMA foreign_keys = ON")
    origin = origin_from_provider(session.source_name)
    native_id = session.provider_session_id
    session_id = archive_session_id(origin.value, native_id)
    incoming_freshness_ms = _timestamp_ms(session.updated_at) or _timestamp_ms(session.created_at)
    if not force_replace and not merge_append and incoming_freshness_ms is not None:
        row = conn.execute(
            "SELECT updated_at_ms FROM sessions WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        existing_updated_at_ms = int(row[0]) if row is not None and row[0] is not None else None
        if existing_updated_at_ms is not None and incoming_freshness_ms < existing_updated_at_ms:
            add_timing("index.skip_stale_replace", t0)
            return session_id
    # This session's own rows are about to be rewritten; drop any stale memoized
    # own-signatures so the batch cache never serves pre-write rows for it.
    if signature_cache is not None:
        signature_cache.pop(session_id, None)
    messages = _normalized_messages(session.messages)
    event_duplicate_message_native_ids = _duplicate_message_native_ids(messages)
    # Lineage normalization (#2467): when this is a prefix-sharing child whose
    # parent is already in the archive, drop the inherited prefix and keep only
    # the divergent tail. All downstream writes (messages, blocks, counts,
    # attachments, events) then operate on the tail, so each real message is
    # stored exactly once. Only applies to full-replace writes; merge-append is
    # an incremental extend of the same session.
    branch_point_message_id: str | None = None
    lineage_inheritance: str | None = None
    parent_session_id: str | None = None
    inherited_source_message_ids: dict[str, str] = {}
    if not merge_append:
        parent_session_id = _existing_parent_session_id(conn, session, origin.value)
        if parent_session_id is not None and messages:
            (
                branch_point_message_id,
                lineage_inheritance,
                messages,
                inherited_source_message_ids,
            ) = _extract_prefix_tail(conn, parent_session_id, messages, cache=signature_cache)
    duplicate_message_native_ids = _duplicate_message_native_ids(messages)
    active_leaf_message_id = _active_leaf_message_id(
        session_id,
        messages,
        session.active_leaf_message_provider_id,
        duplicate_native_ids=duplicate_message_native_ids,
    )
    session_content_hash = (
        bytes.fromhex(content_hash) if content_hash is not None else _hash_bytes("session", origin.value, native_id)
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:3343` — `_reextract_prefix_tail_db`

Score: 112

```python
def _reextract_prefix_tail_db(
    conn: sqlite3.Connection,
    child_session_id: str,
    parent_session_id: str,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    composed_cache: dict[str, list[tuple[str, str]]] | None = None,
    add_timing: Callable[[str, float], None] | None = None,
) -> None:
    """Normalize a child that was stored whole because its parent was ingested
    later (#2467). Aligns the child's already-stored messages against the parent's
    composed transcript, deletes the inherited-prefix rows, and records the edge.
    Only runs while the lineage edge is still un-extracted (``inheritance`` NULL).
    """

    def record_substage(name: str, started_at: float) -> None:
        if add_timing is not None:
            add_timing(f"index.graph_resolve.reextract_prefix_tails.{name}", started_at)

    t0 = time.perf_counter()
    edge = conn.execute(
        """
        SELECT dst_origin, dst_native_id, link_type
        FROM session_links
        WHERE src_session_id = ?
          AND resolved_dst_session_id = ?
          AND inheritance IS NULL
        LIMIT 1
        """,
        (child_session_id, parent_session_id),
    ).fetchone()
    record_substage("edge_lookup", t0)
    if edge is None:
        return
    dst_origin, dst_native_id, link_type = edge
    t0 = time.perf_counter()
    parent_composed = _composed_db_signatures(
        conn,
        parent_session_id,
        cache=cache,
        composed_cache=composed_cache,
    )
    record_substage("parent_composed", t0)
    t0 = time.perf_counter()
    child_composed = _composed_db_signatures(
        conn,
        child_session_id,
        cache=cache,
        composed_cache=composed_cache,
    )
    record_substage("child_composed", t0)
    t0 = time.perf_counter()
    k = 0
    limit = min(len(parent_composed), len(child_composed))
    while k < limit and parent_composed[k][1] == child_composed[k][1]:
        k += 1
    record_substage("signature_compare", t0)

    def _set_edge(branch_point_message_id: str | None, inheritance: str) -> None:
        conn.execute(
            """
            UPDATE session_links
            SET branch_point_message_id = ?, inheritance = ?
            WHERE src_session_id = ? AND dst_origin = ? AND dst_native_id = ? AND link_type = ?
            """,
            (branch_point_message_id, inheritance, child_session_id, dst_origin, dst_native_id, link_type),
        )

    if k == 0:
        t0 = time.perf_counter()
        _set_edge(None, "spawned-fresh")
        record_substage("edge_update", t0)
        return
    prefix_message_ids = [child_composed[i][0] for i in range(k)]
    t0 = time.perf_counter()
    _remap_session_event_prefix_refs(
        conn,
        child_session_id,
        tuple((prefix_message_ids[index], parent_composed[index][0]) for index in range(k)),
    )
```

### `REPO/tests/unit/storage/test_lineage_normalization.py:1270` — `test_sync_composition_holds_one_snapshot_across_concurrent_parent_write`

Score: -3

```python
def test_sync_composition_holds_one_snapshot_across_concurrent_parent_write(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """4ts.4: read_archive_session_envelope must not tear when a concurrent
    writer edits the parent's shared prefix mid-composition. A hook fires the
    concurrent edit right when the child's own edge lookup runs (after the
    child's own read, before the recursive parent read) -- if the composition
    were not held in one transaction, the parent read below would observe the
    mid-flight edit and the composed transcript would mix stale and fresh
    parent content with the (unaffected) child's own tail."""
    db = tmp_path / "index.db"
    conn, parent_id, child_id = _setup_interleaving_fixture(db)
    conn.close()

    # Re-open on a fresh connection so the read below starts a clean snapshot,
    # matching how a live reader (CLI/MCP/API) connects independently of the
    # writer/daemon connection.
    reader = _connect(db)
    reader.execute("PRAGMA journal_mode=WAL")

    real_edge_lookup = _write_module._prefix_sharing_edge_sync
    fired = {"count": 0}

    def _hook(conn_inner: sqlite3.Connection, session_id: str) -> tuple[str, str] | None:
        if session_id == child_id and fired["count"] == 0:
            fired["count"] += 1
            assert conn_inner.in_transaction, "composition must already hold a transaction before this hook fires"
            _concurrently_mutate_parent_block_text(db, parent_id)
        return real_edge_lookup(conn_inner, session_id)

    monkeypatch.setattr(_write_module, "_prefix_sharing_edge_sync", _hook)

    envelope = read_archive_session_envelope(reader, child_id)
    texts = ["".join(block.text or "" for block in message.blocks) for message in envelope.messages]

    assert fired["count"] == 1, "the interleaving hook never fired -- test is not exercising the race"
    # Old-consistent: the reader's held snapshot predates the concurrent edit,
    # so it must see the ORIGINAL parent text, not a torn mix.
    assert texts == ["hello", "hi there", "child diverges"]

    reader.close()

    # The concurrent edit itself did land (proving it wasn't silently a no-op) --
    # a fresh read afterwards sees the new text.
    post = _connect(db)
    post_envelope = read_archive_session_envelope(post, child_id)
    post_texts = ["".join(block.text or "" for block in message.blocks) for message in post_envelope.messages]
    assert post_texts == ["hello", "hi there (concurrently edited)", "child diverges"]
    post.close()
```

## Prefix extraction and canonical message order

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:791` — `read_archive_session_envelope`

Score: 342

```python
def read_archive_session_envelope(
    conn: sqlite3.Connection, session_id: str, *, _depth: int = 0
) -> ArchiveSessionEnvelope:
    """Read a compact archive envelope, holding one read snapshot across composition.

    For a prefix-sharing lineage child (#2467) the inherited prefix is not stored
    under this session; the returned ``messages`` compose the parent's transcript
    up to the branch point followed by this session's own messages, so reads see
    the full logical transcript while storage holds each message once.

    Composition issues multiple autocommit SELECTs across a recursive parent
    walk (own read -> edge read -> recursive parent read). Without a held
    transaction, a concurrent parent re-ingest between those reads can yield a
    torn transcript (4ts.4). If ``conn`` is not already inside a transaction
    (e.g. a caller-held write transaction), this wraps the whole composition
    in one deferred read transaction so every SELECT sees the same snapshot;
    recursive calls see ``conn.in_transaction`` already true and skip
    re-wrapping.
    """
    if not conn.in_transaction:
        conn.execute("BEGIN DEFERRED")
        try:
            return read_archive_session_envelope(conn, session_id, _depth=_depth)
        finally:
            conn.execute("ROLLBACK")
    conn.row_factory = sqlite3.Row
    session = conn.execute(
        """
        SELECT session_id, native_id, origin, title, session_kind, active_leaf_message_id,
               parent_session_id, root_session_id, branch_type,
               title_source, instructions_text,
               created_at_ms, updated_at_ms, git_branch, git_repository_url, provider_project_ref
        FROM sessions
        WHERE session_id = ?
        """,
        (session_id,),
    ).fetchone()
    if session is None:
        raise KeyError(session_id)
    working_directories = tuple(
        str(row["path"])
        for row in conn.execute(
            """
            SELECT path
            FROM session_working_dirs
            WHERE session_id = ?
            ORDER BY position, path
            """,
            (session_id,),
        ).fetchall()
    )

    attachment_rows = conn.execute(
        """
        SELECT r.message_id AS message_id, a.attachment_id AS attachment_id,
               a.display_name AS display_name, a.media_type AS media_type, a.byte_count AS byte_count,
               r.upload_origin AS upload_origin, r.source_url AS source_url, r.caption AS caption
        FROM attachment_refs r
        JOIN attachments a ON a.attachment_id = r.attachment_id
        WHERE r.session_id = ?
        ORDER BY r.message_id, a.attachment_id
        """,
        (session_id,),
    ).fetchall()
    attachments_by_message: dict[str | None, list[ArchiveAttachmentRow]] = {}
    for attachment in attachment_rows:
        attachments_by_message.setdefault(attachment["message_id"], []).append(
            ArchiveAttachmentRow(
                attachment_id=attachment["attachment_id"],
                message_id=attachment["message_id"],
                display_name=attachment["display_name"],
                media_type=attachment["media_type"],
                byte_count=int(attachment["byte_count"] or 0),
                upload_origin=attachment["upload_origin"],
                source_url=attachment["source_url"],
                caption=attachment["caption"],
            )
        )

    message_rows = conn.execute(
```

### `REPO/tests/property/test_write_path_state_machine.py:287` — `_write`

Score: 22

```python
    def _write(
        self,
        native_id: str,
        texts: list[str],
        *,
        parent_native_id: str | None = None,
        updated_at: str = "2026-01-01T00:00:00Z",
        merge_append: bool = False,
        message_id_prefix: str = "message",
        variant_batch: bool = False,
    ) -> str:
        parsed = ParsedSession(
            source_name=Provider.CLAUDE_CODE,
            provider_session_id=native_id,
            parent_session_provider_id=parent_native_id,
            branch_type=BranchType.FORK if parent_native_id else None,
            updated_at=updated_at,
            messages=[
                ParsedMessage(
                    provider_message_id=f"{native_id}-{message_id_prefix}-{index}",
                    role=Role.USER if index % 2 == 0 else Role.ASSISTANT,
                    text=text,
                    # Full snapshots use active-path messages.  Append windows
                    # add a sibling variant at one position, exercising the
                    # variant-index regeneration branch without pretending a
                    # sibling is part of a lineage-replayable prefix.
                    position=0 if variant_batch else index,
                    variant_index=index if variant_batch else 0,
                )
                for index, text in enumerate(texts)
            ],
        )
        return write_parsed_session_to_archive(
            self._conn,
            parsed,
            content_hash=session_content_hash(parsed),
            merge_append=merge_append,
        )
```

### `REPO/polylogue/storage/sqlite/queries/message_query_reads.py:137` — `get_messages_with_lineage_completeness`

Score: 278

```python
async def get_messages_with_lineage_completeness(
    conn: aiosqlite.Connection,
    session_id: str,
    *,
    _compose_in_position_order: bool = False,
) -> tuple[list[MessageRecord], LineageCompleteness]:
    """Compose a session's full message transcript, holding one read snapshot,
    and report whether the composed transcript is complete (4ts.6).

    Composition issues multiple autocommit SELECTs while walking the lineage
    chain (edge reads, then a read per ancestor/descendant). Without a held
    transaction, a concurrent parent re-ingest between those reads can yield a
    torn transcript (4ts.4). If ``conn`` is not already inside a transaction
    (e.g. a caller-held write transaction), this wraps the whole composition
    in one deferred read transaction so every SELECT sees the same snapshot.

    Two paths can silently return an INCOMPLETE transcript: a chain deeper
    than ``_MAX_LINEAGE_DEPTH`` (ancestors beyond the cutoff are dropped), or
    a dangling branch point (the parent message was hard-deleted, so only
    this session's own divergent tail is returned starting mid-conversation).
    Consumers that care (MCP get_messages, context-image) can distinguish a
    complete logical transcript from a truncated one via the returned
    ``LineageCompleteness``.
    """
    if not conn.in_transaction:
        await conn.execute("BEGIN DEFERRED")
        try:
            return await get_messages_with_lineage_completeness(
                conn, session_id, _compose_in_position_order=_compose_in_position_order
            )
        finally:
            await conn.execute("ROLLBACK")
    session_id = await _resolve_session_id(conn, session_id)

    # Lineage composition (#2467): a prefix-sharing child stores only its own
    # divergent tail. Walk UP the parent chain collecting (child, branch_point)
    # links to the root, then compose DOWN. This is ITERATIVE (not recursive) so
    # deep acompact/fork chains cannot hit Python's recursion limit; the composed
    # view is position-ordered end to end, while a plain session keeps the
    # sort-key order the keyset streamer relies on. A `visited` set stops a cyclic
    # session_link; _MAX_LINEAGE_DEPTH is only a runaway backstop.
    chain: list[tuple[str, str]] = []  # (child_session_id, branch_point_message_id), leaf-first
    visited: set[str] = {session_id}
    cursor_session = session_id
    depth_limited = False
    for _ in range(_MAX_LINEAGE_DEPTH):
        edge = await _prefix_sharing_edge(conn, cursor_session)
        if edge is None:
            break
        parent_session_id, branch_point_message_id = edge
        parent_session_id = await _resolve_session_id(conn, parent_session_id)
        if parent_session_id in visited:  # cyclic lineage: stop and compose what we have
            break
        chain.append((cursor_session, branch_point_message_id))
        visited.add(parent_session_id)
        cursor_session = parent_session_id
    else:
        # Loop exhausted _MAX_LINEAGE_DEPTH iterations without a break: there
        # may be more ancestors beyond the cutoff we never walked to.
        if await _prefix_sharing_edge(conn, cursor_session) is not None:
            depth_limited = True
            logger.warning(
                "lineage composition hit depth limit (%d) for session %s; ancestors beyond this depth are dropped",
                _MAX_LINEAGE_DEPTH,
                session_id,
            )

    if not chain:
        # depth_limited can only be set inside the for-else branch below,
        # which only runs after _MAX_LINEAGE_DEPTH non-empty chain entries --
        # an empty chain means the very first edge check returned None.
        return await _own_messages(conn, session_id, position_order=_compose_in_position_order), LineageCompleteness()

    # Compose from the root down: root's full transcript, then splice each
    # descendant's own tail at its branch point in the running composed view.
    composed = await _own_messages(conn, cursor_session, position_order=True)
    dangling = False
    for child_session_id, branch_point_message_id in reversed(chain):
        own = await _own_messages(conn, child_session_id, position_order=True)
        prefix: list[MessageRecord] = []
```

### `REPO/tests/unit/storage/test_lineage_normalization.py:915` — `test_hermes_compression_tail_composes_and_delegate_stays_fresh`

Score: 173

```python
def test_hermes_compression_tail_composes_and_delegate_stays_fresh(
    tmp_path: Path,
    end_reason: str,
) -> None:
    state_db = tmp_path / "state.db"
    with sqlite3.connect(state_db) as source:
        source.executescript(
            """
            CREATE TABLE schema_version(version INTEGER NOT NULL);
            INSERT INTO schema_version VALUES (16);
            CREATE TABLE sessions (
                id TEXT PRIMARY KEY,
                source TEXT,
                model_config TEXT,
                parent_session_id TEXT,
                started_at REAL,
                ended_at REAL,
                end_reason TEXT,
                title TEXT
            );
            CREATE TABLE messages (
                id INTEGER PRIMARY KEY,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT,
                timestamp REAL NOT NULL,
                tool_calls TEXT,
                observed INTEGER,
                active INTEGER,
                compacted INTEGER
            );
            INSERT INTO sessions VALUES
                ('parent', 'cli', '{}', NULL, 1.0, 3.0, 'compression', 'Parent'),
                ('continuation', 'cli', '{}', 'parent', 4.0, NULL, NULL, 'Continuation'),
                ('delegate', 'tool', '{}', 'parent', 5.0, NULL, NULL, 'Delegate');
            INSERT INTO messages VALUES
                (1, 'parent', 'user', 'before', 1.0, NULL, 0, 1, 0),
                (2, 'parent', 'assistant', 'summary', 2.0, NULL, 0, 1, 0),
                (3, 'continuation', 'user', 'after', 4.0, NULL, 0, 1, 0),
                (4, 'continuation', 'assistant', 'continued', 4.5, NULL, 0, 1, 0),
                (5, 'delegate', 'assistant', 'fresh work', 5.0, NULL, 0, 1, 0);
            """
        )
        source.execute(
            "UPDATE sessions SET model_config = ? WHERE id = 'delegate'",
            (json.dumps({"_delegate_from": "parent"}),),
        )
        source.execute(
            "UPDATE sessions SET end_reason = ? WHERE id = 'parent'",
            (end_reason,),
        )

    parsed = parse_state_db(state_db)
    by_raw_id = {session.provider_session_id.split("@", 1)[0]: session for session in parsed}
    parent = by_raw_id["parent"]
    continuation = by_raw_id["continuation"]
    delegate = by_raw_id["delegate"]
    assert continuation.branch_type is BranchType.CONTINUATION
    assert any(
        event.event_type == "compaction" and event.payload.get("end_reason") == end_reason
        for event in parent.session_events
    )
    assert [message.text for message in continuation.messages] == ["before", "summary", "after", "continued"]
    assert delegate.branch_type is BranchType.SUBAGENT
    assert [message.text for message in delegate.messages] == ["fresh work"]

    db = tmp_path / "index.db"
    conn = _connect(db)
    parent_id = write_parsed_session_to_archive(conn, parent)
    continuation_id = write_parsed_session_to_archive(conn, continuation)
    delegate_id = write_parsed_session_to_archive(conn, delegate)

    physical = conn.execute(
        """
        SELECT b.text
        FROM messages AS m
        JOIN blocks AS b ON b.message_id = m.message_id
        WHERE m.session_id = ? AND b.block_type = 'text'
        ORDER BY m.position, b.position
        """,
```

## Full replacement write

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:183` — `write_parsed_session_to_archive`

Score: 134

```python
def write_parsed_session_to_archive(
    conn: sqlite3.Connection,
    session: ParsedSession,
    *,
    content_hash: str | None = None,
    raw_id: str | None = None,
    merge_append: bool = False,
    force_replace: bool = False,
    stage_timings_s: dict[str, float] | None = None,
    stage_timing_prefix: str = "append",
    signature_cache: dict[str, list[tuple[str, str]]] | None = None,
    preacquired_attachment_blobs: dict[int, tuple[bytes | None, int, str]] | None = None,
    manage_transaction: bool = True,
) -> str:
    """Write one parsed session into an initialized archive index DB.

    By default the whole write runs in its own transaction (``with conn:``)
    committed on success. A bulk caller that wants many sessions in one
    transaction — to amortize the per-commit fsync and WAL page churn that
    dominate re-ingest I/O — passes ``manage_transaction=False`` and owns the
    surrounding commit and any rollback-on-error itself.
    """
    t0 = time.perf_counter()

    def add_timing(name: str, started_at: float) -> None:
        _add_stage_timing(
            stage_timings_s,
            stage_timing_prefix=stage_timing_prefix,
            name=name,
            started_at=started_at,
        )

    conn.execute("PRAGMA foreign_keys = ON")
    origin = origin_from_provider(session.source_name)
    native_id = session.provider_session_id
    session_id = archive_session_id(origin.value, native_id)
    incoming_freshness_ms = _timestamp_ms(session.updated_at) or _timestamp_ms(session.created_at)
    if not force_replace and not merge_append and incoming_freshness_ms is not None:
        row = conn.execute(
            "SELECT updated_at_ms FROM sessions WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        existing_updated_at_ms = int(row[0]) if row is not None and row[0] is not None else None
        if existing_updated_at_ms is not None and incoming_freshness_ms < existing_updated_at_ms:
            add_timing("index.skip_stale_replace", t0)
            return session_id
    # This session's own rows are about to be rewritten; drop any stale memoized
    # own-signatures so the batch cache never serves pre-write rows for it.
    if signature_cache is not None:
        signature_cache.pop(session_id, None)
    messages = _normalized_messages(session.messages)
    event_duplicate_message_native_ids = _duplicate_message_native_ids(messages)
    # Lineage normalization (#2467): when this is a prefix-sharing child whose
    # parent is already in the archive, drop the inherited prefix and keep only
    # the divergent tail. All downstream writes (messages, blocks, counts,
    # attachments, events) then operate on the tail, so each real message is
    # stored exactly once. Only applies to full-replace writes; merge-append is
    # an incremental extend of the same session.
    branch_point_message_id: str | None = None
    lineage_inheritance: str | None = None
    parent_session_id: str | None = None
    inherited_source_message_ids: dict[str, str] = {}
    if not merge_append:
        parent_session_id = _existing_parent_session_id(conn, session, origin.value)
        if parent_session_id is not None and messages:
            (
                branch_point_message_id,
                lineage_inheritance,
                messages,
                inherited_source_message_ids,
            ) = _extract_prefix_tail(conn, parent_session_id, messages, cache=signature_cache)
    duplicate_message_native_ids = _duplicate_message_native_ids(messages)
    active_leaf_message_id = _active_leaf_message_id(
        session_id,
        messages,
        session.active_leaf_message_provider_id,
        duplicate_native_ids=duplicate_message_native_ids,
    )
    session_content_hash = (
        bytes.fromhex(content_hash) if content_hash is not None else _hash_bytes("session", origin.value, native_id)
```

### `REPO/tests/unit/storage/test_lineage_normalization.py:804` — `test_parent_reingest_keeps_child_composing`

Score: 69

```python
def test_parent_reingest_keeps_child_composing(tmp_path: Path) -> None:
    """Regression for the FK-cascade bug (#2467 audit H1): re-ingesting a parent
    via full replace must NOT null the child's branch point. branch_point_message_id
    is deliberately not a FK, so the deterministic message id survives the parent's
    DELETE+re-INSERT and the child keeps composing the full transcript."""
    db = tmp_path / "index.db"
    conn = _connect(db)

    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
        ],
    )
    write_parsed_session_to_archive(conn, parent)

    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("c0", Role.USER, "hello", 0),
            _msg("c1", Role.ASSISTANT, "hi there", 1),
            _msg("cx", Role.USER, "child diverges", 2),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)
    assert [
        "".join(b.text or "" for b in m.blocks) for m in read_archive_session_envelope(conn, child_id).messages
    ] == ["hello", "hi there", "child diverges"]

    # Parent grows and is re-ingested (full replace) — the common production case.
    parent_grown = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
            _msg("p2", Role.USER, "parent keeps going", 2),
        ],
    )
    write_parsed_session_to_archive(conn, parent_grown)

    # The child's branch point survived; it still composes the full transcript.
    link = conn.execute(
        "SELECT inheritance, branch_point_message_id FROM session_links WHERE src_session_id = ?",
        (child_id,),
    ).fetchone()
    assert link["inheritance"] == "prefix-sharing"
    assert link["branch_point_message_id"] is not None
    assert [
        "".join(b.text or "" for b in m.blocks) for m in read_archive_session_envelope(conn, child_id).messages
    ] == ["hello", "hi there", "child diverges"]
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:1296` — `_write_web_constructs`

Score: 10

```python
def _write_web_constructs(
    conn: sqlite3.Connection,
    session: ParsedSession,
    messages: list[ParsedMessage],
    *,
    position_offset: int = 0,
    duplicate_native_ids: frozenset[str] = frozenset(),
    replace_session: bool = True,
) -> None:
    origin = origin_from_provider(session.source_name)
    session_id = archive_session_id(origin.value, session.provider_session_id)
    provider = _enum_value(session.source_name)
    rows: list[tuple[object, ...]] = []
    block_ids: list[str] = []
    # Iterate the (possibly lineage-sliced) tail messages, not session.messages —
    # a web construct on an inherited-prefix message would FK-violate against rows
    # that were never written under this session (#2467 audit).
    for fallback_position, message in enumerate(messages):
        message_id = _message_id(
            session_id,
            message,
            fallback_position,
            position_offset=position_offset,
            duplicate_native_ids=duplicate_native_ids,
        )
        blocks = _message_blocks(message)
        for block_position, block in enumerate(blocks):
            block_id = f"{message_id}:{block_position}"
            if not replace_session:
                block_ids.append(block_id)
            for construct_position, construct in enumerate(block.web_constructs):
                rows.append(
                    (
                        session_id,
                        message_id,
                        block_id,
                        construct_position,
                        provider,
                        _enum_value(construct.construct_type),
                        _sqlite_text(construct.provider_key),
                        _sqlite_text(construct.title),
                        _sqlite_text(construct.url),
                        _sqlite_text(construct.text),
                        _sqlite_text(construct.source_id),
                        _sqlite_text(construct.group_id),
                        _sqlite_text(construct.group_title),
                        _sqlite_text(construct.query),
                        _sqlite_text(construct.asset_pointer),
                        _sqlite_text(construct.mime_type),
                        _sqlite_text(construct.status),
                        _sqlite_text(construct.task_id),
                        _sqlite_text(construct.task_type),
                        construct.rank,
                        construct.start_index,
                        construct.end_index,
                    )
                )

    if replace_session:
        conn.execute("DELETE FROM web_content_constructs WHERE session_id = ?", (session_id,))
    else:
        conn.executemany(
            "DELETE FROM web_content_constructs WHERE block_id = ?", ((block_id,) for block_id in block_ids)
        )

    conn.executemany(
        """
        INSERT OR REPLACE INTO web_content_constructs (
            session_id, message_id, block_id, position, provider, construct_type,
            provider_key, title, url, text, source_id, group_id, group_title,
            query, asset_pointer, mime_type, status, task_id, task_type,
            rank, start_index, end_index
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        rows,
    )
```

### `REPO/polylogue/storage/sqlite/queries/session_links.py:33` — `upsert_session_links`

Score: 350

```python
async def upsert_session_links(
    conn: aiosqlite.Connection,
    links: Iterable[TopologyEdgeRecord],
) -> int:
    """Upsert session links. Returns number of rows written."""
    written = 0
    for link in links:
        await conn.execute(
            """
            INSERT INTO session_links (
                src_session_id,
                dst_origin,
                dst_native_id,
                link_type,
                resolved_dst_session_id,
                status,
                method,
                confidence,
                evidence_json,
                observed_at_ms,
                resolved_at_ms
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (src_session_id, dst_origin, dst_native_id, link_type) DO UPDATE SET
                resolved_dst_session_id = COALESCE(
                    excluded.resolved_dst_session_id,
                    session_links.resolved_dst_session_id
                ),
                status = CASE
                    WHEN session_links.status = 'quarantined' THEN session_links.status
                    ELSE excluded.status
                END,
                method = COALESCE(excluded.method, session_links.method),
                confidence = excluded.confidence,
                evidence_json = COALESCE(NULLIF(excluded.evidence_json, '[]'), session_links.evidence_json),
                resolved_at_ms = COALESCE(excluded.resolved_at_ms, session_links.resolved_at_ms)
            """,
            (
                str(link.src_session_id),
                link.dst_origin.value,
                link.dst_native_id,
                str(link.link_type),
                str(link.resolved_dst_session_id) if link.resolved_dst_session_id else None,
                _status_value(link.status),
                "parser-parent",
                link.confidence,
                link.evidence_json,
                _timestamp_ms(link.observed_at) or 0,
                _timestamp_ms(link.resolved_at),
            ),
        )
        written += 1
    return written
```

## Lineage edge persistence

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:1770` — `_write_session_link`

Score: 94

```python
def _write_session_link(
    conn: sqlite3.Connection,
    session_id: str,
    session: ParsedSession,
    *,
    branch_point_message_id: str | None = None,
    inheritance: str | None = None,
) -> None:
    if not session.parent_session_provider_id:
        return
    link_type = branch_type_to_edge_type(session.branch_type, default=TopologyEdgeType.BRANCH).value
    conn.execute(
        """
        INSERT OR REPLACE INTO session_links (
            src_session_id, dst_origin, dst_native_id, link_type,
            branch_point_message_id, inheritance,
            status, method, confidence, evidence_json, observed_at_ms
        ) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)
        """,
        (
            session_id,
            origin_from_provider(session.source_name).value,
            _sqlite_text(session.parent_session_provider_id),
            link_type,
            branch_point_message_id,
            inheritance,
            "parser-parent",
            1.0,
            _json_dumps({"parent_session_provider_id": session.parent_session_provider_id}),
            _timestamp_ms(session.updated_at) or _timestamp_ms(session.created_at) or 0,
        ),
    )
```

### `REPO/polylogue/storage/sqlite/queries/session_links.py:33` — `upsert_session_links`

Score: 350

```python
async def upsert_session_links(
    conn: aiosqlite.Connection,
    links: Iterable[TopologyEdgeRecord],
) -> int:
    """Upsert session links. Returns number of rows written."""
    written = 0
    for link in links:
        await conn.execute(
            """
            INSERT INTO session_links (
                src_session_id,
                dst_origin,
                dst_native_id,
                link_type,
                resolved_dst_session_id,
                status,
                method,
                confidence,
                evidence_json,
                observed_at_ms,
                resolved_at_ms
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (src_session_id, dst_origin, dst_native_id, link_type) DO UPDATE SET
                resolved_dst_session_id = COALESCE(
                    excluded.resolved_dst_session_id,
                    session_links.resolved_dst_session_id
                ),
                status = CASE
                    WHEN session_links.status = 'quarantined' THEN session_links.status
                    ELSE excluded.status
                END,
                method = COALESCE(excluded.method, session_links.method),
                confidence = excluded.confidence,
                evidence_json = COALESCE(NULLIF(excluded.evidence_json, '[]'), session_links.evidence_json),
                resolved_at_ms = COALESCE(excluded.resolved_at_ms, session_links.resolved_at_ms)
            """,
            (
                str(link.src_session_id),
                link.dst_origin.value,
                link.dst_native_id,
                str(link.link_type),
                str(link.resolved_dst_session_id) if link.resolved_dst_session_id else None,
                _status_value(link.status),
                "parser-parent",
                link.confidence,
                link.evidence_json,
                _timestamp_ms(link.observed_at) or 0,
                _timestamp_ms(link.resolved_at),
            ),
        )
        written += 1
    return written
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:3509` — `_repair_stale_prefix_branch_points_db`

Score: 252

```python
def _repair_stale_prefix_branch_points_db(
    conn: sqlite3.Connection,
    session_ids: set[str] | tuple[str, ...] | list[str] | None = None,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    composed_cache: dict[str, list[tuple[str, str]]] | None = None,
    limit: int | None = None,
) -> int:
    """Repair stale immediate-parent branch-point IDs in prefix-sharing edges.

    Older lineage rows can name a branch point as ``<immediate-parent>:<suffix>``
    even after that parent has itself been normalized to tail-only storage. The
    composed reader can only find physical ancestor message IDs, so these stale
    rows make the child bail to its own tail. If the suffix maps to exactly one
    message in the resolved parent's composed transcript, update the edge to the
    composed message id. Ambiguous or unmappable rows stay visible to validation.
    """
    params: list[object] = []
    scope_clause = ""
    if session_ids is not None:
        scoped = sorted(session_ids)
        if not scoped:
            return 0
        placeholders = ",".join("?" for _ in scoped)
        scope_clause = f"AND l.src_session_id IN ({placeholders})"
        params.extend(scoped)
    limit_clause = ""
    if limit is not None:
        if limit < 1:
            return 0
        limit_clause = "LIMIT ?"
        params.append(limit)
    rows = conn.execute(
        f"""
        SELECT l.src_session_id, l.resolved_dst_session_id, l.branch_point_message_id
        FROM session_links l
        WHERE l.inheritance = 'prefix-sharing'
          AND l.resolved_dst_session_id IS NOT NULL
          AND l.branch_point_message_id IS NOT NULL
          {scope_clause}
          AND NOT EXISTS (
              SELECT 1 FROM messages m
              WHERE m.message_id = l.branch_point_message_id
          )
        ORDER BY l.src_session_id
        {limit_clause}
        """,
        tuple(params),
    ).fetchall()
    repaired = 0
    local_composed_cache: dict[str, list[tuple[str, str]]] = composed_cache if composed_cache is not None else {}
    for src_session_id, parent_session_id, branch_point_message_id in rows:
        parent_id = str(parent_session_id)
        stale_branch_point = str(branch_point_message_id)
        suffix = _suffix_after_session_id(stale_branch_point, parent_id)
        if suffix is None:
            continue
        parent_composed = _composed_db_signatures(
            conn,
            parent_id,
            cache=cache,
            composed_cache=local_composed_cache,
        )
        replacement = _replacement_for_stale_prefix_branch_point(parent_composed, suffix)
        if replacement is None:
            continue
        if replacement == stale_branch_point:
            continue
        conn.execute(
            """
            UPDATE session_links
            SET branch_point_message_id = ?
            WHERE src_session_id = ?
              AND resolved_dst_session_id = ?
              AND branch_point_message_id = ?
              AND inheritance = 'prefix-sharing'
            """,
            (replacement, str(src_session_id), parent_id, stale_branch_point),
        )
        repaired += 1
```

### `REPO/tests/unit/storage/test_lineage_normalization.py:915` — `test_hermes_compression_tail_composes_and_delegate_stays_fresh`

Score: 173

```python
def test_hermes_compression_tail_composes_and_delegate_stays_fresh(
    tmp_path: Path,
    end_reason: str,
) -> None:
    state_db = tmp_path / "state.db"
    with sqlite3.connect(state_db) as source:
        source.executescript(
            """
            CREATE TABLE schema_version(version INTEGER NOT NULL);
            INSERT INTO schema_version VALUES (16);
            CREATE TABLE sessions (
                id TEXT PRIMARY KEY,
                source TEXT,
                model_config TEXT,
                parent_session_id TEXT,
                started_at REAL,
                ended_at REAL,
                end_reason TEXT,
                title TEXT
            );
            CREATE TABLE messages (
                id INTEGER PRIMARY KEY,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT,
                timestamp REAL NOT NULL,
                tool_calls TEXT,
                observed INTEGER,
                active INTEGER,
                compacted INTEGER
            );
            INSERT INTO sessions VALUES
                ('parent', 'cli', '{}', NULL, 1.0, 3.0, 'compression', 'Parent'),
                ('continuation', 'cli', '{}', 'parent', 4.0, NULL, NULL, 'Continuation'),
                ('delegate', 'tool', '{}', 'parent', 5.0, NULL, NULL, 'Delegate');
            INSERT INTO messages VALUES
                (1, 'parent', 'user', 'before', 1.0, NULL, 0, 1, 0),
                (2, 'parent', 'assistant', 'summary', 2.0, NULL, 0, 1, 0),
                (3, 'continuation', 'user', 'after', 4.0, NULL, 0, 1, 0),
                (4, 'continuation', 'assistant', 'continued', 4.5, NULL, 0, 1, 0),
                (5, 'delegate', 'assistant', 'fresh work', 5.0, NULL, 0, 1, 0);
            """
        )
        source.execute(
            "UPDATE sessions SET model_config = ? WHERE id = 'delegate'",
            (json.dumps({"_delegate_from": "parent"}),),
        )
        source.execute(
            "UPDATE sessions SET end_reason = ? WHERE id = 'parent'",
            (end_reason,),
        )

    parsed = parse_state_db(state_db)
    by_raw_id = {session.provider_session_id.split("@", 1)[0]: session for session in parsed}
    parent = by_raw_id["parent"]
    continuation = by_raw_id["continuation"]
    delegate = by_raw_id["delegate"]
    assert continuation.branch_type is BranchType.CONTINUATION
    assert any(
        event.event_type == "compaction" and event.payload.get("end_reason") == end_reason
        for event in parent.session_events
    )
    assert [message.text for message in continuation.messages] == ["before", "summary", "after", "continued"]
    assert delegate.branch_type is BranchType.SUBAGENT
    assert [message.text for message in delegate.messages] == ["fresh work"]

    db = tmp_path / "index.db"
    conn = _connect(db)
    parent_id = write_parsed_session_to_archive(conn, parent)
    continuation_id = write_parsed_session_to_archive(conn, continuation)
    delegate_id = write_parsed_session_to_archive(conn, delegate)

    physical = conn.execute(
        """
        SELECT b.text
        FROM messages AS m
        JOIN blocks AS b ON b.message_id = m.message_id
        WHERE m.session_id = ? AND b.block_type = 'text'
        ORDER BY m.position, b.position
        """,
```

## Child-before-parent and descendant repair

### `REPO/polylogue/storage/sqlite/queries/message_query_reads.py:137` — `get_messages_with_lineage_completeness`

Score: 278

```python
async def get_messages_with_lineage_completeness(
    conn: aiosqlite.Connection,
    session_id: str,
    *,
    _compose_in_position_order: bool = False,
) -> tuple[list[MessageRecord], LineageCompleteness]:
    """Compose a session's full message transcript, holding one read snapshot,
    and report whether the composed transcript is complete (4ts.6).

    Composition issues multiple autocommit SELECTs while walking the lineage
    chain (edge reads, then a read per ancestor/descendant). Without a held
    transaction, a concurrent parent re-ingest between those reads can yield a
    torn transcript (4ts.4). If ``conn`` is not already inside a transaction
    (e.g. a caller-held write transaction), this wraps the whole composition
    in one deferred read transaction so every SELECT sees the same snapshot.

    Two paths can silently return an INCOMPLETE transcript: a chain deeper
    than ``_MAX_LINEAGE_DEPTH`` (ancestors beyond the cutoff are dropped), or
    a dangling branch point (the parent message was hard-deleted, so only
    this session's own divergent tail is returned starting mid-conversation).
    Consumers that care (MCP get_messages, context-image) can distinguish a
    complete logical transcript from a truncated one via the returned
    ``LineageCompleteness``.
    """
    if not conn.in_transaction:
        await conn.execute("BEGIN DEFERRED")
        try:
            return await get_messages_with_lineage_completeness(
                conn, session_id, _compose_in_position_order=_compose_in_position_order
            )
        finally:
            await conn.execute("ROLLBACK")
    session_id = await _resolve_session_id(conn, session_id)

    # Lineage composition (#2467): a prefix-sharing child stores only its own
    # divergent tail. Walk UP the parent chain collecting (child, branch_point)
    # links to the root, then compose DOWN. This is ITERATIVE (not recursive) so
    # deep acompact/fork chains cannot hit Python's recursion limit; the composed
    # view is position-ordered end to end, while a plain session keeps the
    # sort-key order the keyset streamer relies on. A `visited` set stops a cyclic
    # session_link; _MAX_LINEAGE_DEPTH is only a runaway backstop.
    chain: list[tuple[str, str]] = []  # (child_session_id, branch_point_message_id), leaf-first
    visited: set[str] = {session_id}
    cursor_session = session_id
    depth_limited = False
    for _ in range(_MAX_LINEAGE_DEPTH):
        edge = await _prefix_sharing_edge(conn, cursor_session)
        if edge is None:
            break
        parent_session_id, branch_point_message_id = edge
        parent_session_id = await _resolve_session_id(conn, parent_session_id)
        if parent_session_id in visited:  # cyclic lineage: stop and compose what we have
            break
        chain.append((cursor_session, branch_point_message_id))
        visited.add(parent_session_id)
        cursor_session = parent_session_id
    else:
        # Loop exhausted _MAX_LINEAGE_DEPTH iterations without a break: there
        # may be more ancestors beyond the cutoff we never walked to.
        if await _prefix_sharing_edge(conn, cursor_session) is not None:
            depth_limited = True
            logger.warning(
                "lineage composition hit depth limit (%d) for session %s; ancestors beyond this depth are dropped",
                _MAX_LINEAGE_DEPTH,
                session_id,
            )

    if not chain:
        # depth_limited can only be set inside the for-else branch below,
        # which only runs after _MAX_LINEAGE_DEPTH non-empty chain entries --
        # an empty chain means the very first edge check returned None.
        return await _own_messages(conn, session_id, position_order=_compose_in_position_order), LineageCompleteness()

    # Compose from the root down: root's full transcript, then splice each
    # descendant's own tail at its branch point in the running composed view.
    composed = await _own_messages(conn, cursor_session, position_order=True)
    dangling = False
    for child_session_id, branch_point_message_id in reversed(chain):
        own = await _own_messages(conn, child_session_id, position_order=True)
        prefix: list[MessageRecord] = []
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:1811` — `_resolve_session_graph`

Score: 148

```python
def _resolve_session_graph(
    conn: sqlite3.Connection,
    session_id: str,
    native_id: str,
    origin: str,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    add_timing: Callable[[str, float], None] | None = None,
) -> None:
    def record_substage(name: str, started_at: float) -> None:
        if add_timing is not None:
            add_timing(f"index.graph_resolve.{name}", started_at)

    t0 = time.perf_counter()
    conn.execute(
        """
        UPDATE sessions
        SET root_session_id = session_id
        WHERE session_id = ? AND root_session_id IS NULL
        """,
        (session_id,),
    )
    record_substage("root_init", t0)
    t0 = time.perf_counter()
    _resolve_outbound_session_links(conn, session_id, origin)
    record_substage("outbound_links", t0)
    t0 = time.perf_counter()
    has_outbound_link = (
        conn.execute("SELECT 1 FROM session_links WHERE src_session_id = ? LIMIT 1", (session_id,)).fetchone()
        is not None
    )
    inbound_rows = conn.execute(
        """
        SELECT links.src_session_id
        FROM session_links links
        WHERE links.dst_native_id = ?
          AND links.resolved_dst_session_id IS NULL
          AND links.dst_origin = ?
        """,
        (native_id, origin),
    ).fetchall()
    record_substage("inbound_lookup", t0)
    t0 = time.perf_counter()
    if not has_outbound_link and not inbound_rows and _root_projection_current(conn, session_id):
        record_substage("root_current_check", t0)
        return
    record_substage("root_current_check", t0)
    composed_cache: dict[str, list[tuple[str, str]]] = {}
    t0 = time.perf_counter()
    for row in inbound_rows:
        conn.execute(
            """
            UPDATE session_links
            SET resolved_dst_session_id = ?,
                resolved_at_ms = COALESCE(resolved_at_ms, observed_at_ms)
            WHERE src_session_id = ?
              AND dst_native_id = ?
              AND resolved_dst_session_id IS NULL
            """,
            (session_id, row[0], native_id),
        )
        # Deferred tail extraction (#2467): a child ingested before its parent was
        # stored whole (the inherited prefix could not be aligned yet). Now that
        # the parent exists, normalize the child the same way the parent-known
        # write path does — drop the inherited prefix rows and record the edge.
        _reextract_prefix_tail_db(
            conn,
            str(row[0]),
            session_id,
            cache=cache,
            composed_cache=composed_cache,
            add_timing=add_timing,
        )
    record_substage("reextract_prefix_tails", t0)

    impacted_session_ids = {session_id, *(str(row[0]) for row in inbound_rows)}
    t0 = time.perf_counter()
    _repair_stale_prefix_branch_points_db(conn, impacted_session_ids, cache=cache, composed_cache=composed_cache)
    record_substage("repair_stale_branch_points", t0)
    t0 = time.perf_counter()
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:3343` — `_reextract_prefix_tail_db`

Score: 112

```python
def _reextract_prefix_tail_db(
    conn: sqlite3.Connection,
    child_session_id: str,
    parent_session_id: str,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    composed_cache: dict[str, list[tuple[str, str]]] | None = None,
    add_timing: Callable[[str, float], None] | None = None,
) -> None:
    """Normalize a child that was stored whole because its parent was ingested
    later (#2467). Aligns the child's already-stored messages against the parent's
    composed transcript, deletes the inherited-prefix rows, and records the edge.
    Only runs while the lineage edge is still un-extracted (``inheritance`` NULL).
    """

    def record_substage(name: str, started_at: float) -> None:
        if add_timing is not None:
            add_timing(f"index.graph_resolve.reextract_prefix_tails.{name}", started_at)

    t0 = time.perf_counter()
    edge = conn.execute(
        """
        SELECT dst_origin, dst_native_id, link_type
        FROM session_links
        WHERE src_session_id = ?
          AND resolved_dst_session_id = ?
          AND inheritance IS NULL
        LIMIT 1
        """,
        (child_session_id, parent_session_id),
    ).fetchone()
    record_substage("edge_lookup", t0)
    if edge is None:
        return
    dst_origin, dst_native_id, link_type = edge
    t0 = time.perf_counter()
    parent_composed = _composed_db_signatures(
        conn,
        parent_session_id,
        cache=cache,
        composed_cache=composed_cache,
    )
    record_substage("parent_composed", t0)
    t0 = time.perf_counter()
    child_composed = _composed_db_signatures(
        conn,
        child_session_id,
        cache=cache,
        composed_cache=composed_cache,
    )
    record_substage("child_composed", t0)
    t0 = time.perf_counter()
    k = 0
    limit = min(len(parent_composed), len(child_composed))
    while k < limit and parent_composed[k][1] == child_composed[k][1]:
        k += 1
    record_substage("signature_compare", t0)

    def _set_edge(branch_point_message_id: str | None, inheritance: str) -> None:
        conn.execute(
            """
            UPDATE session_links
            SET branch_point_message_id = ?, inheritance = ?
            WHERE src_session_id = ? AND dst_origin = ? AND dst_native_id = ? AND link_type = ?
            """,
            (branch_point_message_id, inheritance, child_session_id, dst_origin, dst_native_id, link_type),
        )

    if k == 0:
        t0 = time.perf_counter()
        _set_edge(None, "spawned-fresh")
        record_substage("edge_update", t0)
        return
    prefix_message_ids = [child_composed[i][0] for i in range(k)]
    t0 = time.perf_counter()
    _remap_session_event_prefix_refs(
        conn,
        child_session_id,
        tuple((prefix_message_ids[index], parent_composed[index][0]) for index in range(k)),
    )
```

### `REPO/polylogue/storage/sqlite/queries/session_links.py:175` — `resolve_session_links_for_session`

Score: 90

```python
async def resolve_session_links_for_session(
    conn: aiosqlite.Connection,
    *,
    session_id: str,
    origin: str,
    native_id: str,
    resolved_at: str,
) -> int:
    observed_at_ms = _timestamp_ms(resolved_at) or 0
    cursor = await conn.execute(
        """
        SELECT src_session_id, link_type
          FROM session_links
         WHERE resolved_dst_session_id IS NULL
           AND status IS NULL
           AND dst_origin = ?
           AND dst_native_id = ?
        """,
        (origin, native_id),
    )
    pending_rows = list(await cursor.fetchall())
    if not pending_rows:
        return 0

    valid_branch_types: set[str] = {bt.value for bt in BranchType}
    flipped = 0
    for row in pending_rows:
        child_id = row["src_session_id"]
        link_type = row["link_type"]

        cycle_path = await _would_create_cycle(conn, child_id=child_id, proposed_parent_id=session_id)
        if cycle_path is not None:
            await _quarantine_link(
                conn,
                src_session_id=child_id,
                dst_origin=origin,
                dst_native_id=native_id,
                link_type=link_type,
                cycle_path=cycle_path,
                observed_at_ms=observed_at_ms,
            )
            continue

        await conn.execute(
            """
            UPDATE session_links
               SET resolved_dst_session_id = ?,
                   resolved_at_ms = ?
             WHERE resolved_dst_session_id IS NULL
               AND status IS NULL
               AND src_session_id = ?
               AND dst_origin = ?
               AND dst_native_id = ?
               AND link_type = ?
            """,
            (session_id, observed_at_ms, child_id, origin, native_id, link_type),
        )
        flipped += 1
        branch_type: str | None = link_type if link_type in valid_branch_types else None
        await conn.execute(
            """
            UPDATE sessions
               SET parent_session_id = COALESCE(parent_session_id, ?),
                   branch_type = COALESCE(branch_type, ?)
             WHERE session_id = ?
            """,
            (session_id, branch_type, child_id),
        )

    return flipped
```

## Cycle quarantine

### `REPO/polylogue/storage/sqlite/queries/session_links.py:125` — `_quarantine_link`

Score: 104

```python
async def _quarantine_link(
    conn: aiosqlite.Connection,
    *,
    src_session_id: str,
    dst_origin: str | None,
    dst_native_id: str | None,
    link_type: str | None,
    cycle_path: list[str],
    observed_at_ms: int,
) -> None:
    evidence = json.dumps(
        {
            "reason": "cycle_rejected",
            "cycle_path": cycle_path,
            "detected_at_ms": observed_at_ms,
        },
        sort_keys=True,
    )
    if dst_origin is None or dst_native_id is None or link_type is None:
        await conn.execute(
            """
            UPDATE session_links
               SET status = 'quarantined',
                   evidence_json = ?,
                   resolved_at_ms = ?
             WHERE src_session_id = ?
            """,
            (evidence, observed_at_ms, src_session_id),
        )
        return
    await conn.execute(
        """
        UPDATE session_links
           SET status = 'quarantined',
               evidence_json = ?,
               resolved_at_ms = ?
         WHERE src_session_id = ?
           AND dst_origin = ?
           AND dst_native_id = ?
           AND link_type = ?
        """,
        (evidence, observed_at_ms, src_session_id, dst_origin, dst_native_id, link_type),
    )
```

### `REPO/tests/property/test_write_path_state_machine.py:484` — `test_session_link_resolver_quarantines_cycle`

Score: 101

```python
def test_session_link_resolver_quarantines_cycle() -> None:
    """The async resolver quarantines a late link that would close a cycle."""
    with tempfile.TemporaryDirectory(prefix="polylogue-write-model-", dir="/realm/tmp") as root_text:
        archive_root = Path(root_text)
        initialize_active_archive_root(archive_root)
        db_path = archive_root / "index.db"
        conn = sqlite3.connect(str(db_path))
        try:
            parent = ParsedSession(
                source_name=Provider.CLAUDE_CODE,
                provider_session_id="cycle-parent",
                messages=[ParsedMessage(provider_message_id="parent-0", role=Role.USER, text="parent", position=0)],
            )
            child = ParsedSession(
                source_name=Provider.CLAUDE_CODE,
                provider_session_id="cycle-child",
                parent_session_provider_id="cycle-parent",
                branch_type=BranchType.FORK,
                messages=[ParsedMessage(provider_message_id="child-0", role=Role.USER, text="child", position=0)],
            )
            parent_id = write_parsed_session_to_archive(conn, parent, content_hash=session_content_hash(parent))
            write_parsed_session_to_archive(conn, child, content_hash=session_content_hash(child))
            conn.execute(
                """
                INSERT INTO session_links (
                    src_session_id, dst_origin, dst_native_id, link_type,
                    status, method, confidence, evidence_json, observed_at_ms
                ) VALUES (?, 'claude-code-session', 'cycle-child', 'fork', NULL, 'test', 1.0, '[]', 0)
                """,
                (parent_id,),
            )
            conn.commit()
        finally:
            conn.close()

        async def resolve_cycle() -> int:
            async with aiosqlite.connect(db_path) as async_conn:
                await configure_connection(async_conn)
                resolved = await resolve_unresolved_links_for_child(
                    async_conn,
                    src_session_id=parent_id,
                    resolved_at="2026-01-01T00:00:00Z",
                )
                await async_conn.commit()
            return resolved

        assert asyncio.run(resolve_cycle()) == 0
        with sqlite3.connect(str(db_path)) as verify_conn:
            row = verify_conn.execute(
                "SELECT resolved_dst_session_id, status, evidence_json FROM session_links WHERE src_session_id = ?",
                (parent_id,),
            ).fetchone()
        assert row is not None
        assert row[0] is None
        assert row[1] == TopologyEdgeStatus.QUARANTINED.value
        assert '"reason": "cycle_rejected"' in row[2]
```

### `REPO/polylogue/storage/sqlite/queries/session_links.py:175` — `resolve_session_links_for_session`

Score: 90

```python
async def resolve_session_links_for_session(
    conn: aiosqlite.Connection,
    *,
    session_id: str,
    origin: str,
    native_id: str,
    resolved_at: str,
) -> int:
    observed_at_ms = _timestamp_ms(resolved_at) or 0
    cursor = await conn.execute(
        """
        SELECT src_session_id, link_type
          FROM session_links
         WHERE resolved_dst_session_id IS NULL
           AND status IS NULL
           AND dst_origin = ?
           AND dst_native_id = ?
        """,
        (origin, native_id),
    )
    pending_rows = list(await cursor.fetchall())
    if not pending_rows:
        return 0

    valid_branch_types: set[str] = {bt.value for bt in BranchType}
    flipped = 0
    for row in pending_rows:
        child_id = row["src_session_id"]
        link_type = row["link_type"]

        cycle_path = await _would_create_cycle(conn, child_id=child_id, proposed_parent_id=session_id)
        if cycle_path is not None:
            await _quarantine_link(
                conn,
                src_session_id=child_id,
                dst_origin=origin,
                dst_native_id=native_id,
                link_type=link_type,
                cycle_path=cycle_path,
                observed_at_ms=observed_at_ms,
            )
            continue

        await conn.execute(
            """
            UPDATE session_links
               SET resolved_dst_session_id = ?,
                   resolved_at_ms = ?
             WHERE resolved_dst_session_id IS NULL
               AND status IS NULL
               AND src_session_id = ?
               AND dst_origin = ?
               AND dst_native_id = ?
               AND link_type = ?
            """,
            (session_id, observed_at_ms, child_id, origin, native_id, link_type),
        )
        flipped += 1
        branch_type: str | None = link_type if link_type in valid_branch_types else None
        await conn.execute(
            """
            UPDATE sessions
               SET parent_session_id = COALESCE(parent_session_id, ?),
                   branch_type = COALESCE(branch_type, ?)
             WHERE session_id = ?
            """,
            (session_id, branch_type, child_id),
        )

    return flipped
```

### `REPO/polylogue/storage/sqlite/queries/session_links.py:247` — `resolve_unresolved_links_for_child`

Score: 60

```python
async def resolve_unresolved_links_for_child(
    conn: aiosqlite.Connection,
    *,
    src_session_id: str,
    resolved_at: str,
) -> int:
    observed_at_ms = _timestamp_ms(resolved_at) or 0
    cursor = await conn.execute(
        """
        SELECT link.link_type, link.dst_origin, link.dst_native_id, dst.session_id AS parent_id
          FROM session_links AS link
          JOIN sessions AS dst
            ON dst.origin = link.dst_origin
           AND dst.native_id = link.dst_native_id
         WHERE link.src_session_id = ?
           AND link.resolved_dst_session_id IS NULL
           AND link.status IS NULL
        """,
        (src_session_id,),
    )
    rows = list(await cursor.fetchall())
    if not rows:
        return 0

    valid_branch_types: set[str] = {bt.value for bt in BranchType}
    resolved = 0
    for row in rows:
        link_type = row["link_type"]
        parent_id = row["parent_id"]

        cycle_path = await _would_create_cycle(conn, child_id=src_session_id, proposed_parent_id=parent_id)
        if cycle_path is not None:
            await _quarantine_link(
                conn,
                src_session_id=src_session_id,
                dst_origin=row["dst_origin"],
                dst_native_id=row["dst_native_id"],
                link_type=link_type,
                cycle_path=cycle_path,
                observed_at_ms=observed_at_ms,
            )
            continue

        await conn.execute(
            """
            UPDATE session_links
               SET resolved_dst_session_id = ?,
                   resolved_at_ms = ?
             WHERE src_session_id = ?
               AND dst_origin = ?
               AND dst_native_id = ?
               AND link_type = ?
               AND resolved_dst_session_id IS NULL
               AND status IS NULL
            """,
            (parent_id, observed_at_ms, src_session_id, row["dst_origin"], row["dst_native_id"], link_type),
        )
        branch_type: str | None = link_type if link_type in valid_branch_types else None
        await conn.execute(
            """
            UPDATE sessions
               SET parent_session_id = COALESCE(parent_session_id, ?),
                   branch_type = COALESCE(branch_type, ?)
             WHERE session_id = ?
            """,
            (parent_id, branch_type, src_session_id),
        )
        resolved += 1
    return resolved
```

## Thread and insight projection rebuild

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:1811` — `_resolve_session_graph`

Score: 148

```python
def _resolve_session_graph(
    conn: sqlite3.Connection,
    session_id: str,
    native_id: str,
    origin: str,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    add_timing: Callable[[str, float], None] | None = None,
) -> None:
    def record_substage(name: str, started_at: float) -> None:
        if add_timing is not None:
            add_timing(f"index.graph_resolve.{name}", started_at)

    t0 = time.perf_counter()
    conn.execute(
        """
        UPDATE sessions
        SET root_session_id = session_id
        WHERE session_id = ? AND root_session_id IS NULL
        """,
        (session_id,),
    )
    record_substage("root_init", t0)
    t0 = time.perf_counter()
    _resolve_outbound_session_links(conn, session_id, origin)
    record_substage("outbound_links", t0)
    t0 = time.perf_counter()
    has_outbound_link = (
        conn.execute("SELECT 1 FROM session_links WHERE src_session_id = ? LIMIT 1", (session_id,)).fetchone()
        is not None
    )
    inbound_rows = conn.execute(
        """
        SELECT links.src_session_id
        FROM session_links links
        WHERE links.dst_native_id = ?
          AND links.resolved_dst_session_id IS NULL
          AND links.dst_origin = ?
        """,
        (native_id, origin),
    ).fetchall()
    record_substage("inbound_lookup", t0)
    t0 = time.perf_counter()
    if not has_outbound_link and not inbound_rows and _root_projection_current(conn, session_id):
        record_substage("root_current_check", t0)
        return
    record_substage("root_current_check", t0)
    composed_cache: dict[str, list[tuple[str, str]]] = {}
    t0 = time.perf_counter()
    for row in inbound_rows:
        conn.execute(
            """
            UPDATE session_links
            SET resolved_dst_session_id = ?,
                resolved_at_ms = COALESCE(resolved_at_ms, observed_at_ms)
            WHERE src_session_id = ?
              AND dst_native_id = ?
              AND resolved_dst_session_id IS NULL
            """,
            (session_id, row[0], native_id),
        )
        # Deferred tail extraction (#2467): a child ingested before its parent was
        # stored whole (the inherited prefix could not be aligned yet). Now that
        # the parent exists, normalize the child the same way the parent-known
        # write path does — drop the inherited prefix rows and record the edge.
        _reextract_prefix_tail_db(
            conn,
            str(row[0]),
            session_id,
            cache=cache,
            composed_cache=composed_cache,
            add_timing=add_timing,
        )
    record_substage("reextract_prefix_tails", t0)

    impacted_session_ids = {session_id, *(str(row[0]) for row in inbound_rows)}
    t0 = time.perf_counter()
    _repair_stale_prefix_branch_points_db(conn, impacted_session_ids, cache=cache, composed_cache=composed_cache)
    record_substage("repair_stale_branch_points", t0)
    t0 = time.perf_counter()
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:677` — `apply_insight_materialization`

Score: 48

```python
def apply_insight_materialization(
    conn: sqlite3.Connection,
    *,
    insight_type: str,
    session_id: str,
    materializer_version: int,
    materialized_at_ms: int,
    source_updated_at_ms: int | None = None,
    source_sort_key_ms: int | None = None,
    input_high_water_mark_ms: int | None = None,
    input_high_water_mark_source: str | None = None,
    input_row_count: int = 0,
) -> None:
    """Stamp one session-insight materialization row without committing.

    The bulk insight rebuild (``rebuild_session_insights_sync``) materializes
    every insight table inside one transaction so a SIGKILL mid-rebuild rolls
    the WAL back to the prior insights. It therefore stamps materialization
    through this no-commit primitive; the committing ``upsert_*`` wrapper below
    is for callers that stamp a single insight as its own unit of work.
    """
    conn.execute(
        """
        INSERT INTO insight_materialization (
            insight_type, session_id, materializer_version, materialized_at_ms,
            source_updated_at_ms, source_sort_key_ms, input_high_water_mark_ms,
            input_high_water_mark_source, input_row_count
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(insight_type, session_id) DO UPDATE SET
            materializer_version = excluded.materializer_version,
            materialized_at_ms = excluded.materialized_at_ms,
            source_updated_at_ms = excluded.source_updated_at_ms,
            source_sort_key_ms = excluded.source_sort_key_ms,
            input_high_water_mark_ms = excluded.input_high_water_mark_ms,
            input_high_water_mark_source = excluded.input_high_water_mark_source,
            input_row_count = excluded.input_row_count
        """,
        (
            insight_type,
            session_id,
            materializer_version,
            materialized_at_ms,
            source_updated_at_ms,
            source_sort_key_ms,
            input_high_water_mark_ms,
            input_high_water_mark_source,
            input_row_count,
        ),
    )
```

## Inherited-prefix readers

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:791` — `read_archive_session_envelope`

Score: 342

```python
def read_archive_session_envelope(
    conn: sqlite3.Connection, session_id: str, *, _depth: int = 0
) -> ArchiveSessionEnvelope:
    """Read a compact archive envelope, holding one read snapshot across composition.

    For a prefix-sharing lineage child (#2467) the inherited prefix is not stored
    under this session; the returned ``messages`` compose the parent's transcript
    up to the branch point followed by this session's own messages, so reads see
    the full logical transcript while storage holds each message once.

    Composition issues multiple autocommit SELECTs across a recursive parent
    walk (own read -> edge read -> recursive parent read). Without a held
    transaction, a concurrent parent re-ingest between those reads can yield a
    torn transcript (4ts.4). If ``conn`` is not already inside a transaction
    (e.g. a caller-held write transaction), this wraps the whole composition
    in one deferred read transaction so every SELECT sees the same snapshot;
    recursive calls see ``conn.in_transaction`` already true and skip
    re-wrapping.
    """
    if not conn.in_transaction:
        conn.execute("BEGIN DEFERRED")
        try:
            return read_archive_session_envelope(conn, session_id, _depth=_depth)
        finally:
            conn.execute("ROLLBACK")
    conn.row_factory = sqlite3.Row
    session = conn.execute(
        """
        SELECT session_id, native_id, origin, title, session_kind, active_leaf_message_id,
               parent_session_id, root_session_id, branch_type,
               title_source, instructions_text,
               created_at_ms, updated_at_ms, git_branch, git_repository_url, provider_project_ref
        FROM sessions
        WHERE session_id = ?
        """,
        (session_id,),
    ).fetchone()
    if session is None:
        raise KeyError(session_id)
    working_directories = tuple(
        str(row["path"])
        for row in conn.execute(
            """
            SELECT path
            FROM session_working_dirs
            WHERE session_id = ?
            ORDER BY position, path
            """,
            (session_id,),
        ).fetchall()
    )

    attachment_rows = conn.execute(
        """
        SELECT r.message_id AS message_id, a.attachment_id AS attachment_id,
               a.display_name AS display_name, a.media_type AS media_type, a.byte_count AS byte_count,
               r.upload_origin AS upload_origin, r.source_url AS source_url, r.caption AS caption
        FROM attachment_refs r
        JOIN attachments a ON a.attachment_id = r.attachment_id
        WHERE r.session_id = ?
        ORDER BY r.message_id, a.attachment_id
        """,
        (session_id,),
    ).fetchall()
    attachments_by_message: dict[str | None, list[ArchiveAttachmentRow]] = {}
    for attachment in attachment_rows:
        attachments_by_message.setdefault(attachment["message_id"], []).append(
            ArchiveAttachmentRow(
                attachment_id=attachment["attachment_id"],
                message_id=attachment["message_id"],
                display_name=attachment["display_name"],
                media_type=attachment["media_type"],
                byte_count=int(attachment["byte_count"] or 0),
                upload_origin=attachment["upload_origin"],
                source_url=attachment["source_url"],
                caption=attachment["caption"],
            )
        )

    message_rows = conn.execute(
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:3343` — `_reextract_prefix_tail_db`

Score: 112

```python
def _reextract_prefix_tail_db(
    conn: sqlite3.Connection,
    child_session_id: str,
    parent_session_id: str,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    composed_cache: dict[str, list[tuple[str, str]]] | None = None,
    add_timing: Callable[[str, float], None] | None = None,
) -> None:
    """Normalize a child that was stored whole because its parent was ingested
    later (#2467). Aligns the child's already-stored messages against the parent's
    composed transcript, deletes the inherited-prefix rows, and records the edge.
    Only runs while the lineage edge is still un-extracted (``inheritance`` NULL).
    """

    def record_substage(name: str, started_at: float) -> None:
        if add_timing is not None:
            add_timing(f"index.graph_resolve.reextract_prefix_tails.{name}", started_at)

    t0 = time.perf_counter()
    edge = conn.execute(
        """
        SELECT dst_origin, dst_native_id, link_type
        FROM session_links
        WHERE src_session_id = ?
          AND resolved_dst_session_id = ?
          AND inheritance IS NULL
        LIMIT 1
        """,
        (child_session_id, parent_session_id),
    ).fetchone()
    record_substage("edge_lookup", t0)
    if edge is None:
        return
    dst_origin, dst_native_id, link_type = edge
    t0 = time.perf_counter()
    parent_composed = _composed_db_signatures(
        conn,
        parent_session_id,
        cache=cache,
        composed_cache=composed_cache,
    )
    record_substage("parent_composed", t0)
    t0 = time.perf_counter()
    child_composed = _composed_db_signatures(
        conn,
        child_session_id,
        cache=cache,
        composed_cache=composed_cache,
    )
    record_substage("child_composed", t0)
    t0 = time.perf_counter()
    k = 0
    limit = min(len(parent_composed), len(child_composed))
    while k < limit and parent_composed[k][1] == child_composed[k][1]:
        k += 1
    record_substage("signature_compare", t0)

    def _set_edge(branch_point_message_id: str | None, inheritance: str) -> None:
        conn.execute(
            """
            UPDATE session_links
            SET branch_point_message_id = ?, inheritance = ?
            WHERE src_session_id = ? AND dst_origin = ? AND dst_native_id = ? AND link_type = ?
            """,
            (branch_point_message_id, inheritance, child_session_id, dst_origin, dst_native_id, link_type),
        )

    if k == 0:
        t0 = time.perf_counter()
        _set_edge(None, "spawned-fresh")
        record_substage("edge_update", t0)
        return
    prefix_message_ids = [child_composed[i][0] for i in range(k)]
    t0 = time.perf_counter()
    _remap_session_event_prefix_refs(
        conn,
        child_session_id,
        tuple((prefix_message_ids[index], parent_composed[index][0]) for index in range(k)),
    )
```

### `REPO/polylogue/storage/sqlite/archive_tiers/write.py:3265` — `_composed_db_signatures`

Score: 106

```python
def _composed_db_signatures(
    conn: sqlite3.Connection,
    session_id: str,
    *,
    cache: dict[str, list[tuple[str, str]]] | None = None,
    composed_cache: dict[str, list[tuple[str, str]]] | None = None,
    _depth: int = 0,
) -> list[tuple[str, str]]:
    """Return ``[(message_id, signature), ...]`` for ``session_id``'s composed
    transcript (its inherited prefix + own tail), recursively resolving any
    prefix-sharing lineage edge. Mirrors the read-side composition.

    When ``cache`` is supplied, each session's OWN signatures are memoized by
    ``session_id`` for the life of one ingest batch. When ``composed_cache`` is
    supplied, composed (prefix+own) results are memoized only for one graph
    resolution operation; that avoids cross-write stale ancestors while letting
    sibling delayed-tail repairs share the same parent composition.

    Callers typically already hold a write transaction (single-writer ingest),
    but if ``conn`` is not already inside one this wraps the whole recursive
    composition in one deferred read transaction (4ts.4), matching
    ``read_archive_session_envelope``'s guard against a torn read.
    """
    if not conn.in_transaction:
        conn.execute("BEGIN DEFERRED")
        try:
            return _composed_db_signatures(conn, session_id, cache=cache, composed_cache=composed_cache, _depth=_depth)
        finally:
            conn.execute("ROLLBACK")
    if composed_cache is not None:
        composed = composed_cache.get(session_id)
        if composed is not None:
            return composed
    own = cache.get(session_id) if cache is not None else None
    if own is None:
        own = _own_db_signatures(conn, session_id)
        if cache is not None:
            cache[session_id] = own

    if _depth >= _MAX_LINEAGE_DEPTH:
        if composed_cache is not None:
            composed_cache[session_id] = own
        return own
    edge = conn.execute(
        """
        SELECT resolved_dst_session_id, branch_point_message_id
        FROM session_links
        WHERE src_session_id = ?
          AND inheritance = 'prefix-sharing'
          AND resolved_dst_session_id IS NOT NULL
          AND branch_point_message_id IS NOT NULL
        LIMIT 1
        """,
        (session_id,),
    ).fetchone()
    if edge is None:
        if composed_cache is not None:
            composed_cache[session_id] = own
        return own
    parent_id, branch_point_message_id = edge
    parent_composed = _composed_db_signatures(
        conn,
        str(parent_id),
        cache=cache,
        composed_cache=composed_cache,
        _depth=_depth + 1,
    )
    prefix: list[tuple[str, str]] = []
    for entry in parent_composed:
        prefix.append(entry)
        if entry[0] == branch_point_message_id:
            break
    composed = prefix + own
    if composed_cache is not None:
        composed_cache[session_id] = composed
    return composed
```

### `REPO/tests/unit/storage/test_lineage_normalization.py:79` — `test_prefix_sharing_child_stores_only_tail_and_composes`

Score: 65

```python
def test_prefix_sharing_child_stores_only_tail_and_composes(tmp_path: Path) -> None:
    db = tmp_path / "index.db"
    conn = _connect(db)

    parent = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="parent",
        title="parent",
        messages=[
            _msg("p0", Role.USER, "hello", 0),
            _msg("p1", Role.ASSISTANT, "hi there", 1),
            _msg("p2", Role.USER, "parent continues alone", 2),
        ],
    )
    parent_id = write_parsed_session_to_archive(conn, parent)

    # Child forked after parent[1]: it replays p0/p1 (identical content, fresh
    # provider ids, as a real fork does) then diverges into its own work.
    child = ParsedSession(
        source_name=Provider.CODEX,
        provider_session_id="child",
        title="child",
        parent_session_provider_id="parent",
        branch_type=BranchType.FORK,
        messages=[
            _msg("c0", Role.USER, "hello", 0),
            _msg("c1", Role.ASSISTANT, "hi there", 1),
            _msg("cx", Role.USER, "child diverges here", 2),
            _msg("cy", Role.ASSISTANT, "child reply", 3),
        ],
    )
    child_id = write_parsed_session_to_archive(conn, child)

    # Only the divergent tail is physically stored under the child, at its
    # original positions (2, 3) — the inherited prefix is not duplicated.
    stored = conn.execute(
        "SELECT position FROM messages WHERE session_id = ? ORDER BY position",
        (child_id,),
    ).fetchall()
    assert [row[0] for row in stored] == [2, 3]

    # Aggregate count reflects the child's own messages only (no double count).
    message_count = conn.execute(
        "SELECT message_count FROM sessions WHERE session_id = ?",
        (child_id,),
    ).fetchone()[0]
    assert message_count == 2

    # The lineage edge records the branch point and the inheritance kind.
    link = conn.execute(
        """
        SELECT inheritance, branch_point_message_id, resolved_dst_session_id
        FROM session_links WHERE src_session_id = ?
        """,
        (child_id,),
    ).fetchone()
    assert link["inheritance"] == "prefix-sharing"
    assert link["branch_point_message_id"] is not None
    assert link["resolved_dst_session_id"] == parent_id

    # The sync envelope read (MCP get_session_summary / CLI read) also composes.
    envelope = read_archive_session_envelope(conn, child_id)
    assert ["".join(block.text or "" for block in message.blocks) for message in envelope.messages] == [
        "hello",
        "hi there",
        "child diverges here",
        "child reply",
    ]

    conn.close()

    # Reading the child via the async query path composes the same transcript.
    composed = asyncio.run(_read_texts(db, child_id))
    assert composed == ["hello", "hi there", "child diverges here", "child reply"]
```

## Inferred end-to-end route

The common write route is: freshness gate → normalize snapshot → obtain the parent’s canonical `(position, variant_index)` stream → identify the branch cut → delete/reinsert the replacing session → upsert the lineage edge and its cut evidence → revisit both unresolved and already-resolved descendants → rebuild thread and insight projections. Readers then resolve the edge, verify the witnessed inherited prefix, and compose only the verified prefix with the child-owned tail.

The central invariant is that writers, repair jobs, and readers must use the same canonical ordering and the same witnessed cut. A coordinate-only or `variant_index = 0` writer cannot be safely composed by a reader that includes sibling variants.
