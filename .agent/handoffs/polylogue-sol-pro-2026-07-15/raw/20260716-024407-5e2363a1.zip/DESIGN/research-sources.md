# Primary research sources

Access date: 2026-07-15.

These sources support the implementation choices around JSON evidence, deterministic SQL ordering, and idempotent edge upserts. They do not substitute for the supplied repository evidence.

## SQLite JSON functions

URL: https://www.sqlite.org/json1.html
Fetch result: unavailable in container: URLError: <urlopen error [Errno -3] Temporary failure in name resolution>
Retrieved bytes: None
Content SHA-256: None

## SQLite SELECT ordering semantics

URL: https://www.sqlite.org/lang_select.html
Fetch result: unavailable in container: URLError: <urlopen error [Errno -3] Temporary failure in name resolution>
Retrieved bytes: None
Content SHA-256: None

## SQLite UPSERT

URL: https://www.sqlite.org/lang_upsert.html
Fetch result: unavailable in container: URLError: <urlopen error [Errno -3] Temporary failure in name resolution>
Retrieved bytes: None
Content SHA-256: None

## Concrete project decisions

- Store the cut witness as an additive object inside the existing JSON evidence column.
- Make SQL ordering explicit on both `position` and `variant_index`; row order without a complete `ORDER BY` is not treated as lineage evidence.
- Keep the edge upsert idempotent and regenerate its witness from the canonical prefix during normal repair.
