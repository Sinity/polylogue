# Evidence and rejected alternatives

The observed incident—an operator profile remaining attached to dead `127.0.0.1:8876` while a packaged receiver remained available—cannot be repaired safely with retries alone. Endpoint-only state neither identifies the disappeared runtime nor detects a different runtime later occupying the same address.

Rejected: scanning localhost ports; treating reachability as authentication; accepting unauthenticated health as pairing authority; logging or query-encoding bearer tokens; silently substituting a canonical receiver; clearing queues during repair; privileging one browser profile; or accepting a durable ACK that does not name the intended receiver.

This fallback handoff preserves a reference contract and fixtures, but does not claim production route/UI wiring. That integration remains required unless the main worktree implementation patch was produced before packaging.
