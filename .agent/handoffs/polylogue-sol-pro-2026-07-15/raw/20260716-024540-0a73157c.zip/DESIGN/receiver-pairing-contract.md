# Stable receiver runtime identity contract

A URL is transport, not identity. Pairing authority is an authenticated tuple of normalized endpoint, durable receiver UUID, protocol/schema version, and explicit mode (`canonical` or `isolated-dev`). The receiver UUID is generated once and persisted beside durable spool state. Authenticated status and every durable acceptance receipt expose it. Work-bearing requests send the expected UUID; mismatch returns a classified conflict before request-body acceptance.

Extension runtime state stores last successful authenticated contact and a non-secret failure class: transport offline, authentication rejected, identity mismatch/stale pairing, incompatible schema/protocol, receiver rejection, or invalid durable receipt. Legacy endpoint/token configuration is only an unverified candidate until an authenticated handshake succeeds.

Reset/re-pair is finite and explicit: only configured/canonical candidates are attempted, never a localhost scan. It never falls back unauthenticated and never puts a bearer token in a URL, log, receipt, or UI. Commit replaces pairing metadata only. The stable extension instance ID, queued captures, retry queue, backfill jobs, checkpoints, and recovery state remain unchanged.

Two profiles may share one receiver UUID while retaining different extension instance IDs. An isolated development receiver requires explicit mode and endpoint selection; localhost is not itself a trust signal. Queue/backfill retirement requires existing durability fields plus a matching receiver UUID.
