# Verification limits

The archive structure, manifest hashes/sizes, duplicate/unsafe paths, and final ZIP reopening are verified. The fallback patch is syntax-preserving text and the included verification script performs `git apply --check`, application in a temporary copy, and `git diff --check` when supplied a clean checkout.

The production extension/receiver routes, storage migration, popup/page rendering, receiver spool UUID persistence, queue/backfill drains, operator secrets, real browser profiles, daemon databases, packaged service, and NixOS deployment were not available and were not run. The patch therefore does not claim integrated production completion. It is the strongest internally consistent contract/fixture state retained when no verified integrated worktree ZIP was available.
