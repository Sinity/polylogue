# Scenario matrix

| Scenario | Assertion |
|---|---|
| Profiles A and B share canonical receiver R | Distinct extension instance IDs survive; both pairing records name R; independent drains accept only receipts naming R. |
| Profile C explicitly uses isolated dev receiver D | Pairing mode is explicit; no canonical substitution or port scan; loss shows last contact plus transport failure. |
| Endpoint formerly D now serves R | Expected D mismatch is rejected before body acceptance; stale-pairing UI state; queue remains. |
| Legacy URL/token | Candidate remains unpaired until authenticated identity/schema handshake; pending stores unchanged. |
| Re-pair D to R with pending work | Only pairing metadata changes; preserved drain is retired after a durable receipt naming R. |
| Wrong/missing receipt receiver ID | Receipt validation fails and work stays pending. |
| Auth/schema failure | Distinct non-secret failure class; no unauthenticated fallback. |
