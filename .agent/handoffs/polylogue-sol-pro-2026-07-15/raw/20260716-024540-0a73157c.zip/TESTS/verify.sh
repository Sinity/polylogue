#!/usr/bin/env bash
set -euo pipefail
[[ $# -eq 1 ]] || { echo "usage: $0 /path/to/clean/repo" >&2; exit 64; }
ROOT=$(cd "$(dirname "$0")/.." && pwd)
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
cp -a "$1/." "$TMP/repo/"; cd "$TMP/repo"
while IFS= read -r p; do [[ -z "$p" || "$p" == \#* ]] && continue; git apply --check "$ROOT/PATCHES/$p"; git apply "$ROOT/PATCHES/$p"; done < "$ROOT/PATCHES/SERIES"
git diff --check
echo "Reference patch applies cleanly. Production route/UI integration tests remain required."
