# Polylogue stable receiver-pairing handoff

Read `SUMMARY.md` first, then both `DESIGN/` files, `PATCHES/SERIES`, the patch, and `TESTS/`.

Base assumption: `518ac33e (snapshot-recorded prefix; full object availability depends on supplied context)`. The snapshot-recorded pre-existing `.beads/issues.jsonl` dirty state is excluded.

Apply from a clean supplied-snapshot checkout:

```bash
while IFS= read -r p; do
  [[ -z "$p" || "$p" == \#* ]] && continue
  git apply --check "/path/to/handoff/PATCHES/$p"
  git apply "/path/to/handoff/PATCHES/$p"
done < /path/to/handoff/PATCHES/SERIES
```

This guarded fallback contains a reference contract/schema/fixtures patch rather than claiming production wiring that could not be verified. The exact residual integration is in `SUMMARY.md` and `VERIFICATION-LIMITS.md`.
