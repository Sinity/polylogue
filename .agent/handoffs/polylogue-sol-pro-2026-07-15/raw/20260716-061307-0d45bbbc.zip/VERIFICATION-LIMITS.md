# Verification record and limits

## Snapshot identity

The immutable task metadata reports upstream revision `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`, branch `feature/browser/adopt-completion-monitors`, and a clean working tree with no staged or unstaged patch. The archive contains 124 repository files and does not include upstream Git objects. A synthetic local baseline commit was created only to generate and compare patches.

## Checks run successfully

The following checks were executed against the patched supplied tree:

```text
git diff --check <synthetic-base>..HEAD
python -m compileall -q polylogue tests
python TESTS/verify_projection.py --repo <patched> --fixtures TESTS/objective_posture_cases.json
python TESTS/verify_persistence.py --repo <patched>
python TESTS/measure_objective_posture.py --gold TESTS/measurement-smoke-gold.jsonl --predictions TESTS/measurement-smoke-predictions.jsonl --k 5
```

Results:

```text
patch apply: PASS, four commits
changed-path SHA-256 comparison: PASS, 17/17
patch diff check: PASS
bytecode compilation: PASS
projection fixtures: 13/13 PASS
structural fixtures: 5/5 PASS
authority ablation: PASS
bounded structural boundaries: PASS
known anchor: clean_finish + awaiting_operator + resumable + message ref
Pydantic enrichment round trip: PASS
Pydantic session record round trip: PASS
legacy payload default: unknown, non-resumable
forward enrichment subclass preservation: PASS
JSON schema validation of synthetic JSONL: PASS (jsonschema available)
measurement evaluator smoke: PASS, nine fully synthetic rows
```

The patch series was also applied with `git am` to a fresh copy of the pristine supplied repository. Every changed path was SHA-256 compared with the final development tree, then the applied tree passed `git diff --check` and `compileall`. See `TESTS/patch-apply-check.log`.

Environment used:

```text
Python 3.13
pytest 9.0.2
Pydantic 2.13.4
```

## Managed pytest attempt

This exact command was run:

```bash
PYTHONPATH=. pytest -q \
  tests/unit/archive/test_objective_posture.py \
  tests/unit/insights/test_objective_posture_consumers.py \
  tests/unit/context/test_compiler.py \
  tests/unit/insights/test_fallback_markers.py
```

It exited 2 during collection. The supplied snapshot omits required package paths:

```text
polylogue.archive.actions
polylogue.archive.phase
polylogue.api
```

Therefore no managed pytest test body ran. The exact traceback is preserved in `TESTS/pytest-collection.log`. The custom verification harnesses use narrow stubs only for omitted imports and execute the real changed `documents.py`, `models.py`, `runtime.py`, and `records.py` files.

## Tooling not run

`ruff`, `mypy`, `pyright`, `pylint`, `pyflakes`, and the repository `devtools` command were not available in the slice environment. `uv` exists, but the supplied slice has no project metadata or lockfile with which to reconstruct the managed environment. No formatting, lint, type-check, generated-surface, topology, or full repository verification result is claimed.

No new production module was added, so the repository instruction requiring topology regeneration for a new `polylogue/` file is not triggered by the patch itself. Generated surfaces could still be affected by omitted public model/schema integration and must be checked in the complete tree.

## Runtime and data boundaries

Not available and not run:

- operator live browser or browser capture;
- Polylogue daemon/converger;
- real source/index/user/ops/embeddings databases;
- secrets, linked providers, or live exports;
- NixOS or any deployment environment;
- actual goal/question lifecycle graph;
- actual work-evidence/effect graph;
- durable assertion query/validity route;
- canonical materializer/version constants;
- public `SessionProfileInsight` read/serialization model;
- full context assembly and token budgeting;
- repository-scoped resume query against real profiles;
- live sample labeling, precision, recall, coverage, or ranking measurement.

The synthetic measurement output validates calculator behavior only. It must not be cited as product quality.

## Full-tree checks still required

After applying the patches to the complete repository:

1. Wire fact-owner adapters and stable obligation identity/aliasing.
2. Bump canonical session insight materializer/enrichment versions and rebuild derived rows.
3. Verify public read-model serialization retains the projection.
4. Add the objective segment to real context assembly.
5. Run the four focused test files through `devtools test` or the repository-managed equivalent.
6. Run lint, formatting, type checks, generated-surface checks, topology checks, and full relevant unit/property tests.
7. Exercise SQLite write/read/rebuild convergence and old-row compatibility.
8. Run the live measurement protocol and preserve the frozen sample receipt and output.
