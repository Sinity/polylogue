# Polylogue ObjectivePosture launch handoff

This handoff implements bead `polylogue-37t.23`: derive session resumability from evidence-bearing open obligations rather than terminal-state text. It is scoped to the immutable repository slice supplied for the task.

## Base and worktree assumptions

The upstream snapshot identifies:

```text
revision: 76ee0d3842f12920ee71ad06f22b9cd8d2f88730
branch:   feature/browser/adopt-completion-monitors
status:   clean; no staged or unstaged patch
```

The patch series was generated from exactly that file tree. A local synthetic baseline was used only because the archive did not include upstream Git objects; its hash is not an apply prerequisite. All four patches were applied afresh to a pristine copy of the supplied files and every changed path was byte-compared with the developed worktree.

Do not silently apply over unrelated edits to the 17 touched paths. Preserve or commit existing changes first, then resolve any conflicts explicitly.

## Read order

1. `SUMMARY.md` for the result and acceptance matrix.
2. `DESIGN/objective-posture.md` for semantics and invariants.
3. `DESIGN/integration-map.md` for changed routes and full-tree seams.
4. `DESIGN/evidence-adapter-contract.md` before wiring goal, work, or assertion owners.
5. `DESIGN/rejected-alternatives.md` for safety decisions.
6. `PATCHES/series`, then the four ordered patches.
7. `TESTS/precision-coverage-plan.md` and `VERIFICATION-LIMITS.md` before launch claims.

## Apply

From a clean complete Polylogue checkout containing the base revision:

```bash
git switch -c feature/objective-posture-37t23 \
  76ee0d3842f12920ee71ad06f22b9cd8d2f88730

while IFS= read -r patch; do
  git am "/path/to/handoff/PATCHES/$patch"
done < /path/to/handoff/PATCHES/series
```

The ordered commits are:

```text
1. feat(session): add evidence-bearing objective posture projection
2. feat(insights): persist objective posture in enrichment projection
3. feat(resume): rank and compile from objective posture
4. test(objective): cover projection and shared consumers
```

The patches modify existing production modules only; they do not add a new `polylogue/` module. No topology projection regeneration is expected solely from this series.

## Verify in this supplied slice

```bash
/path/to/handoff/TESTS/verification.sh /path/to/patched/repository
```

This runs patch-relative `git diff --check`, bytecode compilation, the real-file projection harness, the real-Pydantic persistence harness, and a synthetic measurement-calculator smoke test. The synthetic measurement is plumbing verification, not a precision estimate.

## Verify in the complete repository

After wiring the full-tree adapters and version constants, run:

```bash
RUN_MANAGED_PYTEST=1 \
  /path/to/handoff/TESTS/verification.sh /path/to/patched/repository
```

Then run the repository's managed lint, type, focused-test, generated-surface, and materializer/rebuild checks. The supplied archive omits the modules needed to execute those routes here; exact limits and the attempted pytest output are preserved under `TESTS/` and `VERIFICATION-LIMITS.md`.

## Launch integration sequence

Wire goal/question lifecycle, work-evidence/effect, and durable assertion adapters into the existing `objective_evidence` input. Bump the canonical session materializer/enrichment versions in the complete repository and rebuild derived session rows. Confirm the public insight/read model serializes `objective_posture`, add the objective segment to actual context assembly, run storage/read-route tests, then execute the live labeling and measurement plan.

Do not add keyword, final-turn, protocol, or terminal-state fallback classifiers during integration. Missing facts belong in their source adapter; uncertainty belongs in the projection as evidence-bearing `unknown` or `ambiguous`.
