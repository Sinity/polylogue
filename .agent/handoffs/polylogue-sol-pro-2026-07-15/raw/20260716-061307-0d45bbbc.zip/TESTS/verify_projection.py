#!/usr/bin/env python3
"""Self-contained verification for the supplied ObjectivePosture snapshot.

The immutable task archive omits much of the Polylogue package graph. This
runner installs narrow import stubs for those omitted modules, then executes the
real changed documents/models/runtime files from a repository checkout.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import types
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace
from typing import Any


def _package(name: str) -> types.ModuleType:
    module = sys.modules.get(name)
    if module is None:
        module = types.ModuleType(name)
        module.__path__ = []  # type: ignore[attr-defined]
        sys.modules[name] = module
    return module


def _module(name: str, **attrs: object) -> types.ModuleType:
    module = types.ModuleType(name)
    for key, value in attrs.items():
        setattr(module, key, value)
    sys.modules[name] = module
    return module


class _Dummy:
    def __init__(self, **values: object) -> None:
        self.__dict__.update(values)


class _SessionPhase(_Dummy):
    pass


class _WorkEvent(_Dummy):
    @classmethod
    def from_dict(cls, payload: dict[str, object]) -> _WorkEvent:
        return cls(**dict(payload))

    def to_dict(self) -> dict[str, object]:
        return dict(self.__dict__)


class _Origin:
    CODEX_SESSION = "codex-session"


def _mapping_or_empty(value: object) -> dict[object, object]:
    return dict(value) if isinstance(value, dict) else {}


def _mapping_sequence(value: object) -> tuple[dict[str, object], ...]:
    if not isinstance(value, (list, tuple)):
        return ()
    return tuple(item for item in value if isinstance(item, dict))


def _coerce_float(value: object, default: float = 0.0) -> float:
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


def _coerce_int(value: object, default: int = 0) -> int:
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


def _int_pair(value: object) -> tuple[int, int]:
    items = list(value or (0, 0))  # type: ignore[arg-type]
    return (int(items[0]), int(items[1]))


def _optional_date(value: object) -> object:
    if value is None or hasattr(value, "year"):
        return value
    return datetime.fromisoformat(str(value).replace("Z", "+00:00")).date()


def _optional_datetime(value: object) -> object:
    if value is None or hasattr(value, "isoformat"):
        return value
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


def _optional_string(value: object) -> str | None:
    return None if value is None else str(value)


def _string_int_mapping(value: object) -> dict[str, int]:
    return {str(key): int(item) for key, item in _mapping_or_empty(value).items()}


def _string_sequence(value: object) -> tuple[str, ...]:
    if isinstance(value, str):
        return (value,)
    if not isinstance(value, (list, tuple, set)):
        return ()
    return tuple(str(item) for item in value)


def _install_snapshot_stubs() -> None:
    for name in (
        "polylogue",
        "polylogue.archive",
        "polylogue.archive.actions",
        "polylogue.archive.phase",
        "polylogue.archive.semantic",
        "polylogue.archive.session",
        "polylogue.core",
    ):
        _package(name)

    _module(
        "polylogue.archive.phase.extraction",
        SessionPhase=_SessionPhase,
        extract_phases=lambda *args, **kwargs: (),
    )
    _module(
        "polylogue.archive.semantic.facts",
        SessionSemanticFacts=_Dummy,
        build_session_semantic_facts=lambda *args, **kwargs: None,
    )
    _module(
        "polylogue.archive.semantic.timing",
        compute_session_timing=lambda *args, **kwargs: _Dummy(),
        compute_tool_active_duration_ms=lambda *args, **kwargs: 0,
    )
    _module(
        "polylogue.archive.session.attribution",
        SessionAttribution=_Dummy,
        extract_attribution=lambda *args, **kwargs: _Dummy(),
    )
    _module(
        "polylogue.archive.session.extraction",
        WorkEvent=_WorkEvent,
        extract_work_events=lambda *args, **kwargs: (),
    )
    _module(
        "polylogue.archive.session.repo_identity",
        normalize_repo_names=lambda repo_paths=(): (),
        normalize_repo_paths=lambda value: tuple(value),
    )
    _module(
        "polylogue.archive.actions.parsing",
        tool_result_block_outcome=lambda block: "unknown",
    )
    _module("polylogue.core.enums", Origin=_Origin)
    _module(
        "polylogue.core.payload_coercion",
        coerce_float=_coerce_float,
        coerce_int=_coerce_int,
        int_pair=_int_pair,
        mapping_or_empty=_mapping_or_empty,
        mapping_sequence=_mapping_sequence,
        optional_date=_optional_date,
        optional_datetime=_optional_datetime,
        optional_string=_optional_string,
        string_int_mapping=_string_int_mapping,
        string_sequence=_string_sequence,
    )


def _load(name: str, path: Path) -> types.ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {name} from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _session_and_analysis(
    *, role: str, text: str, protocol_only: bool = False, substantive: bool = True
) -> tuple[SimpleNamespace, SimpleNamespace]:
    timestamp = datetime(2026, 7, 15, 10, 30, tzinfo=UTC)
    fact = SimpleNamespace(
        message_id="m2",
        timestamp=timestamp,
        text=text,
        is_protocol_artifact=protocol_only,
        is_candidate_human_authored=role == "user" and not protocol_only,
        is_assistant=role == "assistant",
        is_substantive=substantive,
        is_noise=False,
    )
    session = SimpleNamespace(
        id="codex-session:anchor",
        messages=[SimpleNamespace(id="m2", blocks=[])],
        session_events=[],
        created_at=timestamp,
        updated_at=timestamp,
    )
    analysis = SimpleNamespace(facts=SimpleNamespace(actions=[], message_facts=[fact]))
    return session, analysis


def _verify(repo: Path, fixture_path: Path) -> dict[str, Any]:
    _install_snapshot_stubs()
    _load(
        "polylogue.archive.session.documents",
        repo / "polylogue/archive/session/documents.py",
    )
    models = _load(
        "polylogue.archive.session.models",
        repo / "polylogue/archive/session/models.py",
    )
    runtime = _load(
        "polylogue.archive.session.runtime",
        repo / "polylogue/archive/session/runtime.py",
    )

    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    projector_passed = 0
    for case in fixture["cases"]:
        evidence = tuple(models.ObjectivePostureEvidence.from_mapping(item) for item in case["evidence"])
        posture = models.derive_objective_posture(evidence, as_of=case.get("as_of"))
        expected = case["expected"]
        actual = {
            "state": posture.state,
            "authority": posture.authority,
            "resumable": posture.resumable,
            "obligation_count": len(posture.obligations),
            "obligation_states": [item.state for item in posture.obligations],
            "evidence_refs": list(posture.evidence_refs),
            "contradiction_codes": [item.code for item in posture.contradictions],
            "blocker_summaries": list(posture.blocker_summaries),
        }
        for key, value in actual.items():
            if value != expected[key]:
                raise AssertionError(f"{case['id']} {key}: expected {expected[key]!r}, got {value!r}")
        if posture.as_of != case.get("as_of"):
            raise AssertionError(f"{case['id']} as_of mismatch")
        if models.ObjectivePosture.from_mapping(posture.to_dict()) != posture:
            raise AssertionError(f"{case['id']} round-trip mismatch")
        projector_passed += 1

    precedence = next(
        case for case in fixture["cases"] if case["id"] == "authority_precedence_prevents_false_completion"
    )
    precedence_evidence = tuple(
        models.ObjectivePostureEvidence.from_mapping(item) for item in precedence["evidence"]
    )
    resolved = models.derive_objective_posture(precedence_evidence, as_of=precedence["as_of"])
    ablated = models.derive_objective_posture(
        tuple(item for item in precedence_evidence if item.authority == "work_evidence"),
        as_of=precedence["as_of"],
    )
    if (resolved.state, resolved.resumable) != ("awaiting_operator", True):
        raise AssertionError("Authority precedence did not retain the open question")
    if (ablated.state, ablated.resumable) != ("completed", False):
        raise AssertionError("Authority ablation did not recreate the false completion")

    structural_passed = 0
    anchor_result: dict[str, object] | None = None
    for case in fixture["structural_cases"]:
        session, analysis = _session_and_analysis(
            role=case["last_role"],
            text=case["last_text"],
            protocol_only=case["protocol_only"],
        )
        posture = runtime.project_session_objective_posture(session, analysis)
        if posture.state != case["expected_objective_state"]:
            raise AssertionError(
                f"{case['id']} objective: expected {case['expected_objective_state']}, got {posture.state}"
            )
        expected_terminal = case.get("expected_terminal_state")
        terminal = None
        if expected_terminal is not None:
            terminal = runtime._terminal_state(session, analysis)[0]
            if terminal != expected_terminal:
                raise AssertionError(
                    f"{case['id']} terminal: expected {expected_terminal}, got {terminal}"
                )
        if case.get("known_anchor"):
            anchor_result = {
                "terminal_state": terminal,
                "objective_posture": posture.state,
                "resumable": posture.resumable,
                "evidence_refs": list(posture.evidence_refs),
            }
        structural_passed += 1

    negative_questions = (
        "All work is complete.",
        "Any questions?",
        "The docs mention blocked, failed, complete, and awaiting operator.",
        "Would you like a summary?",
        "Release notes:\n\n- Added the endpoint\n- Updated the tests\n\nWould you like a summary?",
    )
    positive_questions = (
        "Should I deploy now?",
        "Which target should I use: staging or production?",
        "Do you want me to keep the old schema or apply the migration?",
        "Choose an approach:\n\n1. Backfill now\n2. Defer it\n\nWhich approach do you prefer?",
    )
    if any(runtime._bounded_operator_decision_question(text) is not None for text in negative_questions):
        raise AssertionError("A negative structural question became an operator obligation")
    if any(runtime._bounded_operator_decision_question(text) is None for text in positive_questions):
        raise AssertionError("A positive structural choice was missed")

    session, analysis = _session_and_analysis(role="user", text="Thanks.", substantive=False)
    acknowledgement = runtime.project_session_objective_posture(session, analysis)
    if acknowledgement.state != "unknown" or acknowledgement.obligations or acknowledgement.resumable:
        raise AssertionError("A non-substantive acknowledgement became an obligation")

    offset_posture = models.derive_objective_posture(
        (
            models.ObjectivePostureEvidence(
                "goal:release",
                "goal",
                "in_progress",
                "Earlier absolute frame.",
                "goal_lifecycle",
                as_of="2026-07-15T10:00:00+02:00",
            ),
            models.ObjectivePostureEvidence(
                "goal:release",
                "goal",
                "in_progress",
                "Later absolute frame.",
                "goal_lifecycle",
                as_of="2026-07-15T09:00:00Z",
            ),
        )
    )
    if offset_posture.as_of != "2026-07-15T09:00:00Z":
        raise AssertionError("Offset timestamps were compared lexically")
    if offset_posture.obligations[0].summary != "Later absolute frame.":
        raise AssertionError("Summary selection did not use the latest absolute frame")

    contradiction_posture = models.derive_objective_posture(
        (
            models.ObjectivePostureEvidence(
                "blocker:credentials",
                "blocker",
                "blocked",
                "Credentials are unavailable.",
                "durable_assertion",
                evidence_refs=("codex-session:anchor::m1",),
                contradictions=(
                    models.ObjectiveContradiction(
                        "source_disagreement",
                        "A second source disputes the blocker.",
                        ("codex-session:anchor::m0",),
                        ("durable_assertion",),
                        ("blocked", "unknown"),
                    ),
                ),
            ),
        )
    )
    if contradiction_posture.evidence_refs != (
        "codex-session:anchor::m1",
        "codex-session:anchor::m0",
    ):
        raise AssertionError("Contradiction-only refs were not promoted into projection provenance")

    pending_session, pending_analysis = _session_and_analysis(
        role="assistant", text="The structured call has been submitted."
    )
    pending_session.session_events = [
        SimpleNamespace(
            id="event-1",
            event_index=1,
            event_type="function_call",
            payload={"call_id": "call-1"},
            source_message_id=None,
            timestamp=datetime(2026, 7, 15, 10, 31, tzinfo=UTC),
        )
    ]
    pending = runtime.project_session_objective_posture(pending_session, pending_analysis)
    if pending.state != "awaiting_effect" or pending.evidence_refs != ("session-event:event-1",):
        raise AssertionError("Unmatched structured effect did not remain open with provenance")

    legacy = models.coerce_objective_posture({}, as_of="2026-07-15T12:00:00Z")
    if legacy.as_of != "2026-07-15T12:00:00Z" or legacy.resumable:
        raise AssertionError("Legacy empty projection frame/resumability contract failed")

    if anchor_result is None:
        raise AssertionError("Known anchor missing from fixture")
    return {
        "projector_cases": {"passed": projector_passed, "total": len(fixture["cases"])},
        "structural_cases": {"passed": structural_passed, "total": len(fixture["structural_cases"])},
        "authority_ablation": "passed",
        "boundary_checks": "passed",
        "known_anchor": anchor_result,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True, help="Patched Polylogue repository root")
    parser.add_argument(
        "--fixtures",
        type=Path,
        default=Path(__file__).with_name("objective_posture_cases.json"),
    )
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()

    result = _verify(args.repo.resolve(), args.fixtures.resolve())
    rendered = json.dumps(result, indent=2, sort_keys=True)
    print(rendered)
    if args.json_output:
        args.json_output.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
