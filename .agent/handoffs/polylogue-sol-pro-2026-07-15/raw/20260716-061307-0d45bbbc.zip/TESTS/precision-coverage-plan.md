# ObjectivePosture precision and coverage plan

## Purpose

This plan measures whether the projection identifies evidence-bearing open obligations without reverting to terminal-state, keyword, final-turn, protocol, or unsupported self-claim shortcuts. It is a launch measurement protocol, not a substitute for the deterministic fixture suite.

No live Polylogue archive, browser session, daemon, user database, or operator corpus was available in the supplied snapshot. Therefore this handoff contains the executable evaluator and labeling schema, but does not claim live-corpus precision or coverage numbers.

## Unit of evaluation

The unit is one logical session at a frozen `as_of` frame. A row must retain the physical session IDs used to construct the logical session, but the exported evaluation identifier should be a non-sensitive `sample_id`. Gold labels are assigned from cited evidence at or before the frame. Later messages or assertions are excluded.

The primary binary target is `resumable`: at least one evidence-bearing obligation is open. The multiclass target is the aggregate state selected from all obligations. Obligation-level labels preserve IDs, kinds, states, authorities, evidence refs, timestamps, and contradictions.

An empty legacy `unknown` projection is not positive. An evidence-bearing obligation whose state is `unknown` is positive because it remains reviewable.

## Sampling frame

Freeze a materialized archive revision and its projection/materializer versions. Record the archive high-water mark, query, selection timestamp, and exact sample IDs in a durable measurement receipt.

Use a two-part sample:

1. A probability sample of at least 400 recent logical sessions, stratified by provider and terminal state. This yields an approximately five-percentage-point worst-case 95% margin for an unstratified proportion before design effects. Weight aggregate metrics back to the archive stratum frequencies.
2. A targeted challenge set containing every known clean-finish/open anchor and oversampled rare or dangerous conditions. Include final assistant questions, pending structured effects, explicit goal closures, observed effects, unsupported completion claims, durable blockers/decisions/handoffs, protocol-only rows, keyword-marker rows, same-authority conflicts, lower-authority conflicts, and multi-obligation sessions.

Keep probability and challenge results separate. Do not report challenge-set accuracy as corpus prevalence or aggregate precision.

The bead mentions 500 recent sessions and at least two manually confirmed clean-but-unfinished examples. Reuse that frozen 500-session frame when available, preserving the confirmed anchor(s), then add new sessions only under a separately versioned sample receipt.

## Labeling protocol

Two labelers independently inspect source material and existing fact-owner records, blinded to the projected state and resume rank. They apply the authority order exactly as implemented:

1. explicit goal/question lifecycle;
2. work-evidence graph, structured result/effect, or evaluated satisfaction;
3. durable decision, blocker, or handoff assertions;
4. bounded authored structural inference;
5. unknown.

Labelers first enumerate obligations, then resolve each obligation, then derive the aggregate state. This prevents a single dominant-looking final turn from erasing simultaneous work.

A `completed` label requires either an explicit lifecycle closure or work evidence with an observed effect/evaluated satisfaction. A claim such as “done” without that support is not completion. Protocol-only material may be cited as provenance but cannot vote. Terminal state is visible only after obligation labels are frozen, for orthogonality analysis.

Disagreements are adjudicated by a third reviewer. The adjudication record must state whether the disagreement concerned obligation identity, authority, state, timestamp frame, evidence reference, or contradiction retention. Exclude a row only when source material is irrecoverable; do not convert difficult cases to `unknown` merely to obtain agreement.

Use `live-sample-label-schema.json` for both gold and prediction JSONL. Evidence refs should be stable object references, not copied private transcript text. Redacted exports must preserve those refs and the as-of frame.

## Prediction extraction

Rebuild the session-profile materializer at the candidate projection version, then export one prediction row per sampled logical session. Use the same logical-session merge route used by resume discovery. Record rank only for candidates returned by the repository-scoped resume route.

Old rows that have not been rebuilt must be marked as missing predictions rather than silently interpreted as closed. The evaluator counts missing rows against coverage and recall.

## Metrics

Run:

```bash
python TESTS/measure_objective_posture.py \
  --gold live-gold.jsonl \
  --predictions live-predictions.jsonl \
  --k 10 \
  --output live-results.json
```

The evaluator reports:

- prediction coverage and decisive coverage (`unknown`/`ambiguous` are non-decisive), with Wilson 95% intervals;
- exact aggregate-state accuracy and per-state precision/recall/F1;
- open-obligation precision, recall, F1, and Wilson intervals;
- evidence-reference and contradiction-code micro precision/recall/F1;
- state accuracy by authority and sample stratum;
- known-anchor recall;
- recall for sessions that are both `clean_finish` and gold-open;
- unsafe completion false positives: gold-open sessions predicted `completed`;
- optional precision at K for returned resume candidates.

Report raw counts beside every rate. Report probability-sample weighted estimates separately from unweighted challenge-set diagnostics. The included evaluator is deliberately unweighted; produce weighted aggregate estimates in the measurement notebook or add explicit row weights before launch rather than pretending the challenge set is representative.

## Launch gates

These are proposed safety gates, to be ratified against the first live baseline:

- zero unsafe completion false positives in the known-anchor and high-authority challenge strata;
- open-obligation precision lower Wilson bound at least 0.90 on the probability sample;
- clean-finish/open recall lower Wilson bound at least 0.80, with every known anchor recovered;
- evidence-reference precision at least 0.95 and contradiction-reference recall at least 0.90;
- no regression in repository-scoped resume precision at 10 relative to the current manually adjudicated baseline;
- 100% prediction coverage after the required materializer rebuild. Decisive coverage is reported, not optimized by forcing uncertain cases closed.

A launch must fail closed on measurement integrity: mismatched as-of frames, projection-version mixtures, leaked post-frame evidence, duplicate sample IDs, or unlabeled missing predictions invalidate the run.

## Required ablations

Run the candidate projection and these deliberately unsafe variants on the same sample:

- remove authority precedence;
- allow unsupported work/self-report completion;
- let final-assistant presence imply completion or openness;
- enable keyword blocker/completion matching;
- allow protocol-only evidence to vote;
- filter `clean_finish` before posture evaluation.

The known anchor must flip to the historical false completion/exclusion when precedence is removed, as demonstrated by the deterministic fixture. The other ablations should quantify false positives rather than serving as production alternatives.

## Error analysis and iteration

For every false positive, false negative, unsafe completion, missing evidence ref, or lost contradiction, attach a minimal redacted evidence packet and assign one cause: fact-owner gap, adapter identity mismatch, authority resolution, structural-inference overreach, structural-inference miss, as-of error, logical-session merge, persistence/version skew, or ranking/route error.

Change the projection only when the cause is semantic. Fix extraction in the owning goal/work/assertion subsystem when the underlying fact is absent. Do not add transcript keyword rules to compensate for missing fact-owner adapters.

Version the fixture, schema, sample receipt, gold labels, projection, and evaluator together. Re-run the frozen sample for every authority or state-vocabulary change and append a new measurement record rather than overwriting the prior result.
