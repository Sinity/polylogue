#!/usr/bin/env python3
"""Exercise the additive enrichment payload with real Pydantic validation."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_projection as support  # noqa: E402


class SessionEnrichmentPayload(BaseModel):
    model_config = ConfigDict(extra="ignore")

    intent_summary: str | None = None
    outcome_summary: str | None = None
    blockers: tuple[str, ...] = ()
    confidence: float = 0.0
    support_level: str = "unknown"
    support_signals: tuple[str, ...] = ()
    input_band_summary: dict[str, int] = Field(default_factory=dict)
    fallback_reasons: tuple[str, ...] = ()
    is_goal_session: bool = False
    goal_text: str | None = None
    goal_outcome: str | None = None


class SessionEvidencePayload(BaseModel):
    pass


class SessionInferencePayload(BaseModel):
    pass


class ThreadPayload(BaseModel):
    pass


def verify(repo: Path) -> dict[str, object]:
    support._install_snapshot_stubs()
    support._load(
        "polylogue.archive.session.documents",
        repo / "polylogue/archive/session/documents.py",
    )
    models = support._load(
        "polylogue.archive.session.models",
        repo / "polylogue/archive/session/models.py",
    )
    support._module("polylogue.core.types", SessionId=str)
    support._module(
        "polylogue.insights.archive_models",
        SessionEnrichmentPayload=SessionEnrichmentPayload,
        SessionEvidencePayload=SessionEvidencePayload,
        SessionInferencePayload=SessionInferencePayload,
        ThreadPayload=ThreadPayload,
    )
    support._package("polylogue.storage")
    support._package("polylogue.storage.runtime")
    support._module(
        "polylogue.storage.runtime.store_constants",
        SESSION_ENRICHMENT_FAMILY="heuristic_session_enrichment",
        SESSION_ENRICHMENT_VERSION=1,
        SESSION_INFERENCE_FAMILY="heuristic_session_semantics",
        SESSION_INFERENCE_VERSION=1,
        SESSION_INSIGHT_MATERIALIZER_VERSION=1,
    )
    records = support._load(
        "polylogue.storage.insights.session.records",
        repo / "polylogue/storage/insights/session/records.py",
    )

    evidence = models.ObjectivePostureEvidence.from_mapping(
        {
            "obligation_id": "decision:deploy",
            "kind": "decision",
            "state": "awaiting_operator",
            "summary": "Choose the deployment target.",
            "authority": "goal_lifecycle",
            "evidence_refs": ["codex-session:persistence::m2"],
            "as_of": "2026-07-15T12:00:00Z",
        }
    )
    posture = models.derive_objective_posture((evidence,))

    enrichment = records.SessionObjectiveEnrichmentPayload(objective_posture=posture)
    enrichment_dump = enrichment.model_dump(mode="json")
    restored_enrichment = records.SessionObjectiveEnrichmentPayload.model_validate(enrichment_dump)
    if restored_enrichment.objective_posture != posture:
        raise AssertionError("Typed enrichment payload lost ObjectivePosture")

    required = {
        "session_id": "codex-session:persistence",
        "logical_session_id": "codex-session:persistence",
        "materialized_at": "2026-07-15T12:01:00Z",
        "source_name": "codex-session",
        "evidence_payload": SessionEvidencePayload(),
        "inference_payload": SessionInferencePayload(),
        "search_text": "persistence",
        "evidence_search_text": "persistence",
        "inference_search_text": "persistence",
        "enrichment_search_text": "persistence",
    }
    legacy = records.SessionProfileRecord(
        **required,
        enrichment_payload=SessionEnrichmentPayload(intent_summary="Legacy row"),
    )
    if legacy.enrichment_payload.objective_posture.state != "unknown":
        raise AssertionError("Legacy enrichment did not hydrate to unknown")
    if legacy.enrichment_payload.objective_posture.resumable:
        raise AssertionError("Empty legacy unknown became resumable")

    class ForwardCompatibleEnrichmentPayload(SessionEnrichmentPayload):
        objective_posture: object

    forward = records.SessionProfileRecord(
        **required,
        enrichment_payload=ForwardCompatibleEnrichmentPayload(objective_posture=posture),
    )
    if forward.enrichment_payload.objective_posture != posture:
        raise AssertionError("Forward-compatible enrichment subclass lost ObjectivePosture")

    record = records.SessionProfileRecord(
        **required,
        enrichment_payload=enrichment,
    )
    record_dump = record.model_dump(mode="json")
    restored_record = records.SessionProfileRecord.model_validate(record_dump)
    if restored_record.enrichment_payload.objective_posture != posture:
        raise AssertionError("SessionProfileRecord JSON round-trip lost ObjectivePosture")

    return {
        "typed_enrichment_roundtrip": "passed",
        "session_profile_record_roundtrip": "passed",
        "legacy_payload_default": "unknown_non_resumable",
        "forward_subclass_upgrade": "passed",
        "state": posture.state,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    result = verify(args.repo.resolve())
    rendered = json.dumps(result, indent=2, sort_keys=True)
    print(rendered)
    if args.json_output:
        args.json_output.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
