#!/usr/bin/env python3
"""Measure ObjectivePosture precision, coverage, evidence retention, and ranking.

Gold and prediction files are JSONL keyed by ``sample_id``. See
``live-sample-label-schema.json`` and ``precision-coverage-plan.md``.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

CLOSED_STATES = {"completed", "abandoned", "inactive"}
ALL_STATES = {
    "completed",
    "blocked",
    "abandoned",
    "inactive",
    "awaiting_operator",
    "awaiting_effect",
    "in_progress",
    "ambiguous",
    "unknown",
}


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        text = raw.strip()
        if not text or text.startswith("#"):
            continue
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path}:{line_number}: invalid JSON: {exc}") from exc
        if not isinstance(value, dict):
            raise ValueError(f"{path}:{line_number}: row must be an object")
        rows.append(value)
    return rows


def _payload(row: dict[str, Any], key: str) -> dict[str, Any]:
    value = row.get(key, row if key == "prediction" else None)
    if not isinstance(value, dict):
        raise ValueError(f"sample {row.get('sample_id')!r}: {key} must be an object")
    return value


def _state(payload: dict[str, Any]) -> str:
    value = str(payload.get("state") or "unknown").strip().lower()
    return value if value in ALL_STATES else "unknown"


def _resumable(payload: dict[str, Any]) -> bool:
    value = payload.get("resumable")
    if isinstance(value, bool):
        return value
    obligations = payload.get("obligations")
    if isinstance(obligations, list):
        states = {
            str(item.get("state") or "unknown").strip().lower()
            for item in obligations
            if isinstance(item, dict)
        }
        return any(state not in CLOSED_STATES for state in states)
    return _state(payload) not in CLOSED_STATES and _state(payload) != "unknown"


def _strings(payload: dict[str, Any], key: str) -> set[str]:
    value = payload.get(key, [])
    if not isinstance(value, list):
        return set()
    return {str(item) for item in value if str(item).strip()}


def _safe_div(numerator: int | float, denominator: int | float) -> float | None:
    return round(float(numerator) / float(denominator), 6) if denominator else None


def _wilson(successes: int, total: int, *, z: float = 1.959963984540054) -> list[float] | None:
    """Return a dependency-free Wilson score interval for one binomial rate."""

    if total <= 0:
        return None
    proportion = successes / total
    z_squared = z * z
    denominator = 1.0 + (z_squared / total)
    center = (proportion + (z_squared / (2.0 * total))) / denominator
    margin = (z / denominator) * math.sqrt(
        (proportion * (1.0 - proportion) / total) + (z_squared / (4.0 * total * total))
    )
    return [round(max(0.0, center - margin), 6), round(min(1.0, center + margin), 6)]


def _f1(precision: float | None, recall: float | None) -> float | None:
    if precision is None or recall is None or precision + recall == 0:
        return None if precision is None or recall is None else 0.0
    return round(2 * precision * recall / (precision + recall), 6)


def _binary_metrics(tp: int, fp: int, fn: int, tn: int) -> dict[str, Any]:
    precision = _safe_div(tp, tp + fp)
    recall = _safe_div(tp, tp + fn)
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": precision,
        "precision_wilson95": _wilson(tp, tp + fp),
        "recall": recall,
        "recall_wilson95": _wilson(tp, tp + fn),
        "f1": _f1(precision, recall),
    }


def _per_state_metrics(gold_states: list[str], predicted_states: list[str | None]) -> dict[str, Any]:
    report: dict[str, Any] = {}
    f1_values: list[float] = []
    labels = sorted(set(gold_states) | {value for value in predicted_states if value is not None})
    for label in labels:
        tp = sum(gold == label and pred == label for gold, pred in zip(gold_states, predicted_states))
        fp = sum(gold != label and pred == label for gold, pred in zip(gold_states, predicted_states))
        fn = sum(gold == label and pred != label for gold, pred in zip(gold_states, predicted_states))
        metrics = _binary_metrics(tp, fp, fn, 0)
        report[label] = metrics
        if metrics["f1"] is not None:
            f1_values.append(float(metrics["f1"]))
    report["macro_f1"] = round(sum(f1_values) / len(f1_values), 6) if f1_values else None
    return report


def _micro_set_metrics(gold_sets: Iterable[set[str]], predicted_sets: Iterable[set[str]]) -> dict[str, Any]:
    true_positive = false_positive = false_negative = 0
    for gold, predicted in zip(gold_sets, predicted_sets):
        true_positive += len(gold & predicted)
        false_positive += len(predicted - gold)
        false_negative += len(gold - predicted)
    precision = _safe_div(true_positive, true_positive + false_positive)
    recall = _safe_div(true_positive, true_positive + false_negative)
    return {
        "tp": true_positive,
        "fp": false_positive,
        "fn": false_negative,
        "precision": precision,
        "recall": recall,
        "f1": _f1(precision, recall),
    }


def measure(gold_rows: list[dict[str, Any]], prediction_rows: list[dict[str, Any]], *, k: int) -> dict[str, Any]:
    predictions: dict[str, dict[str, Any]] = {}
    ranks: dict[str, int] = {}
    for row in prediction_rows:
        sample_id = str(row.get("sample_id") or "").strip()
        if not sample_id:
            raise ValueError("prediction row missing sample_id")
        if sample_id in predictions:
            raise ValueError(f"duplicate prediction sample_id: {sample_id}")
        predictions[sample_id] = _payload(row, "prediction")
        rank = row.get("rank")
        if isinstance(rank, int) and rank > 0:
            ranks[sample_id] = rank

    seen: set[str] = set()
    gold_states: list[str] = []
    predicted_states: list[str | None] = []
    gold_ref_sets: list[set[str]] = []
    predicted_ref_sets: list[set[str]] = []
    gold_contradictions: list[set[str]] = []
    predicted_contradictions: list[set[str]] = []
    open_tp = open_fp = open_fn = open_tn = 0
    exact_state = 0
    matched = 0
    decisive = 0
    unsafe_completed: list[str] = []
    known_anchor_total = known_anchor_passed = 0
    clean_open_total = clean_open_passed = 0
    authority_counts: Counter[str] = Counter()
    authority_correct: Counter[str] = Counter()
    strata = defaultdict(lambda: {"total": 0, "matched": 0, "state_correct": 0})
    ranked_relevance: list[tuple[int, bool, str]] = []

    for row in gold_rows:
        sample_id = str(row.get("sample_id") or "").strip()
        if not sample_id:
            raise ValueError("gold row missing sample_id")
        if sample_id in seen:
            raise ValueError(f"duplicate gold sample_id: {sample_id}")
        seen.add(sample_id)
        gold = _payload(row, "gold")
        prediction = predictions.get(sample_id)
        gold_state = _state(gold)
        predicted_state = _state(prediction) if prediction is not None else None
        gold_open = _resumable(gold)
        predicted_open = _resumable(prediction) if prediction is not None else False
        gold_states.append(gold_state)
        predicted_states.append(predicted_state)
        gold_ref_sets.append(_strings(gold, "evidence_refs"))
        predicted_ref_sets.append(_strings(prediction, "evidence_refs") if prediction is not None else set())
        gold_contradictions.append(_strings(gold, "contradiction_codes"))
        predicted_contradictions.append(
            _strings(prediction, "contradiction_codes") if prediction is not None else set()
        )

        stratum = str(row.get("stratum") or "unspecified")
        strata[stratum]["total"] += 1
        authority = str(gold.get("authority") or "unknown")
        authority_counts[authority] += 1

        if prediction is not None:
            matched += 1
            strata[stratum]["matched"] += 1
            if predicted_state not in {"unknown", "ambiguous"}:
                decisive += 1
            if predicted_state == gold_state:
                exact_state += 1
                strata[stratum]["state_correct"] += 1
                authority_correct[authority] += 1

        if gold_open and predicted_open:
            open_tp += 1
        elif not gold_open and predicted_open:
            open_fp += 1
        elif gold_open and not predicted_open:
            open_fn += 1
        else:
            open_tn += 1

        if gold_open and predicted_state == "completed":
            unsafe_completed.append(sample_id)

        if bool(row.get("known_anchor")):
            known_anchor_total += 1
            if prediction is not None and predicted_state == gold_state and predicted_open == gold_open:
                known_anchor_passed += 1

        terminal_state = str(row.get("terminal_state") or "")
        if terminal_state == "clean_finish" and gold_open:
            clean_open_total += 1
            if predicted_open:
                clean_open_passed += 1

        rank = ranks.get(sample_id)
        if rank is not None:
            relevant = bool(gold.get("relevant_for_resume", gold_open))
            ranked_relevance.append((rank, relevant, sample_id))

    unknown_prediction_ids = sorted(set(predictions) - seen)
    if unknown_prediction_ids:
        raise ValueError(f"predictions reference unknown sample_ids: {unknown_prediction_ids[:5]}")

    ranked_relevance.sort()
    top_k = [item for item in ranked_relevance if item[0] <= k]
    ranking = None
    if top_k:
        ranking = {
            "k": k,
            "returned": len(top_k),
            "relevant": sum(relevant for _, relevant, _ in top_k),
            "precision_at_k": _safe_div(sum(relevant for _, relevant, _ in top_k), len(top_k)),
            "precision_at_k_wilson95": _wilson(
                sum(relevant for _, relevant, _ in top_k), len(top_k)
            ),
            "sample_ids": [sample_id for _, _, sample_id in top_k],
        }

    authority_report = {
        authority: {
            "count": authority_counts[authority],
            "state_accuracy": _safe_div(authority_correct[authority], authority_counts[authority]),
            "state_accuracy_wilson95": _wilson(
                authority_correct[authority], authority_counts[authority]
            ),
        }
        for authority in sorted(authority_counts)
    }
    stratum_report = {
        name: {
            **values,
            "prediction_coverage": _safe_div(values["matched"], values["total"]),
            "prediction_coverage_wilson95": _wilson(values["matched"], values["total"]),
            "state_accuracy": _safe_div(values["state_correct"], values["total"]),
            "state_accuracy_wilson95": _wilson(values["state_correct"], values["total"]),
        }
        for name, values in sorted(strata.items())
    }

    return {
        "sample_count": len(gold_rows),
        "prediction_count": len(prediction_rows),
        "prediction_coverage": _safe_div(matched, len(gold_rows)),
        "prediction_coverage_wilson95": _wilson(matched, len(gold_rows)),
        "decisive_coverage": _safe_div(decisive, len(gold_rows)),
        "decisive_coverage_wilson95": _wilson(decisive, len(gold_rows)),
        "exact_state_accuracy": _safe_div(exact_state, len(gold_rows)),
        "exact_state_accuracy_wilson95": _wilson(exact_state, len(gold_rows)),
        "open_obligation": _binary_metrics(open_tp, open_fp, open_fn, open_tn),
        "per_state": _per_state_metrics(gold_states, predicted_states),
        "evidence_ref_micro": _micro_set_metrics(gold_ref_sets, predicted_ref_sets),
        "contradiction_code_micro": _micro_set_metrics(gold_contradictions, predicted_contradictions),
        "known_anchor": {
            "total": known_anchor_total,
            "passed": known_anchor_passed,
            "recall": _safe_div(known_anchor_passed, known_anchor_total),
            "recall_wilson95": _wilson(known_anchor_passed, known_anchor_total),
        },
        "clean_finish_open_recall": {
            "total": clean_open_total,
            "passed": clean_open_passed,
            "recall": _safe_div(clean_open_passed, clean_open_total),
            "recall_wilson95": _wilson(clean_open_passed, clean_open_total),
        },
        "unsafe_completion_false_positives": {
            "count": len(unsafe_completed),
            "sample_ids": unsafe_completed,
        },
        "authority_slices": authority_report,
        "strata": stratum_report,
        "ranking": ranking,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gold", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = measure(_read_jsonl(args.gold), _read_jsonl(args.predictions), k=max(1, args.k))
    rendered = json.dumps(report, indent=2, sort_keys=True)
    print(rendered)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
