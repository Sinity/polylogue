#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: $0 /path/to/patched/polylogue-repo" >&2
  exit 64
fi

REPO="$(cd "$1" && pwd)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_REVISION="${BASE_REVISION:-76ee0d3842f12920ee71ad06f22b9cd8d2f88730}"

printf 'Repository: %s\n' "$REPO"
printf 'Snapshot base revision: %s\n' "$BASE_REVISION"

if git -C "$REPO" rev-parse --verify "$BASE_REVISION^{commit}" >/dev/null 2>&1; then
  EFFECTIVE_BASE="$BASE_REVISION"
else
  EFFECTIVE_BASE="$(
    git -C "$REPO" log --format='%H%x09%s' --all \
      | awk -F '\t' -v marker="snapshot base $BASE_REVISION" '$2 == marker {print $1; exit}'
  )"
  if [[ -z "$EFFECTIVE_BASE" ]]; then
    echo "Cannot find upstream base or a local synthetic baseline for $BASE_REVISION" >&2
    exit 65
  fi
fi
printf 'Effective diff base: %s\n' "$EFFECTIVE_BASE"
git -C "$REPO" merge-base --is-ancestor "$EFFECTIVE_BASE" HEAD
git -C "$REPO" diff --check "$EFFECTIVE_BASE"..HEAD

python -m compileall -q "$REPO/polylogue" "$REPO/tests"
python "$HERE/verify_projection.py" \
  --repo "$REPO" \
  --fixtures "$HERE/objective_posture_cases.json"
python "$HERE/verify_persistence.py" --repo "$REPO"
python "$HERE/measure_objective_posture.py" \
  --gold "$HERE/measurement-smoke-gold.jsonl" \
  --predictions "$HERE/measurement-smoke-predictions.jsonl" \
  --k 5

if [[ "${RUN_MANAGED_PYTEST:-0}" == "1" ]]; then
  PYTHONPATH="$REPO" pytest -q \
    "$REPO/tests/unit/archive/test_objective_posture.py" \
    "$REPO/tests/unit/insights/test_objective_posture_consumers.py" \
    "$REPO/tests/unit/context/test_compiler.py" \
    "$REPO/tests/unit/insights/test_fallback_markers.py"
else
  echo 'Managed pytest skipped. Set RUN_MANAGED_PYTEST=1 in a complete checkout.'
fi
