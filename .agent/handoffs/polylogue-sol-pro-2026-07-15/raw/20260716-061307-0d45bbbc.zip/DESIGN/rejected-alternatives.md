# Rejected alternatives

## Map terminal state to completion

Rejected because process termination and objective lifecycle answer different questions. `clean_finish` describes a normal end to the transcript or agent process; it does not prove that every operator decision, effect, or goal is closed. This mapping caused the bead's anchor to disappear from resume discovery.

## Exclude clean finishes before ranking

Rejected because it makes an unresolved clean session unreachable before evidence is examined. Discovery now filters only after logical-session posture is merged and uses `posture.resumable`.

## Let the final assistant turn decide posture

Rejected because a final answer can contain a decision request, a generic offer, protocol boilerplate, a recap, or unsupported claims. Final-turn structure is only the lowest authored fallback and must match a bounded choice form.

## Keyword blocker/completion matching

Rejected because quoted documentation, protocol instructions, error discussions, and historical descriptions produce false positives. Blocker extraction now returns only typed `blocked` obligations. Search text may contain posture words for retrieval, but retrieval text does not classify posture.

## Trust “done” or “completed” self-reports

Rejected because a claim is not an observed effect or evaluated satisfaction. Unsupported completion becomes an evidence-bearing `unknown` obligation with a typed contradiction, preserving the claim without closing the work.

## Give protocol/runtime context a vote

Rejected because protocol rows are not authored intent. Their refs are retained with an explicit contradiction, but they cannot create or close an obligation.

## Collapse to one state and discard obligations

Rejected because sessions can simultaneously be blocked, awaiting an operator, awaiting an effect, and carrying completed work. The aggregate state is a routing summary; obligations remain the durable explanatory projection.

## Store a second goal or work-evidence table

Rejected because the goal and work graphs already own lifecycle/effect facts. The projection stores compact refs in the existing rebuildable enrichment JSON and can be recreated from owners.

## Add posture columns to the session profile table

Rejected for this snapshot because the complete typed projection is nested, additive, and rebuildable. A scalar column would either duplicate the JSON truth or lose obligations/refs/contradictions. Query optimization can add a generated/indexed derivative later, provided it is explicitly non-authoritative.

## Treat every unknown as resumable

Rejected because legacy rows and sessions with no objective evidence would flood resume discovery. Only an actual open obligation, including an evidence-bearing unknown obligation, is resumable.

## Infer next steps from work-event or transcript fallbacks

Rejected because that would create a second obligation path after the projection. Resume next steps are rendered from `open_obligations`; terminal state and keyword/work-event summaries remain descriptive.

## Merge logical members by choosing the newest scalar state

Rejected because it can erase stronger earlier evidence and simultaneous obligations. Logical-session merge reconstructs evidence from member obligations and runs the same authority resolver.
