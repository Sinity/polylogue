# ObjectivePosture design

## Decision

Session resumability is derived from one evidence-bearing `ObjectivePosture` projection. It is independent of process termination. `terminal_state` remains a descriptive process outcome and is never converted into objective completion, exclusion, or blocker state.

This permits the required anchor:

```text
terminal_state = clean_finish
objective_posture.state = awaiting_operator
objective_posture.resumable = true
```

A clean final assistant response can therefore be operationally successful while the session still has an unresolved operator decision.

## Projection shape

`ObjectivePosture` contains:

- aggregate `state` and selected `authority`;
- an `as_of` evidence frame;
- every resolved `ObjectiveObligation`, including closed and open obligations;
- projection-wide evidence refs;
- typed contradictions;
- a projection version;
- derived `resumable`, which is true only when at least one obligation is open.

Each obligation contains a stable ID, kind, state, summary, selected authority, evidence refs, its own as-of frame, and contradictions. The projection does not copy goal graph nodes, work-evidence graph payloads, or assertion bodies. It retains references to those fact owners.

States are `completed`, `blocked`, `abandoned`, `inactive`, `awaiting_operator`, `awaiting_effect`, `in_progress`, `ambiguous`, and `unknown`.

Authorities are `goal_lifecycle`, `work_evidence`, `durable_assertion`, `authored_structure`, and `unknown`.

Kinds are `goal`, `question`, `work_effect`, `decision`, `blocker`, `handoff`, `authored_request`, and `unknown`.

## Resolution algorithm

Evidence is normalized and grouped by `obligation_id`. Authority is resolved inside each obligation, not across unrelated obligations. This distinction preserves simultaneous work: a high-authority completed goal does not erase a separate lower-authority blocker or open decision.

For each obligation:

1. Reject an unsupported `completed` claim by converting it to `unknown` and retaining an `unsupported_completion_claim` contradiction.
2. Ignore protocol-only evidence as a vote, while retaining its refs and a `protocol_only_evidence_ignored` contradiction.
3. Select the highest-authority decisive evidence. Unknown evidence participates only when no decisive state exists.
4. If equally authoritative evidence supplies incompatible decisive states, resolve to `ambiguous` and retain a `same_authority_conflict` contradiction.
5. Retain incompatible lower-authority evidence as `lower_authority_conflict`; do not silently discard it.
6. Select the obligation summary from the latest selected evidence by absolute timestamp, not lexical timestamp order.
7. Promote contradiction-only refs into obligation and projection provenance.

The aggregate state is selected from all obligations in this order:

```text
blocked
awaiting_operator
awaiting_effect
in_progress
ambiguous
unknown
abandoned
inactive
completed
```

The first six are open/reviewable. `completed`, `abandoned`, and `inactive` are closed. The ordering is a routing priority over simultaneous obligations, not an authority ranking.

An empty backward-compatible `unknown` projection is not resumable. An actual evidence-bearing obligation resolved to `unknown` is resumable because the obligation itself is known to exist and needs review.

## Completion safety

Completion is accepted only from:

- explicit goal lifecycle closure, unless the input is marked self-reported without evaluated satisfaction; or
- work evidence with `observed_effect=true` or `evaluated_satisfaction=true`.

Durable assertions and authored structure can express open, blocked, inactive, abandoned, or ambiguous posture, but do not manufacture completion. This preserves the fact-owner boundary: work effects and goal satisfaction decide completion, not prose.

## Bounded structural fallback

Structural inference is deliberately conservative and runs below all supplied fact-owner evidence.

It emits `awaiting_effect` for unmatched structured tool-use/session events, retaining tool or event refs. It emits `in_progress` for the latest substantive authored-user request. It emits `awaiting_operator` for a final substantive assistant question only when the question is structurally a decision: explicit alternatives/options, a typed “which” choice, or a first-person action confirmation such as “Should I deploy now?”

It does not vote from:

- final-assistant presence alone;
- words such as “blocked”, “complete”, or “awaiting operator” in prose;
- protocol/runtime-context messages;
- generic offers such as “Would you like a summary?”;
- non-substantive acknowledgements;
- unsupported self-reports of completion.

## As-of semantics

Every source may supply an ISO timestamp. The latest frame is chosen chronologically after normalizing timezone offsets to UTC. The original winning string is preserved. Invalid or absent timestamps remain deterministic but rank below valid timestamps.

The session-level as-of frame is the latest of source evidence and the available message/event/session frame. Logical-session merge uses the same chronology and the same authority resolver.

## Persistence

The sole projection is serialized inside the existing session enrichment JSON payload as `SessionObjectiveEnrichmentPayload.objective_posture`. This is additive and avoids a second goal/work fact store or a new index column/table.

Old enrichment payloads hydrate to `ObjectivePosture.unknown()`. Because that empty state is not resumable, stale rows are not incorrectly treated as open. A materializer/enrichment version bump and rebuild are still required in the full repository so existing rows acquire evidence-bearing projections.

## Consumer contract

The modified consumers do not reclassify posture:

- session profile and enrichment search text expose the projection;
- blocker extraction returns only `blocked` obligation summaries;
- resume discovery merges logical members with the same resolver, filters on `posture.resumable`, ranks posture separately from descriptive terminal state, and creates next steps only from open obligations;
- context compilation renders the aggregate, every obligation, evidence refs, as-of frames, and contradictions;
- preamble rendering displays the stored candidate posture rather than inferring one from terminal state.

`terminal_state` remains available for explanation and diagnostics. It carries no completion vote and no clean-finish exclusion.

## Known anchor

The labeled anchor uses a normal assistant decision question with no process failure. The deterministic verification asserts:

```json
{
  "terminal_state": "clean_finish",
  "objective_posture": "awaiting_operator",
  "resumable": true,
  "evidence_refs": ["codex-session:anchor::m2"]
}
```

Removing the higher-authority open goal/question evidence from the precedence fixture recreates the historical false result: lower work evidence resolves to `completed` and non-resumable. That ablation makes the authority rule executable rather than merely documented.
