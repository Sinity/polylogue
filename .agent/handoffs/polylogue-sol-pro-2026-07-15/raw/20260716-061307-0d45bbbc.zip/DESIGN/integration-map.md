# Integration map and full-tree seams

## Patched paths

`polylogue/archive/session/documents.py` adds typed wire documents for contradiction, obligation, and posture payloads and makes posture additive on `SessionProfileDocument`.

`polylogue/archive/session/models.py` owns the typed projection, authority resolver, completion guard, chronological as-of handling, coercion/round trip, logical-session merge, and the `SessionProfile.objective_posture` field.

`polylogue/archive/session/runtime.py` adds bounded structural evidence, structured pending-effect detection, the projection entrypoint, and the optional `objective_evidence` input to profile construction. Existing terminal-state analysis remains intact.

`polylogue/archive/session/session_profile.py` exports the public session-profile projection vocabulary and helpers.

`polylogue/storage/insights/session/records.py` defines the additive `SessionObjectiveEnrichmentPayload`, upgrades legacy payloads to explicit unknown, and preserves already-extended payload subclasses.

`polylogue/storage/insights/session/profiles.py` writes, searches, hydrates, and derives blockers/goal outcome/support signals from the projection.

`polylogue/storage/insights/session/rebuild.py` gives bounded/large-session fallback profiles an explicit unknown projection with an as-of frame.

`polylogue/storage/insights/session/storage.py` documents that terminal state is descriptive while the one projection lives in enrichment JSON.

`polylogue/insights/resume.py` reads the stored projection, merges logical members through the same resolver, removes the clean-finish exclusion, filters on open obligations, weights objective posture, carries refs, and renders next steps from obligations.

`polylogue/context/compiler.py` adds a context segment that renders aggregate posture, every obligation, refs, frames, authority, and contradictions.

`polylogue/context/preamble.py` renders stored candidate posture and leaves terminal state descriptive.

`polylogue/context/__init__.py` exposes the compiler helper lazily.

The test patch adds 13 authority-resolution fixtures, five structural cases, consumer tests, context tests, persistence tests, and the clean-finish/awaiting-operator anchor.

## Supplied-snapshot boundary

The immutable archive is a deliberately narrow repository slice. It omits several modules imported by these paths, including `polylogue.archive.actions`, `polylogue.archive.phase`, and `polylogue.api`. It also omits the canonical materializer/version constants, the complete public insight model, goal/work graph implementations, durable assertion query routes, context assembly route, daemon convergence, database DDL, and developer tooling.

The patches are therefore scoped to the supplied files and apply cleanly there. The executable harnesses load the real changed files with narrow stubs only for omitted dependencies. They do not claim end-to-end daemon/database verification.

## Required full-tree integration work

1. Wire goal/question, work-evidence/effect, and durable assertion adapters into the `objective_evidence` seam. Do not add transcript keyword fallbacks.
2. Bump the canonical session insight materializer and enrichment projection versions, then rebuild existing index rows. The patch raises `RESUME_BRIEF_MATERIALIZER_VERSION` locally, but the omitted canonical constants remain to be changed.
3. Confirm the public `SessionProfileInsight`/read model declares or serializes `objective_posture`. Pydantic parent-typed serialization can omit subclass-only fields unless the field is explicit or uses serialize-as-any semantics.
4. Insert `compile_objective_posture_context_segment` in the actual context assembly policy and verify token budgeting/truncation retains refs and contradictions.
5. Add storage/read-route tests against real SQLite rows, including old enrichment JSON, rebuilt rows, and projection-version skew.
6. Run the managed focused tests, type checks, lint, generated-surface checks, and topology checks in the complete checkout. No new production module was added, so topology regeneration should not be required by this patch itself.
7. Run the live measurement plan and preserve the sample receipt/results. No live metric exists in this handoff.

## Conflict assumptions

The source snapshot was clean at upstream commit `76ee0d3842f12920ee71ad06f22b9cd8d2f88730` on branch `feature/browser/adopt-completion-monitors`. The patch series is generated from that exact tree. Apply it before unrelated edits to the 17 touched paths, or resolve those conflicts explicitly.
