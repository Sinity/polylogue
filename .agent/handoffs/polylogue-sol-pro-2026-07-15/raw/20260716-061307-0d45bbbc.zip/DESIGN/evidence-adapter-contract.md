# Fact-owner evidence adapter contract

## Boundary

Goal/question lifecycle, work-evidence/effect graphs, and durable assertions remain the owners of their facts. `ObjectivePosture` consumes a compact reference-bearing adapter record and never stores a duplicate graph node, transcript excerpt, effect payload, or assertion body.

The production seam is `build_session_profile(..., objective_evidence=...)` and `project_session_objective_posture(..., evidence=...)`.

## Required adapter fields

Each adapter emits one `ObjectivePostureEvidence` per claim:

```text
obligation_id
kind
state
summary
authority
evidence_refs[]
as_of
observed_effect
evaluated_satisfaction
self_reported
protocol_only
contradictions[]
```

`obligation_id` must be stable across rematerialization and across fact owners referring to the same semantic obligation. Evidence refs must resolve to durable archive objects. The summary is presentation text, not identity.

## Authority adapters

Goal/question lifecycle adapters use `goal_lifecycle`. They should emit explicit open, close, block, abandon, or inactive transitions and stable goal/question IDs. A closure originating only from a participant claim must set `self_reported=true`; evaluated goal satisfaction sets `evaluated_satisfaction=true`.

Work-evidence adapters use `work_evidence`. Structured calls awaiting output emit `awaiting_effect`; verified file/database/deployment/test effects may emit `completed` only with `observed_effect=true`. Evaluators may set `evaluated_satisfaction=true` when the effect is judged against the obligation.

Durable assertion adapters use `durable_assertion` for decision, blocker, and handoff assertions. They should cite assertion IDs and preserve assertion validity/as-of semantics. A durable “completed” note remains a claim and will not close work by itself.

Structural evidence is produced by the session runtime and uses `authored_structure`. External adapters must not relabel transcript heuristics as a higher authority.

## Identity normalization

The same question may appear in a goal graph and in the final assistant turn. To prevent duplicate simultaneous obligations, the full-tree integration should define a semantic obligation identity registry or alias mapping. Preferred IDs derive from the owning graph (`goal:<id>`, `question:<id>`, `effect:<id>`, `assertion:<id>`). Structural IDs are local fallbacks and may be suppressed or aliased when a higher-authority adapter cites the same message ref.

Until that mapping exists, the resolver correctly preserves both records as separate obligations rather than guessing they are identical. This is conservative for resumability but can duplicate context/ranking summaries.

## Contradictions

Adapters may attach source-specific contradictions. Use stable machine-readable codes and include every supporting ref. The projection adds its own codes for unsupported completion, protocol-only evidence, same-authority conflict, and lower-authority conflict.

Contradictions are evidence, not errors to be dropped. A consumer may summarize them but must retain refs and states.

## As-of and replay

Adapters must evaluate only facts valid at or before the requested frame. Do not feed a current goal state into a historical session frame. ISO timestamps should include offsets. On replay, the same source records and frame must generate the same evidence sequence independent of database row order.

## Versioning and rebuild

The projection version is independent from the source graph versions. Any change to authority semantics, state vocabulary, completion support, structural inference, or identity normalization requires a projection/materializer version bump and a rebuild of derived session profile rows.

A source adapter change that only fills previously missing evidence also requires rematerialization. Durable source tables do not require a migration for this projection because only refs are copied into the rebuildable enrichment payload.

## Integration tests required in the full tree

Add real adapters and route tests for:

- goal open/close/block transitions;
- work call/result/effect and evaluated satisfaction;
- durable blocker/decision/handoff assertions, including validity changes;
- historical as-of replay;
- aliasing of structural and graph-backed versions of one obligation;
- logical-session merge across continuation members;
- materializer version skew and rebuild convergence.
