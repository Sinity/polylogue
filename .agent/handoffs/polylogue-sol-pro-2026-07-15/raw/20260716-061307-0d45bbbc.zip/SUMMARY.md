# Executive result

The patch series introduces one typed, evidence-bearing `ObjectivePosture` projection and makes it the shared source for session profiles, blocker extraction, resume ranking/discovery, and context rendering. Process termination remains descriptive and orthogonal.

The central regression is covered directly: a normal assistant response that ends cleanly while asking the operator to choose a deployment action remains `terminal_state=clean_finish`, resolves to `objective_posture=awaiting_operator`, retains the message evidence ref, and is resumable. There is no clean-finish exclusion in candidate filtering.

Authority is resolved per obligation in the bead order: goal/question lifecycle, work effects/evaluated satisfaction, durable assertions, bounded authored structure, then unknown. Multiple obligations are retained. Same-authority and lower-authority conflicts remain typed contradictions. Protocol-only evidence remains provenance but does not vote. Unsupported completion claims become evidence-bearing unknown obligations instead of silently closing work.

The projection is additive inside the existing enrichment JSON payload, so it does not duplicate goal or work-evidence fact stores and does not add an index table/column in this slice. Legacy rows hydrate to empty `unknown`, which is deliberately non-resumable until rematerialized.

The production patch touches 12 existing modules and adds five repository test/fixture paths. The complete diff is 2,502 insertions and 114 deletions across 17 paths, delivered as four ordered commits.

## Acceptance-criteria matrix

| Bead criterion | Delivered evidence | Status in supplied snapshot |
|---|---|---|
| 1. `clean_finish` and unresolved operator posture coexist; resume discovery includes it | Anchor fixture and executable real-file harness assert `clean_finish`, `awaiting_operator`, `resumable=true`, and `codex-session:anchor::m2`. Resume filtering now uses only merged `posture.resumable`; terminal state remains in diagnostics/ranking output but supplies no exclusion. Consumer unit patch covers candidate inclusion. | Implemented; anchor executable here. Full repository route test requires omitted API/storage graph. |
| 2. Completed, blocked, abandoned/inactive, awaiting operator/effect, ambiguous/unknown preserve obligations, refs, authority, as-of, contradictions | Typed models and 13 labeled authority fixtures cover all listed states, simultaneous obligations, same/lower-authority conflicts, timezone-offset ordering, contradiction-only refs, round trips, and empty-vs-evidence-bearing unknown. Context compiler renders all fields. | Implemented; 13/13 projection cases and 5/5 structural cases pass. |
| 3. Explicit goal/work-effect evidence outranks weaker inference; unsupported self-report cannot complete | Per-obligation authority resolver, observed/evaluated completion gate, `unsupported_completion_claim`, and precedence ablation. Removing the high-authority open evidence recreates the false completed/non-resumable result. | Implemented and executable harness passes. |
| 4. Protocol, final-assistant presence, keywords, and unsupported claims do not decide posture | Protocol evidence is ignored as a vote with retained contradiction/ref. Structural choice detection requires a bounded real decision form. Negative fixtures include keyword prose, final assistant presence, generic summary offer, unrelated bullet list, protocol choice, and non-substantive acknowledgement. | Implemented and boundary harness passes. |
| 5. Profiles, blockers, ranking, and context consume one projection with no parallel terminal completion heuristic | Profile persistence/hydration carries one additive projection; blockers read typed blocked obligations; resume merges and filters that projection; context/preamble render it. Transcript/work-event next-step fallbacks and clean-finish gating are removed from these routes. | Implemented in all supplied consumer files. Full context assembly/public read model integration is outside the slice and remains an explicit check. |
| 6. Labeled live sample records precision/coverage and known anchor; focused tests pass | Labeled deterministic fixture, JSONL live-label schema, evaluator with Wilson intervals, sampling/adjudication/ablation plan, known anchor, unit-test patches, synthetic evaluator smoke. | Partial by environment: no live archive was supplied, so no live metric is claimed. Managed pytest was attempted but collection stops on omitted modules; real-file and persistence harnesses pass. |

## Important implementation decisions

Resumability is `bool(open_obligations)`, not a scalar-state shortcut. This prevents empty legacy unknown rows from flooding discovery while keeping an actual unknown obligation reviewable.

Authority resolves conflicting claims about the same obligation. It does not erase different obligations. Aggregate routing prioritizes blockers, operator decisions, pending effects, active work, ambiguity, and evidence-bearing unknown before closed states.

Completion is narrow. Explicit goal closure is accepted; self-reported goal closure needs evaluated satisfaction. Work completion needs an observed effect or evaluated satisfaction. Durable notes and authored prose cannot independently produce `completed`.

Logical-session members are merged through the same resolver rather than choosing the newest or strongest scalar state. Resume next steps are generated only from open obligations.

As-of comparison parses ISO offsets and orders absolute instants, preserving the winning source string. Contradiction-only refs are promoted into projection provenance.

## Verification result

The ordered patches apply cleanly to a pristine copy of the supplied snapshot. SHA-256 comparison confirms all 17 changed paths match the developed tree. `git diff --check` and repository/test bytecode compilation pass.

The executable projection harness passes 13/13 authority fixtures, 5/5 structural fixtures, authority ablation, bounded-question negatives/positives, offset ordering, contradiction provenance, pending structured effects, legacy unknown behavior, and the clean-finish anchor.

The Pydantic persistence harness passes typed enrichment JSON round trip, full session-record round trip, backward legacy defaulting, and forward subclass preservation.

The focused pytest command was run, not skipped. Collection failed with exit status 2 because the immutable slice omits `polylogue.archive.actions`, `polylogue.archive.phase`, and `polylogue.api`. The exact command and traceback are included in `TESTS/pytest-collection.log`.

The measurement calculator smoke uses nine fully synthetic rows and is not a live quality result. No browser, daemon, secrets, SQLite archive, NixOS deployment, public API route, or operator corpus was available.

## Residual launch risks

The complete repository must wire the actual goal/work/assertion adapters. Stable semantic obligation IDs or aliases are needed so a graph-backed decision and its structural final-turn fallback do not appear as duplicate obligations.

The omitted canonical materializer/enrichment constants must be bumped and existing derived rows rebuilt. Until rebuild, old rows hydrate to non-resumable unknown by design.

The omitted public `SessionProfileInsight` read model must explicitly preserve subclass fields or declare `objective_posture`; parent-typed Pydantic serialization can otherwise drop additive subclass data.

The context compiler helper is implemented, but the omitted context assembly policy must invoke it and preserve evidence/contradictions under token budgeting.

No live precision, recall, coverage, or ranking number exists yet. `TESTS/precision-coverage-plan.md` defines the required frozen sample, blind labeling, adjudication, confidence intervals, gates, and unsafe ablations.
