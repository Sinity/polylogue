#!/usr/bin/env python3
"""Static, dependency-free verification for the supplied Polylogue snapshot.

Usage:
    python TESTS/verify_snapshot.py /path/to/polylogue-sol-pro-work \
        --report TESTS/baseline-report.json

The input may be either the context-pack root (containing REPO/ and GIT/) or the
REPO/ directory itself.  This verifier intentionally avoids importing Polylogue:
the selected snapshot omits project files needed to import the package.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

EXPECTED_HEAD = "76ee0d3842f12920ee71ad06f22b9cd8d2f88730"
EXPECTED_ORIGINS = [
    "claude-code-session",
    "codex-session",
    "gemini-cli-session",
    "hermes-session",
    "antigravity-session",
    "beads-issue",
    "grok-export",
    "chatgpt-export",
    "claude-ai-export",
    "aistudio-drive",
    "unknown-export",
]
EXPECTED_PROVIDERS = [
    "chatgpt",
    "claude-ai",
    "claude-code",
    "codex",
    "gemini",
    "gemini-cli",
    "hermes",
    "antigravity",
    "beads",
    "grok",
    "drive",
    "unknown",
]


@dataclass(frozen=True)
class Check:
    check_id: str
    passed: bool
    evidence: Any


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _tree(path: Path) -> ast.Module:
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def _find_class(tree: ast.Module, name: str) -> ast.ClassDef:
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == name:
            return node
    raise AssertionError(f"missing class {name}")


def _enum_values(tree: ast.Module, name: str) -> list[str]:
    cls = _find_class(tree, name)
    values: list[str] = []
    for node in cls.body:
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str)
        ):
            values.append(node.value.value)
    return values


def _find_function(tree: ast.Module, name: str) -> ast.FunctionDef:
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    raise AssertionError(f"missing function {name}")


def _provider_return(node: ast.If) -> str | None:
    for statement in node.body:
        if isinstance(statement, ast.Return):
            value = statement.value
            if (
                isinstance(value, ast.Attribute)
                and isinstance(value.value, ast.Name)
                and value.value.id == "Provider"
            ):
                return value.attr
    return None


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Call):
        return _call_name(node.func)
    if isinstance(node, ast.Attribute):
        return f"{_call_name(node.value)}.{node.attr}"
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Subscript):
        return _call_name(node.value)
    if isinstance(node, ast.BoolOp):
        return "|".join(_call_name(value) for value in node.values)
    if isinstance(node, ast.Compare):
        return ast.unparse(node)
    return ast.unparse(node)


def _top_level_if_order(function: ast.FunctionDef) -> list[dict[str, Any]]:
    order: list[dict[str, Any]] = []
    for statement in function.body:
        if not isinstance(statement, ast.If):
            continue
        returned = _provider_return(statement)
        # Browser capture delegates to Provider.from_string and is still a
        # semantically distinct first detector.
        if returned is None and "browser_capture.looks_like" not in ast.unparse(statement.test):
            continue
        order.append(
            {
                "condition": _call_name(statement.test),
                "provider": returned or "EMBEDDED_PROVIDER",
                "line": statement.lineno,
            }
        )
    return order


def _sequence_detector_order(function: ast.FunctionDef) -> list[dict[str, Any]]:
    order: list[dict[str, Any]] = []
    for statement in ast.walk(function):
        if not isinstance(statement, ast.If):
            continue
        source = ast.unparse(statement.test)
        if any(
            marker in source
            for marker in (
                "browser_capture.looks_like",
                "beads.looks_like",
                "first_record.get('mapping')",
                "first_record.get('chat_messages')",
                "_looks_like_gemini_mapping",
                "claude.looks_like_code",
                "codex.looks_like",
            )
        ):
            returned = _provider_return(statement)
            if "browser_capture.looks_like" in source:
                returned = "EMBEDDED_PROVIDER"
            order.append({"condition": source, "provider": returned, "line": statement.lineno})
    return sorted(order, key=lambda item: item["line"])


def _provider_set(tree: ast.Module, name: str) -> list[str]:
    for node in tree.body:
        target_name: str | None = None
        value: ast.AST | None = None
        if isinstance(node, ast.Assign):
            value = node.value
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    target_name = target.id
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if node.target.id == name:
                target_name = node.target.id
                value = node.value
        if target_name != name or value is None:
            continue
        if isinstance(value, ast.Call) and value.args:
            value = value.args[0]
        if not isinstance(value, (ast.Set, ast.Tuple, ast.List)):
            raise AssertionError(f"{name} is not a literal collection")
        result: list[str] = []
        for element in value.elts:
            if (
                isinstance(element, ast.Attribute)
                and isinstance(element.value, ast.Name)
                and element.value.id == "Provider"
            ):
                result.append(element.attr)
        return sorted(result)
    raise AssertionError(f"missing provider set {name}")


def _keyword(call: ast.Call, name: str) -> ast.AST | None:
    for item in call.keywords:
        if item.arg == name:
            return item.value
    return None


def _origin_attribute(value: ast.AST | None) -> str | None:
    if (
        isinstance(value, ast.Attribute)
        and isinstance(value.value, ast.Name)
        and value.value.id == "Origin"
    ):
        return value.attr
    return None


def _provider_attribute(value: ast.AST | None) -> str | None:
    if value is None or (isinstance(value, ast.Constant) and value.value is None):
        return None
    if (
        isinstance(value, ast.Attribute)
        and isinstance(value.value, ast.Name)
        and value.value.id == "Provider"
    ):
        return value.attr
    return ast.unparse(value)


def _literal_string(value: ast.AST | None) -> str | None:
    if isinstance(value, ast.Constant) and isinstance(value.value, str):
        return value.value
    return None


def _ann_assignment(tree: ast.Module, name: str) -> ast.AST:
    for node in tree.body:
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == name:
            if node.value is None:
                raise AssertionError(f"{name} has no value")
            return node.value
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == name for target in node.targets):
            return node.value
    raise AssertionError(f"missing assignment {name}")


def _package_specs(tree: ast.Module) -> list[dict[str, Any]]:
    value = _ann_assignment(tree, "PACKAGE_MODE_SPECS")
    if not isinstance(value, ast.Tuple):
        raise AssertionError("PACKAGE_MODE_SPECS is not a tuple")
    rows: list[dict[str, Any]] = []
    for item in value.elts:
        if not isinstance(item, ast.Call):
            continue
        rows.append(
            {
                "package_ref": _literal_string(_keyword(item, "package_ref")),
                "origin": _origin_attribute(_keyword(item, "origin")),
                "capture_mode": _literal_string(_keyword(item, "capture_mode")),
                "provider_wire": _provider_attribute(_keyword(item, "provider_wire")),
                "line": item.lineno,
            }
        )
    return rows


def _origin_fixtures(tree: ast.Module) -> list[dict[str, Any]]:
    value = _ann_assignment(tree, "ORIGIN_FIXTURES")
    if not isinstance(value, ast.List):
        raise AssertionError("ORIGIN_FIXTURES is not a list")
    rows: list[dict[str, Any]] = []
    for item in value.elts:
        if not isinstance(item, ast.Call):
            continue
        rows.append(
            {
                "label": _literal_string(_keyword(item, "label")),
                "provider": _provider_attribute(_keyword(item, "provider")),
                "origin": _origin_attribute(_keyword(item, "expected_origin")),
                "line": item.lineno,
            }
        )
    return rows


def _origin_provider_map(tree: ast.Module) -> list[dict[str, str]]:
    value = _ann_assignment(tree, "_PROVIDER_TO_ORIGIN")
    if not isinstance(value, ast.Dict):
        raise AssertionError("_PROVIDER_TO_ORIGIN is not a dict")
    rows: list[dict[str, str]] = []
    for key, mapped in zip(value.keys, value.values, strict=True):
        provider = _provider_attribute(key)
        origin = _origin_attribute(mapped)
        if provider is not None and origin is not None:
            rows.append({"provider": provider, "origin": origin})
    return rows


def _origin_provider_reverse_map(tree: ast.Module) -> list[dict[str, str]]:
    value = _ann_assignment(tree, "_ORIGIN_TO_PROVIDER")
    if not isinstance(value, ast.Dict):
        raise AssertionError("_ORIGIN_TO_PROVIDER is not a dict")
    rows: list[dict[str, str]] = []
    for key, mapped in zip(value.keys, value.values, strict=True):
        origin = _origin_attribute(key)
        provider = _provider_attribute(mapped)
        if provider is not None and origin is not None:
            rows.append({"origin": origin, "provider": provider})
    return rows


def _provider_from_origin_calls(tree: ast.Module) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or _call_name(node.func) != "provider_from_origin":
            continue
        calls.append(
            {
                "line": node.lineno,
                "argument_count": len(node.args),
                "keywords": sorted(keyword.arg for keyword in node.keywords if keyword.arg is not None),
                "source": ast.unparse(node),
            }
        )
    return sorted(calls, key=lambda item: item["line"])


def _schema_origin_map(tree: ast.Module) -> list[dict[str, str]]:
    value = _ann_assignment(tree, "_PROVIDER_BY_ORIGIN")
    if not isinstance(value, ast.Dict):
        raise AssertionError("_PROVIDER_BY_ORIGIN is not a dict")
    rows: list[dict[str, str]] = []
    for key, mapped in zip(value.keys, value.values, strict=True):
        rows.append({"origin_expression": ast.unparse(key), "provider_expression": ast.unparse(mapped)})
    return rows


def _function_source(path: Path, tree: ast.Module, name: str) -> str:
    node = _find_function(tree, name)
    lines = path.read_text(encoding="utf-8").splitlines()
    return "\n".join(lines[node.lineno - 1 : node.end_lineno])


def _read_optional(path: Path) -> str | None:
    return path.read_text(encoding="utf-8").strip() if path.is_file() else None


def _add(checks: list[Check], check_id: str, passed: bool, evidence: Any) -> None:
    checks.append(Check(check_id=check_id, passed=bool(passed), evidence=evidence))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", type=Path, help="context-pack root or REPO directory")
    parser.add_argument("--report", type=Path, help="write JSON report to this path")
    args = parser.parse_args(argv)

    supplied = args.snapshot.resolve()
    if (supplied / "REPO").is_dir():
        context_root = supplied
        repo = supplied / "REPO"
    else:
        repo = supplied
        context_root = supplied.parent if supplied.name == "REPO" else supplied

    required = {
        "enums": repo / "polylogue/core/enums.py",
        "sources": repo / "polylogue/core/sources.py",
        "dispatch": repo / "polylogue/sources/dispatch.py",
        "assembly": repo / "polylogue/sources/assembly.py",
        "completeness": repo / "polylogue/sources/provider_completeness.py",
        "regression_pack": repo / "tests/unit/sources/parsers/test_origin_regression_pack.py",
        "ordering_tests": repo / "tests/unit/sources/test_dispatch_ordering.py",
        "schema_corpus": repo / "polylogue/schemas/validation/corpus.py",
        "schema_sampling": repo / "polylogue/schemas/sampling_db.py",
        "live_watcher": repo / "polylogue/sources/live/watcher.py",
    }
    missing = [str(path) for path in required.values() if not path.is_file()]
    if missing:
        print(json.dumps({"error": "required snapshot files missing", "paths": missing}, indent=2), file=sys.stderr)
        return 2

    trees = {name: _tree(path) for name, path in required.items()}
    checks: list[Check] = []

    origins = _enum_values(trees["enums"], "Origin")
    providers = _enum_values(trees["enums"], "Provider")
    _add(checks, "origin.enum.exact-eleven", origins == EXPECTED_ORIGINS, origins)
    _add(checks, "provider.enum.exact-twelve", providers == EXPECTED_PROVIDERS, providers)

    provider_origin_map = _origin_provider_map(trees["sources"])
    aistudio_sources = [row["provider"] for row in provider_origin_map if row["origin"] == "AISTUDIO_DRIVE"]
    _add(
        checks,
        "identity.aistudio-many-to-one",
        aistudio_sources == ["GEMINI", "DRIVE"],
        {"providers": aistudio_sources, "mapping": provider_origin_map},
    )

    provider_sets = {
        name: _provider_set(trees["dispatch"], name)
        for name in ("BUNDLE_PROVIDERS", "GROUP_PROVIDERS", "STREAM_RECORD_PROVIDERS", "DRIVE_LIKE_PROVIDERS")
    }
    _add(
        checks,
        "dispatch.manual-provider-inventories-present",
        all(provider_sets.values()),
        provider_sets,
    )

    record_order = _top_level_if_order(_find_function(trees["dispatch"], "_detect_provider_from_record"))
    sequence_order = _sequence_detector_order(_find_function(trees["dispatch"], "_detect_provider_from_sequence"))
    record_providers = [item["provider"] for item in record_order]
    sequence_providers = [item["provider"] for item in sequence_order]
    inversion = (
        record_providers.index("CODEX") < record_providers.index("CLAUDE_CODE")
        and sequence_providers.index("CLAUDE_CODE") < sequence_providers.index("CODEX")
    )
    _add(
        checks,
        "dispatch.detector-order-is-context-scoped",
        inversion,
        {"record": record_order, "sequence": sequence_order},
    )
    pilot_inversion = (
        record_providers.index("CLAUDE_CODE") < record_providers.index("CHATGPT")
        and sequence_providers.index("CHATGPT") < sequence_providers.index("CLAUDE_CODE")
    )
    _add(
        checks,
        "dispatch.three-pilot-order-is-self-contained-and-scoped",
        pilot_inversion,
        {
            "record_relative_order": [provider for provider in record_providers if provider in {"CLAUDE_CODE", "CHATGPT"}],
            "sequence_relative_order": [provider for provider in sequence_providers if provider in {"CLAUDE_CODE", "CHATGPT"}],
        },
    )

    package_specs = _package_specs(trees["completeness"])
    package_origins = [item["origin"] for item in package_specs]
    _add(checks, "completeness.handwritten-nine-rows", len(package_specs) == 9, package_specs)
    _add(
        checks,
        "completeness.omits-beads-and-grok",
        "BEADS_ISSUE" not in package_origins and "GROK_EXPORT" not in package_origins,
        package_origins,
    )
    browser_rows = [row for row in package_specs if row["package_ref"] == "provider-package:browser-capture/live-receiver@v1"]
    _add(
        checks,
        "completeness.browser-capture-is-keyed-as-unknown",
        len(browser_rows) == 1 and browser_rows[0]["origin"] == "UNKNOWN_EXPORT",
        browser_rows,
    )

    fixtures = _origin_fixtures(trees["regression_pack"])
    fixture_origins = [item["origin"] for item in fixtures]
    _add(checks, "fixtures.direct-parser-table-has-nine-origins", len(fixtures) == 9, fixtures)
    _add(
        checks,
        "fixtures.direct-parser-table-omits-reserved-and-fallback",
        "GROK_EXPORT" not in fixture_origins and "UNKNOWN_EXPORT" not in fixture_origins,
        fixture_origins,
    )

    schemas_root = repo / "polylogue/schemas/providers"
    schema_dirs = sorted(path.name for path in schemas_root.iterdir() if path.is_dir())
    _add(
        checks,
        "schemas.provider-directories-current-eight",
        schema_dirs == ["antigravity", "chatgpt", "claude-ai", "claude-code", "codex", "gemini", "gemini-cli", "hermes"],
        schema_dirs,
    )

    schema_reverse = _schema_origin_map(trees["schema_corpus"])
    schema_reverse_text = json.dumps(schema_reverse)
    _add(
        checks,
        "schemas.reverse-origin-map-omits-beads-and-grok",
        "BEADS_ISSUE" not in schema_reverse_text and "GROK_EXPORT" not in schema_reverse_text,
        schema_reverse,
    )

    core_reverse = _origin_provider_reverse_map(trees["sources"])
    core_aistudio = next((row["provider"] for row in core_reverse if row["origin"] == "AISTUDIO_DRIVE"), None)
    schema_aistudio = next(
        (
            row["provider_expression"]
            for row in schema_reverse
            if row["origin_expression"] == "Origin.AISTUDIO_DRIVE.value"
        ),
        None,
    )
    sampling_reverse_calls = _provider_from_origin_calls(trees["schema_sampling"])
    watcher_reverse_calls = _provider_from_origin_calls(trees["live_watcher"])
    unqualified_sampling = [
        call
        for call in sampling_reverse_calls
        if call["argument_count"] == 1 and "family_hint" not in call["keywords"]
    ]
    unqualified_watcher = [
        call
        for call in watcher_reverse_calls
        if call["argument_count"] == 1 and "family_hint" not in call["keywords"]
    ]
    _add(
        checks,
        "identity.aistudio-reverse-projections-are-contextual-and-drifted",
        core_aistudio == "GEMINI"
        and schema_aistudio == "Provider.DRIVE.value"
        and bool(unqualified_sampling)
        and bool(unqualified_watcher),
        {
            "core_compatibility_default": core_aistudio,
            "schema_verification_projection": schema_aistudio,
            "schema_sampling_unqualified_calls": unqualified_sampling,
            "live_watcher_unqualified_calls": unqualified_watcher,
        },
    )

    assembly_source = _function_source(required["assembly"], trees["assembly"], "get_assembly_spec")
    _add(
        checks,
        "assembly.aistudio-applicability-is-currently-gemini-only",
        "Provider.GEMINI" in assembly_source and "Provider.DRIVE" not in assembly_source,
        {
            "function_lines": [
                _find_function(trees["assembly"], "get_assembly_spec").lineno,
                _find_function(trees["assembly"], "get_assembly_spec").end_lineno,
            ],
            "has_gemini_branch": "Provider.GEMINI" in assembly_source,
            "has_drive_branch": "Provider.DRIVE" in assembly_source,
        },
    )

    lower_source = _function_source(required["dispatch"], trees["dispatch"], "_lower_payload_specs")
    parse_source = _function_source(required["dispatch"], trees["dispatch"], "_parse_lowered_spec")
    grok_falls_through = (
        "Provider.GROK" not in lower_source
        and "return _lower_fallback_payload(runtime_provider, shaped_payload, fallback_id)" in lower_source
        and 'if spec.mode == "generic_messages":' in parse_source
    )
    _add(
        checks,
        "lifecycle.grok-explicit-hint-reaches-generic-fallback-statically",
        grok_falls_through,
        {
            "lowering_function": [
                _find_function(trees["dispatch"], "_lower_payload_specs").lineno,
                _find_function(trees["dispatch"], "_lower_payload_specs").end_lineno,
            ],
            "parse_function": [
                _find_function(trees["dispatch"], "_parse_lowered_spec").lineno,
                _find_function(trees["dispatch"], "_parse_lowered_spec").end_lineno,
            ],
            "has_grok_guard": "Provider.GROK" in lower_source,
            "has_generic_fallback": "return _lower_fallback_payload(runtime_provider, shaped_payload, fallback_id)" in lower_source,
            "has_generic_message_parser": 'if spec.mode == "generic_messages":' in parse_source,
        },
    )

    declarations_dir = repo / "polylogue/declarations"
    origin_specs = repo / "polylogue/sources/origin_specs.py"
    _add(
        checks,
        "dependency.declaration-and-origin-kernels-absent",
        not declarations_dir.exists() and not origin_specs.exists(),
        {"declarations_exists": declarations_dir.exists(), "origin_specs_exists": origin_specs.exists()},
    )

    head = _read_optional(context_root / "GIT/HEAD.txt")
    status = _read_optional(context_root / "GIT/status.txt")
    staged = _read_optional(context_root / "GIT/staged.patch")
    working = _read_optional(context_root / "GIT/working-tree.patch")
    if head is not None:
        _add(checks, "snapshot.base-revision", head == EXPECTED_HEAD, head)
        status_lines = status.splitlines() if status is not None else []
        clean_status = bool(status_lines) and all(line.startswith("## ") for line in status_lines)
        _add(
            checks,
            "snapshot.selected-footprint-clean",
            staged == "" and working == "" and clean_status,
            {
                "status": status,
                "status_lines": status_lines,
                "staged_patch_bytes": len(staged or ""),
                "working_patch_bytes": len(working or ""),
            },
        )

    report = {
        "verifier": "polylogue-origin-spec-adjudication-v2",
        "snapshot_label": context_root.name,
        "repo_file_count": sum(1 for path in repo.rglob("*") if path.is_file()),
        "source_hashes": {name: _sha256(path) for name, path in required.items()},
        "checks": [asdict(check) for check in checks],
        "summary": {
            "passed": sum(check.passed for check in checks),
            "failed": sum(not check.passed for check in checks),
            "total": len(checks),
        },
    }

    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.report is not None:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)
    return 0 if report["summary"]["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
