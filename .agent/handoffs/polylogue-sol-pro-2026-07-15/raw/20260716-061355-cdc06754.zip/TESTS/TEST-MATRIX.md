# Verification and future test matrix

## Checks executed against the supplied snapshot

`verify_snapshot.py` is a dependency-free AST/static verifier because the selected source footprint cannot import Polylogue. Its committed baseline report records 19/19 passing checks:

| Check | Purpose |
|---|---|
| exact eleven Origin tokens | pins the migration vocabulary and order |
| exact twelve Provider tokens | pins the physical/wire vocabulary |
| AISTUDIO many-to-one map | proves Gemini + Drive collision |
| four manual dispatch provider sets | identifies inventories to migrate |
| full record/sequence Codex/Claude inversion | proves ordering must be scoped |
| self-contained pilot Claude Code/ChatGPT inversion | proves the three-pilot kernel can exercise scoped ordering without dangling Codex edges |
| nine handwritten completeness rows | records current completeness scope |
| completeness omission of Beads/Grok | records drift |
| browser capture keyed as Unknown | records transport/origin conflation |
| nine direct-parser fixtures | records current fixture scope |
| omission of reserved/fallback fixtures | separates parser census from Origin enum |
| eight provider schema directories | records current schema packages |
| schema reverse-map omission of Beads/Grok | records another inventory |
| AISTUDIO reverse-projection drift | records core Gemini default, schema Drive projection, and unqualified sampling/watcher reconstruction |
| Gemini-only AISTUDIO assembly | proves handler applicability cannot be inferred from Origin alone |
| static Grok generic-fallback reachability | exposes lifecycle conflict |
| absence of DeclarationSpec/OriginSpec modules | proves prerequisite/kernel are not in snapshot |
| exact base revision metadata | pins source assumptions |
| clean selected footprint | identifies no pre-existing patch conflict |

Run it with:

```bash
python TESTS/verify_snapshot.py /path/to/polylogue-sol-pro-work \
  --report /tmp/origin-spec-baseline.json
```

## Patch verification executed

The three patches were checked/applied in order to a copy of the supplied `REPO/` tree. `git diff --check` reported no whitespace errors, both changed Python test modules passed `py_compile`, and reverse-apply checks succeeded. Exact command receipts are in `PATCH-VERIFICATION.txt`. Patch 0003 was not executed under pytest because the selected snapshot omits the importable Polylogue package; its fixture shape and expected providers are independently characterized by the static verifier.

## Test matrix for `polylogue-o21.1`

| Area | Required test | Mutation/anti-vacuity |
|---|---|---|
| compatibility key | equality across identity/lifecycle/authority/access-result/durability | change one dimension and require a named diff diagnostic |
| deterministic registry | shuffled registration yields byte-identical normalized output | randomize 100 times |
| handler/output edges | missing producer, handler, schema, output, example, or consumer | remove a real MCP pilot edge |
| diagnostics | owner path, declaration id, missing edge, exact command | delete each field and fail |
| dependency boundary | declarations imports no domain package | import graph/grep mutation |
| real pilot | MCP consumes kernel while retaining semantics in `polylogue/mcp` | remove pilot declaration/handler and fail |

## Test matrix for `polylogue-2qx.1.1`

`pilot-detector-ambiguity-fixtures.json` supplies the exact combined record that
matches both current Claude Code and ChatGPT detectors. Included Patch 0003
mirrors that payload in the existing parameterized production-dispatch catalog.
The future OriginSpec parity test should load the shared JSON fixture and exercise
both record and one-record-sequence entry points rather than reimplementing
detector predicates.

| Area | Required real-route tests | Mutation/anti-vacuity |
|---|---|---|
| lifecycle/admission policy | executable Claude/ChatGPT, reserved Grok; explicit hint/envelope policies are justified | attach generic parser to Grok, remove an explicit-hint reason, or omit an envelope transform |
| pilot record ordering | combined Claude Code + ChatGPT record is Claude Code | delete/reverse pilot edge |
| pilot sequence ordering | combined Claude Code + ChatGPT sequence is ChatGPT | delete/reverse pilot edge |
| result-provider non-disjointness | Claude/ChatGPT remain order-required despite different returned Providers | remove edge and falsely use Provider inequality as disjointness |
| cycles | synthetic A→B→A binding graph | require exact cycle path |
| disjointness | incomparable detectors require reciprocal disjointness + negative fixture | remove fixture |
| pre-admission transform | browser envelope retains embedded Provider and shared binding metadata is deduplicated | duplicate binding ID with conflicting owner/symbol |
| parser bindings | Claude grouped/document + stream; ChatGPT document/bundle; Grok none | delete handler or create stream/document conflict without selector |
| binding applicability | detector inputs use valid shared contexts; parser/assembly handlers name valid pilot modes/providers | empty context, remove fiber member, or attach a foreign provider |
| assembly | Claude Code sidecars resolve through provider/mode-qualified binding | remove assembly symbol or applicability |
| partial registry guard | three-pilot plans can parity-check but cannot replace production dispatch | make installer ignore computed completeness, or omit one enum member after full migration |
| public vocabulary | pilot Origin values, not Provider tokens | inject `claude-code` into output |
| fixture census | every pilot mode has raw/normalized or negative fixture | remove one fixture file/ref |
| completeness | pilot rows derive/parity-check from declarations | mutate current row path/mode |
| deterministic derivation | shuffled pilot registration identical | randomize order |
| source provenance | every binding/output points to owner path | blank owner path |
| semantic reparse | executable parser changes declare consequence | remove consequence |

Recommended focused commands after implementation:

```bash
devtools test tests/unit/sources/test_origin_specs.py
devtools test tests/unit/sources/test_origin_spec_ordering.py
devtools test tests/unit/sources/test_origin_spec_diagnostics.py
devtools test tests/unit/sources/test_origin_spec_derivations.py
devtools test tests/unit/sources/test_dispatch_ordering.py
devtools test tests/unit/sources/parsers/test_origin_regression_pack.py
```

## Test matrix for `polylogue-2qx.1.2`

| Domain case | Required assertions |
|---|---|
| exact registry completeness | `spec_origins == tuple(Origin)`: all eleven members once in exact required order |
| Claude Code | record/sequence/raw-prefix/group/stream/sidecars unchanged |
| Codex | record/sequence/group/stream/assembly unchanged |
| Gemini CLI | local-agent document detection/parsing unchanged |
| Hermes | state DB, ATIF, local document, source-path behavior, fidelity flags |
| Antigravity | markdown, brain metadata, language-server/session paths, degraded flag |
| Beads | non-chat constructs, record/sequence/group/stream behavior |
| Grok | no positive detector or parser; explicit generic-message hint does not parse after approved correction |
| ChatGPT | document, bundle, sessions wrapper, browser envelope projection |
| Claude AI | document/bundle/chat_messages behavior |
| AISTUDIO | both Gemini and Drive physical providers, explicit collision/disambiguation, provider/mode-qualified parser and assembly applicability, sampling/watcher reverse projection |
| Unknown | no positive detector, final compatibility fallback, no executable completeness claim |
| recursive lowering | nested bundles, grouped JSONL, Drive documents, browser captures |
| runtime consumers | acquisition, emitter, live batch, and revision replay use derived/parity-checked plans |
| public surfaces | schemas/errors/completions/help/docs expose Origin, no Provider leak |
| inventory deletion | removing old set/map/list does not remove behavior; grep finds no parallel owner |
| generated outputs | render check produces no drift |

Recommended existing suites to include:

```bash
devtools test tests/unit/sources/test_dispatch_payloads.py
devtools test tests/unit/sources/test_source_laws.py
devtools test tests/unit/sources/test_provider_contracts.py
devtools test tests/unit/sources/test_provider_completeness.py
devtools test tests/unit/sources/test_browser_capture.py
devtools test tests/unit/sources/test_parsers_local_agent.py
devtools test tests/unit/sources/test_revision_backfill.py
devtools test -k live_batch
devtools render all --check
devtools verify --quick
```

## Explicit decision-gate tests

### Grok

Before changing runtime behavior, add a baseline test that demonstrates the current explicit-hint generic fallback, then change the expected result under an approved reserved-lifecycle correction. The final test must prove both that no detector selects Grok and that explicit `Provider.GROK` cannot parse generic messages.

### AISTUDIO assembly

Test both physical providers with the same logical Origin. The result must prove whether Drive receives Gemini assembly or intentionally does not, based on acquisition mode. A single Origin-level handler with no provider/mode qualifier is insufficient.

### Browser capture

The completeness/docs derivation must list browser capture as an acquisition mode and assert that the parsed session Origin is the embedded provider’s Origin. It must never generate a browser-capture Origin token or count Unknown as the captured page’s source.
