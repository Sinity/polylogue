# Verification limits and exact boundary

## What was inspected

- The supplied tarball was unpacked as a path-safe selected snapshot.
- Repository instructions, mission/scope, pack report, Git metadata, selected Beads record, and all relevant included source/test/doc files were read.
- Exact-revision official Beads records for `o21.1`, `2qx.1.1`, `2qx.1.2`, the umbrella/parent, and the false-unification ruling were inspected because the targeted pack omitted them.
- The exact-revision official `polylogue/core/provider_identity.py` was inspected because the selected footprint imports but omits it.
- Current code was traced statically across enum/source mappings, dispatch detection/lowering/parsing, assembly, acquisition, emitter, live batch, live watcher reconciliation, revision backfill, completeness, fixtures, ordering tests, schema verification, schema sampling, and schema directories.

## Commands/checks run successfully

```text
python TESTS/verify_snapshot.py <snapshot-root> --report TESTS/baseline-report.json
```

Result: 19 checks passed, 0 failed. The report includes source hashes and evidence.

```text
git apply --check PATCHES/0001-docs-record-OriginSpec-dependency-seam.patch
git apply PATCHES/0001-docs-record-OriginSpec-dependency-seam.patch
git apply --check PATCHES/0002-tests-correct-executable-origin-fixture-scope.patch
git apply PATCHES/0002-tests-correct-executable-origin-fixture-scope.patch
git apply --check PATCHES/0003-tests-pin-OriginSpec-pilot-detector-precedence.patch
git apply PATCHES/0003-tests-pin-OriginSpec-pilot-detector-precedence.patch
git diff --check
python -m py_compile <patched test_origin_regression_pack.py> <patched test_dispatch_ordering.py>
git apply --reverse --check <patches>
```

Result: all passed. See `TESTS/PATCH-VERIFICATION.txt`.

The final ZIP was separately reopened, checked for duplicate/absolute/traversal paths, and every manifest size/SHA-256 was recomputed before delivery.

## What could not be run

The selected snapshot is not a complete Git worktree and contains no `.git` directory. It omits `pyproject.toml`, `polylogue/core/provider_identity.py`, the DeclarationSpec package, and other modules/dependencies required to import Polylogue. A direct project import/test attempt therefore cannot represent the repository’s real test environment. No claim is made that `pytest`, `devtools test`, `devtools render`, or `devtools verify` passed.

The pack contains 286 selected source files rather than the complete repository. Generated/public surface conclusions are complete only for included files plus the exact-revision provider identity file inspected externally. The full integration branch must repeat the census before implementation.

## Runtime and external systems not available

No operator live browser, browser extension, receiver, daemon, secrets, archive databases, networked provider account, NixOS deployment, or production file system was executed. No live ingest, parser corpus, schema render, daemon convergence, or archive reparse was performed.

## Static inference boundary

The Grok finding is a static control-flow inference: `_lower_payload_specs` has no Grok guard, unhandled providers reach fallback lowering, and `generic_messages` is parsed. The incomplete snapshot prevented executing `parse_payload(Provider.GROK, ...)`. The kernel pilot must add an executable regression in the full checkout before changing behavior.

## Patch scope

The included patches change one architecture document, one Python module docstring, and one existing detector-ordering test catalog. They do not add OriginSpec, change runtime code, alter public vocabulary, migrate an Origin, or claim acceptance of `2qx.1.1`/`2qx.1.2`. Patch 0003 does change test execution by adding two production-route characterization cases.
