# Patch series

Base assumption: revision `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`, with the supplied selected footprint clean. The source pack is not itself a Git worktree, so patch applicability was verified against a copied file tree using `git apply`.

Apply in this order:

```bash
git apply --check PATCHES/0001-docs-record-OriginSpec-dependency-seam.patch
git apply PATCHES/0001-docs-record-OriginSpec-dependency-seam.patch

git apply --check PATCHES/0002-tests-correct-executable-origin-fixture-scope.patch
git apply PATCHES/0002-tests-correct-executable-origin-fixture-scope.patch

git apply --check PATCHES/0003-tests-pin-OriginSpec-pilot-detector-precedence.patch
git apply PATCHES/0003-tests-pin-OriginSpec-pilot-detector-precedence.patch
```

## 0001 — document the dependency seam

Adds a durable section to `docs/provider-origin-identity.md` that records:

- DeclarationSpec → OriginSpec kernel → all-origin migration ordering;
- a partial-registry guard: pilot plans may parity-check but cannot replace production dispatch;
- detector precedence scoped by input context, including a self-contained Claude Code/ChatGPT pilot proof and the rule that different result Providers are not input disjointness;
- browser-envelope decoding as a shared pre-admission transform;
- physical-provider/acquisition-mode applicability and explicitly lossy reverse defaults;
- reserved Grok, fallback Unknown, and browser capture lifecycle/identity rules;
- the prohibition on a second generic registry before `polylogue-o21.1` lands.

This is documentation, not an OriginSpec implementation.

## 0002 — correct the regression-pack scope

Updates the module documentation in `tests/unit/sources/parsers/test_origin_regression_pack.py` so it accurately describes nine live direct-parser fixtures instead of claiming every supported Origin. It explicitly places reserved Grok and compatibility-fallback Unknown outside the direct-parser table and identifies browser capture as an acquisition mode that projects to an embedded provider Origin.

This patch changes no test execution or runtime behavior. Its purpose is to prevent the existing fixture table from being mistaken for the complete Origin inventory during the later migration.

## 0003 — pin pilot detector precedence on production dispatch

Adds two adversarial rows to the existing parameterized `detect_provider` catalog in `tests/unit/sources/test_dispatch_ordering.py`. The same ambiguous record contains Claude Code `sessionId` evidence and ChatGPT `mapping` evidence:

- as a single record, current production dispatch must select `Provider.CLAUDE_CODE`;
- as a one-record sequence, current production dispatch must select `Provider.CHATGPT`.

This is the executable golden for scope-specific precedence in the Claude Code/ChatGPT pilot. It deliberately avoids Codex references because Codex is not declared until `2qx.1.2`. It changes test execution only; no runtime code changes.

## Why there is no production OriginSpec patch

`polylogue-2qx.1.1` has a hard dependency on the absent DeclarationSpec kernel. A source-local substitute would violate the issue contract and the portfolio’s false-unification ruling. The exact production contract and ordered implementation plan are in `DESIGN/ORIGIN-SPEC-CONTRACT.md` and `DESIGN/IMPLEMENTATION-PLAN.md`.
