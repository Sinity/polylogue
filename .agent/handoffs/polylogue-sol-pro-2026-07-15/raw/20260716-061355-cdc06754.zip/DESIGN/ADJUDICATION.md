# Implementation-grade adjudication

## Decision

Do not implement `polylogue/sources/origin_specs.py` in this snapshot. The later, more specific Beads record for `polylogue-2qx.1.1` contains an explicit hard dependency on `polylogue-o21.1`, and `polylogue-o21.1` is absent from the supplied source footprint. Creating a local declaration base class, registry, derivation protocol, or diagnostic model here would duplicate the prerequisite and become throwaway architecture.

The correct deliverable at this revision is therefore design-first plus a truthful first patch series that can land without the prerequisite. The included three-patch series records the dependency seam in the existing identity document, corrects a regression-pack overclaim, and pins the pilot’s real record-versus-sequence detector inversion in the existing production-dispatch test catalog. It changes no parser, detector implementation, public token, or runtime behavior.

## Evidence hierarchy and supersession

The supplied context pack contains the umbrella record `polylogue-2qx.1`, but not the child records or the DeclarationSpec prerequisite. The exact repository revision is `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`. The complete Beads export at that revision was inspected from the official repository.

The records establish this sequence:

1. `polylogue-o21.1` owns a storage-free `polylogue/declarations` kernel and explicitly calls itself the executable prerequisite for `polylogue-2qx.1.1`.
2. `polylogue-2qx.1.1` requires `polylogue/sources/origin_specs.py` to consume `polylogue/declarations`; its dependency list contains `depends_on_id="polylogue-o21.1", type="blocks"`.
3. `polylogue-2qx.1.2` depends on `2qx.1.1` and owns the complete eleven-origin migration and deletion/parity-checking of parallel inventories.
4. A portfolio ruling states that OriginSpec, query declarations, maintenance declarations, and surface contracts share only the DeclarationSpec protocols; they must not be collapsed into a universal registry.

An older parent note that treated DeclarationSpec as merely related is superseded by the later child dependency edge, updated readiness notes, and the explicit prerequisite note on `o21.1`.

## What belongs to DeclarationSpec

`polylogue-o21.1` owns only generic declaration mechanics:

- declaration, family, output, handler, example, and completeness-edge models;
- the five-dimension compatibility key: identity, lifecycle, authority, access/result shape, and durability;
- deterministic registration and normalized derivation inputs independent of registration order;
- typed deriver protocols for names, contracts, schemas, docs, examples, discovery, and completeness;
- one source-locatable `Diagnostic` type carrying declaration id, owning path, missing edge/output/handler, and exact repair command;
- no source adapters, Origin semantics, parser dispatch, plugin loader, persistence, or universal runtime table.

OriginSpec must consume these types rather than recreate equivalents under `polylogue/sources`.

## What belongs to the OriginSpec kernel (`2qx.1.1`)

The reusable source-domain kernel owns:

- Origin lifecycle and admission semantics;
- acquisition/artifact modes;
- detector bindings and scope-specific precedence constraints;
- parser, stream-parser, and assembly bindings;
- Provider-to-Origin projection and non-injective collision policy;
- normalized construct capabilities;
- provenance/authority and known fidelity loss;
- coverage expectations and fixture references;
- semantic-reparse consequences;
- derivation or parity validation of dispatch, public vocabulary, completeness, fixtures, docs, and generated surfaces;
- representative production proof for Claude Code, ChatGPT export, and reserved Grok;
- actionable Origin-specific validations populated into the generic DeclarationSpec `Diagnostic`.

Actual detector/parser/assembly functions stay in their current adapter modules.

## What belongs to current-origin migration (`2qx.1.2`)

Migration owns the complete eleven-token adoption and removal of duplicate inventories. It is not part of the reusable kernel proof. It must:

- declare every current Origin exactly once;
- preserve recursive lowering, bundle/grouped/stream/browser/Drive behavior;
- replace or mechanically parity-check the manual provider-mode and fixture/schema/docs inventories;
- encode Beads as non-chat, Grok as reserved, Unknown as compatibility fallback, and AISTUDIO as a many-to-one Provider projection;
- delete parallel central lists only after parity passes;
- expose Claude/Codex extension hooks to follow-on work without another admission registry.

## Source-supported current findings

### Detector ordering is context-scoped

`polylogue/sources/dispatch.py:135-168` checks Codex before Claude Code for a single record, while `dispatch.py:171-192` checks Claude Code before Codex for a sequence. The three selected pilots expose the same need without referencing undeclared Codex state: Claude Code precedes ChatGPT for records, while ChatGPT precedes Claude Code for sequences. A single total ordering of Origin values cannot preserve either inversion. Ordering must therefore be computed per detector scope and shared input-side admission context; different result Providers do not prove two detectors disjoint. Raw-prefix, path-sample, and ZIP-entry detection require their own contexts. Browser-envelope decoding is a shared pre-admission transform, not an Origin detector node.

### Current inventories are parallel and incomplete

The snapshot contains manual provider sets in `dispatch.py`, a manual assembly switch in `assembly.py`, nine handwritten package-mode rows in `provider_completeness.py`, nine direct-parser fixture rows in `test_origin_regression_pack.py`, and a separate reverse mapping in `schemas/validation/corpus.py`. Their scopes differ and they already drift:

- provider completeness omits Beads and Grok;
- the direct-parser fixture table omits Grok and Unknown;
- schema verification omits Beads and Grok;
- browser capture is keyed as `UNKNOWN_EXPORT` even though its own caveat says the embedded session projects to a provider-specific Origin;
- AISTUDIO reverse choices differ (`Provider.GEMINI` as core’s explicitly lossy compatibility default, `Provider.DRIVE` in schema verification);
- `schemas/sampling_db.py` and `sources/live/watcher.py` reconstruct provider-wire identity from Origin without disambiguating evidence, so AISTUDIO silently becomes Gemini there;
- the selected schema directories have no Beads, Grok, or Unknown package.

These are migration inputs, not justification for a second pre-prerequisite registry.

### Grok has an unresolved behavior conflict

The target contract says `grok-export` is reserved with no parser. Current dispatch has no Grok detector or dedicated parser, but `_lower_payload_specs` sends unhandled providers to `_lower_fallback_payload`, and `_parse_lowered_spec` parses `generic_messages`. Consequently, an explicit `Provider.GROK` hint plus a `messages` list reaches the generic parser statically.

This must be decided explicitly in the kernel pilot. Recommended target: reserved Grok rejects parser admission, including generic fallback. That is a behavior change and needs a focused regression and release note; it must not be smuggled into a manual pre-kernel branch.

### AISTUDIO requires provider-fiber-aware assembly

`Provider.GEMINI` and `Provider.DRIVE` both map to `Origin.AISTUDIO_DRIVE`, but `get_assembly_spec` returns Gemini assembly only for `Provider.GEMINI`. OriginSpec cannot replace the assembly switch with a single unqualified Origin-level handler. Parser and assembly bindings require explicit physical-provider and acquisition-mode applicability, while any core reverse default remains a named lossy compatibility bridge rather than semantic handler selection.

## Facts, inferences, and proposals

Facts in this handoff are directly supported by the supplied files or exact-revision Beads records. Inferences are called out where static control flow implies behavior that could not be executed because the selected snapshot is incomplete. Proposals—type signatures, diagnostic codes, ordering law, and patch sequence—are implementation recommendations to apply after `o21.1` lands.

## Immediate patch verdict

Apply all three included patches if the branch still matches the base files:

1. record the ordered DeclarationSpec → OriginSpec kernel → all-origin migration boundary in `docs/provider-origin-identity.md`;
2. correct the test module’s claim from “every supported origin” to the nine origins with live direct-parser fixtures, explicitly separating reserved Grok, fallback Unknown, and browser capture as an acquisition mode;
3. add the ambiguity payload to the existing production dispatch catalog in both record and sequence forms, pinning Claude Code-before-ChatGPT for records and ChatGPT-before-Claude Code for sequences.

Do not treat these patches as satisfying `2qx.1.1` or `2qx.1.2`. They are a reviewable, non-placeholder precondition that prevents the current source map and regression pack from teaching the wrong architecture while the hard prerequisite is outstanding. The third patch is executable characterization, not an OriginSpec substitute.
