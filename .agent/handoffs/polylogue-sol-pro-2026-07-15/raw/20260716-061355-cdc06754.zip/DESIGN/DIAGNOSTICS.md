# Actionable OriginSpec diagnostics

OriginSpec validation must populate the generic `polylogue.declarations.validation.Diagnostic`; it must not define a competing diagnostic class.

## Required fields from the DeclarationSpec seam

Every Origin diagnostic needs:

```text
code
declaration_id
message
owner_path
source_line (when available)
missing edge/output/handler identifier (as applicable)
repair_command
structured details
```

The repair command is a real command registered with the implementation, not prose such as “add a parser.” Recommended command surface:

```bash
devtools origin-specs check [--origin TOKEN] [--explain]
devtools origin-specs render --check
devtools origin-specs render --write
```

Focused pytest commands may be emitted for fixture-specific repairs.

## Required codes and repair behavior

| Code | Condition | Minimum details | Example repair command |
|---|---|---|---|
| `ORIGIN_MISSING_PARSER` | executable acquisition mode has no parser | origin, mode, owner path, expected protocol | `devtools origin-specs check --origin claude-code-session --explain` |
| `ORIGIN_STREAM_PARSER_CONFLICT` | stream and non-stream handlers can both claim one mode without selector | both binding IDs and mode | `devtools test tests/unit/sources/test_origin_spec_diagnostics.py -k stream_parser_conflict` |
| `ORIGIN_DETECTOR_AMBIGUOUS` | potentially overlapping same-scope detectors have no path order | scope, both IDs, missing edge | `devtools origin-specs check --origin claude-code-session --explain` |
| `ORIGIN_DETECTOR_CYCLE` | before/after graph cycles | ordered cycle path and owner paths | `devtools test tests/unit/sources/test_origin_spec_ordering.py -k cycle` |
| `ORIGIN_DETECTOR_REFERENCE_MISSING` | constraint names absent or cross-scope binding | source binding, target ID, scopes | `devtools origin-specs check --explain` |
| `ORIGIN_DISJOINTNESS_UNPROVEN` | incomparable pair claims disjointness without negative fixture | both IDs, required fixture edge | `devtools test tests/unit/sources/test_origin_spec_ordering.py -k disjoint` |
| `ORIGIN_DECLARATION_REFERENCE_MISSING` | source mode/binding references absent generic example or completeness edge | declaration id, reference id, source field | `devtools origin-specs check --origin <token> --explain` |
| `ORIGIN_ADMISSION_POLICY_INVALID` | lifecycle/mode policy is inconsistent, lacks reason, or lacks required pre-admission transform | lifecycle, mode, policy, missing field | `devtools origin-specs check --origin <token> --explain` |
| `ORIGIN_PRE_ADMISSION_CONFLICT` | the same shared envelope-transform binding ID has conflicting metadata or ordering | binding id, owner paths, normalized definitions | `devtools test tests/unit/sources/test_origin_spec_ordering.py -k pre_admission` |
| `ORIGIN_FIXTURE_MISSING` | detector/parser/acquisition mode lacks fixture | mode/binding and required fixture role | `devtools test tests/unit/sources/test_origin_specs.py -k <origin>` |
| `ORIGIN_COVERAGE_UNDECLARED` | claimed normalized construct has no coverage expectation | construct, owner path | `devtools origin-specs check --origin <token> --explain` |
| `ORIGIN_BINDING_APPLICABILITY_INVALID` | detector has empty/unknown input context or handler names an unknown mode/provider | binding id, context/mode/provider, owning Origin fiber | `devtools origin-specs check --origin <token> --explain` |
| `ORIGIN_DETECTOR_RESULT_PROVIDER_INVALID` | detector result Provider is outside the owning Origin fiber | binding id, result Provider, expected fiber | `devtools origin-specs check --origin <token> --explain` |
| `ORIGIN_PROVIDER_LEAK` | public derived schema/help/error emits Provider token | output ID, token, expected Origin | `devtools origin-specs render --check` |
| `ORIGIN_PROVIDER_COLLISION_POLICY_MISSING` | multiple physical Providers without many-to-one policy | provider fiber, disambiguation evidence, and any explicitly lossy compatibility default | `devtools test tests/unit/sources/test_origin_specs.py -k aistudio` |
| `ORIGIN_PROVIDER_FIBER_HANDLER_GAP` | parser/assembly applicability omits a fiber member without explicit mode restriction | provider, handler, acquisition mode | `devtools origin-specs check --origin aistudio-drive --explain` |
| `ORIGIN_RESERVED_HAS_HANDLER` | reserved origin declares or inherits detector/parser/assembly | lifecycle, offending binding | `devtools test tests/unit/sources/test_origin_specs.py -k grok` |
| `ORIGIN_FALLBACK_HAS_POSITIVE_DETECTOR` | compatibility fallback can win positive detection | fallback and detector IDs | `devtools test tests/unit/sources/test_origin_spec_ordering.py -k unknown` |
| `ORIGIN_ENUM_DRIFT` | complete migration registry differs from `tuple(Origin)` in membership, uniqueness, or order | missing, extra, duplicate, and out-of-order tokens | `devtools origin-specs render --check` |
| `ORIGIN_RUNTIME_PLAN_INCOMPLETE` | a partial registry is offered for production dispatch/parser/assembly installation | covered/missing Origins and requested plan | `devtools origin-specs check --explain` |
| `ORIGIN_SURFACE_DRIFT` | derived dispatch/completeness/fixture/docs/public projection differs | output ID, expected/actual digest, owner path | `devtools origin-specs render --check` |
| `ORIGIN_REPARSE_UNDECLARED` | behavior/normalized output changes without consequence | changed binding/output and affected Origin | `devtools origin-specs check --origin <token> --explain` |

## Example diagnostics

### Missing parser

```text
ORIGIN_MISSING_PARSER
origin:claude-code-session
acquisition mode grouped-jsonl declares parser mode grouped-records but no
HandlerBinding is present.
owner: polylogue/sources/origin_specs.py:<line>
missing_handler: origin:claude-code-session:parse:grouped-records
repair: devtools origin-specs check --origin claude-code-session --explain
```

### Ambiguous detector order

```text
ORIGIN_DETECTOR_AMBIGUOUS
scope=record
origin:codex-session:detect:record:codex.looks_like and
origin:claude-code-session:detect:record:claude.looks_like_code can overlap, but
neither is reachable before the other and no proven disjointness fixture exists.
owners: polylogue/sources/origin_specs.py:<lines>
repair: devtools test tests/unit/sources/test_origin_spec_ordering.py -k codex_claude_record
```

### Partial runtime installation

```text
ORIGIN_RUNTIME_PLAN_INCOMPLETE
production detector installation requires exact Origin coverage; pilot registry
covers claude-code-session, chatgpt-export, and grok-export and is missing eight
current tokens.
owner: polylogue/sources/origin_specs.py:<lines>
repair: devtools origin-specs check --explain
```

### Grok reserved violation

```text
ORIGIN_RESERVED_HAS_HANDLER
origin:grok-export is reserved but compatibility fallback resolves a
`generic_messages` parser for Provider.GROK.
owner: polylogue/sources/dispatch.py:629-832
repair: devtools test tests/unit/sources/test_origin_specs.py -k grok_reserved
```

### AISTUDIO collision gap

```text
ORIGIN_PROVIDER_FIBER_HANDLER_GAP
origin:aistudio-drive declares physical providers gemini and drive, but assembly
binding applies to gemini only and has no acquisition-mode restriction or
intentional-absence edge for drive.
owner: polylogue/sources/assembly.py:68-82
repair: devtools test tests/unit/sources/test_origin_specs.py -k aistudio_assembly
```

## Diagnostic stability law

Diagnostics sort by `(declaration_id, code, owner_path, missing-edge-or-handler)` and contain stable binding/output IDs. Registration order, object addresses, callable representations, and filesystem absolute paths must not affect output. This makes mutation tests and generated reports byte-equivalent.
