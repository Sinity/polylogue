# Ordered implementation plan

## Phase 0 — land and verify DeclarationSpec (`polylogue-o21.1`)

Required files from the prerequisite:

```text
polylogue/declarations/models.py
polylogue/declarations/registry.py
polylogue/declarations/derive.py
polylogue/declarations/validation.py
```

Required proof before OriginSpec work begins:

- storage-free imports and no dependency on sources/MCP/storage/insights/maintenance;
- five-dimension compatibility equality and actionable difference diagnostics;
- deterministic normalized output under shuffled registration;
- source-locatable diagnostics with exact repair command;
- real MCP pilot consumes the kernel without moving MCP semantics into it;
- focused tests and `devtools verify --quick` pass.

Do not begin Phase 1 by copying provisional o21 types into `sources`.

## Phase 1 — rebase and repeat the full-repository census

The supplied pack is targeted. On the integration branch:

1. verify HEAD/base and inspect dirty state;
2. read the latest Beads notes again;
3. rerun the grep commands in `CURRENT-SURFACE-CENSUS.md` over the full tree;
4. classify every discovered list as authoritative domain declaration, derived consumer, parity check, or unrelated Provider inventory;
5. record any conflict with concurrent DeclarationSpec changes before editing.

Apply the three included pre-prerequisite patches first if they are not already present.

## Phase 2 — add the three-pilot OriginSpec kernel (`2qx.1.1`)

Add:

```text
polylogue/sources/origin_specs.py

tests/unit/sources/test_origin_specs.py
tests/unit/sources/test_origin_spec_ordering.py
tests/unit/sources/test_origin_spec_diagnostics.py
tests/unit/sources/test_origin_spec_derivations.py
```

Because adding a module under `polylogue/` changes topology projection, also run and commit the existing generated topology updates required by repository instructions:

```bash
devtools render topology-projection
devtools render topology-status
```

Implement in this order:

1. source-domain enums/data classes wrapping DeclarationSpec types;
2. immutable Origin registry, derived token index/coverage, and stable HandlerBinding resolution;
3. lifecycle/admission-policy, cross-reference, provider-fiber, input-context, and handler-applicability validation;
4. shared pre-admission transform normalization for browser envelopes;
5. scoped/input-context detector graph derivation that assumes same-context competition regardless of result Provider;
6. parser/stream/assembly plan derivation with explicit selection predicates for overlapping modes;
7. computed runtime-completeness guard that refuses partial runtime installation;
8. fixture/completeness/public-output typed derivations by reference to generic DeclarationSpec examples/edges;
9. Claude Code declaration;
10. ChatGPT declaration, including browser-envelope acquisition projection;
11. reserved Grok declaration and named negative fallback correction test;
12. source-locatable mutation diagnostics.

Do not add the remaining eight origins in this phase.

## Phase 3 — connect pilot derivations to real runtime paths

Prefer derived registration where the current function can consume a typed plan without widening scope. Otherwise add an exact parity check first.

Primary anchors:

- `polylogue/sources/dispatch.py:38-41`, `:135-202`, `:629-739`, `:774-876`;
- `polylogue/sources/assembly.py:68-82`;
- `polylogue/sources/source_acquisition_components.py:424-478`;
- `polylogue/sources/source_parsing.py:108-188`;
- `polylogue/sources/emitter.py:202-243`, `:382-419`;
- `polylogue/sources/live/batch.py:1638-1670`, `:1902-1915`;
- `polylogue/sources/revision_backfill.py:322-334`.

Safe pilot strategy:

- derive record and sequence detector subplans for the three pilot Origins; pin Claude Code before ChatGPT for records and ChatGPT before Claude Code for sequences with combined real-route ambiguity fixtures, and prove different result Providers do not exempt the pair from ordering;
- parity-check browser-envelope decoding as a shared pre-admission transform that retains embedded Provider evidence rather than an Origin detector;
- derive parser/stream/assembly bindings and assert current runtime switches contain exactly the pilot bindings with matching provider/mode applicability and any required selection predicate;
- derive pilot fixture/completeness/docs/public-output inputs and parity-check only pilot rows/tokens;
- assert `runtime_complete is False` and prove the installation path rejects the partial registry;
- keep non-pilot current branches untouched until `2qx.1.2`.

The anti-vacuity test must remove a real pilot handler/declaration and produce the expected diagnostic—not merely validate synthetic declarations.

## Phase 4 — migrate every current Origin (`2qx.1.2`)

Add the remaining eight declarations according to `MIGRATION-MATRIX.md`. For each commit:

1. declare all actual acquisition modes and physical providers;
2. add or reference real fixtures;
3. run detector/parser/assembly parity for that Origin;
4. add coverage and public-output parity;
5. preserve current behavior unless a named decision gate authorizes a correction;
6. do not delete the old inventory yet.

After all eleven are present, enforce:

```text
set(spec.origin for spec in ORIGIN_SPECS) == set(Origin)
len(ORIGIN_SPECS) == len(Origin) == 11
```

and preserve the exact required normalized order.

## Phase 5 — retire parallel inventories after parity

Replace or delete, in this order:

1. detector branches/order tables in `sources/dispatch.py`;
2. parser/stream provider switches and `BUNDLE/GROUP/STREAM/DRIVE_LIKE` sets;
3. Provider assembly switch in `sources/assembly.py`;
4. handwritten `PACKAGE_MODE_SPECS` in `sources/provider_completeness.py`;
5. fixture census duplication in `test_origin_regression_pack.py` and related tests;
6. `_PROVIDER_BY_ORIGIN` in `schemas/validation/corpus.py`, replacing it with an acquisition-mode-aware projection;
7. lossy reverse consumers in `schemas/sampling_db.py` and `sources/live/watcher.py`, retaining or supplying physical-provider/acquisition evidence instead of silently defaulting AISTUDIO to Gemini;
8. public schema/error/completion/help/docs lists found by the full-tree census;
9. copied JSONL/schema-provider lists where they are genuinely Origin-derived.

Each deletion commit must have a mutation test proving the derived owner is live. Do not delete Provider-wire schema inventories that represent a distinct raw-schema concern; instead bind them as evidence/output edges.

## Phase 6 — generated surfaces and verification

Run the project’s normal render and verify gates, including at minimum:

```bash
devtools render all --check
devtools test tests/unit/sources/test_origin_specs.py
devtools test tests/unit/sources/test_origin_spec_ordering.py
devtools test tests/unit/sources/test_origin_spec_diagnostics.py
devtools test tests/unit/sources/test_dispatch_ordering.py
devtools test tests/unit/sources/parsers/test_origin_regression_pack.py
devtools test tests/unit/sources/test_provider_completeness.py
devtools test tests/unit/sources/test_provider_contracts.py
devtools verify --quick
```

Then run targeted bundle, grouped JSONL, stream, browser-capture, Drive, Hermes, Antigravity, acquisition, live-batch, and revision-backfill tests identified in `TESTS/TEST-MATRIX.md`.

## Phase 7 — unblock follow-on source semantics

Only after all-origin migration and duplicate-inventory deletion should Claude orchestration, Codex child-call semantics, or new origin adapters consume OriginSpec extension hooks. They must add one OriginSpec or extend an existing declaration plus owning adapter/fixtures, never introduce a private admission registry.

## Commit/patch shape recommendation

1. DeclarationSpec prerequisite (separate branch/series).
2. OriginSpec types/registry/laws with synthetic tests.
3. Claude Code pilot and parity.
4. ChatGPT pilot and parity.
5. reserved Grok pilot and explicit fallback decision.
6. kernel mutation diagnostics and generated topology.
7. Codex + ordering pair.
8. Beads.
9. AISTUDIO/provider fiber.
10. Hermes/Antigravity.
11. Gemini CLI/Claude AI.
12. Unknown fallback.
13. all-eleven completeness gate.
14. derived runtime/completeness/schema/fixture/docs surfaces.
15. deletion of obsolete inventories and final render/verify receipts.

This shape keeps `2qx.1.1` reviewable and executable without hiding the larger `2qx.1.2` migration inside it.
