# Eleven-origin migration matrix

This matrix is the ordered worklist for `polylogue-2qx.1.2`, after the three-pilot kernel is proven. “Current” describes the supplied snapshot; “target” describes OriginSpec.

| Origin | Physical Provider fiber | Target lifecycle | Current detector/parser/assembly | Current coverage gaps | Required migration declaration |
|---|---|---|---|---|---|
| `claude-code-session` | Claude Code | executable | Record and sequence detectors; grouped JSONL and stream parsers; Claude assembly with session-index/history sidecars | Dispatch, stream set, group set, assembly, fixtures, completeness all separate | All JSONL/raw-prefix/group/stream/sidecar modes; pilot record-before-ChatGPT and sequence-after-ChatGPT constraints; add record-after-Codex/sequence-before-Codex when Codex migrates; provider/mode-qualified assembly; provenance/fidelity/coverage; semantic reparse |
| `codex-session` | Codex | executable | Record and sequence detectors; grouped JSONL and stream parser; Codex assembly | Same parallel inventories; JSONL list also copied in provider-contract test | All JSONL/group/stream modes; inverse scoped Claude constraints; assembly; fixtures and semantic reparse |
| `gemini-cli-session` | Gemini CLI | executable | Record detector in `local_agent`; local-agent document parser; no assembly | No sequence detector; completeness has one mode | Local-agent acquisition/document mode; detector/parser binding; fixture, authority, fidelity, coverage, reparse |
| `hermes-session` | Hermes | executable | State DB, ATIF, and local-agent detectors/parsers; path-aware source handling; no assembly | Completeness lists only state DB; multiple modes split across modules | State DB, ATIF, and local document modes separately; path/sample bindings; all fixtures and degraded/fidelity consequences |
| `antigravity-session` | Antigravity | executable | Markdown export and brain-metadata detectors; path/session special case; local-artifact parser | Completeness represents language-server export but not every actual artifact path | Markdown, brain metadata, language-server/session-directory modes; degraded flag/fidelity; fixtures and reparse |
| `beads-issue` | Beads | executable, non-chat | Record/sequence detector; grouped and stream parse; no assembly | Omitted from provider completeness and schema reverse map/schema dirs | Explicit non-chat constructs and provenance; grouped/stream modes; no chat-only completeness assumptions; fixtures and semantic reparse |
| `grok-export` | Grok | reserved | No positive detector/dedicated parser; explicit hint currently reaches generic-message fallback; no assembly | Omitted fixtures/completeness/schema dir while official schema-provider inventory includes it | Reserved reason; no detector/parser/stream/assembly; negative fallback fixture; public vocabulary only until separate admission |
| `chatgpt-export` | ChatGPT | executable | Mapping detector in record/sequence; document/bundle/sessions-wrapper parser; browser envelope projects to ChatGPT; no assembly | Browser capture represented as Unknown completeness row | Takeout document/bundle/wrapper/browser-envelope acquisition; parser binding; fixtures; no synthetic browser Origin |
| `claude-ai-export` | Claude AI | executable | `chat_messages`/design-chat detector; document/bundle parser; no assembly | Separate bundle set and completeness row | Export document/bundle modes; detector/parser; attachment/fidelity capabilities; fixtures and reparse |
| `aistudio-drive` | Gemini + Drive | executable | Gemini mapping detector; Drive-like lowering/parser for both; assembly only for Gemini; schema reverse chooses Drive; core/sampling/watcher reverse defaults choose Gemini | Non-injective projections differ; fixture uses Drive while detected provider may be Gemini; sampling and cursor reconciliation lose physical identity | `many-to-one` collision policy; both physical providers; disambiguation via retained capture/source-family evidence; explicitly lossy compatibility default only for legacy bridges; provider/mode-qualified parser and assembly; migrate schema sampling/watcher projections; parity tests |
| `unknown-export` | Unknown | compatibility-only | No positive detector; generic-message fallback for explicit/fallback Provider; no assembly | No direct fixture/schema; browser row falsely uses it as transport identity | Last-resort fallback binding only; no positive detector/executable completeness; negative detector-theft fixtures; declared fidelity loss and semantic-reparse policy |

## Migration order

Use detector/admission risk rather than enum order for implementation commits, while the final registry order remains the exact eleven-token order required by the Bead.

1. Prove kernel on Claude Code, ChatGPT, Grok.
2. Add Codex immediately to complete the adversarial Claude/Codex ordering pair.
3. Add Beads to prove non-chat grouped/stream behavior.
4. Add AISTUDIO to prove many-to-one projection and mode-dependent assembly.
5. Add Hermes and Antigravity to prove local artifacts/path-aware modes and fidelity/degraded state.
6. Add Gemini CLI and Claude AI as simpler executable modes.
7. Add Unknown last as compatibility fallback, after every positive detector is represented.
8. Run exact enum/registry completeness and delete parallel inventories only after all parity gates pass.

## Decision gates before changing behavior

### Grok

Recommended: explicit Grok plus generic `messages` returns no parsed sessions (or a typed reserved-origin result at a higher boundary). Record this as an intentional correction, not “behavior-preserving migration.”

### AISTUDIO assembly

Decide whether Drive-acquired AISTUDIO sessions require Gemini assembly. If yes, extend assembly behavior with a fixture before deriving by Origin. If no, bind assembly to the Gemini physical provider/acquisition mode only.

### Reserved schema visibility

Decide whether Grok remains in schema-provider selection while no schema package exists. The derived public Origin vocabulary may include a reserved token without advertising a usable raw schema.
