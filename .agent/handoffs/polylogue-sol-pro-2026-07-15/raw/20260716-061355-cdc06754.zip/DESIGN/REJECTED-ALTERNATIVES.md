# Rejected alternatives

## Reimplement DeclarationSpec inside `sources`

Rejected because `polylogue-2qx.1.1` is explicitly blocked by `polylogue-o21.1` and must consume it. A local base class, registry, derivation protocol, or Diagnostic would create the second generic kernel the portfolio ruling forbids.

## Add an `origin_specs.py` placeholder with empty or partial generic types

Rejected as fake progress. It would either duplicate unknown final prerequisite APIs or contain no executable pilot/conformance law. The first production OriginSpec patch should compile against the landed DeclarationSpec and prove real adapters.

## Migrate all eleven origins before proving the kernel

Rejected because it mixes mechanism proof with inventory migration, makes review and mutation testing diffuse, and violates the explicit `2qx.1.1`/`2qx.1.2` split. The kernel should prove three structurally different pilots first.

## Use one global detector rank per Origin

Rejected because current record detection orders Codex before Claude Code while sequence detection orders Claude Code before Codex. One global rank necessarily changes at least one behavior.

## Preserve behavior with lexical tie-breaking

Rejected because lexical order would hide an ambiguous semantic pair. Stable IDs may order only bindings declared and proven disjoint; overlapping detectors require an explicit edge.

## Treat Provider and Origin as one injective enum

Rejected because Gemini and Drive both map to AISTUDIO. Provider remains physical/wire identity in adapters and schemas; Origin remains public source identity. Collision policy and disambiguation must be explicit.

## Key browser capture to `unknown-export`

Rejected as a domain model. Browser capture is an acquisition/transport mode; the embedded session projects to ChatGPT or another provider-specific Origin. The current completeness row is migration evidence, not the desired identity.

## Treat Unknown as an ordinary executable origin

Rejected because Unknown has no positive detector and represents compatibility fallback. Counting generic fallback as executable completeness would conceal unsupported material and detector theft.

## Silently add a manual Grok guard now

Rejected for this pre-prerequisite patch. It would alter behavior through another hand-maintained branch and obscure the current contradiction. The reserved Grok pilot must make the behavior correction explicit, with a real negative fixture and release/adjudication note.

## Preserve explicit Grok generic-message parsing as compatibility

Rejected as the recommended target because the Bead explicitly requires Grok reserved with no parser. Retaining it would make lifecycle declarations non-authoritative. If operators intentionally rely on the fallback, that evidence must change the Bead or introduce a compatibility-only mode rather than being assumed.

## Derive every Provider/schema inventory from OriginSpec

Rejected because some Provider inventories are legitimate raw-schema or acquisition concerns. OriginSpec should bind them as outputs/evidence and derive only the public/admission projections. Distinct schema-provider semantics must not be erased.

## Put adapter callables directly in DeclarationSpec

Rejected because deterministic derivation cannot depend on callable object identity or import source adapters into the generic kernel. Use stable HandlerBinding metadata and resolve functions in the source domain/runtime.

## Add persistence or a dynamic plugin loader

Rejected by `o21.1` and unnecessary for current local source admission. The registry is an in-process, storage-free declaration set; durability/reparse is declared semantics, not registry storage.
