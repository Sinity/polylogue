# Exact-revision Beads dependency evidence

Source: the complete official `.beads/issues.jsonl` at revision `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`, accessed 2026-07-16. The supplied targeted pack contained only the umbrella record, so these child/prerequisite records were recovered from the immutable upstream revision named by the pack.

## `polylogue-o21.1` — DeclarationSpec prerequisite

Title: **Land the DeclarationSpec kernel and derivation contract**.

Controlling contract:

- add storage-free `polylogue/declarations/models.py`, `registry.py`, `derive.py`, and `validation.py`;
- generic models include `DeclarationSpec`, `FamilySpec`, `OutputSpec`, `HandlerBinding`, `ExampleSpec`, and `CompletenessEdge`;
- compatibility requires equality across identity, lifecycle, authority, access/result shape, and durability;
- derivation returns deterministic typed inputs with source provenance and byte-equivalent normalized output under shuffled registration;
- validation returns source-locatable diagnostics with declaration id, missing edge/output/handler, owner path, and exact repair command;
- MCP is the first real pilot, while MCP owns its domain semantics;
- no imports from sources/MCP/storage/insights/maintenance into the generic package;
- no universal runtime table, dynamic plugin loader, persistence layer, or migration of every existing registry.

Its later note names this record as the executable prerequisite for `polylogue-2qx.1.1` and reiterates that it is a derivation protocol, not a universal registry or storage system.

## `polylogue-2qx.1.1` — OriginSpec admission kernel

Title: **Land the OriginSpec admission kernel and conformance law**.

Hard dependency metadata:

```text
issue_id      = polylogue-2qx.1.1
depends_on_id = polylogue-o21.1
type          = blocks
created_at    = 2026-07-15T20:55:22Z
```

Controlling contract:

- add `polylogue/sources/origin_specs.py` as the sole typed Origin-domain registry over `polylogue/declarations`;
- declare lifecycle, acquisition/artifact modes, detector tightness, parser/stream/assembly entry points, physical/public projection and collision policy, constructs, authority/provenance, fidelity loss, coverage, fixtures, and reparse consequence;
- leave actual detector/parser/assembly implementations in current source adapters;
- derive or validate dispatch order, parser registration, enum/public vocabulary, completeness, fixtures, and generated documentation;
- pilot Claude Code (streaming/JSONL plus sidecars), ChatGPT (document/bundle), and Grok (reserved);
- require deterministic ordering and actionable diagnostics for missing handlers/fixtures/coverage, stream conflicts, ambiguity/cycles, Provider leaks, and non-injective projection;
- do not absorb provider-specific record semantics or treat Provider and Origin as injective equivalents.

The latest readiness note fixes `origin_specs.py` as the domain registry, names the three pilots, preserves adapter ownership/detector tightness, and makes non-injective Provider-to-Origin projection an explicit law.

## `polylogue-2qx.1.2` — current-origin migration

Title: **Migrate every current origin onto OriginSpec**.

Hard dependency metadata:

```text
issue_id      = polylogue-2qx.1.2
depends_on_id = polylogue-2qx.1.1
type          = blocks
created_at    = 2026-07-15T20:55:23Z
```

Controlling contract:

- migrate exactly eleven current tokens, once each and in the named enum order;
- declare every actual acquisition mode and detector/parser/assembly/identity/construct/provenance/fidelity/coverage/fixture/reparse field;
- preserve dispatch tightness and recursive lowering for ambiguous records, bundles, grouped JSONL, streams, browser captures, and Drive documents;
- derive or mechanically parity-check provider completeness, public schemas/errors/completions, fixture census, and docs;
- delete parallel hand-maintained inventories only after parity;
- reserve Grok with no parser, model Unknown as fallback rather than executable completeness, and make Beads explicitly non-chat;
- model AISTUDIO’s non-injective physical-provider projection explicitly;
- expose Claude/Codex extension hooks without another admission registry.

## Supersession ruling

The umbrella record originally separated kernel and migration but did not itself carry the later hard edge. The more specific child metadata and later readiness notes control execution order: `o21.1` first, then `2qx.1.1`, then `2qx.1.2`.

A portfolio note dated 2026-07-15 separately rejects false unification: OriginSpec, executable query declarations, MaintenanceTargetSpec, and surface contracts consume the shared declaration/generation/completeness protocols but are not one generic registry. Their identity, authority, lifecycle, access/result shape, and durability/reparse semantics differ.

## Implementation consequence

A production `origin_specs.py` patch against this snapshot would have to invent the absent generic models/registry/derivation/diagnostic contract. That would violate both the explicit blocking edge and the false-unification ruling. The safe pre-prerequisite patch may document/correct current architecture facts, but executable OriginSpec work begins only against the landed `polylogue.declarations` API.
