# Deterministic detector ordering without a false global order

## Existing orders

### Record scope (`dispatch.py:135-168`)

1. browser capture envelope → embedded provider
2. Gemini CLI local-agent document
3. Hermes state DB payload
4. Hermes ATIF payload
5. Hermes local-agent document
6. Antigravity markdown export
7. Antigravity brain metadata
8. Beads record
9. Codex record
10. Claude Code record
11. ChatGPT mapping
12. Claude AI document
13. Gemini/Drive mapping

### Sequence scope (`dispatch.py:171-192`)

1. browser capture envelope → embedded provider
2. Beads first record
3. ChatGPT mapping
4. Claude AI `chat_messages`
5. Gemini/Drive mapping
6. Claude Code sequence
7. Codex sequence

The Codex/Claude relative order is inverted. This is not accidental noise: the existing adversarial tests pin both outcomes. Therefore an Origin-level rank or a single detector list cannot preserve current semantics.

## Required model

Detector precedence belongs to a `DetectorBinding` in a `DetectorScope` and stable input-side admission context. One Origin may have several detector bindings with different constraints. A binding also declares its fixed result Provider, but that output identity is never used to infer input disjointness.

Recommended stable IDs:

```text
origin:<origin-token>:detect:<scope>:<adapter-symbol>
```

Examples:

```text
origin:claude-code-session:detect:record:claude.looks_like_code
origin:claude-code-session:detect:sequence:claude.looks_like_code
origin:chatgpt-export:detect:record:chatgpt.looks_like
origin:chatgpt-export:detect:sequence:chatgpt.looks_like
```

The three-pilot registry must constrain only bindings it owns:

```text
record:   claude-code before chatgpt
sequence: chatgpt before claude-code
```

A combined payload carrying Claude Code record keys and a ChatGPT `mapping`
object exercises both handlers and preserves the current winner in each scope.
Codex is added in `2qx.1.2`; that commit adds the independently observed
Codex/Claude inversion rather than leaving dangling edges to an undeclared
binding in the pilot registry.

## Derivation algorithm

For each `(scope, admission_context_id)` independently:

1. Select bindings naming that input context. Context IDs are global input vocabulary such as `json-record` or `json-sequence`, not Origin-local mode names or Provider values.
2. Validate non-empty applicability, fixed result Provider membership in the owning Origin fiber, and every `before`/`after` reference. Cross-scope or cross-context references are invalid.
3. Build a directed graph and reject self-edges and cycles.
4. Treat every pair in the same input context as potentially overlapping by default. Different output Providers, different owning Origins, or different parser modes do not prove detector disjointness.
5. Require every pair to be ordered by a path. A pair is exempt only when both sides declare reciprocal disjointness and a negative ambiguity fixture proves the input domains cannot overlap.
6. Topologically sort. When several ready nodes are proven disjoint, sort by stable binding ID for byte-equivalent output under shuffled registration.
7. Emit an immutable plan containing binding IDs, handler bindings, result Providers, input applicability, scope/context, and source provenance.
8. Runtime dispatch resolves handler bindings from adapter modules and returns the first match.

Lexical sorting must never silently decide an overlapping pair. It is only a deterministic serialization rule after semantic disjointness has been proven. In particular, Claude Code and ChatGPT must remain order-constrained even though their detectors return different Providers.

## Contexts beyond record and sequence

Current production paths imply additional scopes or acquisition selectors:

- raw-prefix detection over a decoded document or a bounded JSONL prefix;
- path-sample detection used by live ingestion;
- ZIP-entry hints/preservation;
- local-artifact path checks for Hermes and Antigravity.

Browser capture is different: its envelope decoder runs as a declared pre-admission transform, retains the embedded Provider, and then projects to that Provider's public Origin. It is not an Origin detector and does not create a browser Origin. The admission plan must preserve its current first-prelude behavior and deduplicate shared transform references by stable binding ID.

These paths do not need identical handler protocols. OriginSpec should bind each to a typed protocol or acquisition mode while DeclarationSpec stores only the stable `HandlerBinding` metadata.

## Required diagnostics

- unresolved before/after reference;
- cross-scope or cross-context ordering reference;
- invalid or empty input applicability/result Provider;
- cycle with the exact binding path;
- same-context pair with no order;
- declared-disjoint pair with no negative fixture;
- duplicate binding ID;
- derived plan that differs from current dispatch parity during migration.

Every diagnostic must name the OriginSpec, binding ID, owning adapter path, and exact command that reproduces or repairs the issue.

## Mutation-sensitive tests

1. In the pilot, remove Claude-before-ChatGPT in record scope: ambiguous-order diagnostic must fire.
2. Reverse that pilot edge: the combined-record real-route golden must fail.
3. In the pilot, remove ChatGPT-before-Claude in sequence scope: ambiguous-order diagnostic must fire.
4. Reverse that pilot edge: the combined-sequence real-route golden must fail.
5. After Codex is declared in `2qx.1.2`, remove/reverse each Codex/Claude scope edge and require the existing adversarial golden to fail.
6. Add `A before B` and `B before A`: cycle diagnostic must include both IDs.
7. Shuffle declaration registration 100 times: derived plans must serialize identically.
8. Declare two overlapping detectors disjoint without a fixture: validation must fail.
9. Remove the Claude/ChatGPT edge and claim they are disjoint because their result Providers differ: validation must still fail.
10. Delete an adapter symbol: handler-resolution diagnostic must point to the owner path and repair command.
11. Duplicate the browser-envelope transform through two Origin declarations with conflicting binding metadata: validation must fail rather than choose one by registration order.
