# Current source-dispatch and vocabulary census

All line anchors refer to the supplied revision `76ee0d3842f12920ee71ad06f22b9cd8d2f88730` before applying the included patches.

## Vocabulary owners

| Surface | Current owner | Snapshot anchor | Finding |
|---|---|---:|---|
| Public origin tokens | `Origin` | `polylogue/core/enums.py:42-55` | Exactly eleven tokens, in the migration order named by `2qx.1.2`. Invalid strings normalize to `UNKNOWN_EXPORT`. |
| Runtime/provider-wire tokens | `Provider` | `polylogue/core/enums.py:68-82` | Twelve tokens, including both Gemini and Drive plus Grok and Unknown. |
| Rich source descriptors | `Source` and `_PROVIDER_TO_SOURCE` | `polylogue/core/sources.py:62-172` | One Source per Provider. `gemini-export`, `drive-takeout`, and `unknown` do not match their public Origin spellings. |
| Provider → Origin | `_PROVIDER_TO_ORIGIN` | `polylogue/core/sources.py:214-240` | Total map; Gemini and Drive both collapse to AISTUDIO. |
| Origin → Provider compatibility bridge | `_ORIGIN_TO_PROVIDER` | `polylogue/core/sources.py:289-306` | Explicitly lossy AISTUDIO default is Gemini; callers need retained evidence for semantic selection. |
| Provider fiber | `_build_origin_provider_fiber` | `polylogue/core/sources.py:309-343` | Derived from the forward map; AISTUDIO is the sole multi-member fiber. |
| Public projection helper | `source_name_to_origin` | `polylogue/core/sources.py:399-429` | Handles existing Origin strings, Source families, and Provider tokens. |
| Schema-origin set | `CORE_SCHEMA_ORIGINS` | `polylogue/core/sources.py:436-438` | Derived from `CORE_SCHEMA_PROVIDERS`, whose defining file was omitted from the selected snapshot. The exact-revision official file includes Grok and excludes Beads, Drive, and Unknown. |

## Dispatch inventories and consumers

| Inventory/branch | Anchor | Current content or behavior | OriginSpec destination |
|---|---:|---|---|
| `BUNDLE_PROVIDERS` | `polylogue/sources/dispatch.py:38` | ChatGPT, Claude AI | acquisition/parser modes |
| `GROUP_PROVIDERS` | `dispatch.py:39` | Claude Code, Codex, Gemini, Drive, Beads | acquisition/parser modes; used outside dispatch |
| `STREAM_RECORD_PROVIDERS` | `dispatch.py:40` | Claude Code, Codex, Beads | stream parser bindings |
| `DRIVE_LIKE_PROVIDERS` | `dispatch.py:41` | Gemini, Drive | AISTUDIO provider-fiber acquisition modes |
| Record detector chain | `dispatch.py:135-168` | Structural/local detectors, then Beads, Codex, Claude Code, ChatGPT, Claude AI, Gemini | scoped detector plan |
| Sequence detector chain | `dispatch.py:171-192` | Browser, Beads, ChatGPT, Claude AI, Gemini, Claude Code, Codex | separate scoped detector plan |
| Raw-prefix detection | `dispatch.py:205-246` | JSON document or up to 32 JSONL records, then fallback provider | raw-prefix scope plus explicit fallback |
| Lowering | `dispatch.py:629-739` | Manual provider/set branches for browser, bundles, grouping, local artifacts, Drive, and fallback | acquisition/parser mode derivation or parity |
| Parser switch | `dispatch.py:774-834` | Manual Provider/mode branches; generic messages at the end | parser plan |
| Stream parser switch | `dispatch.py:861-876` | Claude Code, Codex, Beads | stream parser plan |
| Assembly switch | `polylogue/sources/assembly.py:68-82` | Claude Code, Codex, Gemini only | assembly binding with physical-provider applicability |

The four dispatch sets are runtime dependencies, not mere documentation. `GROUP_PROVIDERS` is consumed by `source_acquisition_components.py`, `source_parsing.py`, and `emitter.py`; stream selection is consumed by live batch and revision backfill. A kernel patch that only rewrites `detect_provider` would leave parallel owners intact.

## Runtime call paths that must be migrated or parity-checked

| Consumer | Anchor | Dependency on current inventory |
|---|---:|---|
| ZIP acquisition | `polylogue/sources/source_acquisition_components.py:424-478` | Uses `GROUP_PROVIDERS` to preserve/group entries and detection results. |
| Source parsing | `polylogue/sources/source_parsing.py:108-188` | Uses `GROUP_PROVIDERS` to choose grouped processing. |
| Emitter | `polylogue/sources/emitter.py:16-20`, `:202-243`, `:382-419` | Detects providers, groups payloads, parses, then resolves assembly by Provider. |
| Live ingest | `polylogue/sources/live/batch.py:1638-1670`, `:1902-1915` | Chooses stream versus ordinary parsing. |
| Revision replay | `polylogue/sources/revision_backfill.py:322-334` | Chooses stream versus ordinary parsing for retained raw material. |
| Schema sampling | `polylogue/schemas/sampling_db.py:58-97` | Reconstructs provider-wire tokens from stored Origin through the lossy core default; AISTUDIO becomes Gemini without mode/family evidence. |
| Live watcher reconciliation | `polylogue/sources/live/watcher.py:859-877` | Reconstructs cursor `source_name` from Origin through the same lossy default; AISTUDIO becomes Gemini. |
| Raw acquisition | `polylogue/sources/source_acquisition.py:98-139` | Carries Provider hints through detection. |

## Completeness, fixtures, and schemas

### Handwritten provider completeness

`polylogue/sources/provider_completeness.py:54-204` defines nine `_PackageModeSpec` rows:

1. Claude Code export JSONL
2. Codex session JSONL
3. ChatGPT takeout JSON
4. Claude AI export JSON
5. AISTUDIO/Drive-like export
6. browser capture, keyed to `UNKNOWN_EXPORT`
7. Antigravity language-server export
8. Gemini CLI local-agent document
9. Hermes state DB

It omits Beads and Grok. Hermes has multiple live detector/parser modes but only the state-DB mode is represented. Browser capture’s own caveat says captured sessions map to provider-specific origins, so using Unknown as its row identity is a transport/origin conflation.

### Direct parser regression pack

`tests/unit/sources/parsers/test_origin_regression_pack.py:523-716` contains nine fixtures: Beads, ChatGPT, Claude AI, Claude Code, Codex, Gemini CLI, AISTUDIO, Antigravity, and Hermes. Grok and Unknown are absent. The included patch corrects the module documentation so it no longer claims every supported Origin is listed.

The browser-capture snapshot at `:747-768` and its dispatch assertion at `:939-951` correctly project to ChatGPT Origin; this is evidence that browser capture is an acquisition mode, not an Origin.

### Dispatch ambiguity tests

`tests/unit/sources/test_dispatch_ordering.py:34-117` contains adversarial payloads that pin detector precedence. Most importantly, one sequence-shaped conflict expects Claude Code while one single-record conflict expects Codex. Included Patch 0003 adds a self-contained pilot pair using the same combined Claude Code/ChatGPT record in record and one-record-sequence forms, pinning the opposite winners without introducing Codex into the pilot registry. These tests must be consumed as golden behavior by scoped ordering derivation.

### Schema verification reverse map

`polylogue/schemas/validation/corpus.py:28-46` declares a separate Origin-to-Provider map. It omits Beads and Grok and chooses Drive for AISTUDIO, while `core/sources.py` exposes Gemini as a compatibility default. `polylogue/schemas/sampling_db.py:58-97` and `polylogue/sources/live/watcher.py:859-877` call that core reverse without a family hint, so both also reconstruct AISTUDIO as Gemini. Some choices may be boundary-specific, but OriginSpec must preserve provider/acquisition evidence and make each projection explicit rather than allowing a global “canonical” provider to select schema, parser, assembly, sampling, or cursor semantics.

### Provider schema directories

The selected snapshot contains eight directories under `polylogue/schemas/providers`: Antigravity, ChatGPT, Claude AI, Claude Code, Codex, Gemini, Gemini CLI, and Hermes. Beads, Grok, and Unknown have no directory. The exact-revision `CORE_SCHEMA_PROVIDERS` nevertheless includes Grok. The migration must resolve whether reserved tokens appear in schema selection, public vocabulary only, or a reserved/unavailable schema result.

## Current Grok and Unknown behavior

There is no positive Grok detector and no dedicated Grok parser. However, `dispatch.py:739` sends any unhandled Provider to fallback lowering, and `dispatch.py:829-832` parses `generic_messages`. An explicit Grok hint therefore reaches a generic parser when the payload has a `messages` list. This is a static control-flow inference; the selected snapshot cannot import the package to execute it.

Unknown follows the same generic fallback but is intended to be compatibility-only. OriginSpec should model this as an explicit fallback binding that is last and does not count as executable-origin completeness.

## Generated/public surfaces not fully present in the selected footprint

The Beads contract requires public schemas, errors, completions, CLI/MCP help, fixture census, generated docs, and enum parity. The selected pack is a targeted 286-file footprint and does not contain the complete render/devtools/surface tree. Before implementation, repeat a full-repository census using:

```bash
rg -n 'Origin|CORE_SCHEMA_ORIGINS|origin_from_provider|provider_from_origin|valid.*origin|exclude_origin|completion' polylogue tests docs
rg -n 'GROUP_PROVIDERS|STREAM_RECORD_PROVIDERS|BUNDLE_PROVIDERS|DRIVE_LIKE_PROVIDERS|PACKAGE_MODE_SPECS' polylogue tests
find polylogue/schemas/providers -mindepth 1 -maxdepth 1 -type d -print
```

Any newly found list becomes either a derived consumer, a mechanical parity check, or an explicitly justified non-Origin inventory. It must not become another registry.
