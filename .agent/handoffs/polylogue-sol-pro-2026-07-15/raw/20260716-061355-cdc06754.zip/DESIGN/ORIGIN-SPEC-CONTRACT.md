# OriginSpec contract after DeclarationSpec lands

This is the implementation target for `polylogue-2qx.1.1`. It assumes `polylogue-o21.1` has shipped the storage-free declaration models, registry/derivation protocols, and source-locatable diagnostics. OriginSpec specializes those protocols for source admission; it does not copy or fork the generic kernel.

## Dependency and package boundary

Add one source-domain module:

```text
polylogue/sources/origin_specs.py
```

The allowed dependency direction is:

```text
polylogue.declarations  <-  polylogue.sources.origin_specs  ->  existing source adapters
```

`polylogue.declarations` must not import `polylogue.sources`. `origin_specs.py` may name adapter symbols through stable `HandlerBinding` values, but deterministic derivation must not import or execute those adapters. Runtime plan resolution may import them lazily at the existing dispatch/parse boundary.

Use the landed prerequisite types rather than introducing source-local equivalents:

```python
from polylogue.declarations.models import DeclarationSpec, HandlerBinding
from polylogue.declarations.registry import DeclarationRegistry
from polylogue.declarations.validation import Diagnostic
from polylogue.core.enums import Origin, Provider
```

Do not add `polylogue/sources/declarations.py`, a second generic compatibility key, a source-local `Diagnostic`, a universal registry, persistence, or a plugin loader.

## Exact source-domain types

Names may adapt mechanically to the final `polylogue-o21.1` API, but these fields and laws are the required domain contract.

```python
from __future__ import annotations

from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Literal


class OriginLifecycle(StrEnum):
    EXECUTABLE = "executable"
    RESERVED = "reserved"
    UNSUPPORTED = "unsupported"
    COMPATIBILITY_ONLY = "compatibility-only"


class AdmissionPolicy(StrEnum):
    POSITIVE_DETECTOR = "positive-detector"
    EXPLICIT_HINT_ONLY = "explicit-hint-only"
    ENVELOPE_PROJECTED = "envelope-projected"
    FALLBACK_ONLY = "fallback-only"


class DetectorScope(StrEnum):
    RECORD = "record"
    SEQUENCE = "sequence"
    RAW_PREFIX = "raw-prefix"
    PATH_SAMPLE = "path-sample"
    ZIP_ENTRY = "zip-entry"


class ParserMode(StrEnum):
    DOCUMENT = "document"
    BUNDLE = "bundle"
    GROUPED_RECORDS = "grouped-records"
    STREAM_RECORDS = "stream-records"
    LOCAL_ARTIFACT = "local-artifact"
    COMPATIBILITY_FALLBACK = "compatibility-fallback"


class ReparseConsequence(StrEnum):
    NONE = "none"
    METADATA_ONLY = "metadata-only"
    SEMANTIC_REPARSE = "semantic-reparse"


CollisionPolicy = Literal["injective", "many-to-one", "compatibility-fallback"]


@dataclass(frozen=True, slots=True)
class AcquisitionModeSpec:
    mode_id: str
    artifact_kinds: tuple[str, ...]
    capture_modes: tuple[str, ...]
    admission_policy: AdmissionPolicy
    admission_reason: str | None
    detector_scopes: tuple[DetectorScope, ...]
    parser_modes: tuple[ParserMode, ...]
    pre_admission: HandlerBinding | None
    completeness_edge_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DetectorApplicability:
    acquisition_mode_ids: tuple[str, ...]
    admission_context_ids: tuple[str, ...]
    artifact_kinds: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class HandlerApplicability:
    acquisition_mode_ids: tuple[str, ...]
    physical_providers: tuple[Provider, ...]


@dataclass(frozen=True, slots=True)
class DetectorBinding:
    binding_id: str
    scope: DetectorScope
    handler: HandlerBinding
    result_provider: Provider
    applicability: DetectorApplicability
    before: tuple[str, ...] = ()
    after: tuple[str, ...] = ()
    disjoint_with: tuple[str, ...] = ()
    fixture_example_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ParserBinding:
    binding_id: str
    mode: ParserMode
    handler: HandlerBinding
    applicability: HandlerApplicability
    selection_predicate: HandlerBinding | None = None


@dataclass(frozen=True, slots=True)
class AssemblyBinding:
    binding_id: str
    handler: HandlerBinding
    applicability: HandlerApplicability


@dataclass(frozen=True, slots=True)
class ProviderProjection:
    physical_providers: tuple[Provider, ...]
    collision_policy: CollisionPolicy
    compatibility_default: Provider | None
    disambiguation_fields: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class AuthorityProfile:
    positive_evidence: tuple[str, ...]
    prohibited_inferences: tuple[str, ...]
    provenance_fields: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class FidelityProfile:
    preserved: tuple[str, ...]
    known_losses: tuple[str, ...]
    degraded_flags: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CoverageExpectation:
    counter_id: str
    construct: str
    minimum: int | None
    evidence_edge_id: str


@dataclass(frozen=True, slots=True)
class FixtureRef:
    example_id: str
    acquisition_mode_id: str
    expected_origin: Origin
    expected_provider: Provider | None
    negative: bool = False


@dataclass(frozen=True, slots=True)
class OriginSpec:
    declaration: DeclarationSpec
    origin: Origin
    lifecycle: OriginLifecycle
    lifecycle_reason: str | None
    acquisition_modes: tuple[AcquisitionModeSpec, ...]
    detectors: tuple[DetectorBinding, ...]
    parsers: tuple[ParserBinding, ...]
    assembly: tuple[AssemblyBinding, ...]
    provider_projection: ProviderProjection
    normalized_constructs: frozenset[str]
    authority: AuthorityProfile
    fidelity: FidelityProfile
    coverage: tuple[CoverageExpectation, ...]
    fixtures: tuple[FixtureRef, ...]
    semantic_reparse: ReparseConsequence


@dataclass(frozen=True, slots=True)
class OriginSpecCoverage:
    spec_origins: tuple[Origin, ...]

    @property
    def covered_origins(self) -> frozenset[Origin]:
        return frozenset(self.spec_origins)

    @property
    def duplicate_origins(self) -> tuple[Origin, ...]:
        counts = Counter(self.spec_origins)
        return tuple(origin for origin in Origin if counts[origin] > 1)

    @property
    def runtime_complete(self) -> bool:
        return self.spec_origins == tuple(Origin)
```

`completeness_edge_ids` and `example_id` are references to generic `CompletenessEdge` and `ExampleSpec` records owned by the embedded `DeclarationSpec`. OriginSpec must validate those references but must not copy generic examples, outputs, completeness edges, source locations, or compatibility dimensions into another model.

`HandlerBinding` is stable declaration data—owner module/path, importable symbol, and protocol/role—not a callable `repr`. That applies equally to detectors, pre-admission envelope transforms, parser selection predicates, parsers, and assembly handlers. Runtime resolution may import the symbol lazily from its owning adapter; normalized derivation operates only on stable binding data.

`admission_context_ids` are stable input-side contexts shared across Origins, such as `json-record`, `json-sequence`, or `raw-prefix-jsonl`. They are not provider names and are not inferred from the detector's result. This distinction is required because detectors returning different Providers can still compete for the same payload.

## Registry and derivation API

The prerequisite `DeclarationRegistry` remains the generic registry. The source module exposes one immutable domain projection plus explicit coverage metadata:

```python
ORIGIN_DECLARATIONS: DeclarationRegistry
ORIGIN_SPECS: tuple[OriginSpec, ...]
ORIGIN_SPEC_BY_TOKEN: Mapping[Origin, OriginSpec]
ORIGIN_SPEC_COVERAGE: OriginSpecCoverage


def get_origin_spec(origin: Origin) -> OriginSpec: ...
def validate_origin_specs() -> tuple[Diagnostic, ...]: ...
def derive_detector_plan(
    scope: DetectorScope, *, admission_context_id: str
) -> DetectorPlan: ...
def derive_parser_plan() -> ParserPlan: ...
def derive_assembly_plan() -> AssemblyPlan: ...
def derive_fixture_census() -> FixtureCensus: ...
def derive_provider_completeness_inputs() -> tuple[ProviderCompletenessInput, ...]: ...
def derive_public_origin_inputs() -> PublicOriginInputs: ...
def derive_origin_docs_inputs() -> OriginDocsInputs: ...
def require_runtime_complete() -> None: ...
```

`ORIGIN_SPEC_BY_TOKEN` and `ORIGIN_SPEC_COVERAGE` are derived mechanically from `ORIGIN_SPECS`; neither is a second authoring surface. Construction must reject duplicate tokens before building the index.

During `2qx.1.1`, `ORIGIN_SPECS` contains only Claude Code, ChatGPT, and Grok, `spec_origins` is exactly those three tokens in declaration order, and `runtime_complete` is false. Pilot derivations may be compared with the corresponding current branches, but `require_runtime_complete()` must prevent a partial detector/parser/assembly plan from replacing production dispatch.

During `2qx.1.2`, `spec_origins` must equal `tuple(Origin)` exactly—membership, uniqueness, and order. Only then does the computed `runtime_complete` property become true and may derived plans replace all current inventories. There is no independently mutable completeness flag.

## Lifecycle laws

### Executable

An executable origin must have:

- at least one acquisition mode;
- at least one parser binding;
- a positive detector for every `POSITIVE_DETECTOR` mode;
- a non-empty reason for every `EXPLICIT_HINT_ONLY` mode;
- a pre-admission transform plus retained embedded-provider evidence for every `ENVELOPE_PROJECTED` mode;
- no `FALLBACK_ONLY` mode;
- fixtures covering each declared detector scope, admission policy, and parser mode;
- coverage expectations for each normalized construct it claims;
- a declared reparse consequence;
- no Provider token in public outputs.

Every detector, parser, and assembly binding must name non-empty applicability. Detector acquisition-mode IDs must exist on the same OriginSpec, its result Provider must be in that Origin's provider fiber, and its admission-context IDs describe input context rather than output identity. Parser/assembly acquisition-mode IDs must exist on the same OriginSpec, and every applicable physical Provider must be in that fiber.

A stream parser is legal only for an acquisition mode declaring `STREAM_RECORDS`. Document and stream bindings that can both handle the same provider/mode require a non-null `selection_predicate`, or validation emits a conflict diagnostic. The predicate remains in the owning adapter; OriginSpec stores only its stable binding.

### Reserved

A reserved origin must have a non-empty reason and no detector, parser, stream parser, assembly handler, or executable coverage claim. It may reference negative examples proving that the public token exists while admission remains unavailable.

For Grok, the pilot must close the current explicit-hint path that can fall through to generic-message parsing. This is an intentional behavior correction with a named regression and release note, not a compatibility-preserving migration claim.

### Unsupported

An unsupported origin is recognized for explain/diagnostics but does not parse. It requires a reason and an explicit user-facing unsupported result. It differs from reserved: the token names material that is known and intentionally rejected, rather than future capacity held open.

### Compatibility-only

A compatibility-only origin may own a `FALLBACK_ONLY` acquisition mode and last-resort parser, but has no positive detector and makes no executable-acquisition completeness claim. `unknown-export` belongs here. Its fallback is selected only after every positive detector and explicit-hint route declines; it must not be represented as an ordinary detector-order node or steal material from an executable origin.

## Provider projection and applicability laws

`physical_providers` is non-empty. Every provider appears in the forward `Provider -> Origin` fiber for this Origin.

- `injective` requires exactly one physical provider and no disambiguation fields. A compatibility default, when retained for a legacy bridge, must equal that sole provider.
- `many-to-one` requires at least two physical providers, non-empty disambiguation fields, and fixtures for every fiber member. Parser or assembly selection must use retained provider/acquisition evidence; a public Origin token alone is insufficient.
- `compatibility-fallback` is legal only for a compatibility-only lifecycle.
- `compatibility_default` is an explicitly lossy bridge for legacy boundaries. It must never decide parser, assembly, schema, or acquisition applicability.

For AISTUDIO, the physical fiber is `(Provider.GEMINI, Provider.DRIVE)`. Core’s current reverse compatibility default is Gemini, schema verification separately chooses Drive, and archive/watcher consumers reconstruct provider-wire identity without a disambiguating hint. OriginSpec must preserve the fiber, declare the evidence fields that distinguish its members, and migrate those consumers to mode-aware projection. The current `Provider.GEMINI`-only assembly branch cannot be generalized to Drive by assumption.

## Scoped detector-order law

Detector ordering is derived independently for each `(DetectorScope, admission_context_id)` input context.

1. Select bindings naming that scope/context and validate non-empty input applicability, result Provider membership, stable binding IDs, and all same-scope/context references.
2. Build a directed graph from `before` and `after` constraints.
3. Reject self-edges, cross-context references, and cycles.
4. Treat every pair active in the same scope/context as potentially overlapping by default—even when the bindings return different Providers or belong to different OriginSpecs. Different output Providers are not evidence of input disjointness.
5. Require a directed path in one direction for each pair. A pair may remain incomparable only when both declarations name each other in `disjoint_with` and a negative ambiguity example proves the input domains disjoint.
6. Use stable binding-ID sorting only among proven-disjoint ready nodes so shuffled registration produces byte-identical plans. Lexical order must never choose a semantic winner.
7. Emit binding IDs, stable handler references, result Providers, input applicability, scope/context, and source provenance; runtime dispatch resolves the handlers.

Browser capture is not an Origin detector in this graph. Its envelope decoder is a `pre_admission` transform that runs in a fixed acquisition prelude, retains the embedded physical Provider, and then projects to that Provider's public Origin. The derived admission plan deduplicates shared transforms by stable HandlerBinding ID and fails if copies disagree.

The three-pilot registry can prove scope-specific ordering without referencing undeclared Codex bindings:

- record scope: Claude Code before ChatGPT;
- sequence scope: ChatGPT before Claude Code.

A combined payload containing both Claude Code record keys and ChatGPT `mapping` evidence provides the positive ambiguity fixture in each scope. `2qx.1.2` adds Codex and then preserves the second production inversion: Codex before Claude Code for records, Claude Code before Codex for sequences.

## Pilot declarations

### Claude Code

- lifecycle: executable;
- physical provider: `CLAUDE_CODE`;
- modes: grouped JSONL, stream records, raw-prefix detection, and sidecar assembly;
- pilot detector constraints: before ChatGPT in record scope and after ChatGPT in sequence scope;
- parsers: grouped/document and stream, each restricted to Claude Code modes/provider;
- assembly: `ClaudeCodeAssemblySpec`, restricted to declared sidecar modes/provider;
- fixtures: direct parser, pilot ambiguity in both scopes, streaming, session-index/history sidecars;
- consequence: semantic reparse.

### ChatGPT export

- lifecycle: executable;
- physical provider: `CHATGPT`;
- modes: document, takeout bundle, sessions wrapper, and browser-envelope projection;
- pilot detector constraints: after Claude Code in record scope and before Claude Code in sequence scope;
- parser: document/bundle; no stream parser or assembly;
- fixtures: direct parser, pilot ambiguity in both scopes, bundle cardinality, browser-capture snapshot;
- consequence: semantic reparse.

### Grok export

- lifecycle: reserved;
- physical provider: `GROK`;
- non-empty reason naming the missing admission/parser implementation;
- no detector/parser/stream/assembly/positive coverage binding;
- negative examples: no detector selects Grok; explicit Grok hint plus generic `messages` does not parse after the approved correction;
- public token remains available without advertising executable support.

## Admission/conformance kernel versus migration

`2qx.1.1` owns only:

- the source-domain models above;
- cross-reference, lifecycle, applicability, collision, and scoped-order validators;
- deterministic typed derivations;
- explicit partial-registry guard;
- the three production pilots and their real-route parity/mutation tests;
- source-locatable diagnostics.

`2qx.1.2` owns:

- the remaining eight declarations;
- exact eleven-token completeness/order;
- provider-fiber and acquisition-mode decisions for AISTUDIO;
- parity and then replacement of dispatch sets/branches, parser/stream/assembly switches, provider completeness, schema reverse projection, fixtures, public schemas/errors/completions/help/docs, and generated surfaces;
- deletion of obsolete inventories after anti-vacuity tests prove the derived owners are live.

No runtime branch should be deleted while `runtime_complete` is false.
