# Research and source index

Access date for external sources: 2026-07-16.

## Immutable supplied snapshot

- Archive: `polylogue-sol-pro-context-2fab33f7c22e6224.tar.gz`
- Archive SHA-256: `2fab33f7c22e62245ddd69f835eaaf2263504a492543ee690ed3345e91af399a`
- Base revision: `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- Branch metadata: `feature/browser/adopt-completion-monitors`
- Selected source files: 286
- Selected Beads records: only `polylogue-2qx.1`
- Selected-footprint staged and working-tree patches: empty

The snapshot files are the source of truth for all current-code findings and line anchors in this handoff.

## Official exact-revision sources used to recover omitted prerequisite records

- Complete Beads export at the exact base revision:
  `https://raw.githubusercontent.com/Sinity/polylogue/76ee0d3842f12920ee71ad06f22b9cd8d2f88730/.beads/issues.jsonl`

  Relevant records: `polylogue-o21.1`, `polylogue-2qx.1.1`, `polylogue-2qx.1.2`, `polylogue-2qx.1`, `polylogue-2qx`, and the portfolio false-unification ruling around `polylogue-z9gh` notes.

- Provider identity inventory omitted from the selected footprint, exact revision:
  `https://raw.githubusercontent.com/Sinity/polylogue/76ee0d3842f12920ee71ad06f22b9cd8d2f88730/polylogue/core/provider_identity.py`

  Used only to confirm `CORE_RUNTIME_PROVIDERS` and `CORE_SCHEMA_PROVIDERS`. No external branch or newer code was mixed into the patch.

- Official repository at the exact commit:
  `https://github.com/Sinity/polylogue/tree/76ee0d3842f12920ee71ad06f22b9cd8d2f88730`

## Research decisions derived from those sources

- The explicit hard edge from `2qx.1.1` to `o21.1` controls implementation sequencing.
- DeclarationSpec owns shared declaration/generation/completeness protocols only.
- OriginSpec remains a typed domain registry with source-specific lifecycle, authority, detector/parser, fidelity, and reparse semantics.
- The kernel pilots are Claude Code, ChatGPT export, and reserved Grok.
- The complete migration is a separate eleven-origin slice.
- Universal-registry unification is explicitly rejected because domain identity, lifecycle, authority, access/result shape, and durability differ.
