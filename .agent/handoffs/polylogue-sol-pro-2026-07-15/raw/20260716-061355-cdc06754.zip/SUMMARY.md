# Executive summary

## Result

The correct architectural decision is **design-first at this revision**. `polylogue-2qx.1.1` is explicitly hard-blocked by `polylogue-o21.1`, and the supplied source snapshot contains neither `polylogue/declarations` nor `polylogue/sources/origin_specs.py`. Implementing an OriginSpec registry now would require inventing a duplicate DeclarationSpec protocol, registry, derivation model, and Diagnostic—exactly the false generic unification and second-kernel outcome the project records reject.

This handoff nevertheless makes concrete progress:

- reconstructs the complete prerequisite and child-slice contract from the exact base revision;
- separates generic DeclarationSpec responsibilities from source-domain OriginSpec responsibilities and the later all-origin migration;
- traces the current Origin/Provider/Source vocabulary, dispatch/lowering/parser/assembly paths, acquisition/live/replay consumers, completeness rows, fixtures, and schema reverse maps;
- proves that detector precedence must be scope-specific: the three pilots already invert Claude Code/ChatGPT across record and sequence scopes, and the full current chain separately inverts Codex/Claude Code;
- identifies the static Grok lifecycle conflict and the AISTUDIO physical-provider/assembly decision gate;
- specifies exact types, lifecycle laws, ordering algorithm, derivations, diagnostics, pilot declarations, files, commit sequence, and mutation-sensitive tests;
- includes three clean unified patches that can land before DeclarationSpec: two durable documentation/scope corrections and one production-route detector-order characterization, with no runtime-code change;
- includes a dependency-free verifier with a 19/19 passing baseline and patch-application receipts.

## Most important decisions

1. **No second declaration kernel.** OriginSpec consumes `polylogue.declarations` after `o21.1`; source code does not recreate `DeclarationSpec`, `HandlerBinding`, derivation protocols, or `Diagnostic`.
2. **Kernel and migration remain separate.** `2qx.1.1` proves Claude Code, ChatGPT, and reserved Grok. `2qx.1.2` migrates all eleven current Origins and only then deletes duplicate inventories.
3. **Detector order is per binding scope and input context.** The pilot uses only Claude Code/ChatGPT edges; Codex edges arrive with Codex in `2qx.1.2`, avoiding dangling constraints to an undeclared origin. Detectors returning different Providers still compete for the same input, while browser-envelope decoding is a shared pre-admission transform rather than an Origin detector.
4. **Provider is physical/wire; Origin is public.** AISTUDIO’s Gemini+Drive fiber requires explicit many-to-one evidence, provider/mode-qualified handlers, and migration of lossy schema-sampling/watcher reverse projections; a compatibility default cannot choose semantics.
5. **Grok requires an explicit behavior correction decision.** It is specified as reserved, but explicit Grok hints currently fall through to generic-message parsing. The recommended final law prohibits that path, with a named regression and release note.
6. **Unknown is compatibility-only.** It owns last-resort fallback semantics, no positive detector, and no executable-completeness claim.
7. **Browser capture is acquisition, not Origin.** It projects the embedded provider session to that provider’s public Origin.

## Included patch result

| Patch | Status | Effect |
|---|---|---|
| `0001-docs-record-OriginSpec-dependency-seam.patch` | applies cleanly | Records the ordered dependency seam, partial-registry guard, input-context-scoped ordering law, browser pre-admission transform, provider/mode applicability, lifecycle cases, and anti-duplication rule in the existing identity document. |
| `0002-tests-correct-executable-origin-fixture-scope.patch` | applies cleanly | Corrects the regression-pack claim to nine live direct-parser fixtures and separates Grok, Unknown, and browser capture. No test/runtime logic changes. |
| `0003-tests-pin-OriginSpec-pilot-detector-precedence.patch` | applies cleanly | Adds two production-dispatch adversarial rows proving Claude Code wins the ambiguous record while ChatGPT wins the one-record sequence. Test-only; no runtime-code change. |

## Acceptance-criteria matrix

| Criterion | Result | Evidence in this ZIP | Residual |
|---|---|---|---|
| Inspect source dispatch and current vocabulary | satisfied for supplied footprint | `DESIGN/CURRENT-SURFACE-CENSUS.md`, `TESTS/baseline-report.json` | Repeat census on full checkout because pack is targeted. |
| Inspect fixtures/generated surfaces | substantially satisfied | fixture/completeness/schema census and official provider identity inventory | Complete CLI/MCP/render tree was not included. |
| Read complete relevant Beads and later notes | satisfied via exact-revision official export | `DESIGN/BEADS-DEPENDENCY-EVIDENCE.md`, `DESIGN/ADJUDICATION.md`, `DESIGN/RESEARCH-SOURCES.md` | Re-read latest records when rebasing. |
| Separate DeclarationSpec from OriginSpec | satisfied as an exact contract | `DESIGN/ORIGIN-SPEC-CONTRACT.md` | Await landed `o21.1` API names. |
| Separate reusable kernel from all-origin migration | satisfied | `DESIGN/ADJUDICATION.md`, `DESIGN/MIGRATION-MATRIX.md` | Production work remains. |
| Avoid second generic declaration kernel | satisfied | no production placeholder; rejected alternatives documented | Enforce import/dependency test after implementation. |
| Representative executable/reserved pilots | contracts fully specified; detector ambiguity golden landed | Claude Code, ChatGPT, Grok contracts plus Patch 0003 | Declaration-backed pilots remain blocked on `o21.1`. |
| Deterministic detector ordering | exact scoped law and self-contained pilot proof specified | `DESIGN/DETECTOR-ORDERING.md` | Implement and parity-test after prerequisite. |
| Actionable missing-edge diagnostics | exact codes/fields/commands specified | `DESIGN/DIAGNOSTICS.md` | Populate landed generic Diagnostic. |
| Migrate every current Origin exactly once | precise follow-on plan | `DESIGN/MIGRATION-MATRIX.md`, `DESIGN/IMPLEMENTATION-PLAN.md` | Owned by `2qx.1.2`; not prematurely done. |
| Preserve current parser/detector behavior | characterization strengthened; runtime code unchanged | baseline verifier, Patch 0003, and patch receipt | Grok conflict needs an explicit approved correction. |
| No duplicate inventory remains after migration | deletion sequence and anti-vacuity gates specified | implementation plan/test matrix | Current snapshot still has duplicate inventories. |
| Coherent first patch where dependency allows | satisfied | three ordered unified patches | Production kernel remains correctly blocked; Patch 0003 adds executable characterization only. |
| Executable verification plan | satisfied | `TESTS/verify_snapshot.py`, baseline report, test matrix | Full project test runner unavailable in selected pack. |
| Exact final handoff archive contract | satisfied | required root files/directories and manifest | None after final archive validation. |

## Verification summary

- Static snapshot verifier: **19 passed, 0 failed**.
- Patch 1 `git apply --check`: pass.
- Patch 2 `git apply --check`: pass after Patch 1.
- Patch 3 `git apply --check`: pass after Patches 1–2.
- `git diff --check` on applied result: pass.
- `python -m py_compile` on both changed test modules: pass.
- Reverse-apply checks: pass.
- Full Polylogue tests/devtools verification: not runnable from the selected snapshot because required project files and package modules are absent.

## Residual risks

- DeclarationSpec’s final landed names may require mechanical adaptation of the proposed source-domain signatures, but not a boundary change.
- The targeted pack may omit additional public/completion/render inventories; the full-tree census is a mandatory Phase 1 gate.
- Grok’s generic fallback may have undocumented users. Resolve with evidence and an explicit behavior-change decision.
- AISTUDIO assembly and reverse-projection behavior differs by boundary today; an Origin-only migration could silently broaden enrichment or erase Drive/Gemini acquisition identity.
- Manual inventories currently disagree in legitimate and illegitimate ways. Delete them only after per-surface parity and mutation proof, not through bulk replacement.
