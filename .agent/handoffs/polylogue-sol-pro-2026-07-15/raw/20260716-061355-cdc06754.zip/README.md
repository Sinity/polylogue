# Polylogue OriginSpec launch handoff

This archive adjudicates `polylogue-2qx.1`, separates the reusable OriginSpec admission/conformance kernel from current-origin migration, and supplies the maximum safe first patch for the provided snapshot.

## Executive read order

1. `SUMMARY.md` — result, acceptance matrix, and residual risks.
2. `DESIGN/ADJUDICATION.md` — dependency ruling and source-supported findings.
3. `DESIGN/BEADS-DEPENDENCY-EVIDENCE.md` — normalized exact-revision prerequisite/child records and hard edges.
4. `DESIGN/ORIGIN-SPEC-CONTRACT.md` — exact post-DeclarationSpec API and laws.
5. `DESIGN/CURRENT-SURFACE-CENSUS.md` — current inventories and source anchors.
6. `DESIGN/DETECTOR-ORDERING.md` — scoped deterministic ordering design.
7. `DESIGN/MIGRATION-MATRIX.md` — every current Origin and its migration work.
8. `DESIGN/IMPLEMENTATION-PLAN.md` — ordered files/commits/gates.
9. `DESIGN/DIAGNOSTICS.md` and `DESIGN/REJECTED-ALTERNATIVES.md`.
10. `PATCHES/SERIES.md` — apply instructions for the three safe patches.
11. `TESTS/TEST-MATRIX.md`, `TESTS/baseline-report.json`, and `VERIFICATION-LIMITS.md`.

## Result in one paragraph

Production OriginSpec implementation is correctly blocked on the absent `polylogue-o21.1` DeclarationSpec kernel. The later child Beads record contains an explicit hard dependency and requires OriginSpec to consume that kernel. This handoff therefore does not create a second declaration registry or an empty placeholder. It provides an implementation-grade contract, a complete current-surface census, a scoped detector-order law, a full eleven-origin migration matrix, exact diagnostics, an ordered patch/test plan, and three clean pre-prerequisite patches that improve the existing architecture documentation, correct fixture-scope claims, and pin the real pilot detector inversion without altering runtime behavior.

## Base and worktree assumptions

- Base revision: `76ee0d3842f12920ee71ad06f22b9cd8d2f88730`
- Branch metadata: `feature/browser/adopt-completion-monitors`
- Supplied source footprint: 286 files under `REPO/`
- Supplied staged patch: empty
- Supplied working-tree patch: empty
- The context pack is a selected snapshot, not a Git checkout.

Before applying in a live checkout, verify the same files have not changed and inspect the current Beads notes again.

## Applying the included patch series

From a repository checkout at the compatible base:

```bash
git apply --check PATCHES/0001-docs-record-OriginSpec-dependency-seam.patch
git apply PATCHES/0001-docs-record-OriginSpec-dependency-seam.patch

git apply --check PATCHES/0002-tests-correct-executable-origin-fixture-scope.patch
git apply PATCHES/0002-tests-correct-executable-origin-fixture-scope.patch

git apply --check PATCHES/0003-tests-pin-OriginSpec-pilot-detector-precedence.patch
git apply PATCHES/0003-tests-pin-OriginSpec-pilot-detector-precedence.patch
```

The patches do not implement or claim completion of `2qx.1.1`/`2qx.1.2`. The first two clarify durable architecture and fixture scope; the third adds a production-route characterization golden for the Claude Code/ChatGPT scope inversion. None changes runtime code.

## Re-running snapshot verification

```bash
python TESTS/verify_snapshot.py /path/to/unpacked/polylogue-sol-pro-work \
  --report /tmp/polylogue-origin-spec-baseline.json
```

The committed baseline report passed 19/19 static checks. See `VERIFICATION-LIMITS.md` for why project imports/tests were not runnable from this targeted pack.

## Durable handoff contents

- `PATCHES/`: ordered unified patches and application notes.
- `DESIGN/`: adjudication, exact contract, source census, detector order, migration matrix, diagnostics, implementation plan, rejected alternatives, and research URLs.
- `TESTS/`: executable static verifier, baseline output, pilot ambiguity fixture, patch receipt, and future test matrix.
- `MANIFEST.json`: SHA-256, size, purpose, and apply order for every other ZIP member.
