# Verification limits

## Supplied immutable input

- Archive: `polylogue-sol-pro-context-a62e54f83c114626.tar(1).gz`
- Size: 202,200 bytes
- SHA-256: `a62e54f83c1146264990ba756e00ecaa0de236d0705114653bf10737c6948b94`
- Safely inspected members: 60
- Recorded repository revision: `518ac33e318995539743e220c01b9883b7a688a0`
- Recorded branch: `feature/browser/sol-pro-dispatch`
- Recorded pre-existing dirty state: staged modification to `.beads/issues.jsonl`

The source pack was a selected footprint. It omitted packaging metadata, most storage/core modules, generated topology files, daemon fixtures, and many public-surface implementations.

## What was run

1. Read the repository instructions, mission, scope, full selected Beads record, git status/patch metadata, and every source file relevant to the destructive census.
2. Reconstructed a local Git base whose tree matches the supplied selected source and whose commit message records the real base revision.
3. Implemented and committed three ordered patches without touching `.beads/`.
4. Generated full-index unified mail patches with `git format-patch`.
5. Applied the exact patch files with `git am` to a fresh detached verification tree at the reconstructed base.
6. Ran `git diff --check` over the applied series; it passed.
7. Compiled every changed production and test Python module under Python 3.13.5; compilation passed.
8. Ran the focused kernel/reset suite under pytest 9.0.2; result: `16 passed in 0.20s`.
9. Ran the included static bypass scanner against the clean patched selected-source tree. It found no production call outside the reviewed guarded-actuator allowlist and reported the known unrouted public operations.
10. Attempted `tests/unit/security/test_excision.py`; collection stopped because `polylogue.core` was absent from the selected snapshot. The exact output is retained in `TESTS/excision-suite-blocked.txt`.
11. Reopened the final ZIP, read every member to force CRC verification, rejected absolute/traversal/backslash/NUL/duplicate/case-fold-duplicate paths, verified required root entries and nonempty required directories, and recomputed every manifest size and SHA-256.

## What was not run

- The repository-wide test suite, canonical lint/format/type checks, Nix build, package build, documentation build, topology render, or generated-file checks.
- Real CLI command execution through the full Click application.
- An MCP host or real MCP tool invocation.
- The HTTP daemon, browser shell, machine-token authentication, web-cookie authentication, CORS/origin checks, or route-level status mapping.
- The complete Python API against real `ArchiveStore` implementations.
- The existing excision and lifecycle database integration tests.
- Live SQLite archive tiers, embeddings extension, replica topology, Sinex service, legal holds, backups, or anti-resurrection re-ingest.
- Multi-process claim races, process-kill fault injection, power loss, disk-full behavior, key rotation, audit-journal migration, network filesystems, or production filesystem ownership.
- The unresolved destructive MCP/HTTP/Python/query-delete operations; the patch does not claim they are protected.
- Any operation against the operator's live archive, daemon, browser, secrets, credentials, databases, or NixOS deployment.

## Evidence strength

The passing tests establish internal behavior of the stdlib transaction kernel and reset file domain in the supplied footprint. Clean patch application establishes reviewable source coherence against that footprint. Compilation of the excision integration establishes syntax/import-reference coherence only up to missing external modules; it does not prove real-route execution.

The archive is therefore a durable implementation handoff and launch-gap report, not a claim that `polylogue-kwsb.2` is complete or production-certified.
