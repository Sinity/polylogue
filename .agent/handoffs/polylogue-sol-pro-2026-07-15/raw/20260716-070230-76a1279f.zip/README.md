# Polylogue MutationTransaction launch handoff

This handoff contains a reviewable three-patch implementation for `polylogue-kwsb.2`, built against the supplied immutable project snapshot at revision `518ac33e318995539743e220c01b9883b7a688a0` on `feature/browser/sol-pro-dispatch`.

The implementation establishes a narrow shared PREPARE → AUTHORIZE → APPLY → RECONCILE kernel, then routes the existing reset and standalone-excision domains through it. It does not claim that the whole mission is complete: the supplied footprint still contains destructive MCP, HTTP, and Python operations that bypass this boundary. Those gaps are explicitly inventoried in `DESIGN/02-destructive-census.md` and marked open in `SUMMARY.md`.

## Read order

1. `SUMMARY.md` — executive result and acceptance-criteria matrix.
2. `DESIGN/02-destructive-census.md` — public-surface census and exact remaining bypasses.
3. `DESIGN/01-architecture.md` — protocol, trust boundaries, crash semantics, and domain split.
4. `DESIGN/03-rejected-alternatives.md` — approaches intentionally not taken.
5. `DESIGN/04-research-notes.md` — official-source design inputs and exact project translations.
6. `PATCHES/BASE-ASSUMPTIONS.md` and `PATCHES/series` — application assumptions and patch order.
7. `TESTS/README.md` and `TESTS/verification-plan.md` — checks that ran and full-checkout gates.
8. `VERIFICATION-LIMITS.md` — precise boundary of evidence.

## Apply order

Start from the recorded base or a descendant where the touched files have not materially diverged. Preserve the operator's pre-existing staged `.beads/issues.jsonl` change; this series does not touch it.

```bash
git status --short
git rev-parse HEAD

git am /path/to/handoff/PATCHES/0001-security-add-plan-bound-mutation-transaction-kernel.patch
git am /path/to/handoff/PATCHES/0002-security-route-reset-actuators-through-mutation-tran.patch
git am /path/to/handoff/PATCHES/0003-security-guard-excision-and-lifecycle-invalidation.patch
```

If the checkout has moved since the base revision, use a throwaway branch and review every three-way resolution. Do not resolve conflicts by discarding the existing reset or excision domain semantics.

Three new modules are added under `polylogue/`. Repository instructions therefore require regenerating and committing the topology projection in the full checkout:

```bash
devtools render topology-projection
devtools render topology-status
```

Those generated files were not present in the immutable snapshot and are intentionally not fabricated here.

## Focused verification

The exact patch series was applied with `git am` to a clean reconstruction of the supplied base. The following focused suite then passed:

```bash
PYTHONPATH=. pytest -q \
  tests/unit/security/test_mutation_transaction.py \
  tests/unit/security/test_reset_transaction.py
```

Result: `16 passed in 0.20s` in the clean verification tree.

The modified production modules and test modules compiled under Python 3.13.5. The existing excision integration suite could not collect from the selected snapshot because `polylogue.core` and other full-repository dependencies were not included. Its updated source compiles, but its real database route remains a full-checkout gate.

## Patch contents

Patch 1 adds the shared transaction kernel, signed authorization envelopes, atomic single-use claims, guarded actuator entry, redacted hash-chained audit receipts, trusted local wiring, and mutation-sensitive kernel tests.

Patch 2 adds reset-owned identity and file plans/actuators, exact snapshot vectors, guarded per-target outcomes, non-writing reconciliation, symlink-safe file targeting, and CLI reset integration.

Patch 3 adds excision-owned MutationPlans and reconciliation, enforces transaction-issued guards at the public excision actuator, redacts durable reasons, routes standalone CLI excision and confirmed primary lifecycle invalidation, and updates the existing excision regression suite to traverse the authorized route.

## Rollback

Before merge, `git am --abort` rolls back a failed application. After merge, revert the three commits in reverse order. Do not restore the former unguarded `apply_session_excision` call sites while keeping the new guarded signature; that creates a fail-closed runtime break rather than a safe rollback.
