#!/usr/bin/env python3
"""Static guardrail for destructive public-surface and actuator bypasses.

This scanner is intentionally conservative. It does not prove authorization
correctness; it detects known public destructive entry points and production
calls to guarded actuators outside their reviewed owner/adapter files.

Default mode fails only on a direct guarded-actuator bypass. ``--strict`` also
fails while any known unrouted public destructive entry point remains.
"""

from __future__ import annotations

import argparse
import ast
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Finding:
    category: str
    path: str
    line: int | None
    symbol: str
    detail: str


# Public destructive entrypoints present in the supplied snapshot. Presence is
# evidence that the census row still needs routing, not proof that every method
# has identical semantics.
KNOWN_UNROUTED: dict[str, tuple[str, ...]] = {
    "polylogue/api/archive.py": (
        "delete_session",
        "delete_session_safe",
        "remove_tag",
        "delete_metadata",
        "remove_mark",
        "delete_annotation",
        "delete_view",
        "delete_recall_pack",
        "delete_workspace",
        "delete_correction",
        "clear_corrections",
    ),
    "polylogue/mcp/server_mutation_tools.py": (
        "remove_tag",
        "remove_mark",
        "delete_session",
    ),
    "polylogue/daemon/http.py": (
        "_handle_reset",
        "_handle_web_auth_revoke",
    ),
    "polylogue/daemon/user_state_http.py": (
        "handle_delete_mark",
        "handle_delete_annotation",
        "handle_delete_saved_view",
        "handle_delete_recall_pack",
        "handle_delete_workspace",
    ),
}

# Calls to these domain actuators are allowed only in the owner or explicitly
# reviewed adapter. Tests are excluded because negative tests intentionally call
# the actuators without guards.
GUARDED_CALL_ALLOWLIST: dict[str, frozenset[str]] = {
    "apply_session_excision": frozenset({"polylogue/security/excision.py"}),
    "apply_prepared_session_excision": frozenset(
        {
            "polylogue/security/excision.py",
            "polylogue/security/lifecycle.py",
            "polylogue/cli/commands/excise.py",
        }
    ),
    "apply_identity_reset_plan": frozenset(
        {
            "polylogue/security/reset_transaction.py",
            "polylogue/cli/commands/reset.py",
        }
    ),
    "apply_file_reset_plan": frozenset(
        {
            "polylogue/security/reset_transaction.py",
            "polylogue/cli/commands/reset.py",
        }
    ),
}

# Named by the operation catalog or imports, but implementation was absent from
# the supplied source footprint. The full-checkout scan must resolve these.
EXPECTED_ABSENT_IMPLEMENTATIONS: tuple[tuple[str, str], ...] = (
    ("polylogue/cli/query_verbs.py", "delete_verb"),
    ("polylogue/mcp/server_personal_state_tools.py", "delete_metadata and peers"),
)


def _relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def _call_name(node: ast.Call) -> str | None:
    target: ast.AST = node.func
    if isinstance(target, ast.Name):
        return target.id
    if isinstance(target, ast.Attribute):
        return target.attr
    return None


def _definitions(tree: ast.AST) -> dict[str, int]:
    result: dict[str, int] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            result[node.name] = node.lineno
    return result


def _python_files(root: Path) -> Iterable[Path]:
    for path in sorted(root.rglob("*.py")):
        rel = _relative(path, root)
        if "/__pycache__/" in f"/{rel}/":
            continue
        yield path


def scan(root: Path) -> dict[str, object]:
    findings: list[Finding] = []
    parse_errors: list[Finding] = []
    definitions_by_path: dict[str, dict[str, int]] = {}

    for path in _python_files(root):
        rel = _relative(path, root)
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=rel)
        except (OSError, SyntaxError, UnicodeError) as exc:
            parse_errors.append(
                Finding("parse_error", rel, getattr(exc, "lineno", None), "", type(exc).__name__)
            )
            continue
        definitions_by_path[rel] = _definitions(tree)

        if rel.startswith("tests/"):
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = _call_name(node)
            if name not in GUARDED_CALL_ALLOWLIST:
                continue
            if rel not in GUARDED_CALL_ALLOWLIST[name]:
                findings.append(
                    Finding(
                        "direct_guarded_actuator_bypass",
                        rel,
                        node.lineno,
                        name,
                        "production call is outside the reviewed owner/adapter allowlist",
                    )
                )

    unrouted: list[Finding] = []
    for rel, symbols in KNOWN_UNROUTED.items():
        defs = definitions_by_path.get(rel, {})
        for symbol in symbols:
            line = defs.get(symbol)
            if line is not None:
                unrouted.append(
                    Finding(
                        "known_unrouted_public_operation",
                        rel,
                        line,
                        symbol,
                        "present in supplied-footprint census; requires MutationTransaction or typed exemption",
                    )
                )

    unresolved: list[Finding] = []
    for rel, symbol in EXPECTED_ABSENT_IMPLEMENTATIONS:
        if not (root / rel).exists():
            unresolved.append(
                Finding(
                    "implementation_absent",
                    rel,
                    None,
                    symbol,
                    "named by supplied catalog/imports but absent from selected snapshot",
                )
            )

    return {
        "schema": "polylogue.static-destructive-scan.v1",
        "root": str(root.resolve()),
        "summary": {
            "direct_guarded_actuator_bypasses": len(findings),
            "known_unrouted_public_operations": len(unrouted),
            "unresolved_absent_implementations": len(unresolved),
            "parse_errors": len(parse_errors),
        },
        "direct_guarded_actuator_bypasses": [asdict(item) for item in findings],
        "known_unrouted_public_operations": [asdict(item) for item in unrouted],
        "unresolved_absent_implementations": [asdict(item) for item in unresolved],
        "parse_errors": [asdict(item) for item in parse_errors],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path, help="repository root")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="also fail while known unrouted or unresolved public operations remain",
    )
    args = parser.parse_args()
    root = args.repo.resolve()
    if not root.is_dir():
        parser.error(f"not a directory: {root}")

    report = scan(root)
    print(json.dumps(report, indent=2, sort_keys=True))
    summary = report["summary"]
    assert isinstance(summary, dict)
    hard = int(summary["direct_guarded_actuator_bypasses"]) + int(summary["parse_errors"])
    if hard:
        return 1
    if args.strict and (
        int(summary["known_unrouted_public_operations"])
        or int(summary["unresolved_absent_implementations"])
    ):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
