# Test evidence and executable follow-up

## Evidence in this directory

- `source-pack-verification.txt` verifies the uploaded tar paths, manifest coverage, sizes, and SHA-256 values.
- `patch-apply-verification.txt` records a clean `git am` of the exact three-patch series and the resulting commit/file summary.
- `focused-pytest.txt` is the exact focused security-kernel/reset test output from the clean applied tree.
- `excision-suite-blocked.txt` records the attempted existing excision suite and the missing-module collection boundary.
- `static-bypass-scan.py` finds production calls to guarded actuators outside the reviewed owner/adapters and reports known unrouted public destructive methods.
- `static-bypass-scan-output.json` is its output against the clean patched selected-source tree.
- `surface-parity-cases.json` is a machine-readable cross-surface contract fixture. It is deliberately marked as a contract specification rather than proof that unresolved routes pass.
- `tooling-availability.txt` records the exact available and unavailable checkers.
- `verification-plan.md` gives the full-checkout and deployment gates.

## Patch tests added or modified

The patch series itself contains:

- `tests/unit/security/test_mutation_transaction.py` — canonical binding, preview-side-effect detection, authorization omission and exact actor/capability/scope denial, replay, plan drift, guard bypass, partial/held/unknown state mapping, hard-crash reconciliation, explicit idempotent resume, audit redaction, file mode, and event-chain verification.
- `tests/unit/security/test_reset_transaction.py` — exact file plans, guarded direct-call rejection, apply-once/replay, symlink safety, file TOCTOU, and observe-only reconciliation.
- `tests/unit/security/test_excision.py` — existing excision cases migrated through plan/authorization/guard and a direct actuator bypass negative test. It compiled but could not collect without the full repository's `polylogue.core` and storage fixtures.

## Focused command

```bash
PYTHONPATH=. pytest -q \
  tests/unit/security/test_mutation_transaction.py \
  tests/unit/security/test_reset_transaction.py
```

Observed in the clean applied tree: `16 passed in 0.20s`.

## Static scan command

```bash
python /path/to/handoff/TESTS/static-bypass-scan.py /path/to/checkout
```

Default mode fails on direct guarded-actuator bypass or parse errors while reporting known census gaps. Strict mode also fails until every known unrouted/absent public operation is closed:

```bash
python /path/to/handoff/TESTS/static-bypass-scan.py --strict /path/to/checkout
```
