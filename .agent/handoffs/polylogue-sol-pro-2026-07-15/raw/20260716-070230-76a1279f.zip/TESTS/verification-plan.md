# Full-checkout verification plan

Run this plan on a throwaway branch based on `518ac33e318995539743e220c01b9883b7a688a0` or a reviewed descendant. Preserve the pre-existing staged `.beads/issues.jsonl` change.

## 1. Apply and regenerate repository projections

```bash
git status --short
git rev-parse HEAD
git am PATCHES/0001-security-add-plan-bound-mutation-transaction-kernel.patch
git am PATCHES/0002-security-route-reset-actuators-through-mutation-tran.patch
git am PATCHES/0003-security-guard-excision-and-lifecycle-invalidation.patch

devtools render topology-projection
devtools render topology-status
git diff --check
```

Review the generated topology files rather than accepting unrelated projection churn.

## 2. Static and policy gates

```bash
python TESTS/static-bypass-scan.py /path/to/checkout
python TESTS/static-bypass-scan.py --strict /path/to/checkout  # expected to fail until census closure
ruff check polylogue/security polylogue/cli/commands tests/unit/security
ruff format --check polylogue/security polylogue/cli/commands tests/unit/security
mypy polylogue/security  # or the repository's canonical type command
```

Also run the repository's operation-catalog, layering, topology, API-surface, import-cycle, and generated-file checks. Search the full tree for direct `DELETE`, `unlink`, `rmtree`, backend delete/remove/clear calls, credential revocation, GC, reset, purge, and excision. Every result needs a domain route or a reviewed typed exemption.

## 3. Focused unit and integration suites

```bash
PYTHONPATH=. pytest -q \
  tests/unit/security/test_mutation_transaction.py \
  tests/unit/security/test_reset_transaction.py \
  tests/unit/security/test_excision.py \
  tests/unit/security/test_excision_lifecycle.py
```

Add and run real-route tests for:

- CLI reset identity, each file-reset option, `--all`, preview, `--yes`, plain, and JSON;
- CLI standalone excision, lineage hold, cascade, not-found, drift, and anti-resurrection;
- MCP reset/excision or their explicit replacement tools, including read-only/write/admin role denials;
- HTTP reset/excision with machine auth, web-cookie denial, cross-origin denial, stale plan, replay, and non-complete receipt mapping;
- Python plan/authorize/apply/reconcile APIs without access to the local self-grant helper; and
- confirmed primary lifecycle invalidation after network fault/restart, hold, not-found, drift, and partial tier failure.

The tests must invoke the real surface adapter and real domain planner/actuator. Do not satisfy parity with in-test replicas.

## 4. Execute the parity contract

Build a parametrized harness over `surface-parity-cases.json` that normalizes transport framing and compares:

- identical canonical plan hash for the same frozen fixture snapshot;
- exact actor/capability/scope authorization semantics;
- identical target outcome vocabulary and receipt state;
- denial before actuation for missing role/capability/scope;
- replay and stale-plan behavior; and
- absence of raw target/reason/exception data from the shared journal.

Transport-specific status codes and message text may differ; the security semantics may not.

## 5. Fault, crash, and concurrency campaign

Use disposable archives and process boundaries, not only monkeypatched function exceptions.

1. Kill the process after claim, after the first target, after each tier commit, and before terminal receipt commit.
2. Restart with the same key/journal and verify observe-only reconciliation.
3. Race two processes applying the same authorization; exactly one claim may succeed.
4. Race different authorizations for the same stale plan; the second must reprepare and return `replan_required` after target drift.
5. Inject SQLite busy/locked, disk-full, read-only filesystem, truncated journal, corrupt receipt, missing key, wrong key, symlink swap, and insecure file-mode cases.
6. Inject source/index/embedding/user replica holds and failures. Confirm `partial`, `held`, or `unknown`, never `complete`.
7. Verify explicit resume only for actuators proven idempotent, reusing the original transaction ID. Add fresh-plan revalidation before exposing resume publicly.

## 6. Privacy and audit verification

Inspect the SQLite main file plus rollback/WAL/shared-memory files. Search bytes and decoded rows for:

- session IDs, source paths, message/block IDs, excision reasons, secret literals;
- raw domain receipt or residual references;
- exception messages and stack traces; and
- authority/audit key bytes.

Verify actor, capability, policy version, plan hash, authorization/transaction references, target digests, per-target status, residual digests, and timestamps are present. Tamper with each retained event field and verify chain failure. Separately test suffix truncation handling or add an external checkpoint/anchor before claiming truncation evidence.

## 7. Key and journal lifecycle

Define and test:

- ownership and 0600 permissions under the daemon account;
- secure state-root directory permissions;
- key provisioning, backup, rotation, and recovery;
- audit-key derivation/versioning;
- journal schema migration and retention;
- cross-process locking and network-filesystem prohibition/behavior;
- fsync and abrupt-power-loss expectations; and
- redacted export for operator review.

## 8. Close remaining census rows

Highest priority is `Polylogue.delete_session_safe`, currently shared by MCP and HTTP reset. Then add a domain-owned durable assertion/user-state deletion plan for tags, metadata, marks, annotations, views, recall packs, workspaces, and corrections. Locate the query `delete` implementation and all personal-state MCP tools in the full checkout.

Strict static scan and the acceptance matrix may turn green only after every public destructive operation is routed or has a reviewed typed exemption.

## 9. Repository-wide gate

Run the canonical full test, lint, type, documentation, topology, Nix, and packaging commands from repository instructions. Exercise a disposable daemon and all four surfaces. Do not run destructive verification against the operator's live archive, credentials, or primary replicas.
