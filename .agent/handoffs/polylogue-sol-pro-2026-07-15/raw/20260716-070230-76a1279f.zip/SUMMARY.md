# Executive result

The supplied code had compatible command-local previews and confirmations for reset and excision, but no shared security boundary. Authorization could be omitted or replayed, a stale preview could be applied after target drift, adapters could call destructive actuators directly, and partial/crash outcomes could be reported through domain-specific success paths without a common receipt.

This patch series implements the smallest shared kernel that can close those defects for the reset and excision domains without creating a universal mutation executor:

- immutable, canonical plans bind exact targets, affected tiers and replicas, snapshot vector, reversibility, privacy impact, capability, exact scope, policy version, creation time, expiry, domain payload, and plan hash;
- signed authorizations bind actor, capability, exact scope, operation/domain, plan hash, policy version, issuance, expiry, and a nonce;
- an atomic SQLite claim makes each authorization single-use before any actuator guard exists;
- APPLY re-prepares the domain plan and returns `replan_required` before actuation on snapshot/target drift;
- only a transaction-issued, plan-bound, transaction-bound guard can enter public reset/excision actuators;
- domains return one outcome per exact target: `applied`, `already_satisfied`, `blocked`, `failed`, or `unknown`;
- receipt state preserves `partial`, `held`, `unknown`, and `replan_required` instead of upgrading uncertainty to success;
- reconciliation observes orphaned claims without repeating writes, while explicit resume is limited to a domain-idempotent actuator;
- durable shared evidence stores target/receipt/residual digests, bounded machine detail codes, event-chain hashes and HMAC signatures, not private target strings, raw reasons, or exception text.

Reset and excision retain separate planners, holds, snapshots, actuators, postflight logic, and domain receipts. Confirmed primary lifecycle invalidation now traverses the same excision transaction route. File reset no longer follows a symlink to delete its destination.

This is substantial security-kernel progress, not a claim of mission completion. CLI reset and standalone excision are wired. Destructive MCP, HTTP, and Python operations in the supplied footprint remain un-routed and are launch blockers unless they receive their own domain plans/actuators or a genuinely reviewed typed exemption.

The included static census guard reports 21 known unrouted public destructive definitions and two implementation locations named by the selected catalog/import graph but absent from the snapshot. It finds no production call to the newly guarded reset/excision actuators outside the reviewed owner/adapters.

## Most important findings

1. `Polylogue.delete_session_safe()` is a cross-surface bypass shared by MCP `delete_session` and HTTP `/api/reset` session scope. It directly calls `ArchiveStore.delete_sessions()` and does not use reset or excision authorization.
2. HTTP user-state DELETE routes and Python delete/remove/clear methods destroy irreplaceable `user.db` evidence with no plan, capability binding, replay defense, or durable transaction receipt.
3. The existing excision lifecycle confirmer called the excision actuator directly. The patch routes it through a fresh, exact excision plan after durable confirmation.
4. The reset CLI performed file and identity writes itself. The patch moves those writes into reset-owned guarded actuators and leaves the CLI as an adapter.
5. The supplied snapshot is a selected source footprint, not a buildable full checkout. Topology regeneration and real-route tests cannot be completed honestly from it.

## Acceptance-criteria matrix

| Criterion | Result | Evidence / residual |
|---|---|---|
| 1. Census every destructive public operation; route or typed-exempt each | **Partial** | The supplied-footprint census is complete in `DESIGN/02-destructive-census.md`. Reset, standalone excision, and confirmed primary invalidation are routed. MCP, HTTP user-state deletion, web-auth revocation, Python deletion APIs, and the query `delete` implementation remain open rather than being falsely exempted. |
| 2. PREPARE is non-mutating and binds exact targets, tiers/replicas, impact, snapshot, hash, expiry | **Implemented for reset/excision** | `MutationPlan`, reset planners, excision planner, plan-hash tests, preview-write negative test, and exact file/symlink tests. Full excision route test requires the complete repository. |
| 3. Fresh authorization, TOCTOU revalidation, idempotent per-target apply, domain refs, replan on drift | **Implemented in kernel/reset; integrated into excision** | Single-use HMAC authorization, atomic claim, fresh plan comparison, guarded actuators, per-target receipt normalization, replay/drift tests. Excision integration compiles but was not executable in the selected snapshot. |
| 4. CLI/MCP/HTTP/Python reset/excision parity and role denials | **Not complete** | CLI reset/excision adapters are wired. Contract fixture cases are in `TESTS/surface-parity-cases.json`, but no claim is made that MCP/HTTP/Python routes satisfy them. Those adapters must be added in the full checkout. |
| 5. Crash/timeout/partial resume or reconcile without duplicate effects/false success; held explicit | **Kernel implemented; domain verification partial** | Hard-crash claim, reconcile, resume, partial/held/unknown tests pass. Excision lineage hold maps to `held`; real tier fault injection remains a full-checkout gate. |
| 6. Durable redacted audit evidence with actor/authority/policy/targets/hashes/outcomes/residuals/timestamps | **Implemented in shared journal** | 0600 regular-file journal, atomic claims/receipts, target/ref digests, hash chain + HMAC, exception-type digest only, redaction test. Production key lifecycle and concurrent daemon behavior remain unverified. |
| 7. Mutation-sensitive negatives for preview writes, auth omission/replay/scope, drift, direct bypass | **Implemented for kernel/reset; excision source updated** | Focused suite passes 16 tests. Existing excision suite now uses the authorized route and contains a direct-bypass test, but collection is blocked by missing snapshot dependencies. |

## Merge recommendation

Review and land the kernel and reset/excision integration on a feature branch, then keep `polylogue-kwsb.2` open. Do not declare the trust floor complete until the unresolved census rows are either routed through domain-owned plans or receive reviewed typed exemptions that prove they cannot remove durable/user evidence.
