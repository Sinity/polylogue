# MutationTransaction architecture

## Security objective

A destructive operation must not become safer or less safe depending on whether it entered through CLI, MCP, HTTP, or Python. The shared boundary must make the authorization evidence inseparable from the exact domain plan, must close the preview-to-apply race, and must preserve uncertainty instead of reporting false success.

The implementation deliberately shares protocol and evidence only. Reset and excision remain separate domains because they have different target selection, tier semantics, hold behavior, reversibility, and postflight evidence.

## Protocol

### PREPARE

A domain planner resolves a bounded, immutable `MutationPlan` without writing. The common envelope binds:

- operation and domain;
- exact actuation target references;
- affected authority tiers, replicas, and tier-specific references;
- a component-wise snapshot vector;
- reversibility and privacy impact;
- required capability and exact target scope;
- policy version;
- creation and expiry timestamps;
- canonical domain-owned plan data; and
- a SHA-256 plan hash over all of the above.

The kernel canonicalizes an I-JSON-shaped subset: strings, integers, booleans, nulls, arrays, and string-keyed objects. Floating-point values are rejected to avoid cross-runtime representation ambiguity. This is intentionally narrower than a complete RFC 8785 implementation.

`MutationTransactionKernel.prepare()` can compare a domain side-effect probe before and after planning. Domains still carry the primary burden of making planners read-only; a generic probe cannot prove absence of every possible external side effect.

### AUTHORIZE

`AuthorizationContext` supplies the authenticated actor, requested capability, and exact scope. The policy requires:

- the context capability to equal the plan's required capability;
- the context scope to equal the plan's required scope, not merely overlap it;
- an actor grant covering that capability; and
- grant patterns covering every exact scope reference.

The resulting signed authorization binds authorization ID, plan hash, operation, domain, actor, capability, exact scope and its digest, policy version, issuance time, expiry, and a nonce. The HMAC covers the complete canonical authorization binding.

Authorization is not authentication. The first-party local helper is valid only after the outer adapter has established actor, capability, and confirmation. It must not be exposed as a self-service capability mint to untrusted Python, MCP, or HTTP callers. Those unresolved adapters are called out in the census.

### APPLY

The kernel verifies the signature and every plan/context binding, then performs an atomic `BEGIN IMMEDIATE` claim keyed by authorization ID before it can issue an actuator guard. The unique claim makes the authorization single-use across cooperating processes sharing the journal.

After the claim, APPLY invokes the domain planner again with the original creation and expiry bounds. Any planner error or plan-hash difference produces a terminal `replan_required` receipt without issuing a guard. This closes the target/snapshot TOCTOU window for the initial apply.

Only after a fresh-plan match does the kernel issue an opaque `MutationActuatorGuard` bound to plan hash, transaction ID, actor, capability, and exact targets. Guard construction is private; domain actuators reject a missing, consumed, mismatched, or out-of-scope guard. The guard is consumed after the attempt, including exception paths.

The domain actuator remains responsible for idempotent writes and emits one `TargetOutcome` per target. Allowed target outcomes are:

- `applied`;
- `already_satisfied`;
- `blocked`;
- `failed`; and
- `unknown`.

Missing outcomes are normalized to `unknown`; outcomes outside the authorized target set are rejected. Free-form error text is not accepted as a detail code.

### RECONCILE and RESUME

A hard process interruption may leave a durable claim without a terminal receipt. `reconcile()` observes domain state and writes a receipt without repeating destructive writes. It accepts an expired authorization only because the authorization was already signed and claimed before the crash.

`resume()` is an explicit recovery path for a domain-declared idempotent actuator. It reuses the original transaction ID. The current patch does not wire automatic resume from any public route; production callers should observe first and resume only under a domain-specific recovery decision. Fresh-plan revalidation on resume remains a recommended hardening before that API is exposed beyond tests.

## Receipt state lattice

The kernel never infers success from HTTP status, CLI exit, or the absence of an exception. It maps target outcomes as follows:

| Target outcomes | Receipt state |
|---|---|
| only `applied` / `already_satisfied` | `complete` |
| success plus `failed` or `blocked` | `partial` |
| only `blocked` | `held` |
| only `failed` | `failed` |
| any `unknown` | `unknown` |
| fresh-plan mismatch or planner failure | `replan_required` |

Adapters must treat every state except `complete` as non-success and preserve the transaction ID for reconciliation.

## Durable evidence and privacy

The journal stores three related records:

1. an authorization audit event;
2. an atomic authorization claim; and
3. a terminal redacted receipt plus reconciled audit event.

Audit events include actor, capability/authority, policy version, plan hash, authorization and transaction references, target digests, outcome, bounded evidence, timestamps, previous event hash, event hash, and an HMAC signature. Terminal receipt persistence replaces exact target, domain receipt, and residual references with SHA-256 digests. Exception evidence stores only a digest of the exception type; raw exception messages and domain reasons are excluded.

The database is required to be a non-symlink regular file without group/world permissions. The authority key is created atomically as a private regular file. The event chain detects modification or reordering of retained events, but it is not an external transparency log: deletion of a suffix cannot be detected without an independently anchored checkpoint.

## Domain ownership

### Reset

`reset.identity` owns exact session selection, durable suppression creation, rebuildable index deletion, SQLite row snapshots, and postflight checks. It is classified compensatable because durable suppressions preserve intent while the index can be rebuilt.

`reset.files` owns exact lexical paths, file metadata snapshots, symlink-safe deletion, and per-path outcomes. It deletes a symlink itself rather than following it to its destination. Reversibility and privacy are derived from the selected files; credential targets are explicit.

### Excision

`excise.session` owns exact session/cascade expansion, lineage holds, source/index/embedding/user tier references, row snapshots, irreversible/private-content classification, anti-resurrection receipts, and per-session result conversion. The previously public actuator now requires the prepared plan, matching transaction ID, and transaction-issued guard.

Confirmed primary lifecycle invalidation prepares and authorizes a fresh excision plan. Mirror-mode submission remains an append-only durable request and read-time hide decision; it is not local destructive actuation.

## Crash and concurrency model

The common journal serializes claims and terminal receipts with SQLite write transactions. A crash before claim causes no destructive apply. A crash after claim but before a receipt leaves an observable orphan. A normal Python `Exception` during actuation becomes `unknown`; a process-level interruption such as `KeyboardInterrupt` propagates and leaves the claim for later reconciliation.

The design does not claim a distributed transaction across archive tiers or replicas. Domain postflight evidence and explicit residuals are the contract for partial work. Production verification still needs multi-process contention, abrupt process termination, disk-full, fsync/durability, and replica fault injection.

## Scope boundary of this patch

The kernel and domain integrations are complete enough to review and test for CLI reset, standalone CLI excision, and confirmed primary lifecycle invalidation. The supplied footprint still exposes unrouted destructive MCP, HTTP, and Python operations. The architecture is therefore a security foundation, not yet a complete launch gate. See `02-destructive-census.md` and the acceptance matrix in `SUMMARY.md`.
