# Research notes and design translation

Accessed 2026-07-16. These sources informed design choices; the patch does not claim formal compliance with any standard.

## Canonical plan serialization

**Source:** RFC 8785, JSON Canonicalization Scheme (JCS)  
https://www.rfc-editor.org/rfc/rfc8785

**Relevant principle:** cryptographic bindings require deterministic serialization and a constrained JSON data model.

**Project decision:** plans and authorization bindings use sorted-key, separator-stable UTF-8 JSON over strings, integers, booleans, null, arrays, and string-keyed objects. Floats are rejected. This is an intentionally narrower project-specific canonical subset, not a claim of complete RFC 8785 interoperability.

## Atomic authorization claims

**Source:** SQLite transaction documentation  
https://www.sqlite.org/lang_transaction.html

**Relevant principle:** `BEGIN IMMEDIATE` starts a write transaction at the beginning rather than deferring the write-lock attempt.

**Project decision:** claiming an authorization and appending its `apply_claimed` event happen in one immediate transaction. Unique authorization and transaction identifiers reject replay. Terminal receipt insertion and its audit event are likewise atomic.

## Audit minimization and secret exclusion

**Source:** OWASP Logging Cheat Sheet  
https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html

**Source:** OWASP Application Logging Vocabulary Cheat Sheet  
https://cheatsheetseries.owasp.org/cheatsheets/Logging_Vocabulary_Cheat_Sheet.html

**Relevant principle:** logs should support security review without collecting secrets, private data, keys, or unbounded sensitive payloads.

**Project decision:** target references, domain receipt references, residual references, and exception types are digested; raw reasons and exception messages are excluded. Evidence fields accept bounded machine codes and canonical structured values.

## Audit evidence as a control, not proof of distributed atomicity

**Source:** NIST SP 800-53 Rev. 5, Security and Privacy Controls for Information Systems and Organizations  
https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

**Relevant principle:** audit records support accountability and review as part of a broader risk-management process.

**Project decision:** the journal records actor, authority, policy, target digests, plan hash, claims, outcomes, residual digests, timestamps, and a signed hash chain. The documentation explicitly avoids claiming that this local journal is an external transparency log or a substitute for deployment controls, key management, access control, backup, monitoring, and independent anchoring.

## Source-supported versus project inference

Source-supported facts are limited to the standards' general serialization, transaction, logging, and audit guidance. The following are project-specific inferences and design choices:

- exact-scope equality instead of subset authorization;
- consuming authorization before TOCTOU revalidation;
- target outcome/state vocabulary;
- guard issuance only after a durable claim;
- digest-only shared receipts for privacy; and
- preserving domain-specific actuators instead of building a universal executor.
