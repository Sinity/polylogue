# Destructive-operation census

## Method and scope

This census combines:

- direct source search for delete/remove/clear/reset/excise operations;
- HTTP DELETE and destructive POST route tables;
- MCP tool registration;
- Python facade mutation methods;
- the authored `OperationSpec` mutation catalog; and
- call-site review of reset, excision, and lifecycle actuators.

The immutable input was a selected 60-member snapshot, not the whole repository. Rows whose implementation modules were absent are marked `source absent`; they are not assumed safe. Dynamically loaded plugins and external services are outside this census.

Classification vocabulary:

- **Routed** — the destructive write is reachable only after a domain plan, signed authorization, atomic claim, fresh-plan comparison, and actuator guard.
- **Non-destructive / typed exemption candidate** — reviewed behavior does not delete or invalidate durable/user evidence. It still needs project review before being treated as a permanent exemption.
- **Open bypass** — destructive behavior remains callable without MutationTransaction.
- **Unresolved** — the selected snapshot names the operation but omits the implementation needed to classify it fully.

## CLI

| Surface operation | Evidence in supplied footprint | Classification after patch | Required follow-up |
|---|---|---|---|
| `polylogue ops reset --session/--source` identity reset | `polylogue/cli/commands/reset.py` | **Routed** through `reset.identity` | Full-checkout CLI route tests and topology regeneration. |
| `polylogue ops reset` database/cache/token path deletion | `polylogue/cli/commands/reset.py` | **Routed** through `reset.files` | Full-checkout CLI matrix, including every option combination. |
| standalone/off-mode `polylogue ops excise` | `polylogue/cli/commands/excise.py` | **Routed** through `excise.session` | Full database integration and anti-resurrection suite. |
| mirror/primary excision request submission | `polylogue/cli/commands/excise.py`, `security/lifecycle.py` | **Non-destructive / exemption candidate** for submission itself | Preserve distinction: request/outbox insertion and mirror read-time hiding are not local deletion; confirmed primary invalidation is separately routed. |
| confirmed primary lifecycle invalidation | `polylogue/security/lifecycle.py` | **Routed** through `excise.session` | Full lifecycle integration/fault tests. |
| query-first `delete` verb | Named in `operations/specs.py` as `polylogue.cli.query_verbs.delete_verb` and `_emit_delete` | **Unresolved; source absent** | Locate implementation in full checkout, add domain plan/guard or prove typed exemption. Existing spec says `previewable=False`, which conflicts with the trust-floor requirement. |

## MCP

| MCP operation | Implementation | Classification | Evidence destroyed | Required follow-up |
|---|---|---|---|---|
| `remove_tag` | `mcp/server_mutation_tools.py` → `poly.remove_tag` | **Open bypass** | Durable `user.db` assertion/tag evidence | Add assertion-deletion plan with exact assertion refs and user-tier snapshot. |
| `remove_mark` | `mcp/server_mutation_tools.py` → `poly.remove_mark` | **Open bypass** | Durable mark assertion | Same domain-owned assertion plan; role/capability denial fixture. |
| `delete_session` | `mcp/server_mutation_tools.py` → `poly.delete_session_safe` | **Open bypass** | Archive session rows and cascades | Decide reset vs permanent-delete semantics; do not alias silently to excision. Route through its own plan or retire in favor of an explicit domain operation. |
| personal-state deletion tools, including `delete_metadata` | `register_personal_state_tools` imported; implementation absent. `operations/specs.py` names `delete_metadata`. | **Unresolved / presumed destructive** | Durable assertion metadata and potentially other user state | Inspect full module and enumerate every delete/retract/supersede tool. |
| rejection/supersession of assertion-like records | Names not fully present in selected footprint | **Unresolved** | May change state rather than delete bytes | Review semantics. Append-only supersession can qualify for a typed exemption only if prior evidence is retained and immutable. |

The existing MCP `confirm=true` guard for `delete_session` is not authorization: it is not bound to actor, capability, exact scope, plan hash, snapshot, or expiry, and it is replayable.

## HTTP

| HTTP route | Implementation | Classification | Required follow-up |
|---|---|---|---|
| `POST /api/reset`, `scope=session` | `daemon/http.py::_handle_reset` → `poly.delete_session_safe` | **Open bypass** | Replace direct delete with a reset- or delete-owned PREPARE/AUTHORIZE/APPLY route; bind authenticated machine actor and role. |
| `POST /api/reset`, `scope=all` | Supplied implementation returns `{"ok": true}` without deleting | **No-op exemption candidate, but misleading** | Either remove/rename it or implement an authorized exact plan. A no-op must not masquerade as completed destructive reset. |
| `DELETE /api/web-auth/session` | `daemon/http.py::_handle_web_auth_revoke` | **Open bypass** under a broad destructive reading | Add credential-revocation plan or record a reviewed exemption if revocation is intentionally immediate, self-scoped, and independently receipted. Privacy impact is `credential`. |
| `DELETE /api/user/marks` | `daemon/user_state_http.py` → `poly.remove_mark` | **Open bypass** | Route durable assertion deletion. |
| `DELETE /api/user/annotations/:id` | `daemon/user_state_http.py` → `poly.delete_annotation` | **Open bypass** | Route durable user evidence deletion. |
| `DELETE /api/user/saved-views/:id` | `daemon/user_state_http.py` → `poly.delete_view` | **Open bypass** | Route exact assertion/resource deletion. |
| `DELETE /api/user/recall-packs/:id` | `daemon/user_state_http.py` → `poly.delete_recall_pack` | **Open bypass** | Route exact durable context artifact deletion. |
| `DELETE /api/user/workspaces/:id` | `daemon/user_state_http.py` → `poly.delete_workspace` | **Open bypass** | Route exact durable workspace evidence deletion. |

Host, origin, cookie, machine-token, and write-gate checks are valuable outer controls, but they do not replace plan-bound authorization or a durable per-target receipt.

## Python facade

The following public async facade methods in `polylogue/api/archive.py` perform destructive deletion/removal without MutationTransaction:

| Method | Current sink / semantics | Classification |
|---|---|---|
| `delete_session`, `delete_session_safe` | `ArchiveStore.delete_sessions` | **Open bypass**; shared by MCP and HTTP reset. |
| `remove_tag` | removes user tags/assertions | **Open bypass**. |
| `delete_metadata` | deletes a metadata key/assertion | **Open bypass**. |
| `remove_mark` | deletes a mark assertion | **Open bypass**. |
| `delete_annotation` | deletes annotation evidence | **Open bypass**. |
| `delete_view` | deletes a saved view | **Open bypass**. |
| `delete_recall_pack` | deletes a recall pack | **Open bypass**. |
| `delete_workspace` | deletes a durable reader workspace | **Open bypass**. |
| `delete_correction` | deletes one correction | **Open bypass**. |
| `clear_corrections` | deletes every correction for a session | **Open bypass**. |

The public domain actuator `security.excision.apply_session_excision` is now fail-closed without a matching plan, transaction ID, and actuator guard. Reset actuators have the same guard requirement. This closes direct actuator bypass for the integrated domains but does not automatically protect the independent facade methods above.

## Substrate and maintenance candidates outside the four requested surfaces

The supplied operation catalog contains destructive or potentially destructive maintenance that should be reviewed before claiming complete coverage:

- derived-tier rebuild/reset and garbage collection;
- source/blob cleanup and convergence-debt cleanup;
- migration/backup pruning;
- demo archive seeding when it overwrites an existing target;
- credential/token rotation or revocation;
- retention and compaction jobs; and
- external-primary purge/replica invalidation.

Most implementations were absent from the selected snapshot. Derived/rebuildable data is still evidence for authorization purposes; “rebuildable” is not by itself a typed exemption.

## Typed exemption rubric

A destructive-looking operation may bypass MutationTransaction only after a review record proves all of the following:

1. It cannot delete, invalidate, hide, revoke, overwrite, or make unreachable durable or user evidence.
2. It cannot trigger such a write indirectly, asynchronously, or through a delegated backend.
3. Its no-op/read-only/append-only nature is enforced by type and implementation, not convention.
4. It has a bounded target and outcome contract sufficient to detect future semantic drift.
5. Tests fail if it begins performing destructive effects.

Examples that may qualify after review are a pure preview, an append-only excision request, or a true no-op compatibility route. “Already authenticated,” “requires confirm=true,” “idempotent,” “derived tier,” and “only local” are not sufficient exemptions.

## Closure sequence

1. Route `delete_session_safe` or replace it with an explicitly named domain operation; this removes the highest-leverage MCP/HTTP/Python bypass.
2. Create an assertion/user-state deletion domain plan for tags, metadata, marks, annotations, views, recall packs, workspaces, and corrections without conflating their semantics with reset or excision.
3. Add authenticated MCP/HTTP/Python adapters that submit externally established actor/capability context rather than using the local self-grant helper.
4. Locate and route the query `delete` verb.
5. Run an all-repository static and operation-catalog census, then require a route or reviewed typed exemption for every result.
