# Rejected alternatives

## One universal mutation executor

Rejected because reset, excision, user-state deletion, credential revocation, garbage collection, and external replica invalidation do not share target selection, legal-hold behavior, reversibility, idempotency, or postflight evidence. A universal executor would either erase those distinctions or become a second domain layer. The patch shares only plan binding, authorization lifecycle, guarded entry, outcome normalization, and durable evidence.

## Treat every delete as reset or excision

Rejected because reset is normally compensatable/rebuild-oriented, while excision is irreversible privacy deletion with anti-resurrection semantics. Tags, annotations, corrections, saved views, credentials, and workspaces need their own domain semantics. Reusing an envelope does not justify merging actuators.

## Keep command-local `--yes` or `confirm=true`

Rejected because a boolean confirmation is replayable and is not bound to actor, capability, exact target scope, snapshot, plan hash, policy version, or expiry. It also gives non-interactive surfaces no equivalent proof.

## Let adapters call actuators after checking their own roles

Rejected because every adapter can drift and one forgotten check reopens the boundary. Actuators must fail closed unless the kernel has atomically claimed a matching authorization and issued a plan-bound guard.

## Opaque bearer approval unrelated to the plan

Rejected because a broad “may delete” token permits target substitution and TOCTOU. Authorization must bind the canonical plan hash and exact scope.

## Caller-controlled authority grants

Rejected as a public API. The included trusted-local helper exists only to adapt already-authenticated/confirmed first-party paths. It is not suitable for MCP, HTTP, or arbitrary Python callers until those surfaces supply independently established policy grants.

## Persist the full plan and raw domain receipts in the shared journal

Rejected because excision targets, source paths, reasons, residuals, and exception messages may recreate the information being removed. The shared journal stores digests and bounded codes. Domains may retain separate evidence according to their own authority-tier and privacy rules.

## Use one cross-tier database transaction

Rejected because the archive is split across files and may involve external replicas. Pretending to have distributed atomicity would produce false guarantees. The protocol uses an atomic authorization claim, domain-idempotent writes, per-target outcomes, and reconciliation.

## Roll back automatically after partial failure

Rejected because irreversible deletion cannot be undone and compensating actions differ by domain. The receipt records partial, held, failed, and unknown states plus residual references. A domain may expose an undo plan separately when it genuinely exists.

## Convert exceptions to generic failure/success

Rejected because an exception after a write may leave the target applied. The kernel records `unknown` unless postflight proves a more specific state. It never treats “no exception” alone as complete; exact target outcomes are required.

## Automatically retry an orphaned claim

Rejected because retries can duplicate non-idempotent effects or act on a drifted target. Recovery observes first. Explicit resume is allowed only with a domain-declared idempotent actuator, and the current patch does not expose automatic public resume.

## Preserve backward compatibility with an optional guard

Rejected. An optional guard preserves the bypass. Integrated reset and excision actuators require the guard and matching transaction ID; old direct callers fail closed and must be migrated.

## Declare all user-state removals harmless because `user.db` is local

Rejected. `user.db` is durable, irreplaceable user evidence. Locality changes threat actors and deployment assumptions, not the need for exact authorization, replay defense, and receipts.
