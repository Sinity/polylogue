# Base and dirty-state assumptions

- Supplied base revision: `518ac33e318995539743e220c01b9883b7a688a0`
- Supplied branch: `feature/browser/sol-pro-dispatch`
- Reconstructed patch base commit: `ec03f97d` (tree copied from the immutable selected-source snapshot; its commit message records the real base revision)
- Pre-existing full-worktree status supplied by the operator:

```text
## feature/browser/sol-pro-dispatch...origin/feature/browser/sol-pro-dispatch
M  .beads/issues.jsonl
```

The staged `.beads/issues.jsonl` change is operator-owned. None of the three patches touches `.beads/`, and no Beads state update is included.

The snapshot did not contain the full repository, generated topology files, packaging metadata, storage implementations, or most shared test fixtures. The patches are therefore source-scoped and must be applied and verified in the complete checkout before merge.

The format-patch commit IDs are reconstruction-local. Review applicability by file content and the recorded real base revision, not by expecting those local parent IDs to exist in the operator repository.
